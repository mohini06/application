<?php 
echo "hi";
phpinfo();
?>
