<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use App\NewUser;

class CreateUserregistrationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('userregistration', function (Blueprint $table) {
            $table->increments('UserRegId');
            $table->string('Name');
            $table->string('Email');
            $table->string('Password');
            $table->string('Phone');
            $table->string('Mobile');
            $table->string('UserId');
            $table->string('UserStatus');
            $table->string('RegistrationCompleted');
            $table->string('ClaimFlag')->default(1);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('userregistration');
    }
}
