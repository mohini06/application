<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use App\Classifieds;

class CreateClassifiedregistrationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('classifiedregistration', function (Blueprint $table) {
            $table->increments('ClassifiedRegId');
            $table->string('ClassifiedTitle');
            $table->string('CategoryCode');
            $table->string('SubCategoryCode');
            $table->string('email');
            $table->string('name');
            $table->string('city');
            $table->string('mobile');
            $table->string('phone');
            $table->string('ClassifiedContent');
            $table->Integer('UserRegId')->unsigned();
            $table->string('Weburl');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('classifiedregistration');
    }
}
