<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{
    /**
     * The URIs that should be excluded from CSRF verification.
     *
     * @var array
     */
    protected $except = [
       "/*saveproposal*/", "/*validateregistereduser*/","/*uservalidation*/", "/*api/register*/","/*api/login*/","/*api/citySuggestions*/","/*api/companySuggestions*/","/*api/FindCompany*/",
    ];
}
