<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\User;
use App\Category;
use App\SubCategory;
use App\City;
use DB;
use App\Mail\Email;
use Mail;
use App\Area;
use App\CompanyImage;
use App\ProductImage;
use App\Company;
use App\Classified;
use App\CompanyProposal;
use App\Review;
use Auth;

class CompanyController extends Controller
{
   public function index()
   {
//       $category=DB::table('category')
//          ->get();
       $anouncement= DB::select('call Usp_GetAnnouncementList()');
       $subcategory=DB::table('subcategory')
           ->get();
//       $city=DB::table('city')
//           ->get();
//       $area=DB::table('area')
//           ->get();
       $headermenu= DB::table('headermenu')
           ->where('DisplaySection',3)
           ->get();

       $city=DB::select('call usp_GetCityList()');
     
       $category=DB::table('category')
           ->get();
       $banner=DB::table('bannerimage')
           ->where('IsActive', 1)
           ->get();
       $footersubmenu=DB::table('footersubmenu')
           ->where('MenuId',5)
           ->get();
       return view('Companyregistration')->with(array('anouncement'=>$anouncement,'subcategory'=>$subcategory,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
//       return view('Companyregistration')->with(array('category'=>$category,'subcategory'=>$subcategory,'city'=>$city,'area'=>$area));
   }
    
  public function checkUserId(){
    $anouncement= DB::select('call Usp_GetAnnouncementList()');
    $subcategory=DB::table('subcategory')
           ->get();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
  }
    public function  store(Request $request){

      $anouncement= DB::select('call Usp_GetAnnouncementList()');
       $subcategory=DB::table('subcategory')
      ->get();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
       $email = DB::table('userregistration')->where('Email',$request->input('Email') )->first();

          if($email==null)
          {
            $user=new User;
            $user->Name=$request->input('ContactName');
            $user->Email=$request->input('Email');
      $user->Phone=preg_replace('/[^\dxX]/', '', $request->input('phone'));
            $user->Mobile=preg_replace('/[^\dxX]/', '', $request->input('mobile'));
            
            $user->UserId=$request->input('UserName');
            $user->Password=bcrypt($request->input('password'));
            $user->remember_token=$request->input('_token');
            $user->save();
             $user_reg_id=$user->UserRegId;


            $company= new Company;
            $company->CompanyName=$request->input('CompanyName');
            $company->Address1=$request->input('Address1');
            $company->UserRegId=$user_reg_id;
            $company->Address2=$request->input('Address2');
            $company->PostalCode=$request->input('PostalCode');
            $company->FaxNo=$request->input('FaxNo');
//        $company->mobile=$request->input('mobile');
//        $company->UserName=$request->input('UserName');
            $company->CategoryCode=$request->input('category');
            $company->SubCategoryCode=$request->input('subcategory');
            $company->ActualRegType=0;
//        $company->ClassifiedContent=$request->input('ClassifiedContent');
            $company->WebsiteLink=$request->input('WebsiteLink');
            $company->City=$request->input('City');
            $company->DescribeBusiness=$request->input('DescribeBusiness');
            $company->dateofincorporation=$request->input('dateofincorporation');
            $company->save();
      $emailadd=$request->input('Email');
            $data = array('user_reg_id'=>$user->UserRegId,'name'=>$request->input('ContactName'),'email'=>$request->input('Email'),'email_md5'=>md5($emailadd),'phone'=>$request->input('phone'),'discription'=>$request->input('DescribeBusiness'),'UserId'=>$request->input('UserName'),'Password_original'=>$request->input('password'),'comname'=>$request->input('CompanyName'),'overview'=>$request->input('DescribeBusiness'));
      //print_r($data['email']);echo $data['name'];exit;
                  Mail::send('mail2',$data,function($message) use ($data) {
                  $message->to( $data['email'], $data['name'])
                      ->subject('Детали вашего компании');
                  // $message->from('infoypkteam@gmail.com','ypk');
                 });
                 Mail::send('newuser',$data,function($message) use($data) {
                 $message->to('support@ypk.kz' , $data['name'])
                     ->subject('Данные компании, отправленные новым пользователем');
                 // $message->from('infoypkteam@gmail.com','ypk');
                  });
            $userd= DB::table('userregistration') ->where('Email',$user->Email)
                ->leftjoin('companyregistration','companyregistration.UserRegId','=','userregistration.UserRegId')
                ->leftjoin('city','city.CityId','=','companyregistration.City')
                ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
                ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
                ->first();
           $classifiedprofile=DB::table('classifiedregistration')->where('IsApprove',1)
             ->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->orderBy('ClassifiedRegId','desc')
            ->get();
            return view('companyregistered')->with(array('anouncement'=>$anouncement, 'subcategory'=>$subcategory,'classifiedprofile'=>$classifiedprofile,'userd'=>$userd,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
      
          }
     else {
          $headermenu= DB::table('headermenu')
           ->where('DisplaySection',3)
           ->get();

       $city=DB::table('city')
           ->get();
       $category=DB::table('category')
           ->get();
       $subcategory=DB::table('subcategory')
           ->get();
       $banner=DB::table('bannerimage')
           ->where('IsActive', 1)
           ->get();
       $footersubmenu=DB::table('footersubmenu')
           ->where('MenuId',5)
           ->get();
       return view('Companyregistration')->with(array('anouncement'=>$anouncement,'subcategory'=>$subcategory,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
             }

    }

    public function reviewadd(Request $request,$companyid)
    {
    $anouncement= DB::select('call Usp_GetAnnouncementList()');
     
      
    

       
        $newreview= new Review;
        $newreview->CompanyId=$companyid;
        $newreview->CommentedPerson=$request->input('CommentedPerson');
        $newreview->CommentedPersonEmail=$request->input('CommentedPersonEmail');
        $newreview->CommentedPersonPhoneNo=$request->input('CommentedPersonPhoneNo');
    $proposalfile = $request->file('Proposalforu');
    if($proposalfile!="")
      
      {
        $pathinfo= pathinfo($proposalfile->getClientOriginalName());
              
      $proposal_name=$pathinfo['filename'].'_'.time().'.'.$pathinfo['extension'];
       $proposalfile->move('public/Proposals', $proposal_name);
    $newreview->Proposals=$proposal_name;
      }
    else {
      $newreview->Proposals="";
    } 
        $newreview->ReviewMessage=$request->input('ReviewMessage');

        $newreview->save();
         $com=DB::table('companyregistration')
            ->where('CompanyRegId',$companyid)
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
            ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
           
            ->first();
      $useremail=$request->input('CommentedPersonEmail');
      $ownername=$com->Name;
      $companyemail=$com->Email;
    $data = array('name'=>$request->input('CommentedPerson'),'CommentedPersonPhoneNo'=>$request->input('CommentedPersonPhoneNo'),'comments'=>$request->input('ReviewMessage'),'useremail'=>$useremail,'companyemail'=>$companyemail,'ownername'=>$ownername);
      
            Mail::send('sentReviewMail_user',$data,function($message) use($data) {
                $message->to($data['useremail'] , $data['name'])
                    ->subject('Ответ пользователя Желтые страницы Казахстана');
                // $message->from('infoypkteam@gmail.com','ypk');
            });
            Mail::send('getingReviewMail',$data,function($message) use($data) {
                $message->to($data['companyemail'] , $data['ownername'])
                    ->subject('Ответ пользователя для вашей компании, размещенный в Желтые страницы Казахстана');
                // $message->from('infoypkteam@gmail.com','ypk');
            });
    
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $subcategory=DB::table('subcategory')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
       
        $companyprofile= DB::table('companyregistration')

            ->leftjoin('companyimage', 'companyimage.CompanyId', '=', 'companyregistration.CompanyRegId')
//        ->select('companyregistration.*', 'companyimage.*')
            ->where('ActualRegType',3)
//            ->where('ActualRegType',2)
            ->get();
        $productimage= DB::table('productimage')->where('CompanyId',$companyid)
            ->orderBy('ImageId', 'desc')
            ->take(5)
            ->get();
        $proposal= DB::table('companyproposal')->where('CompanyId',$companyid)
            ->get();

        $classifiedprofile=DB::table('classifiedregistration')->where('IsApprove',1)
             ->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->orderBy('ClassifiedRegId','desc')
            ->get();

        return redirect('companydetail/'.$companyid)->with(array('anouncement'=>$anouncement,'subcategory'=>$subcategory,'proposal'=>$proposal,'productimage'=>$productimage,'classifiedprofile'=>$classifiedprofile,'companyprofile'=>$companyprofile,'subcategory'=>$subcategory,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'com'=>$com,'footersubmenu'=>$footersubmenu));


    }
      public function review(){
        $id=Auth::user()->UserRegId;
      $anouncement= DB::select('call Usp_GetAnnouncementList()');
          $userd= DB::table('companyregistration')->where('UserRegId',$id)
//             ->join('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
              ->leftjoin('city','city.CityId','=','companyregistration.City')
              ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
              ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
              ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')
              ->leftjoin('area','area.AreaId','=','companyregistration.Area')
              ->first();
          $user= DB::table('userregistration')->where('UserRegId',$id)
              ->first();
          $footersubmenu=DB::table('footersubmenu')
              ->where('MenuId',5)
              ->get();
      
          $headermenu= DB::table('headermenu')
              ->where('DisplaySection',3)
              ->get();
          $area=DB::table('area')
              ->get();
          $city=DB::table('city')
              ->get();
          $category=DB::table('category')
              ->get();
          $banner=DB::table('bannerimage')
              ->where('IsActive', 1)
              ->get();
        $subcategory=DB::table('subcategory')

           ->get();

          $classified=Company::where('UserRegId', '=', $id);
      
         
      $classifieddata=DB::table('classifiedregistration')->where('UserRegId',$id)
              ->leftjoin('city','city.CityId','=','classifiedregistration.City')
              ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
              ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
              
              ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.UserRegId')
              ->select('classifiedregistration.*')
              ->get();
  if($userd!=null)
    {
    $review=DB::table('review')
              ->where('CompanyId', $userd->CompanyRegId)
              ->get();
      $addreview=DB::table('review')
              
              ->get();
          return view('reviewcompany')->with(array('addreview'=>$addreview,'classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'review'=>$review,'area'=>$area,'user'=>$user,'userd'=>$userd,'banner'=>$banner,'headermenu'=>$headermenu,'footersubmenu'=>$footersubmenu,'classified'=>$classified,'category'=>$category,'city'=>$city));
//
      } 
     else {
    $addreview=DB::table('review')
                      ->get();
          return view('reviewcompany')->with(array('addreview'=>$addreview,'classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'area'=>$area,'user'=>$user,'userd'=>$userd,'banner'=>$banner,'headermenu'=>$headermenu,'footersubmenu'=>$footersubmenu,'classified'=>$classified,'category'=>$category,'city'=>$city));
// 
   }    
         

      }
    public function replyReview(Request $request,$reviewId)
      {
         $id=Auth::user()->UserRegId;
      $anouncement= DB::select('call Usp_GetAnnouncementList()');
          $reviewer=DB::table('review')
               ->leftjoin('companyregistration','companyregistration.CompanyRegId','=','review.CompanyId')
            ->where('ReviewId',$reviewId)->first();
    
            $name= $reviewer->CommentedPerson;
            $emailid= $reviewer->CommentedPersonEmail;
            $description= $request->Input('comment');
             $data = array('email'=>$emailid,'description'=>$description,'name'=>$name);
        //print_r($data['email']);echo $data['name'];exit;
                  Mail::send('replyMail',$data,function($message) use ($data) {
                  $message->to( $data['email'], $data['name'],$data['description'])
                      ->subject('Ответить на ваш отзыв');
                  // $message->from('infoypkteam@gmail.com','ypk');
                 });
          $UserRegId= $reviewer->UserRegId;
          $remove=DB::table('review')->where('ReviewId',$reviewId)->delete();
           $userd= DB::table('companyregistration')->where('UserRegId',$UserRegId)
//                ->join('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
              ->leftjoin('city','city.CityId','=','companyregistration.City')
              ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
              ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
              ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')
              ->leftjoin('area','area.AreaId','=','companyregistration.area')
              ->first();
          $user= DB::table('userregistration')->where('UserRegId',$UserRegId)
              ->first();
          $footersubmenu=DB::table('footersubmenu')
              ->where('MenuId',5)
              ->get();
          $headermenu= DB::table('headermenu')
              ->where('DisplaySection',3)
              ->get();
          $area=DB::table('area')
              ->get();
          $city=DB::table('city')
              ->get();
          $category=DB::table('category')
              ->get();
          $banner=DB::table('bannerimage')
              ->where('IsActive', 1)
              ->get();
        $subcategory=DB::table('subcategory')
           ->get();

          $classified=Company::where('UserRegId', '=', $UserRegId);
          $review=DB::table('review')
              ->where('CompanyId', $userd->CompanyRegId)
              ->get();
           $classifieddata=DB::table('classifiedregistration')->where('UserRegId',$id)
              ->leftjoin('city','city.CityId','=','classifiedregistration.City')
              ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
              ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
             
              ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.UserRegId')
              ->get();
       $addreview=DB::table('review')->get();
          return view('reviewcompany')->with(array('addreview'=>$addreview,'classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'review'=>$review,'area'=>$area,'user'=>$user,'userd'=>$userd,'banner'=>$banner,'headermenu'=>$headermenu,'footersubmenu'=>$footersubmenu,'classified'=>$classified,'category'=>$category,'city'=>$city));           
           
         }
         public function removeReview($reviewId)

         {
       $id=Auth::user()->UserRegId;
            $anouncement= DB::select('call Usp_GetAnnouncementList()');
     $reviewer=DB::table('review')
               ->leftjoin('companyregistration','companyregistration.CompanyRegId','=','review.CompanyId')
            ->where('ReviewId',$reviewId)->first();
      $UserRegId= $id;
           $remove=DB::table('review')->where('ReviewId',$reviewId)->delete();
       
           $userd= DB::table('companyregistration')->where('UserRegId',$UserRegId)
//                ->join('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
              ->leftjoin('city','city.CityId','=','companyregistration.City')
              ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
              ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
              ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')
              ->leftjoin('area','area.AreaId','=','companyregistration.area')
        ->leftjoin('review','review.CompanyId','=','companyregistration.CompanyRegId')
              ->first();
          $user= DB::table('userregistration')->where('UserRegId',$UserRegId)
              ->first();
          $footersubmenu=DB::table('footersubmenu')
              ->where('MenuId',5)
              ->get();
          $headermenu= DB::table('headermenu')
              ->where('DisplaySection',3)
              ->get();
          $area=DB::table('area')
              ->get();
          $city=DB::table('city')
              ->get();
          $category=DB::table('category')
              ->get();
          $banner=DB::table('bannerimage')
              ->where('IsActive', 1)
              ->get();
        $subcategory=DB::table('subcategory')
           ->get();
//        $subcategory=DB::table('subcategory')
//
//            ->get();
 $classifieddata=DB::table('classifiedregistration')->where('UserRegId',$UserRegId)
              ->leftjoin('city','city.CityId','=','classifiedregistration.City')
              ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
              ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
              
              ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.UserRegId')
              ->get();
          $classified=Company::where('UserRegId', '=', $UserRegId);
          $review=DB::table('review')
              ->where('CompanyId', $userd->CompanyRegId)
              ->get();
            $addreview=DB::table('review')
                      ->get();
          return view('reviewcompany')->with(array('addreview'=>$addreview,'classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'review'=>$review,'area'=>$area,'user'=>$user,'userd'=>$userd,'banner'=>$banner,'headermenu'=>$headermenu,'footersubmenu'=>$footersubmenu,'classified'=>$classified,'category'=>$category,'city'=>$city));           
           
         }

        public function edit()
    {
       $id=Auth::user()->UserRegId;
    $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $userd= DB::table('companyregistration')->where('UserRegId',$id)
//                ->join('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
            ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('area','area.AreaId','=','companyregistration.area')
            ->first();
        $user= DB::table('userregistration')->where('UserRegId',$id)
            ->first();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();
       $area=DB::table('area')
           ->get();
        $city=DB::select('call usp_GetCityList()');
        $category=DB::table('category')
            ->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)->get();
        $subcategory=DB::table('subcategory')
           ->get();
     $classifieddata=DB::table('classifiedregistration')->where('UserRegId',$id)
              ->leftjoin('city','city.CityId','=','classifiedregistration.City')
              ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
              ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
              
              ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.UserRegId')
              ->get();
        $classified=Company::where('UserRegId', '=', $id);
        // $classified =Classified::find($id);
        return view('editcompany')->with(array('classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'area'=>$area,'user'=>$user,'userd'=>$userd,'banner'=>$banner,'headermenu'=>$headermenu,'footersubmenu'=>$footersubmenu,'classified'=>$classified,'category'=>$category,'city'=>$city));
//        return view('editad')->with('classified',$classified);
//        return view('edit')->with(array('classified'=>$classified,'category'=>$category,'subcategory'=>$subcategory,'city'=>$city));

    }
    public function update(Request $request)
    {
    /* $user=new User;
            $user->Name=$request->input('ContactName');
            $user->Email=$request->input('Email');
            $user->Phone=$request->input('phone');
            $user->Mobile=$request->input('mobile');
            $user->UserId=$request->input('UserName');
            $user->Password=$request->input('password');
            $user->save();
             $user_reg_id=$user->id;


            $company= new Company;
            $company->CompanyName=$request->input('CompanyName');
            $company->Address1=$request->input('Address1');
            $company->UserRegId=$user_reg_id;
            $company->Address2=$request->input('Address2');
            $company->PostalCode=$request->input('PostalCode');
            $company->FaxNo=$request->input('FaxNo');
//        $company->mobile=$request->input('mobile');
//        $company->UserName=$request->input('UserName');
            $company->CategoryCode=$request->input('category');
            $company->SubCategoryCode=$request->input('subcategory');

//        $company->ClassifiedContent=$request->input('ClassifiedContent');
            $company->WebsiteLink=$request->input('WebsiteLink');
            $company->City=$request->input('City');
            $company->DescribeBusiness=$request->input('DescribeBusiness');
            $company->dateofincorporation=$request->input('dateofincorporation');
            $company->save();*/
             $id=Auth::user()->UserRegId;
      $anouncement= DB::select('call Usp_GetAnnouncementList()');
       DB::table('userregistration')
            ->where('UserRegId', $id)
            ->update(array('Name'=>$request->input('ContactName'),'Email'=>$request->input('Email'),'Phone'=>$request->input('phone'),'Mobile'=>$request->input('mobile'),
        'UserId'=>$request->input('UserName'),'Password'=>$request->input('password') ));
     DB::table('companyregistration')
      ->where('UserRegId', $id)
            ->update(array('CompanyName'=>$request->input('CompanyName'),'Address1'=>$request->input('Address1'),'Address2'=>$request->input('Address2'),'PostalCode'=>$request->input('PostalCode'),
        'FaxNo'=>$request->input('FaxNo'),'CategoryCode'=>$request->input('category'),'SubCategoryCode'=>$request->input('subcategory'),'WebsiteLink'=>$request->input('WebsiteLink'),
              'City'=>$request->input('City'),'DescribeBusiness'=>$request->input('DescribeBusiness'),'dateofincorporation'=>$request->input('dateofincorporation')));
    $userd= DB::table('companyregistration')->where('UserRegId',$id)
//                ->join('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
            ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('area','area.AreaId','=','companyregistration.area')
            ->first();
        $user= DB::table('userregistration')->where('UserRegId',$id)
            ->first();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();
       $area=DB::table('area')
           ->get();
        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)->get();
        $subcategory=DB::table('subcategory')
           ->get();
        $classified=Company::where('UserRegId', '=', $id);
    $classifieddata=DB::table('classifiedregistration')->where('UserRegId',$id)
              ->leftjoin('city','city.CityId','=','classifiedregistration.City')
              ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
              ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
              
              ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.UserRegId')
              ->get();
        // $classified =Classified::find($id);
        return redirect('/profile')->with(array('classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'area'=>$area,'user'=>$user,'userd'=>$userd,'banner'=>$banner,'headermenu'=>$headermenu,'footersubmenu'=>$footersubmenu,'classified'=>$classified,'category'=>$category,'city'=>$city));
//        return view('editad')->with('classified',$classified);
//        return view('edit')->with(array('classified'=>$classified,'category'=>$category,'subcategory'=>$subcategory,'city'=>$city));  
         }
    public function sharedetail(Request $request)
  {
    $id=$request->input('CompanyRegId');
  
    
    $user_email=$request->input('user_mail');
  
    $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $subcategory=DB::table('subcategory')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $com=DB::table('companyregistration')
               ->where('CompanyRegId',$id)
              ->leftjoin('city','city.CityId','=','companyregistration.City')
              ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
              ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
              ->leftjoin('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
             // ->leftjoin('addressgeocode','addressgeocode.CompanyOrClassifiedId','=','companyregistration.CompanyRegId')
                            ->first();
      if(Auth::user() !=null)
      {

        $userregid=Auth::user()->UserRegId;
        $companylist=DB::table('companyregistration')->where('UserRegId',$userregid)->first();
         
        
      }
       else 
      {
        $companylist="";
      }
    $overview=$com->DescribeBusiness;
    $data = array('email'=>$user_email,'comname'=>$com->CompanyName,'overview'=>$overview,'phone'=>$com->Phone);
    Mail::send('shareCompanyDeatail',$data,function($message) use ($data) {
                  $message->to( $data['email'], $data['comname'],$data['overview'])
                      ->subject('Подробная информация о компании YellowPages');
                   // $message->from('infoypkteam@gmail.com','ypk');
                 });
        $companyprofile= DB::table('companyregistration')

            ->leftjoin('companyimage', 'companyimage.CompanyId', '=', 'companyregistration.CompanyRegId')
//        ->select('companyregistration.*', 'companyimage.*')
            ->where('ActualRegType',3)
//            ->where('ActualRegType',2)
            ->get();
      
        $productimage= DB::table('productimage')->where('CompanyId',$id)
                     ->orderBy('ImageId', 'desc')
                    ->take(5)
                    ->get();
        $proposal= DB::table('companyproposal')->where('CompanyId',$id)

            ->get();

        $classifiedprofile=DB::table('classifiedregistration')->where('IsApprove',1)
             ->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->orderBy('ClassifiedRegId','desc')
            ->get();
        return view ('companydetail')->with(array('companylist'=>$companylist,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'proposal'=>$proposal,'productimage'=>$productimage,'classifiedprofile'=>$classifiedprofile,'companyprofile'=>$companyprofile,'subcategory'=>$subcategory,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'com'=>$com,'footersubmenu'=>$footersubmenu));
   
  }
    public  function companydetail($id){
    $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $subcategory=DB::table('subcategory')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $com=DB::table('companyregistration')
               ->where('CompanyRegId',$id)
              ->leftjoin('city','city.CityId','=','companyregistration.City')
              ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
              ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
              ->leftjoin('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
             // ->leftjoin('addressgeocode','addressgeocode.CompanyOrClassifiedId','=','companyregistration.CompanyRegId')
                            ->first();
    if(Auth::user() !=null)
      {

        $userregid=Auth::user()->UserRegId;
        $companylist=DB::table('companyregistration')->where('UserRegId',$userregid)->first();
         
        
      }
       else 
      {
        $companylist="";
      }   
        $companyprofile= DB::table('companyregistration')

            ->leftjoin('companyimage', 'companyimage.CompanyId', '=', 'companyregistration.CompanyRegId')
//        ->select('companyregistration.*', 'companyimage.*')
            ->where('ActualRegType',3)
//            ->where('ActualRegType',2)
            ->get();
        $productimage= DB::table('productimage')->where('CompanyId',$id)
                     ->orderBy('ImageId', 'desc')
                    ->take(5)
                    ->get();
        $proposal= DB::table('companyproposal')->where('UserId',$com->UserRegId)

            ->get();

        $classifiedprofile=DB::table('classifiedregistration')->where('IsApprove',1)
             ->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->orderBy('ClassifiedRegId','desc')
            ->get();
           
            $new_company=DB::table('companyregistration')->orderBy('CompanyRegId', 'DESC')->first();
            $new_classified=DB::table('classifiedregistration')->orderBy('ClassifiedRegId', 'DESC')->first();
           
            $vistors = DB::select('call Usp_GetVisitorCountByRegId1(?,?)',array($id,1));

            $ip = $_SERVER['REMOTE_ADDR'];
            $cur_date = date("Y-m-d h:i:s"); 
            $data=array('IPAddress'=>$ip,"Type"=>"Company","ID"=>$id,"VisitingDate"=>$cur_date);
            DB::table('analysistracking')->insert($data);

           
            return view ('companydetail')->with(array('companylist'=>$companylist,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'proposal'=>$proposal,'productimage'=>$productimage,'classifiedprofile'=>$classifiedprofile,'companyprofile'=>$companyprofile,'subcategory'=>$subcategory,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'com'=>$com,'footersubmenu'=>$footersubmenu,'new_company'=>$new_company,'new_classified'=>$new_classified,'visitors_count'=>$vistors[0]));
    }
public  function viewmap($id){
    $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $subcategory=DB::table('subcategory')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $com=DB::table('companyregistration')
               ->where('CompanyRegId',$id)
              ->leftjoin('city','city.CityId','=','companyregistration.City')
              ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
              ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
              ->leftjoin('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
              // ->leftjoin('addressgeocode','addressgeocode.CompanyOrClassifiedId','=','companyregistration.CompanyRegId')
                            ->first();
        $companyprofile= DB::table('companyregistration')

            ->leftjoin('companyimage', 'companyimage.CompanyId', '=', 'companyregistration.CompanyRegId')
//        ->select('companyregistration.*', 'companyimage.*')
            ->where('ActualRegType',3)
//            ->where('ActualRegType',2)
            ->get();
        $productimage= DB::table('productimage')->where('CompanyId',$id)
                     ->orderBy('ImageId', 'desc')
                    ->take(5)
                    ->get();
        $proposal= DB::table('companyproposal')->where('CompanyId',$id)

            ->get();

       $classifiedprofile=DB::table('classifiedregistration')->where('IsApprove',1)
             ->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->orderBy('ClassifiedRegId','desc')
            ->get();
        return view ('viewmap')->with(array('anouncement'=>$anouncement,'subcategory'=>$subcategory,'proposal'=>$proposal,'productimage'=>$productimage,'classifiedprofile'=>$classifiedprofile,'companyprofile'=>$companyprofile,'subcategory'=>$subcategory,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'com'=>$com,'footersubmenu'=>$footersubmenu));
    }
    public function upload(){
       $id1=Auth::user()->UserRegId;
    $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $userd= DB::table('companyregistration')->where('UserRegId',$id1)
//                ->join('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')

            ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')


            ->first();
        $user= DB::table('userregistration')->where('UserRegId',$id1)
            ->first();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
        ->get();

        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
      $subcategory=DB::table('subcategory')
           ->get();
        $classifieddata=DB::table('classifiedregistration')->where('UserRegId',$id1)
              ->leftjoin('city','city.CityId','=','classifiedregistration.City')
              ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
              ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
              
              ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.UserRegId')
              ->get();
       if($userd!=null)
      {
        $comdp= DB::table('companyimage')->where('CompanyId',$userd->CompanyRegId)->get();
    $adddp=DB::table('classifiedimage')->get();
    return view('uploadpic')->with(array('classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'adddp'=>$adddp,'subcategory'=>$subcategory,'comdp'=>$comdp,'user'=>$user,'userd'=>$userd,'banner'=>$banner,'headermenu'=>$headermenu,'footersubmenu'=>$footersubmenu,'category'=>$category,'city'=>$city));

      }
       else{
       
     
     $adddp=DB::table('classifiedimage')->get();
     return view('uploadpic')->with(array('classifieddata'=>$classifieddata,'adddp'=>$adddp,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'user'=>$user,'userd'=>$userd,'banner'=>$banner,'headermenu'=>$headermenu,'footersubmenu'=>$footersubmenu,'category'=>$category,'city'=>$city));
     }
    }
   public function storeimage(Request $request)
   {
     
     $anouncement= DB::select('call Usp_GetAnnouncementList()');
     $subcategory=DB::table('subcategory')
           ->get();
       $id=Auth::user()->UserRegId;
//                ProductImage::create($input);
//                $productimg->save();
       $headermenu= DB::table('headermenu')
           ->where('DisplaySection',3)
           ->get();

       $city=DB::table('city')
           ->get();
       $category=DB::table('category')
           ->get();
       $banner=DB::table('bannerimage')
           ->where('IsActive', 1)
           ->get();
       $footersubmenu=DB::table('footersubmenu')
           ->where('MenuId',5)
           ->get();
       $userd= DB::table('companyregistration')->where('UserRegId',$id)
//                ->leftjoin('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
           ->leftjoin('city','city.CityId','=','companyregistration.City')
           ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
           ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
           ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
           ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')

           ->first();


$classifieddata=DB::table('classifiedregistration')->where('UserRegId',$id)
              ->leftjoin('city','city.CityId','=','classifiedregistration.City')
              ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
              ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
              
              ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.UserRegId')
              ->get();

       //  $input = $request->all();
       $data=DB::table('companyimage')->where('CompanyId',$userd->CompanyRegId)->count('*');
 
   if($data<1)
   {

           $image = $request->file('ImageUrl');

              $pathinfo= pathinfo($image->getClientOriginalName());
        $imgname=$pathinfo['filename'].'_'.time().'.'.$pathinfo['extension'];
        //                     $img=$image->getRealPath();

               $image->move('public/ProductImages', $imgname);


        //                   Image::make($image->getRealPath())->resize(468, 249)->save('public/ProductImage/'.$imgname);
        //                   move('public/ProductImages', $img);
        //                    $input['prodimg'] = $imgname;
        //                    $image->image = 'public/ProductImage/'.$imgname;
        //                    $imgname->save();
        //                    $input['ImageUrl'] = $imgname;

               $imagename = new CompanyImage;
               $imagename->ImageUrl = $imgname;
               $imagename->CompanyId = $userd->CompanyRegId;


               $imagename->save();
        //          return $imagename;

        //          return view('showprofileimg')->with(array('userd'=>$userd,'data'=>$data,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
               $data1 = DB::table('companyimage')->where('CompanyId', $userd->CompanyRegId)->get();
          $adddp=DB::table('classifiedimage')->where('ClassifiedId',$userd->ClassifiedRegId)->first();
               return redirect('uploadprofilepic')->with(array('classifieddata'=>$classifieddata,'adddp'=>$adddp,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'userd' => $userd, 'data1' => $data1, 'category' => $category, 'city' => $city, 'headermenu' => $headermenu, 'city' => $city, 'category' => $category, 'banner' => $banner, 'footersubmenu' => $footersubmenu));




   }
        //       $data1=DB::table('companyimage')->where('CompanyId',$id)->first();
//       return view('showprofileimg')->with(array('userd'=>$userd,'data1'=>$data1,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
            else {
                $data1 = DB::table('companyimage')->where('CompanyId',$userd->CompanyRegId)->delete();

           $image = $request->file('ImageUrl');

               $imgname = $image->getClientOriginalName();

        //                     $img=$image->getRealPath();

               $image->move('public/ProductImages', $imgname);


        //                   Image::make($image->getRealPath())->resize(468, 249)->save('public/ProductImage/'.$imgname);
        //                   move('public/ProductImages', $img);
        //                    $input['prodimg'] = $imgname;
        //                    $image->image = 'public/ProductImage/'.$imgname;
        //                    $imgname->save();
        //                    $input['ImageUrl'] = $imgname;

               $imagename = new CompanyImage;
               $imagename->ImageUrl = $imgname;
               $imagename->CompanyId =$userd->CompanyRegId;


               $imagename->save();
        //          return $imagename;

        //          return view('showprofileimg')->with(array('userd'=>$userd,'data'=>$data,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
    
               $data1 = DB::table('companyimage')->where('CompanyId', $userd->CompanyRegId)->get();
                 $adddp=DB::table('classifiedimage')->where('ClassifiedId',$userd->ClassifiedRegId)->first();

                return redirect('uploadprofilepic')->with(array('classifieddata'=>$classifieddata,'adddp'=>$adddp,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'userd' => $userd, 'data1' => $data1, 'category' => $category, 'city' => $city, 'headermenu' => $headermenu, 'city' => $city, 'category' => $category, 'banner' => $banner, 'footersubmenu' => $footersubmenu));

}


   }
    public function uploadproductimg(){
       $id=Auth::user()->UserRegId;
    $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
      $subcategory=DB::table('subcategory')
           ->get();
        $userd= DB::table('companyregistration')->where('UserRegId',$id)
//                ->leftjoin('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
            ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')

            ->first();
     $classifieddata=DB::table('classifiedregistration')->where('UserRegId',$id)
              ->leftjoin('city','city.CityId','=','classifiedregistration.City')
              ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
              ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
             
              ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.UserRegId')
              ->get(); 
         if($userd!=null)
    {
       $type=$userd->ActualRegType;
       if($type>2){
         $data=DB::table('productimage')->where('CompanyId',$userd->CompanyRegId)
            ->orderBy('ImageId', 'desc')
            ->take(5)
            ->get();
       }
       elseif($type>1)
       {
         $data=DB::table('productimage')->where('CompanyId',$userd->CompanyRegId)
            ->orderBy('ImageId', 'desc')
            ->take(3)
            ->get();
       }
       else{
         $data=DB::table('productimage')->where('CompanyId',$userd->CompanyRegId)
            ->orderBy('ImageId', 'desc')
            ->take(1)
            ->get();
       }
           $add_productimage=DB::table('productimage')->take(10)->orderBy('ImageId', 'desc')->get();

        return view('uploadproductimg')->with(array('add_productimage'=>$add_productimage,'classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'userd'=>$userd,'data'=>$data,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
  
          }
  else{
    $add_productimage=DB::table('productimage')->get();
      return view('uploadproductimg')->with(array('add_productimage'=>$add_productimage,'classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'userd'=>$userd,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
  
      }
      
    
         
       
    }
    public function  saveproductimg( Request $request)
    {
       
      $id=Auth::user()->UserRegId;
$anouncement= DB::select('call Usp_GetAnnouncementList()');
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();
        $subcategory=DB::table('subcategory')
           ->get();
        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $userd= DB::table('companyregistration')->where('UserRegId',$id)
//                ->leftjoin('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
            ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')

            ->first();
          

    
  
        //  $input = $request->all();

        $image = $request->file('ImageUrl');

       $pathinfo= pathinfo($image->getClientOriginalName());
        $imgname=$pathinfo['filename'].'_'.time().'.'.$pathinfo['extension'];
    
//                     $img=$image->getRealPath();
        $image->move('public/ProductImages', $imgname);

   
//                   Image::make($image->getRealPath())->resize(468, 249)->save('public/ProductImage/'.$imgname);
//                   move('public/ProductImages', $img);
//                    $input['prodimg'] = $imgname;
//                    $image->image = 'public/ProductImage/'.$imgname;
//                    $imgname->save();
//                    $input['ImageUrl'] = $imgname;
        $imagename= new ProductImage;
        $imagename->ImageUrl=$imgname;
        $imagename->CompanyId=$userd->CompanyRegId;
        $imagename->save();
      $classifieddata=DB::table('classifiedregistration')->where('UserRegId',$id)
              ->leftjoin('city','city.CityId','=','classifiedregistration.City')
              ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
              ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
              
              ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.UserRegId')
              ->get(); 
       // return $imagename;
  if($userd!=null)
{
 $type=$userd->ActualRegType;
       if($type>2){
         $data=DB::table('productimage')->where('CompanyId',$userd->CompanyRegId)
            ->orderBy('ImageId', 'desc')
            ->take(5)
            ->get();
       }
       elseif($type>1)
       {
         $data=DB::table('productimage')->where('CompanyId',$userd->CompanyRegId)
            ->orderBy('ImageId', 'desc')
            ->take(3)
            ->get();
       }
       elseif($type>0){
         $data=DB::table('productimage')->where('CompanyId',$userd->CompanyRegId)
            ->orderBy('ImageId', 'desc')
            ->take(1)
            ->get();
       }
       else {
          $data="";
       }
     $add_productimage=DB::table('productimage')->get();
return redirect('uploadproductimg')->with(array('add_productimage'=>$add_productimage,'classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'userd'=>$userd,'data'=>$data,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
}
else
{
 $add_productimage=DB::table('productimage')->get();
return view('uploadproductimg')->with(array('add_productimage'=>$add_productimage,'classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'userd'=>$userd,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));

}
    }
    public function destroyimage($imageid)
    {
       $id2=Auth::user()->UserRegId;
    $anouncement= DB::select('call Usp_GetAnnouncementList()');
       
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
    $subcategory=DB::table('subcategory')
           ->get();
        $userd= DB::table('companyregistration')->where('UserRegId',$id2)
//                ->leftjoin('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
            ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')

            ->first();
       $classifieddata=DB::table('classifiedregistration')->where('UserRegId',$id2)
              ->leftjoin('city','city.CityId','=','classifiedregistration.City')
              ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
              ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
             
              ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.UserRegId')
              ->get(); 
      ProductImage::where('ImageId',$imageid)->delete();
          
      if($userd!=null)
{
  
 $type=$userd->ActualRegType;
       if($type>2){
         $data=DB::table('productimage')->where('CompanyId',$userd->CompanyRegId)
            ->orderBy('ImageId', 'desc')
            ->take(5)
            ->get();
       }
       elseif($type>1)
       {
         $data=DB::table('productimage')->where('CompanyId',$userd->CompanyRegId)
            ->orderBy('ImageId', 'desc')
            ->take(3)
            ->get();
       }
       else{
         $data=DB::table('productimage')->where('CompanyId',$userd->CompanyRegId)
            ->orderBy('ImageId', 'desc')
            ->take(1)
            ->get();
       }
     $add_productimage=DB::table('productimage')->get();
return redirect('/uploadproductimg')->with(array('add_productimage'=>$add_productimage,'classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'userd'=>$userd,'data'=>$data,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
}
else
{
 $add_productimage=DB::table('productimage')->get();
return redirect('/uploadproductimg')->with(array('add_productimage'=>$add_productimage,'classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'userd'=>$userd,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));

}




    }

    public function addclassified()
    {
      $id=Auth::user()->UserRegId;
    $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $headermenu= DB::table('headermenu')
        ->where('DisplaySection',3)
        ->get();

        $city=DB::select('call usp_GetCityList()');
        $category=DB::table('category')
            ->get();
        $subcategory=DB::table('subcategory')
            ->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $user= DB::table('userregistration')->where('UserRegId',$id)->first();
        return view('addclassified')->with(array('anouncement'=>$anouncement,'subcategory'=>$subcategory,'user'=>$user,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
    }
    public function storeclassified(Request $request)
    {
       $id=Auth::user()->UserRegId;
    
      
     $companypaymenttype=DB::table('companyregistration')->where ('companyregistration.UserRegId',$id)
     ->leftjoin('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
     ->first();
     $username=$companypaymenttype->UserId;
     $password_original="Используйте тот же пароль";
     $companyActualRegType=$companypaymenttype->ActualRegType;
     $email_id=$companypaymenttype->Email;
     $name=$companypaymenttype->Name;
     $existing_classified=DB::table('classifiedregistration')->where ('UserRegId',$id)->get();
         
    if((count($existing_classified)<1)&&($companyActualRegType>1))  
    {
    $classified= new Classified;
        $classified->ClassifiedTitle=$request->input('ClassifiedTitle');
        $classified->CategoryCode=$request->input('category');
        $classified->SubCategoryCode=$request->input('subcategory');
        $classified->ClassifiedContent=$request->input('ClassifiedContent');
        $classified->UserRegId=$id;
      $classified->ActualRegType=1;
    $classified->Weburl=$request->input('Weburl');
        $classified->city=$request->input('city');
        $classified->save();   
    }
    else{
      $classified= new Classified;
        $classified->ClassifiedTitle=$request->input('ClassifiedTitle');
        $classified->CategoryCode=$request->input('category');
        $classified->SubCategoryCode=$request->input('subcategory');
        $classified->ClassifiedContent=$request->input('ClassifiedContent');
        $classified->UserRegId=$id;
      $classified->ActualRegType=0;
    $classified->Weburl=$request->input('Weburl');
        $classified->city=$request->input('city');
        $classified->save();
    }
     $data = array('name'=> $name,'userid'=>$username,'password_original'=>$password_original,'email'=>$email_id,'comname'=>$request->input('ClassifiedTitle'),'overview'=>$request->input('ClassifiedContent'),'phone'=>$companypaymenttype->Phone);
            Mail::send('mail',$data,function($message) use($data) {
                $message->to($data['email'] , $data['name'])
                    ->subject('Детали вашего компании');
                // $message->from('infoypkteam@gmail.com','ypk');
            });
            Mail::send('newuser',$data,function($message) use($data) {
                $message->to('admyellowpages@gmail.com' , $data['name'])
                    ->subject('Данные компании, отправленные новым пользователем');
                // $message->from('infoypkteam@gmail.com','ypk');
            });
     $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
      $subcategory=DB::table('subcategory')
      ->get();
             $userd= DB::table('userregistration') ->where('userregistration.UserRegId',$id)
                ->join('classifiedregistration','classifiedregistration.UserRegId','=','userregistration.UserRegId')
                ->leftjoin('city','city.CityId','=','classifiedregistration.City')
                ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
                ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
                ->first();
      $classifiedprofile=DB::table('classifiedregistration')->where('IsApprove',1)
             ->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->orderBy('ClassifiedRegId','desc')
            ->get();
       
        $classifieddata=DB::table('classifiedregistration')->where('UserRegId',$id)
            ->get();
        $userdata=DB::table('userregistration')->where('UserRegId',$id)
            ->first();
       
        $subcategory=DB::table('subcategory')->get();
    
    return view('classifiedregistered')->with(array('anouncement'=>$anouncement,'classifiedprofile'=>$classifiedprofile,'subcategory'=>$subcategory,'userd'=>$userd,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));


    }
}
