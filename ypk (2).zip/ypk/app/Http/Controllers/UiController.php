<?php

namespace App\Http\Controllers;
use DB;
use App\HeaderMenu;
use Illuminate\Http\Request;
use App\Category;
use App\Mail\Email;
use Mail;
use App\Visitor;
class UiController extends Controller
{
   public function index(){
       $headermenu= DB::table('headermenu')
           ->where('DisplaySection',3)
           ->get();
       $city=DB::table('city')
           ->get();
       $category=DB::table('category')
           ->get();
       $banner=DB::table('bannerimage')
           ->where('IsActive', 1)
           ->get();
       $footersubmenu=DB::table('footersubmenu')
           ->where('MenuId',5)
           ->get();
            $anouncement= DB::select('call Usp_GetAnnouncementList()');
       //       $category1=Category::take($category)->get() ;
       return view('layouts.app')->with(array('anouncement'=>$anouncement,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
   }
    public function test(){
        $data=DB::table('category')
            ->get()->count()/3;
        $data2=$data+$data;
        $data1= Category::take($data2)->get();
//        $data3= Category::take($data)->get();
        //$data=$data/3;
      //  $record=DB::table()
   return $data1;
    }
    public function contact(){
         $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();
        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
            $subcategory=DB::table('subcategory')->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
              $classifiedprofile=DB::table('classifiedregistration')->where('IsApprove',1)
             ->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->orderBy('ClassifiedRegId','desc')
            ->get();
        return view('contact_us')->with(array('anouncement'=>$anouncement, 'classifiedprofile'=>$classifiedprofile,'subcategory'=>$subcategory,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
    }
    public function enquiry(Request $request){
    
//        $name=$request->input('uname');
//        $email=$request->input('umail');
//        $mobile=$request->input('uphone');
           $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $data = array('name'=>$request->input('uname'),'email'=>$request->input('umail'),'phone'=>$request->input('unumber'),'comments'=>$request->input('comment_text'));
        Mail::send('enquiry-mail',$data,function($message) use ($data) {
            $message->to( 'infoypkteam@gmail.com','ypk')
                ->subject('Электронная почта');
            $message->from($data['email'], $data['name']);

        });
         
             $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();
        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
            $subcategory=DB::table('subcategory')->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
              $classifiedprofile=DB::table('classifiedregistration')->where('IsApprove',1)
             ->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->orderBy('ClassifiedRegId','desc')
            ->get();
        return view('contact_us')->with(array('anouncement'=>$anouncement, 'classifiedprofile'=>$classifiedprofile,'subcategory'=>$subcategory,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
        
    }
    public function company_help(){
         $classifiedprofile=DB::table('classifiedregistration')->where('IsApprove',1)
             ->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->orderBy('ClassifiedRegId','desc')
            ->get();
         $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();
        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
        $subcategory=DB::table('subcategory')
        ->get();
        return view('company_help')->with(array('classifiedprofile'=>$classifiedprofile,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));

    }
    public function classified_help(){
         $classifiedprofile=DB::table('classifiedregistration')->where('IsApprove',1)
             ->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->orderBy('ClassifiedRegId','desc')
            ->get();
         $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();
        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
            $subcategory=DB::table('subcategory')
        ->get();
        return view('classified_help')->with(array('classifiedprofile'=>$classifiedprofile,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));

    }
    public function checkvalidation(){
        return view('ckeckvalidation');
    }
    public function checking(Request $request){
        return $request;
    }
    public function shownews()
    {
         $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $footersubmenu = DB::table('footersubmenu')
            ->where('MenuId', 5)
            ->get();
        $headermenu = DB::table('headermenu')
            ->where('DisplaySection', 3)
            ->get();
        $city = DB::table('city')
            ->get();
        $category = DB::table('category')
            ->get();
        $subcategory= DB::table('subcategory')
        ->get();
        $banner = DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
       $classifiedprofile=DB::table('classifiedregistration')->where('IsApprove',1)
             ->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->orderBy('ClassifiedRegId','desc')
            ->get();

        return view('newschannels')->with(array('anouncement'=>$anouncement,'subcategory'=>$subcategory,'classifiedprofile'=>$classifiedprofile,'headermenu' => $headermenu, 'city' => $city, 'category' => $category, 'banner' => $banner, 'footersubmenu' => $footersubmenu));
    }
    public function visitors_count()
    {
        $ip = $_SERVER['REMOTE_ADDR']; 
        $visiting_date=date('m/d/Y h:i:s a', time());
        DB::select('call SaveSiteVisitor(?,?)',array($ip,$visiting_date));
           
            ///DB::select('EXEC SaveSiteVisitor( $ip,$visiting_date )');
    }
    public function privacyPolicy()
    {
        $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $footersubmenu = DB::table('footersubmenu')
            ->where('MenuId', 5)
            ->get();
        $headermenu = DB::table('headermenu')
            ->where('DisplaySection', 3)
            ->get();
        $city = DB::table('city')
            ->get();
        $category = DB::table('category')
            ->get();
        $subcategory= DB::table('subcategory')
        ->get();
        $banner = DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
       $classifiedprofile=DB::table('classifiedregistration')->where('IsApprove',1)
             ->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->orderBy('ClassifiedRegId','desc')
            ->get();
       return view('privacy_policy')->with(array('anouncement'=>$anouncement,'subcategory'=>$subcategory,'classifiedprofile'=>$classifiedprofile,'headermenu' => $headermenu, 'city' => $city, 'category' => $category, 'banner' => $banner, 'footersubmenu' => $footersubmenu));
   
    }

    public function subcategory_list(Request $request)
    {
        $categoryid=$request->category_id;
        $subcategory=DB::table('subcategory')->where('CategoryId',$categoryid)->get();_
        return $subcategory;
    }

}
