<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;

class PassportController extends Controller
{
    public function register(Request $request)
    {
      /*    $this->validate($request, [
            'Name' => 'required|min:3',
            'UserId' => 'required|min:3',
            'Email' => 'required|email|unique:users',
            'Password' => 'required|min:6',
          ]);
      */
        $user = User::create([
            'Name' => $request->Name,
            'Email' => $request->Email,
            'UserId' => $request->UserId,
            'Password' => bcrypt($request->Password)
        ]);

       $token = $user->createToken('YellowPages')->accessToken;
       return response()->json(['token' => $token], 200);
    }

    public function login(Request $request)
    {
        $credentials = [
            'UserId' => $request->UserName,
            'password' => $request->Password
        ];

        if (auth()->attempt($credentials)) {
            $token = auth()->user()->createToken('YellowPages')->accessToken;
            return response()->json(['AuthToken' => $token], 200);
        } else {
            return response()->json(['error' => 'UnAuthorised'], 401);
        }
    }
    public function details()
    {
        return response()->json(['user' => auth()->user()], 200);
    }

}