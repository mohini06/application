<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use DB;
use App\NewUser;

class StoreController extends Controller
{
    public function index()
    {
        $user = DB::select('call GetUserDetail()');
        return $user;
    }

    public function testcat()
    {
        $category=DB::table('category')->get();
        return view('testsearchcate')->with('category',$category);
    }
}
