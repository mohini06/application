<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Banner;

use DB;

class BannerController extends Controller
{
    public function bannerCompany(Request $request)
    {
        $data = array();
        $images = DB::table('bannerimage')
            ->Where('IsActive','1')
            ->get();

        $path = config('constants.img_path');

        foreach($images as $image)
        {
            $img["BannerImageID"] = $image->BannerImageID;
            $img["AppImageURL"] = url('public/Images/'.$image->AppImageURL);
            $img["NavigationUrl"] = $image->NavigationUrl;
            $data[]=$img;
        }
        $result["TotalRecords"]=count($data);
        $result["BannerImages"]=$data;
        $result["Message"]=['Status' => 'Success','StatusMessage' => null];

        return response()->json($result,200,[],JSON_UNESCAPED_SLASHES);
    }
}
