<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use App\Classified;
use App\User;
use App\Category;
use App\SubCategory;
use App\city;
use DB;
use App\Mail\Email;
use Mail;
use App\ProductImage;
use Auth;
use App\Review;
use App\Company;
use App\ClassifiedImage;
class ClassifiedController extends Controller
{
    public function index()
    {
     $ip = $_SERVER['REMOTE_ADDR']; 
  
    $visiting_date=date('m/d/Y h:i:s a', time());
   
      $companyprofile= DB::table('companyregistration') 

        ->leftjoin('companyimage', 'companyimage.CompanyId', '=', 'companyregistration.CompanyRegId')
//        ->select('companyregistration.*', 'companyimage.*')
           ->whereRaw(' ExpiryDate > now()')
       ->where('IsApprove',1)
            ->where('ActualRegType',3)
        ->orwhere('ActualRegType',2)
       ->orderBy('CompanyRegId', 'desc')
      // ->take(100)
           
        ->get();
         $anouncement= DB::select('call Usp_GetAnnouncementList()');
     $classifiedprofile=DB::table('classifiedregistration')->where('IsApprove',1)
             ->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->orderBy('ClassifiedRegId','desc')
            ->get();


//        $companyprofile= DB::table('companyimage')
//
//            ->get();
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();
        $category=DB::table('category')

                ->get();


        $subcategory=DB::table('subcategory')
            ->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();

       return view('index')->with(array('anouncement'=>$anouncement,'subcategory'=>$subcategory,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'companyprofile'=>$companyprofile,'footersubmenu'=>$footersubmenu,'classifiedprofile'=>$classifiedprofile));
   
}

    /**
     * @return $this|string
     */
    public function create()
    {
           $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $subcategory=DB::table('subcategory')
            ->get();

        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::select('call usp_GetCityList()');
        $category=DB::table('category')
            ->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
      $subcategory=DB::table('subcategory')
            ->get();
//        $category= DB::table("category")->lists("CategoryName","CategoryId");

//        $category=DB::table('category')
//            ->groupBy('category')
//            ->get();
       //$id=DB::select('select * from category' );
        //$category =Category::find($id);

//        $subcategory = DB::table("subcategory")->where("CategoryId",$category->CategoryId)->pluck("SubCategoryName","SubCategoryId");
      //  return json_encode($subcategory);

//        return view('Classified\Classifiedregistration')->with(array('category'=>$category,'city'=>$city));
       return view('Classifiedregistration')->with(array('anouncement'=>$anouncement,'subcategory'=>$subcategory,'category'=>$category,'subcategory'=>$subcategory,'city'=>$city,'banner'=>$banner,'headermenu'=>$headermenu,'footersubmenu'=>$footersubmenu));

//        //$subcategory=DB::select('select * from subcategory where CategoryId=?',[$category=>'CategoryId']);

//       $category = category::pluck('CategoryName', 'CategoryId');
//      $subcategory=subcategory::pluck('SubCategoryName','SubCategoryId','CategoryId');
//    $city=city::pluck('CityName','CityId');
//        return view ('Classified\Classifiedregistration',compact('category','subcategory','city'));
}

    /**
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {
//        $this->validate($request,[
//        'ClassifiedTitle'=>'required',
//        'CategoryCode'=>'required',
//        'SubCategoryCode'=>'required',
//        'email'=>'required|unique|',
//        'name'=>'required',
//        'city'=>'required',
//        'mobile'=>'required',
//        'phone'=>'required',
//        'ClassifiedContent'=>'required'
//
//      ]);
//        $this->validate($request,[
//            'ClassifiedTitle' => 'required',
//            'category' => 'required|not_in:0',
//            'subcategory'=> 'required|not_in:0',
//            'name' => 'required|min:3|max:35|alpha',
//            'email' => 'required|email',
//            'city'=>'required|not_in:0',
//            'mobile' => 'required|numeric',
//            'phone' => 'required|numeric',
//            'ClassifiedContent' =>'required|min:20|max:200',
//
//
//        ]);
  $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
      $subcategory=DB::table('subcategory')
      ->get();
        $mail=$request->input('email');
        //$email= DB::select('select Email from userregistration where  Email=?',[$mail]);
          $usermail=DB::table('userregistration')->where ('Email',$mail)->first();
      if(empty($usermail))
      {
      $newuser= new User;
      $password_original=str_random(8);
            $password = bcrypt($password_original);
      
            $username1=str_shuffle('abcdefghijklmnopqrstuvwxyz');
            $username = substr( $username1, 0,7);
            $newuser->Name=$request->input('name');
            $newuser->Email=$request->input('email');
            $newuser->Phone=preg_replace('/[^\dxX]/', '', $request->input('phone'));
            $newuser->Mobile=preg_replace('/[^\dxX]/', '', $request->input('mobile'));
            $newuser->setAttribute('UserId', $username);
            $newuser->setAttribute('Password',$password);
            $newuser->remember_token=$request->input('_token');
            $newuser->save();

$data = array('name'=>$request->input('name'),'userid'=>$username,'password_original'=>$password_original,'email'=>$request->input('email'),'comname'=>$request->input('ClassifiedTitle'),'overview'=>$request->input('ClassifiedContent'),'phone'=>$newuser->Phone);            //$emails=['$data[email]','admyellowpages@gmail.com'];
            Mail::send('mail',$data,function($message) use($data) {
                $message->to($data['email'] , $data['name'])
                    ->subject('Детали вашего объявления');
                // $message->from('infoypkteam@gmail.com','ypk');
            });
            Mail::send('newuser',$data,function($message) use($data) {
                $message->to('support@ypk.kz' , $data['name'])
                    ->subject('Классифицированные данные, отправленные новым пользователем');
                // $message->from('infoypkteam@gmail.com','ypk');
            });
            $user_reg_id=$newuser->UserRegId;
            $classified= new Classified;
            $classified->ClassifiedTitle=$request->input('ClassifiedTitle');
            $classified->CategoryCode=$request->input('category');
            $classified->SubCategoryCode=$request->input('subcategory');
            $classified->ClassifiedContent=$request->input('ClassifiedContent');
            $classified->UserRegId=$user_reg_id;
            $classified->Weburl=$request->input('Weburl');
            $classified->city=$request->input('city');
      $classified->ActualRegType=0;
             
            $classified->save();
      $classfiedid=$classified->id;
           $userd= DB::table('classifiedregistration') ->where('ClassifiedRegId',$classfiedid)
                ->leftjoin('userregistration','userregistration.UserRegId','=','classifiedregistration.UserRegId')
                ->leftjoin('city','city.CityId','=','classifiedregistration.City')
                ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
                ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
                ->first();
       $classifiedprofile=DB::table('classifiedregistration')->where('IsApprove',1)
             ->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->orderBy('ClassifiedRegId','desc')
            ->get();
      }
      else {
        $user_reg_id=$usermail->UserRegId;
            $classified= new Classified;
            $classified->ClassifiedTitle=$request->input('ClassifiedTitle');
            $classified->CategoryCode=$request->input('category');
            $classified->SubCategoryCode=$request->input('subcategory');
            $classified->ClassifiedContent=$request->input('ClassifiedContent');
            $classified->UserRegId=$user_reg_id;
            $classified->Weburl=$request->input('Weburl');
            $classified->city=$request->input('city');
      $classified->ActualRegType=0;
             
            $classified->save();
      $classfiedid=$classified->id;
       
           $data = array('name'=>$usermail->Name,'userid'=>$usermail->UserId,'password_original'=>'Использовать старый пароль','email'=>$usermail->Email,'comname'=>$request->input('ClassifiedTitle'),'overview'=>$request->input('ClassifiedContent'),'phone'=>$usermail->Phone);
            //$emails=['$data[email]','admyellowpages@gmail.com'];
            Mail::send('mail',$data,function($message) use($data) {
                $message->to($data['email'] , $data['name'])
                    ->subject('confirmaition for registration');
                // $message->from('infoypkteam@gmail.com','ypk');
            });
            Mail::send('newuser',$data,function($message) use($data) {
                $message->to('support@ypk.kz.com' , $data['name'])
                    ->subject('Notification for new user Registration');
                // $message->from('infoypkteam@gmail.com','ypk');
            });
         
      $userd= DB::table('classifiedregistration') ->where('ClassifiedRegId',$classfiedid)
                ->leftjoin('userregistration','userregistration.UserRegId','=','classifiedregistration.UserRegId')
                ->leftjoin('city','city.CityId','=','classifiedregistration.City')
                ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
                ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
                ->first();
      $classifiedprofile=DB::table('classifiedregistration')->where('IsApprove',1)
             ->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->orderBy('ClassifiedRegId','desc')
            ->get();
      }
   
          return view('classifiedregistered')->with(array('anouncement'=>$anouncement,'classifiedprofile'=>$classifiedprofile,'subcategory'=>$subcategory,'userd'=>$userd,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
       
            
      }
        public  function classifieddetail($id){
        $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $subcategory=DB::table('subcategory')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $com=DB::table('classifiedregistration')
               ->where('ClassifiedRegId',$id)
              ->leftjoin('city','city.CityId','=','classifiedregistration.City')
              ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
              ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
              ->leftjoin('userregistration','userregistration.UserRegId','=','classifiedregistration.UserRegId')
             // ->leftjoin('addressgeocode','addressgeocode.CompanyOrClassifiedId','=','companyregistration.CompanyRegId')
                            ->first();
        $companyprofile= DB::table('companyregistration')

            ->leftjoin('companyimage', 'companyimage.CompanyId', '=', 'companyregistration.CompanyRegId')
//        ->select('companyregistration.*', 'companyimage.*')
            ->where('ActualRegType',3)
//            ->where('ActualRegType',2)
            ->get();
        $productimage= DB::table('productimage')->where('ClassifiedRegId',$id)
                     ->orderBy('ImageId', 'desc')
                    ->take(10)
                    ->get();
        $proposal= DB::table('companyproposal')->where('UserId',$com->UserRegId)

            ->get();

       $classifiedprofile=DB::table('classifiedregistration')->where('IsApprove',1)
             ->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->orderBy('ClassifiedRegId','desc')
            ->get();
            
        $new_company=DB::table('companyregistration')->orderBy('CompanyRegId', 'DESC')->first();
        $new_classified=DB::table('classifiedregistration')->orderBy('ClassifiedRegId', 'DESC')->first();


        return view ('classifieddetail')->with(array('anouncement'=>$anouncement,'subcategory'=>$subcategory,'proposal'=>$proposal,'productimage'=>$productimage,'classifiedprofile'=>$classifiedprofile,'companyprofile'=>$companyprofile,'subcategory'=>$subcategory,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'com'=>$com,'footersubmenu'=>$footersubmenu,'new_company'=>$new_company,'new_classified'=>$new_classified));
    }
public  function viewmap($id){
    $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $subcategory=DB::table('subcategory')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
       $com=DB::table('classifiedregistration')
               ->where('ClassifiedRegId',$id)
              ->leftjoin('city','city.CityId','=','classifiedregistration.City')
              ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
              ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
              ->leftjoin('userregistration','userregistration.UserRegId','=','classifiedregistration.UserRegId')
             // ->leftjoin('addressgeocode','addressgeocode.CompanyOrClassifiedId','=','companyregistration.CompanyRegId')
                            ->first();
        $companyprofile= DB::table('companyregistration')

            ->leftjoin('companyimage', 'companyimage.CompanyId', '=', 'companyregistration.CompanyRegId')
//        ->select('companyregistration.*', 'companyimage.*')
            ->where('ActualRegType',3)
//            ->where('ActualRegType',2)
            ->get();
        $productimage= DB::table('productimage')->where('ClassifiedRegId',$id)
                     ->orderBy('ImageId', 'desc')
                    ->take(5)
                    ->get();
        $proposal= DB::table('companyproposal')->where('UserId',$com->UserRegId)

            ->get();

       $classifiedprofile=DB::table('classifiedregistration')->where('IsApprove',1)
             ->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->orderBy('ClassifiedRegId','desc')
            ->get();
        return view ('classifiedviewmap')->with(array('anouncement'=>$anouncement,'subcategory'=>$subcategory,'proposal'=>$proposal,'productimage'=>$productimage,'classifiedprofile'=>$classifiedprofile,'companyprofile'=>$companyprofile,'subcategory'=>$subcategory,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'com'=>$com,'footersubmenu'=>$footersubmenu));
  }
    public function show($id){

    }
    public function edit($id)
    {  $anouncement= DB::select('call Usp_GetAnnouncementList()');
//        DB::table('classifiedregistration')
//            ->where('UserRegId', $id);
        $userd= DB::table('classifiedregistration')->where('UserRegId',$id)
//                ->leftjoin('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
            ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')

            ->first();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
//        $subcategory=DB::table('subcategory')
//
//            ->get();

        $classified=Classified::where('UserRegId', '=', $id);
       // $classified =Classified::find($id);
        return view('editad')->with(array('anouncement'=>$anouncement,'userd'=>$userd,'banner'=>$banner,'headermenu'=>$headermenu,'footersubmenu'=>$footersubmenu,'classified'=>$classified,'category'=>$category,'city'=>$city));
//        return view('editad')->with('classified',$classified);
//        return view('edit')->with(array('classified'=>$classified,'category'=>$category,'subcategory'=>$subcategory,'city'=>$city));
    }
    
   public function storeaddprofile(Request $request)
   {
     
     $anouncement= DB::select('call Usp_GetAnnouncementList()');
     $subcategory=DB::table('subcategory')
           ->get();
       $id=Auth::user()->UserRegId;

       $headermenu= DB::table('headermenu')
           ->where('DisplaySection',3)
           ->get();

       $city=DB::table('city')
           ->get();
       $category=DB::table('category')
           ->get();
       $banner=DB::table('bannerimage')
           ->where('IsActive', 1)
           ->get();
       $footersubmenu=DB::table('footersubmenu')
           ->where('MenuId',5)
           ->get();
       $userd= DB::table('companyregistration')->where('UserRegId',$id)
//                ->leftjoin('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
           ->leftjoin('city','city.CityId','=','companyregistration.City')
           ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
           ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
           ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
           ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')

           ->first();


$classifieddata=DB::table('classifiedregistration')->where('UserRegId',$id)
              ->leftjoin('city','city.CityId','=','classifiedregistration.City')
              ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
              ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
             
              ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.UserRegId')
              ->get();
     $classfied_reg_id=$request->input('ClassifiedRegId');
       //  $input = $request->all();
       $data=DB::table('classifiedimage')->where('ClassifiedId',$classfied_reg_id)->count('*');
 
   if($data<1)
   {

           $image = $request->file('ImageUrl');
             
               
                $pathinfo= pathinfo($image->getClientOriginalName());
        $imgname=$pathinfo['filename'].'_'.time().'.'.$pathinfo['extension'];
        
   

               $image->move('public/ProductImages', $imgname);


       

               $imagename = new ClassifiedImage;
               $imagename->ImageUrl = $imgname;
               $imagename->ClassifiedId = $classfied_reg_id;


               $imagename->save();
        //          return $imagename;

        //          return view('showprofileimg')->with(array('userd'=>$userd,'data'=>$data,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
            if($userd!=null)   
      {       
       $data1 = DB::table('companyimage')->where('CompanyId', $userd->CompanyRegId)->get();
             $adddp=DB::table('classifiedimage')->where('ClassifiedId',$classfied_reg_id)->first();
        
                return redirect('uploadprofilepic')->with(array('classifieddata'=>$classifieddata,'adddp'=>$adddp,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'userd' => $userd,'category' => $category, 'city' => $city, 'headermenu' => $headermenu, 'city' => $city, 'category' => $category, 'banner' => $banner, 'footersubmenu' => $footersubmenu));
      }
      else {
        
                 $adddp=DB::table('classifiedimage')->where('ClassifiedId',$classfied_reg_id)->first();
        
                return redirect('uploadprofilepic')->with(array('classifieddata'=>$classifieddata,'adddp'=>$adddp,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'userd' => $userd,'category' => $category, 'city' => $city, 'headermenu' => $headermenu, 'city' => $city, 'category' => $category, 'banner' => $banner, 'footersubmenu' => $footersubmenu));
    
      }



   }
        //       $data1=DB::table('companyimage')->where('CompanyId',$id)->first();
//       return view('showprofileimg')->with(array('userd'=>$userd,'data1'=>$data1,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
            else {
                $data1 = DB::table('classifiedimage')->where('ClassifiedId',$classfied_reg_id)->delete();

           $image = $request->file('ImageUrl');

              $pathinfo= pathinfo($image->getClientOriginalName());
        $imgname=$pathinfo['filename'].'_'.time().'.'.$pathinfo['extension'];
                
        //                     $img=$image->getRealPath();

               $image->move('public/ProductImages', $imgname);


        //                   Image::make($image->getRealPath())->resize(468, 249)->save('public/ProductImage/'.$imgname);
        //                   move('public/ProductImages', $img);
        //                    $input['prodimg'] = $imgname;
        //                    $image->image = 'public/ProductImage/'.$imgname;
        //                    $imgname->save();
        //                    $input['ImageUrl'] = $imgname;

               $imagename = new ClassifiedImage;
               $imagename->ImageUrl = $imgname;
               $imagename->ClassifiedId =$classfied_reg_id;


               $imagename->save();
        //          return $imagename;

        //          return view('showprofileimg')->with(array('userd'=>$userd,'data'=>$data,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
            if($userd!=null)   
      {       
       $data1 = DB::table('companyimage')->where('CompanyId', $userd->CompanyRegId)->get();
             $adddp=DB::table('classifiedimage')->where('ClassifiedId',$classfied_reg_id)->first();
        
                return redirect('uploadprofilepic')->with(array('classifieddata'=>$classifieddata,'adddp'=>$adddp,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'userd' => $userd,'category' => $category, 'city' => $city, 'headermenu' => $headermenu, 'city' => $city, 'category' => $category, 'banner' => $banner, 'footersubmenu' => $footersubmenu));
      }
      else {
        
                 $adddp=DB::table('classifiedimage')->where('ClassifiedId',$classfied_reg_id)->first();
        
                return redirect('uploadprofilepic')->with(array('classifieddata'=>$classifieddata,'adddp'=>$adddp,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'userd' => $userd,'category' => $category, 'city' => $city, 'headermenu' => $headermenu, 'city' => $city, 'category' => $category, 'banner' => $banner, 'footersubmenu' => $footersubmenu));
    
      }
}


   }
public function reviewadd(Request $request,$classifiedid)
    {
    $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $newreview= new Review;
        $newreview->ClassifiedId=$classifiedid;
        $newreview->CommentedPerson=$request->input('CommentedPerson');
        $newreview->CommentedPersonEmail=$request->input('CommentedPersonEmail');
        $newreview->CommentedPersonPhoneNo=$request->input('CommentedPersonPhoneNo');
        $newreview->ReviewMessage=$request->input('ReviewMessage');

        $newreview->save();
    
       $com=DB::table('classifiedregistration')
               ->where('ClassifiedRegId',$classifiedid)
              ->leftjoin('city','city.CityId','=','classifiedregistration.City')
              ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
              ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
              ->leftjoin('userregistration','userregistration.UserRegId','=','classifiedregistration.UserRegId')
             // ->leftjoin('addressgeocode','addressgeocode.CompanyOrClassifiedId','=','companyregistration.CompanyRegId')
                            ->first();
      $useremail=$request->input('CommentedPersonEmail');
      $ownername=$com->Name;
      $companyemail=$com->Email;
    $data = array('name'=>$request->input('CommentedPerson'),'CommentedPersonPhoneNo'=>$request->input('CommentedPersonPhoneNo'),'comments'=>$request->input('ReviewMessage'),'useremail'=>$useremail,'companyemail'=>$companyemail,'ownername'=>$ownername);
      
            Mail::send('sentReviewMail_user',$data,function($message) use($data) {
                $message->to($data['useremail'] , $data['name'])
                    ->subject('Ответ пользователя Желтые страницы Казахстана');
                // $message->from('infoypkteam@gmail.com','ypk');
            });
            Mail::send('getingReviewMail',$data,function($message) use($data) {
                $message->to($data['companyemail'] , $data['ownername'])
                    ->subject('Ответ пользователя для вашей компании, размещенный в Желтые страницы Казахстана');
                // $message->from('infoypkteam@gmail.com','ypk');
            });

        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $subcategory=DB::table('subcategory')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
           
        $companyprofile= DB::table('companyregistration')

            ->leftjoin('companyimage', 'companyimage.CompanyId', '=', 'companyregistration.CompanyRegId')
//        ->select('companyregistration.*', 'companyimage.*')
            ->where('ActualRegType',3)
//            ->where('ActualRegType',2)
            ->get();
        $productimage= DB::table('productimage')->where('ClassifiedRegId',$classifiedid)
                     ->orderBy('ImageId', 'desc')
                    ->take(10)
                    ->get();
        $proposal= DB::table('companyproposal')->where('UserId',$com->UserRegId)

            ->get();
       $classifiedprofile=DB::table('classifiedregistration')->where('IsApprove',1)
             ->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->orderBy('ClassifiedRegId','desc')
            ->get();
        return view ('classifieddetail')->with(array('anouncement'=>$anouncement,'subcategory'=>$subcategory,'proposal'=>$proposal,'productimage'=>$productimage,'classifiedprofile'=>$classifiedprofile,'companyprofile'=>$companyprofile,'subcategory'=>$subcategory,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'com'=>$com,'footersubmenu'=>$footersubmenu));
    }
 public function replyReview_add(Request $request)
      {
          $id=Auth::user()->UserRegId;
           $classifiedid=$request->input('ClassifiedId');
      $anouncement= DB::select('call Usp_GetAnnouncementList()');
         $reviewid=$request->input('ReviewId');
          $reviewer=DB::table('review')->where('ReviewId',$reviewid)
               ->leftjoin('classifiedregistration','classifiedregistration.ClassifiedRegId','=','review.ClassifiedId')
              
            ->first();

            $name= $reviewer->CommentedPerson;
            $emailid= $reviewer->CommentedPersonEmail;
            $description= $request->Input('comment');
             $data = array('email'=>$emailid,'description'=>$description,'name'=>$name);
        //print_r($data['email']);echo $data['name'];exit;
                  Mail::send('replyMail',$data,function($message) use ($data) {
                  $message->to( $data['email'], $data['name'],$data['description'])
                      ->subject('Ответить на ваш отзыв');
                  // $message->from('infoypkteam@gmail.com','ypk');
                 });
          $UserRegId= $reviewer->UserRegId;
          $remove=DB::table('review')->where('ReviewId',$reviewer->ReviewId)->delete();
           $userd= DB::table('companyregistration')->where('UserRegId',$UserRegId)
//                ->join('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
              ->leftjoin('city','city.CityId','=','companyregistration.City')
              ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
              ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
              ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')
              ->leftjoin('area','area.AreaId','=','companyregistration.area')
              ->first();
          $user= DB::table('userregistration')->where('UserRegId',$UserRegId)
              ->first();
          $footersubmenu=DB::table('footersubmenu')
              ->where('MenuId',5)
              ->get();
          $headermenu= DB::table('headermenu')
              ->where('DisplaySection',3)
              ->get();
          $area=DB::table('area')
              ->get();
          $city=DB::table('city')
              ->get();
          $category=DB::table('category')
              ->get();
          $banner=DB::table('bannerimage')
              ->where('IsActive', 1)
              ->get();
        $subcategory=DB::table('subcategory')
           ->get();

          $classified=Classified::where('UserRegId', '=', $id);
 $classifieddata=DB::table('classifiedregistration')->where('UserRegId',$id)
              ->leftjoin('city','city.CityId','=','classifiedregistration.City')
              ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
              ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
             
              ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.UserRegId')
              ->get();
         if($userd!=null)
    {
    $review=DB::table('review')
              ->where('CompanyId', $userd->CompanyRegId)
              ->get();
      $addreview=DB::table('review')
              
              ->get();
          return redirect('/review')->with(array('addreview'=>$addreview,'classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'review'=>$review,'area'=>$area,'user'=>$user,'userd'=>$userd,'banner'=>$banner,'headermenu'=>$headermenu,'footersubmenu'=>$footersubmenu,'classified'=>$classified,'category'=>$category,'city'=>$city));
//
      } 
     else {
    $addreview=DB::table('review')
                      ->get();
           return redirect('/review')->with(array('addreview'=>$addreview,'classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'area'=>$area,'user'=>$user,'userd'=>$userd,'banner'=>$banner,'headermenu'=>$headermenu,'footersubmenu'=>$footersubmenu,'classified'=>$classified,'category'=>$category,'city'=>$city));
// 
   }     
         }
         public function removeReview_add($reviewId)

         {
       $id=Auth::user()->UserRegId;
            $anouncement= DB::select('call Usp_GetAnnouncementList()');
            
     $reviewer=DB::table('review')
               ->leftjoin('classifiedregistration','classifiedregistration.ClassifiedRegId','=','review.ClassifiedId')
            ->where('ReviewId',$reviewId)->first();
      $UserRegId= $id;
           $remove=DB::table('review')->where('ReviewId',$reviewId)->delete();
       
           $userd= DB::table('companyregistration')->where('UserRegId',$UserRegId)
//                ->join('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
              ->leftjoin('city','city.CityId','=','companyregistration.City')
              ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
              ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
              ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')
              ->leftjoin('area','area.AreaId','=','companyregistration.area')
        ->leftjoin('review','review.CompanyId','=','companyregistration.CompanyRegId')
              ->first();
          $user= DB::table('userregistration')->where('UserRegId',$UserRegId)
              ->first();
          $footersubmenu=DB::table('footersubmenu')
              ->where('MenuId',5)
              ->get();
          $headermenu= DB::table('headermenu')
              ->where('DisplaySection',3)
              ->get();
          $area=DB::table('area')
              ->get();
          $city=DB::table('city')
              ->get();
          $category=DB::table('category')
              ->get();
          $banner=DB::table('bannerimage')
              ->where('IsActive', 1)
              ->get();
        $subcategory=DB::table('subcategory')
           ->get();
//        $subcategory=DB::table('subcategory')
//
//            ->get();
 $classifieddata=DB::table('classifiedregistration')->where('UserRegId',$UserRegId)
              ->leftjoin('city','city.CityId','=','classifiedregistration.City')
              ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
              ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
              
              ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.UserRegId')
              ->get();
          $classified=Classified::where('UserRegId', '=', $UserRegId);
          if($userd!=null)
    {
    $review=DB::table('review')
              ->where('CompanyId', $userd->CompanyRegId)
              ->get();
      $addreview=DB::table('review')
              
              ->get();
          return redirect('/review')->with(array('addreview'=>$addreview,'classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'review'=>$review,'area'=>$area,'user'=>$user,'userd'=>$userd,'banner'=>$banner,'headermenu'=>$headermenu,'footersubmenu'=>$footersubmenu,'classified'=>$classified,'category'=>$category,'city'=>$city));
//
      } 
     else {
    $addreview=DB::table('review')
                      ->get();
          return redirect('/review')->with(array('addreview'=>$addreview,'classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'area'=>$area,'user'=>$user,'userd'=>$userd,'banner'=>$banner,'headermenu'=>$headermenu,'footersubmenu'=>$footersubmenu,'classified'=>$classified,'category'=>$category,'city'=>$city));
// 
   }      
         }
   
    public function  saveproductimg( Request $request)
    {
       
      $id=Auth::user()->UserRegId;
    $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();
        $subcategory=DB::table('subcategory')
           ->get();
        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $userd= DB::table('companyregistration')->where('UserRegId',$id)
//                ->leftjoin('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
            ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')

            ->first();
          
         $classifieddata=DB::table('classifiedregistration')->where('UserRegId',$id)
              ->leftjoin('city','city.CityId','=','classifiedregistration.City')
              ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
              ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
             
              ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.UserRegId')
              ->get(); 
    
       $classifiedregid=$request->input('ClassifiedRegId');
        //  $input = $request->all();

        $image = $request->file('ImageUrl');

       $pathinfo= pathinfo($image->getClientOriginalName());
        $imgname=$pathinfo['filename'].'_'.time().'.'.$pathinfo['extension'];
    
//                     $img=$image->getRealPath();
        $image->move('public/ProductImages', $imgname);

   

        $imagename= new ProductImage;
        $imagename->ImageUrl=$imgname;
        $imagename->ClassifiedRegId=$classifiedregid;
        $imagename->save();
     
       // return $imagename;
        if($userd!=null)
{
 $type=$userd->ActualRegType;
       if($type>2){
         $data=DB::table('productimage')->where('CompanyId',$userd->CompanyRegId)
            ->orderBy('ImageId', 'desc')
            ->take(5)
            ->get();
       }
       elseif($type>1)
       {
         $data=DB::table('productimage')->where('CompanyId',$userd->CompanyRegId)
            ->orderBy('ImageId', 'desc')
            ->take(3)
            ->get();
       }
       else{
         $data=DB::table('productimage')->where('CompanyId',$userd->CompanyRegId)
            ->orderBy('ImageId', 'desc')
            ->take(1)
            ->get();
       }
     $add_productimage=DB::table('productimage')->get();
return redirect('/uploadproductimg')->with(array('add_productimage'=>$add_productimage,'classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'userd'=>$userd,'data'=>$data,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
}
else
{
 $add_productimage=DB::table('productimage')->get();
return redirect('/uploadproductimg')->with(array('add_productimage'=>$add_productimage,'classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'userd'=>$userd,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));

}
    }
  
   public function update(Request $request)
    {
         $classifiedregid=$request->input('ClassifiedRegId');
  
             $id=Auth::user()->UserRegId;
      $anouncement= DB::select('call Usp_GetAnnouncementList()');
       DB::table('userregistration')
            ->where('UserRegId', $id)
            ->update(array('Name'=>$request->input('ContactName'),'Email'=>$request->input('Email'),'Phone'=>$request->input('phone'),'Mobile'=>$request->input('mobile')
       ));
     DB::table('classifiedregistration')
      ->where('ClassifiedRegId', $classifiedregid)
            ->update(array('ClassifiedTitle'=>$request->input('ClassifiedTitle'),'CategoryCode'=>$request->input('category'),'SubCategoryCode'=>$request->input('subcategory'),'WebUrl'=>$request->input('WebUrl'),
              'City'=>$request->input('City'),'ClassifiedContent'=>$request->input('ClassifiedContent'),'dateofincorporation'=>$request->input('dateofincorporation')));
    $userd= DB::table('companyregistration')->where('UserRegId',$id)
//                ->join('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
            ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('area','area.AreaId','=','companyregistration.area')
            ->first();
        $user= DB::table('userregistration')->where('UserRegId',$id)
            ->first();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();
       $area=DB::table('area')
           ->get();
        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)->get();
        $subcategory=DB::table('subcategory')
           ->get();
        $classified=Company::where('UserRegId', '=', $id);
    $classifieddata=DB::table('classifiedregistration')->where('UserRegId',$id)
              ->leftjoin('city','city.CityId','=','classifiedregistration.City')
              ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
              ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
              ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
              
              ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.UserRegId')
              ->get();
        // $classified =Classified::find($id);
        return redirect('/profile')->with(array('classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'area'=>$area,'user'=>$user,'userd'=>$userd,'banner'=>$banner,'headermenu'=>$headermenu,'footersubmenu'=>$footersubmenu,'classified'=>$classified,'category'=>$category,'city'=>$city));
//        return view('editad')->with('classified',$classified);
//        return view('edit')->with(array('classified'=>$classified,'category'=>$category,'subcategory'=>$subcategory,'city'=>$city));  
         }
     public function addcompany()
     {
         $id=Auth::user()->UserRegId;
         $user=DB::table('userregistration')->where('UserRegId',$id)->first();
         $anouncement= DB::select('call Usp_GetAnnouncementList()');
         $subcategory=DB::table('subcategory')
           ->get();

         $headermenu= DB::table('headermenu')
           ->where('DisplaySection',3)
           ->get();

         $city=DB::select('call usp_GetCityList()');
         $category=DB::table('category')
           ->get();
         $banner=DB::table('bannerimage')
           ->where('IsActive', 1)
           ->get();
         $footersubmenu=DB::table('footersubmenu')
           ->where('MenuId',5)
           ->get();
         return view('addcompany')->with(array('user'=>$user,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
     }
    public function storecompany(Request $request)
    {
           $id=Auth::user()->UserRegId;
         $user=DB::table('userregistration')->where('UserRegId',$id)->first();
         $anouncement= DB::select('call Usp_GetAnnouncementList()');
         $subcategory=DB::table('subcategory')
           ->get();

         $headermenu= DB::table('headermenu')
           ->where('DisplaySection',3)
           ->get();

         $city=DB::table('city')
           ->get();
         $category=DB::table('category')
           ->get();
         $banner=DB::table('bannerimage')
           ->where('IsActive', 1)
           ->get();
         $footersubmenu=DB::table('footersubmenu')
           ->where('MenuId',5)
           ->get();
      $user=new User;
            $user->Name=$request->input('ContactName');
            $user->Phone=preg_replace('/[^\dxX]/', '', $request->input('phone'));
            $user->Mobile=preg_replace('/[^\dxX]/', '', $request->input('mobile'));
            $user->remember_token=$request->input('_token');
            $user->save();
             


            $company= new Company;
            $company->CompanyName=$request->input('CompanyName');
            $company->Address1=$request->input('Address1');
            $company->UserRegId=$id;
            $company->Address2=$request->input('Address2');
            $company->PostalCode=$request->input('PostalCode');
            $company->FaxNo=$request->input('FaxNo');
//        $company->mobile=$request->input('mobile');
//        $company->UserName=$request->input('UserName');
            $company->CategoryCode=$request->input('category');
            $company->SubCategoryCode=$request->input('subcategory');

//        $company->ClassifiedContent=$request->input('ClassifiedContent');
            $company->WebsiteLink=$request->input('WebsiteLink');
            $company->City=$request->input('City');
            $company->DescribeBusiness=$request->input('DescribeBusiness');
            $company->dateofincorporation=$request->input('dateofincorporation');
            $company->save();
      $emailadd=$request->input('Email');
      $password_original="Используйте тот же пароль";
           $data = array('name'=>$request->input('ContactName'),'email'=>$request->input('Email'),'email_md5'=>md5($emailadd),'phone'=>$request->input('phone'),'discription'=>$request->input('DescribeBusiness'),'UserId'=>$request->input('UserName'),'Password_original'=>$password_original,'comname'=>$request->input('CompanyName'),'overview'=>$request->input('DescribeBusiness'));
      //print_r($data['email']);echo $data['name'];exit;
                  Mail::send('mail2',$data,function($message) use ($data) {
                  $message->to( $data['email'], $data['name'])
                      ->subject('Детали вашего объявления');
                  // $message->from('infoypkteam@gmail.com','ypk');
                 });
                 Mail::send('newuser',$data,function($message) use($data) {
                 $message->to('support@ypk.kz' , $data['name'])
                     ->subject('Классифицированные данные, отправленные новым пользователем');
                 // $message->from('infoypkteam@gmail.com','ypk');
                  });
          
            $userd= DB::table('userregistration') ->where('Email',$request->input('Email'))
                ->leftjoin('companyregistration','companyregistration.UserRegId','=','userregistration.UserRegId')
                ->leftjoin('city','city.CityId','=','companyregistration.City')
                ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
                ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
                ->first();
         $classifiedprofile=DB::table('classifiedregistration')->where('IsApprove',1)
             ->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->orderBy('ClassifiedRegId','desc')
            ->get();
            return view('companyregistered')->with(array('anouncement'=>$anouncement, 'subcategory'=>$subcategory,'classifiedprofile'=>$classifiedprofile,'userd'=>$userd,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
      
         
    }
}
