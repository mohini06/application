<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use DB;
class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
	 public function index()
    {
        $ip = $_SERVER['REMOTE_ADDR']; 
		$visiting_date=date('m/d/Y h:i:s a', time());
		DB::select('call usp_SaveSiteVisitor(?)',array($ip));
	}
}
