<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Company;
use App\City;
use App\Classified;
use DB;
use App\Mail\Email;
use Mail;
class SearchController extends Controller
{
    public function search(Request $request)
    {
	    $get_cityname = $request->get('city');
        $city__name=DB::table('city')
            ->where('CityId',$get_cityname)
            ->first();
				  
        $get_search_item = $request->get('search_item');
        $get_selectedoption = $request->get('selectedoption');
        $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();

        $category=DB::table('category')
            ->get();

        $subcategory=DB::table('subcategory')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();

        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();

		$currentDate = date('Y-m-d');
        $cityname = $request->input('city');
        $search_item = $request->input('search_item');
        $selectedoption = $request->input('selectedoption');
        $cat_subcat=DB::table('subcategory')
            ->where ('SubCategoryName', $selectedoption)
            ->leftjoin('category', 'category.CategoryId', '=', 'subcategory.CategoryId')
            ->first();
        
        $companyprofile= DB::table('companyregistration')
            ->leftjoin('companyimage', 'companyimage.CompanyId', '=', 'companyregistration.CompanyRegId')
            ->where('ActualRegType',3)
            ->where('ActualRegType',2)
            ->get();

        $classifiedprofile=DB::table('classifiedregistration')->where('ActualRegType','array(0,1)')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->whereRaw(' ExpiryDate > now()')->get();
     
        if(($search_item!="")&&($cityname=="")&&($selectedoption==""))
        {
            $classifieddata=DB::table('classifiedregistration')
                ->where('IsApprove',1)
			    ->whereRaw("(`ClassifiedTitle` like '%".$search_item."%' or `ClassifiedContent` like '%".$search_item."%') and ExpiryDate > now()")
                ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
                ->leftjoin('city','city.CityId','=','classifiedregistration.City')
                ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
                ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
                ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
                ->orderBy('ActualRegType','desc')
			    ->select(DB::raw('ActualRegType,ClassifiedRegId,ClassifiedTitle,city.CityName,WebUrl,ClassifiedContent,classifiedimage.ImageUrl,Phone,"classified" as type'));
		    
            $companydata=Company::where('CompanyName','like', '%' .$search_item.'%')
                ->where('IsApprove',1)
                ->orWhere('DescribeBusiness','like', '%' .$search_item.'%')
                ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
                ->leftjoin('city','city.CityId','=','companyregistration.City')
                ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
                ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
                ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
			    ->select(DB::raw('ActualRegType,CompanyRegId,CompanyName,city.CityName,WebsiteLink,DescribeBusiness,companyimage.ImageUrl,Phone,"Company" as type'))
			    ->union($classifieddata)
			    ->orderBy('ActualRegType','desc')
                ->unionPaginate(5,'*',$pageName = 'page',null);	
        }
        elseif (($search_item!="")&&($cityname!="")&&($selectedoption=="")) 
        {
           	$classifieddata=DB::table('classifiedregistration')
			->where([
                ['City', $request->input('city') ],
                ['ClassifiedTitle','like', '%' .$search_item.'%']
            ])
            ->where('IsApprove',1)
			->whereRaw(' ExpiryDate > now()')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
            ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
            ->orderBy('ActualRegType','desc')
			->select(DB::raw('ActualRegType,ClassifiedRegId,ClassifiedTitle,city.CityName,WebUrl,ClassifiedContent,Phone,classifiedimage.ImageUrl,"classified" as type'));
			 
               $companydata=Company::where([
                ['City', $request->input('city') ],
                ['CompanyName','like', '%' .$search_item.'%']
                   ])
            ->where('IsApprove',1)
             ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
			
            
			
		     ->select(DB::raw('ActualRegType,CompanyRegId,CompanyName,city.CityName,WebsiteLink,DescribeBusiness,Phone,companyimage.ImageUrl,"Company" as type'))
			 ->union($classifieddata)
		      ->orderBy('ActualRegType','desc')
			 ->unionPaginate(5,'*',$pageName = 'page',null);
             
            }
            elseif(($search_item=="")&&($cityname!="")&&($selectedoption!=""))
            {
			 $classifieddata=DB::table('classifiedregistration')->where([
                ['City', $request->input('city') ],
                ['subcategory.SubCategoryName',$selectedoption]
                     ])
                  
            ->where('IsApprove',1)
             ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
            ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
            ->orderBy('ActualRegType','desc')
			->whereRaw(' ExpiryDate > now()')
		    ->select(DB::raw('ActualRegType,ClassifiedRegId,ClassifiedTitle,subcategory.SubCategoryName,city.CityName,WebUrl,ClassifiedContent,Phone,classifiedimage.ImageUrl,"classified" as type'));
		
            $companydata=Company::where([
                ['City', $request->input('city') ],
                ['subcategory.SubCategoryName',$selectedoption]
                     ])
            ->where('IsApprove',1)
             ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
          
		
		  ->select(DB::raw('ActualRegType,CompanyRegId,CompanyName,subcategory.SubCategoryName,city.CityName,WebsiteLink,DescribeBusiness,Phone,companyimage.ImageUrl,"Company" as type'))
			 ->union($classifieddata)
			 ->orderBy('ActualRegType','desc')
		     ->unionPaginate(5,'*',$pageName = 'page',null);
             
             }
             elseif (($search_item=="")&&($cityname=="")&&($selectedoption!="")){
			$classifieddata=DB::table('classifiedregistration')
             ->where('IsApprove',1)
             ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
            ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
			->where('subcategory.SubCategoryName',$selectedoption)
            ->orderBy('ActualRegType','desc')
			->orderBy('Ranking','asc')
			->whereRaw(' ExpiryDate > now()')
		    ->select(DB::raw('Ranking,ActualRegType,ClassifiedRegId,ClassifiedTitle,subcategory.SubCategoryName,city.CityName,WebUrl,ClassifiedContent,Phone,classifiedimage.ImageUrl,"classified" as type'));
				
             $companydata=Company::where('IsApprove',1)
            ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
			->where('subcategory.SubCategoryName',$selectedoption)
            
			 ->select(DB::raw('Ranking,ActualRegType,CompanyRegId,CompanyName,subcategory.SubCategoryName,city.CityName,WebsiteLink,DescribeBusiness,Phone,companyimage.ImageUrl,"Company" as type'))
			 ->union($classifieddata)
			 ->orderBy('ActualRegType','desc')
			 ->orderBy('Ranking','asc')
		     ->unionPaginate(5,'*',$pageName = 'page',null);
            }  
         
            
           else{
            $companydata=[];
           }

          //return $classifieddata;
       return view('search')->with(array('city__name'=>$city__name,'cat_subcat'=>$cat_subcat,'get_selectedoption'=>$get_selectedoption,'get_search_item'=>$get_search_item,'get_cityname'=>$get_cityname,'search_item'=>$search_item,'anouncement'=>$anouncement,'companyprofile'=>$companyprofile,'classifiedprofile'=>$classifiedprofile,'subcategory'=>$subcategory,'companydata'=>$companydata,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
       
    }
	public function advsearch(Request $request){

     
     
        $anouncement= DB::select('call Usp_GetAnnouncementList()');
         $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();
        $category=DB::table('category')
            ->get();

        $subcategory=DB::table('subcategory')
            ->get();
        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();
        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();
       
        $selectedsubcat = $request->input('selectedsubcat');
        //$search_item=$request->get('search_item'); 
		$get_search_item = $request->get('search_item');
        //print_r($_REQUEST);exit;
        $companyprofile= DB::table('companyregistration')

            ->leftjoin('companyimage', 'companyimage.CompanyId', '=', 'companyregistration.CompanyRegId')
//        ->select('companyregistration.*', 'companyimage.*')
            ->where('ActualRegType',array(2,3))
//            ->where('ActualRegType',2)
            ->get();
		
      $cat_subcat=DB::table('subcategory')
        ->where ('SubCategoryName', $selectedsubcat)
        ->leftjoin('category', 'category.CategoryId', '=', 'subcategory.CategoryId')
        ->first();
        $classifiedprofile=DB::table('classifiedregistration')->where('ActualRegType','array(0,1)')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
             ->whereRaw(' ExpiryDate > now()')->get();
        $classifieddata=DB::table('classifiedregistration')->where([
                ['ClassifiedTitle', 'like', '%' .$get_search_item.'%'],
                ['subcategory.SubCategoryName',$selectedsubcat]
                     ])
             ->where('IsApprove',1)
             ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
            ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
			->orderBy('ActualRegType','desc')
			->whereRaw(' ExpiryDate > now()')
		    ->select(DB::raw('ActualRegType,ClassifiedRegId,ClassifiedTitle,subcategory.SubCategoryName,city.CityName,WebUrl,ClassifiedContent,Phone,classifiedimage.ImageUrl,"classified" as type'));
			
         $companydata=Company::where([
                ['CompanyName', 'like', '%' .$get_search_item.'%'],
                ['subcategory.SubCategoryName',$selectedsubcat]
                     ])
			->where('IsApprove',1)
            ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
            
			->select(DB::raw('ActualRegType,CompanyRegId,CompanyName,subcategory.SubCategoryName,city.CityName,WebsiteLink,DescribeBusiness,Phone,companyimage.ImageUrl,"Company" as type'))
			->union($classifieddata)
			->orderBy('ActualRegType','desc')
		     ->unionPaginate(5,'*',$pageName = 'page',null);
            
       return view('search')->with(array('get_search_item'=>$get_search_item,'cat_subcat'=>$cat_subcat,'anouncement'=>$anouncement,'companyprofile'=>$companyprofile,'classifiedprofile'=>$classifiedprofile,'subcategory'=>$subcategory,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'companydata'=>$companydata,'footersubmenu'=>$footersubmenu));

    }
  public function claim_flag(Request $request)
  { 
	  $old_email=$request->get('old_email');
	  $email=$request->input('email_id');
	  $phonenumber=$request->input('phone_number');
	  $comment=$request->input('comment');
	  $companyregid=$request->get('companyreid');
	 
	  $data = array('email'=>$email,'comment'=>$comment,'phonenumber'=>$phonenumber,'old_email'=>$old_email);
        //print_r($data['email']);echo $data['name'];exit;
                  Mail::send('claim_mail',$data,function($message) use ($data) {
                  $message->to( 'infoypkteam@gmail.com', 'ypk',$data['comment'])
                      ->subject('Claim flag from user');
                  $message->from($data['email'],'User');
                 });
				 
  return redirect('companydetail/'.$companyregid);
	  
  }
}
