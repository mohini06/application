<?php

namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Hash;
use DB;
use Mail;
use App\User;
use App\Classified;
use App\Company;
use App\ProductImage;
use App\CompanyProposal;
use Response;
class RegistrationController extends Controller
{
    public function index()
    {
        return view('index');
    }
   
    public function store(Request $request)
    {
        $newuser= new User;
        $newuser->Name=$request->input('name');
        $newuser->Email=$request->input('email');
        $newuser->Phone=$request->input('phone');
        $newuser->Mobile=$request->input('Mobile');
        $newuser->save();
    }
   
    public function showLogin()
    {
        return redirect('/');
    }

    public function doLogin(Request $request)
    {
        $userid=$request->user;
        $pass=$request->pass;
	    $password=bcrypt($pass);
		$user=DB::table('userregistration')
            ->whereRaw('UserId',$userid)
            ->first();
        $field = filter_var(($request->user), FILTER_VALIDATE_EMAIL)
        ? 'Email' : 'UserId';
      
        $credentials = [
            $field =>$request->user,
            'password' => $request->pass
        ];
        $remember = ($request->rem_value==1) ? true : false;
        
        if (!Auth::attempt($credentials,$remember)) 
        {
            return
                response([
                    'success' => false,
                    'message' => 'Пожалуйста, введите правильное имя пользователя / пароль'
                ], 403);
        }
        else 
        {
			return "";	
		}
    }
    public function myprofile()
    { 
        $id=Auth::user()->UserRegId;
        $anouncement= DB::select('call Usp_GetAnnouncementList()');
       
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $subcategory=DB::table('subcategory')
            ->get();

        $city=DB::table('city')
            ->get();

        $category=DB::table('category')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();

        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();

        $userd= DB::table('companyregistration')
            ->where('UserRegId',$id)
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
            ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','companyregistration.UserRegId')
            ->first();

        $classifieddata=DB::table('classifiedregistration')->where('UserRegId',$id)
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.UserRegId')
			->get();
		
        $userdata=DB::table('userregistration')
            ->where('UserRegId',$id)
            ->first();
		if($userd!=null)
		{
			$type=$userd->ActualRegType;
            if($type>2)
            {
			    $image=DB::table('productimage')->where('CompanyId',$userd->CompanyRegId)
                    ->orderBy('ImageId', 'desc')
                    ->take(5)
                    ->get();
			}
			elseif($type>1)
			{
			    $image=DB::table('productimage')->where('CompanyId',$userd->CompanyRegId)
                    ->orderBy('ImageId', 'desc')
                    ->take(3)
                    ->get();
			}
            elseif($type>0)
            {
				$image=DB::table('productimage')->where('CompanyId',$userd->CompanyRegId)
                    ->orderBy('ImageId', 'desc')
                    ->take(1)
                    ->get();
			}
            else 
            {
			    $image=DB::table('productimage')->where('CompanyId',$userd->CompanyRegId)
                    ->orderBy('ImageId', 'desc')
                    ->take(0)
                    ->get();
			}
				
            $dpimage=DB::table('companyimage')
                ->where('CompanyId',$userd->CompanyRegId)
                ->get();
            
            $image_add=DB::table('productimage')
                  ->get();
        
            $addprofileimg =DB::table('classifiedimage')
                ->get();

		    return view('userdashboard')->with(array('addprofileimg'=>$addprofileimg,'image_add'=>$image_add,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'dpimage'=>$dpimage,'image'=>$image,'userdata'=>$userdata,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu,'userd'=>$userd,'classifieddata'=>$classifieddata));
		}
        else 
        {
		    $image_add=DB::table('productimage')
                ->get();
            $addprofileimg =DB::table('classifiedimage')->get();
		    return view('userdashboard')->with(array('addprofileimg'=>$addprofileimg,'image_add'=>$image_add,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'userdata'=>$userdata,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu,'userd'=>$userd,'classifieddata'=>$classifieddata));
		}
	}
    public function loggeduser()
    {
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();
            
        $category=DB::table('category')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();

        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();

        return redirect('/userdashboard')->with(array('category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
    }

    public function getemail(){
       
		$headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();

        $category=DB::table('category')
            ->get();

        $subcategory=DB::table('subcategory')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();

        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();

            return view('getemail')->with(array('subcategory'=>$subcategory,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
    }
public function uservalidation(Request $request)
{
	$userid=$request->user;
        
    $user_exist=DB::table('userregistration')
        ->where('Email',$userid)
        ->first();
		if(empty($user_exist))
		{
			return response([
                'success' => false,
                'message' => 'Адрес электронной почты не зарегистрирован'
            ], 403);
		}
        else 
        {
            $email_md5= md5($userid);
            $data = array('email'=>$userid,'name'=>$user_exist->Name,'user'=> $user_exist,'email_md5'=>$email_md5);
		
            Mail::send('change_password',$data,function($message) use($data){
                $message->to($data['email'],$data['email_md5'])
                    ->subject('Желтые страницы забыли пароль');
            });
		
		    return response([
                'success' => true,
                'message' => 'success'
            ], 200);
		}
    }

    public function forgotpassword(Request $request)
    {
        $this->validate($request,[
            'email' =>'required|email',
        ]);
        $url= $request->fullUrl();

        $email=$request->get('email');
        $email_md5= md5($email);
        
        $user=DB::table('userregistration')
            ->where('Email',$email)
            ->first();
        
        $data = array('email'=>$email,'name'=>$user->Name,'user'=> $user,'email_md5'=>$email_md5);
        
        Mail::send('change_password',$data,function($message) use($data){
            $message->to($data['email'],$data['email_md5'])
                ->subject('Желтые страницы забыли пароль');
        });
        return redirect('/login');
    }

    public function resetpswd(Request $request)
    {
        $email= $request->get('email');
      
        $user=DB::select('select * from userregistration where md5(Email) =?',[$email]);
        $id=$user[0]->UserRegId;
        $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $subcategory=DB::table('subcategory')
            ->get();
        
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();

        $category=DB::table('category')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();

        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();

        $userd=DB::table('userregistration')
            ->where('UserRegId',$id)
            ->first();
        
        return view('linkedpsdw')->with(array('anouncement'=>$anouncement,'subcategory'=>$subcategory,'userd'=>$userd,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));     
    }

    public function changelinkedpswd(Request $request)
    {
        $id= $request->input('id');
        $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $subcategory=DB::table('subcategory')
            ->get();
        
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();

        $category=DB::table('category')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();

        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();

        $newpassword=bcrypt($request->cnfpass);
       
        DB::table('userregistration')
            ->where('UserRegId', $id)
            ->update(array('Password' => $newpassword));
        return redirect('/profile')->with(array('anouncement'=>$anouncement,'subcategory'=>$subcategory,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
    }

    public function chpswd()
    {
		$id=Auth::user()->UserRegId;
        $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $subcategory=DB::table('subcategory')
            ->get();
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();

        $category=DB::table('category')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();

        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();

        $userd= DB::table('companyregistration')->where('UserRegId',$id)
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
            ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')
            ->first();
        return view('chpswd')->with(array('anouncement'=>$anouncement,'subcategory'=>$subcategory,'userd'=>$userd,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
    }

    public function updatepswd(Request $request)
    {
		$id=Auth::user()->UserRegId;
        $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $subcategory=DB::table('subcategory')
            ->get();

        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();

        $category=DB::table('category')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();

        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();

        $newpassword=bcrypt($request->cnfpass);

        $companyprofile= DB::table('companyregistration') 
            ->leftjoin('companyimage', 'companyimage.CompanyId', '=', 'companyregistration.CompanyRegId')          
		    ->where('IsApprove',1)
            ->where('ActualRegType',3)
		    ->orwhere('ActualRegType',2)
			->orderBy('CompanyRegId', 'desc')
            ->get();
        
        DB::table('userregistration')
            ->where('UserRegId', $id)
            ->update(array('Password' => $newpassword));
        return redirect('/chpswd')->with(array('status'=> 'Пароль успешно изменен','companyprofile'=>$companyprofile,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
    }

    public function emailcheck($email)
    {
        $count= DB::select('select count(*) from userregistration where  Email=?',[$email]);
        if($count==0)
        {
            return 'true';
        }
        else 
        {
            return 'false';
        }
        return "aaa";
    }

    public function uploadimage($id1,$id2)
    {
        $anouncement= DB::select('call Usp_GetAnnouncementList()');
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();

        $category=DB::table('category')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();

        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();

		$subcategory=DB::table('subcategory')
            ->get();
        
        $userd= DB::table('companyregistration')->where('UserRegId',$id1)
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
            ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')
            ->first();

        $data=DB::select('select * from productimage where  CompanyId=?',[$id2]);

        return view('imageupload')->with(array('subcategory'=>$subcategory,'userd'=>$userd,'data'=>$data,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
    }
    public function uploadproposal()
    {
        $id=Auth::user()->UserRegId;
        $anouncement= DB::select('call Usp_GetAnnouncementList()');
        
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

       $subcategory=DB::table('subcategory')
           ->get();

        $city=DB::table('city')
            ->get();

        $category=DB::table('category')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();

        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();

        $userd= DB::table('companyregistration')
            ->where('UserRegId',$id)
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
            ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')
            ->first();

        $classifieddata=DB::table('classifiedregistration')
            ->where('UserRegId',$id)
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.UserRegId')
            ->get(); 
        $data=DB::select('select * from companyproposal where  UserId=?',[$id]);
       
        return view('uploadproposal')->with(array('classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'userd'=>$userd,'data'=>$data,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
    }

    public function  saveproposal(Request $request)
    {
        $id=Auth::user()->UserRegId;
		$anouncement= DB::select('call Usp_GetAnnouncementList()');
        $subcategory=DB::table('subcategory')
            ->get();
        
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $city=DB::table('city')
            ->get();

        $category=DB::table('category')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();

        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();

        $userd= DB::table('companyregistration')->where('UserRegId',$id)
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
            ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')
            ->first();

        $classifieddata=DB::table('classifiedregistration')->where('UserRegId',$id)
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->leftjoin('productimage','productimage.ClassifiedRegId','=','classifiedregistration.ClassifiedRegId')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.UserRegId')
            ->get(); 

        $image = $request->file('ProposalUrl');
        $pathinfo= pathinfo($image->getClientOriginalName());
		$imgname=$pathinfo['filename'].'_'.time().'.'.$pathinfo['extension'];
      
        $image->move('public/Proposals', $imgname);

        $imagename= new companyproposal;
        $imagename->ProposalUrl=$imgname;
        $imagename->UserId=$id;

        $imagename->save();

        $data=DB::select('select * from companyproposal where  UserId=?',[$id]);
        return redirect('uploadproposal')->with(array('classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'userd'=>$userd,'data'=>$data,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
    }

    public function destroyproposal($proposalid)
    {
        $id=Auth::user()->UserRegId;
		$anouncement= DB::select('call Usp_GetAnnouncementList()');
        $headermenu= DB::table('headermenu')
            ->where('DisplaySection',3)
            ->get();

        $subcategory=DB::table('subcategory')
            ->get();

        $city=DB::table('city')
            ->get();

        $category=DB::table('category')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();

        $footersubmenu=DB::table('footersubmenu')
            ->where('MenuId',5)
            ->get();

        $userd= DB::table('companyregistration')
            ->where('UserRegId',$id)
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
            ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
            ->leftjoin('productimage','productimage.CompanyId','=','companyregistration.CompanyRegId')
            ->first();

        $classifieddata=DB::table('classifiedregistration')
            ->where('UserRegId',$id)
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
            ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
            ->leftjoin('productimage','productimage.ClassifiedRegId','=','classifiedregistration.ClassifiedRegId')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.UserRegId')
            ->get(); 
            
        CompanyProposal::where('Proposal_Id',$proposalid)
            ->delete();
		
		$data=DB::select('select * from companyproposal where  UserId=?',[$id]);
        return redirect('uploadproposal')->with(array('classifieddata'=>$classifieddata,'anouncement'=>$anouncement,'subcategory'=>$subcategory,'userd'=>$userd,'data'=>$data,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));

    }
	public function users_reply()
	{
		$anouncement= DB::select('call Usp_GetAnnouncementList()');
        $subcategory=DB::table('subcategory')
            ->get();
        
        $headermenu= DB::table('headermenu')
           ->where('DisplaySection',3)
           ->get();

        $city=DB::table('city')
            ->get();

        $category=DB::table('category')
            ->get();

        $banner=DB::table('bannerimage')
            ->where('IsActive', 1)
            ->get();

        $footersubmenu=DB::table('footersubmenu')
           ->where('MenuId',5)
           ->get();

		return view ('userregistrationreply')->with(array('anouncement'=>$anouncement,'subcategory'=>$subcategory,'category'=>$category,'city'=>$city,'headermenu'=>$headermenu,'city'=>$city,'category'=>$category,'banner'=>$banner,'footersubmenu'=>$footersubmenu));
	}
}
