<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Classified;
use DB;

class AdminController extends Controller
{
    public function index()
    {
        return view('Admin\login');
    }
   
    public function store(Request $request)
    {
        $input = $request->all();

        Classified::create($input);
        return redirect('/dashboard')->with('success','Classified Created');
    }
    
    public function doLogin(Request $request)
    {
        $classified= DB::table('classifiedregistration')
            ->leftJoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
            ->select('classifiedregistration.*', 'userregistration.Name', 'userregistration.Email','userregistration.Phone')
            ->get();
            
        return View('dashboard')->with('classified',$classified);
    }
}
