<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Company;
use App\City;
use DB;

class SuggestionController extends Controller
{
    public function suggestionCity($name)
    {
        $data = array();
        $char = $name;

        $cities = City::select('CityName')
            ->where('CityName', 'like', $char . '%')
            ->distinct('CityName')
            ->get();

        foreach($cities as $city)
        {
            $data[] = $city->CityName;
        }

        $result["Suggestions"]=$data;
        $result["Message"]=['Status' => 'Success','StatusMessage' => null];
        return json_encode($result, JSON_UNESCAPED_UNICODE);
    }

    public function suggestionCompany($name)
    {
        $data = array();
        $char = $name;

        $companies = Company::select('CompanyName')
            ->where('CompanyName', 'like', $char . '%')
            ->distinct('CompanyName')
            ->get();

        foreach($companies as $company)
        {
            $data[] = $company->CompanyName;
        }
        $result["Suggestions"]=$data;
        $result["Message"]=['Status' => 'Success','StatusMessage' => null];

        return json_encode($result, JSON_UNESCAPED_UNICODE);
    }
}
