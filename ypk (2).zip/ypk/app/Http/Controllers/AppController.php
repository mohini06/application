<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;

use DB;

class AppController extends Controller
{
    public function appVersion(Request $request)
    {
        $data = DB::table('androidversion')->get();
        return response()->json($data[0], 200);
    }
}
