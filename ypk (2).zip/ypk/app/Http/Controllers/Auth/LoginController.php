<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

use Illuminate\Http\Request; 

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/profile';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    /**
     * Get the needed authorization credentials from the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    protected function credentials(Request $request)
    {
        /*
			$field = filter_var($request->get($this->username()), FILTER_VALIDATE_EMAIL)
				? $this->username()
				: 'userid';

			return [
				$field => $request->get($this->username()),
				'password' => $request->password,
			];
		*/
		
		// set the remember me cookie if the user check the box
		/*$remember = (Input::has('remember')) ? true : false;
       
		// attempt to do the login
		$auth = Auth::attempt(
			[
				'username'  => strtolower(Input::get('username')),
				'password'  => Input::get('password')    
			], $remember
		);
		if ($auth) {
			return Redirect::to('home');
		} else {
			// validation not successful, send back to form 
			return Redirect::to('/')
				//->with Input(Input::except('password'))
				->with('flash_notice', 'Your username/password combination was incorrect.');
		}*/
		
		
		
    }

}
