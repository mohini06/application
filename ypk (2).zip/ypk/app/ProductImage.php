<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductImage extends Model
{
    protected $table='productimage';
    public $primarykey ='ImageId';
    public $timestamps=false;
}
