<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmailLog extends Model
{
    protected $table='Email_log';
    public $primarykey ='log_id';
    public $timestamps=false;
}
