<?php
namespace App\Helpers;
use Analytics;
use Spatie\Analytics\Period;
use Carbon\Carbon;

class GAHelper
{
	public function uniquePageviews()
	{
		$startDate=Carbon::parse('2017-03-30');
		$endDate=$endDate = Carbon::now();
		$period=Period::create($startDate, $endDate);
		$analyticsData = Analytics::performQuery(
		    $period,
		    'ga:sessions',
		    [
			'metrics' => 'ga:uniquePageviews'
		    ]
		);

		return $analyticsData['totalsForAllResults']['ga:uniquePageviews'];
	}
	public static function instance()
	{
	 return new GAHelper();
	}
     
}

