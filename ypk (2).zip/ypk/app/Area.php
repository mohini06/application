<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Area extends Model
{
    protected $table='area';
    public $primarykey ='AreaId';
    public $timestamps=false;

}
