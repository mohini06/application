<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Krossroad\UnionPaginator\UnionPaginatorTrait;
class Company extends Model
{
	use UnionPaginatorTrait;
    protected $table='companyregistration';
    public $primarykey ='CompanyRegId';
    public $timestamps=true;
    const CREATED_AT = 'DateOfReg';
    const UPDATED_AT = 'modifieddate';
    public $fillable  = [
        'CompanyName','Address1','Address2','State','StateName','PostalCode','Country','FaxNo','CategoryCode','SubCategoryCode','Status','DateOfReg','WebsiteLink','DescribeBusiness','CityName','City','Area','DateOfPost','CategoryName','oldStatus','Ranking','IsApprove','ExpiryDate','IsProfileEnabled','ModifiedBy',
        'ModifiedDate','AdminModifiedDate'
    ];
}

