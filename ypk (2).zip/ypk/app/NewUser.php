<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Classified;

class NewUser extends Model
{
    protected $table='userregistration';
    public $primarykey ='UserRegId';
    public $timestamps=false;
}
