<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Review extends Model
{
    public $timestamps=true;
    const CREATED_AT = 'DateOfPost';
    const UPDATED_AT = 'modifieddate';
    protected $table='review';
    public $primarykey ='ReviewId';
}
