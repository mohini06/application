<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompanyProposal extends Model
{
    protected $table='companyproposal';
    public $primarykey ='Proposal_Id';
    public $timestamps=false;
}
