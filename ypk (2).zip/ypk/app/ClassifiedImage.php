<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClassifiedImage extends Model
{
    protected $table='classifiedimage';
    public $primarykey ='ImageId';
    public $timestamps=false;
}
