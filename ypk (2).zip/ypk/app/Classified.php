<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Krossroad\UnionPaginator\UnionPaginatorTrait;
class Classified extends Model
{
	use UnionPaginatorTrait;
    protected $table='classifiedregistration';
    public $primarykey ='ClassifiedRegId';
    public $timestamps=true;
    const CREATED_AT = 'PostedDate';
    const UPDATED_AT = 'ModifiedDate';
    public $fillable  = [
        'ClassifiedTitle','CategoryCode','SubCategoryCode','email','name','city','mobile','phone','ClassifiedContent','url','UserRegId','PostedDate','ModifiedDate',
    ];
}
