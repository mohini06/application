<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;
use App\Mail\Email;
use Mail;
use App\EmailLog;
class MonthlyReport extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'monthlyreport:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'YPK monthly report';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
       
// foreach ($user as $a)
// {
      $todays_date=now();
      $year=now()->year;
      $monthlyreport=DB::select('call Usp_GetYPKRevenueEntityReport(?,?)',array('2018-06-01','2018-06-01'));
      $registration_detailed_report=DB::select('call Usp_GetCountOfNewlyRegisteredRecords(?,?,?)',array( '2018-07-01','2018-07-31','2018-01-01'));
    
   
	   $data=array('email'=>'mohinig@datatemplate.in','registration_details'=> $registration_detailed_report,'revenue_details'=>$monthlyreport);
   
     Mail::send(['html'=>'revenueEntityMail'],$data,function($message) use($data)
 
     {   $message->to($data['email'])
       ->subject('Yellow Pages Kazakhstan - Revenue Entity Report');
        
     }); 

		   
		 Mail::send(['html'=>'monthlyreport'],$data,function($message) use($data)
 
   {   $message->to($data['email'])
	   ->subject('Yellow Pages Kazakhstan - Registration Detail Report');
      
   });
   if(Mail::failures()){
    $log=new EmailLog;
    $log->Email='mohinig@datatemplate.in';
    $log->Type='test';
    $log->UserId=0;
    $log->Type_Id=0;
    $log->Subject="Yellow Pages –testing";
    $log->Status='Fails';
      $log->save();    
   }
   else {
     $log=new EmailLog;
    $log->Email='mohinig@datatemplate.in';
    $log->Type='test';
    $log->UserId=0;
    $log->Type_Id=0;
    $log->Subject="Yellow Pages –testing";
    $log->Status='Success';
      $log->save();
   }
  
	   
  }
 // $this->info('Aniversary CongratsMail has been send successfully');
    
}
