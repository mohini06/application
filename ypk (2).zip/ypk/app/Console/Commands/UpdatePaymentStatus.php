<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;
use App\Mail\Email;
use Mail;
use App\EmailLog;



class UpdatePaymentStatus extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'PaymentStatus:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Payment Status of User';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
         $user_company = DB::table('companyregistration')
	    // ->whereRaw('(ActualRegType)>0')
		->whereRaw('DATE(ExpiryDate)= curdate()')
		->leftjoin('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
	    ->select('companyregistration.ActualRegType','companyregistration.ExpiryDate','companyregistration.CompanyRegId','userregistration.*')
	    ->get();
      
foreach ($user_company as $a)
{
	
	    $todays=now();
	   $expirydate=$a->ExpiryDate;
	   $name=$a->Name;
	   $email=$a->Email;
	   $UserRegId=$a->UserRegId;
	   $companyid=$a->CompanyRegId;
	   $phone=$a->Phone;
	   $type='Company';
	   $payment=$a->ActualRegType;
	   if($payment==1){
		   $paymenttype=="Siver";
	   }
	   elseif($payment==2)
	   {
		   $paymenttype="Gold";
	   }
	   elseif($payment==3)
	   {
		   $paymenttype=="Premium";
	   }
	   else {
		   $paymenttype="";
	   }
	   $data=array('name'=>$name,'phone'=>$phone,'email'=>$email,'type'=>$type,'UserRegId'=>$UserRegId,'paymenttype'=>$paymenttype);
	  
		 // return $data;  
		 Mail::send(['html'=>'UpdatePaymentStatusMail'],$data,function($message) use($data)
 
   {   $message->to('mohinijha06@gmail.com')
	   ->subject('Yellow Pages – UpdatePaymentStatus');
       
   });
   
   if(Mail::failures()){
	  $log=new EmailLog;
	  $log->Email=$email;
	  $log->Type=$type;
	  $log->UserId=$UserRegId;
	  $log->Type_Id=$companyid;
	  $log->Subject="Yellow Pages- UpdatePaymentStatus";
	  $log->Status='Fails';
      $log->save();	   
   }
   else {
	   $log=new EmailLog;
	  $log->Email=$email;
	  $log->Type=$type;
	  $log->UserId=$UserRegId;
	  $log->Type_Id=$companyid;
	  $log->Subject="Yellow Pages – UpdatePaymentStatus";
	  $log->Status='Success';
      $log->save();
   }
	   
 }
 $user_classified = DB::table('classifiedregistration')
	    ->whereRaw('(ActualRegType)>0')
		->whereRaw('DATE(ExpiryDate)= curdate()')
		->leftjoin('userregistration','userregistration.UserRegId','=','classifiedregistration.UserRegId')
	    ->select('classifiedregistration.ExpiryDate','classifiedregistration.ClassifiedRegId','userregistration.*')
	    ->get();
      
foreach ($user_classified as $a)
{
	    $todays=now();
	   $expirydate=$a->ExpiryDate;
	   $name=$a->Name;
	   $email=$a->Email;
	   $UserRegId=$a->UserRegId;
	   $type='Classified';
	   $payment=$a->ActualRegType;
	   if($payment==1){
		   
		   $paymenttype=="Premium";
	   }
	   else {
		   $paymenttype="";
	   }
	   $data=array('name'=>$name,'email'=>$email,'type'=>$type,'UserRegId'=>$UserRegId,'paymenttype'=>$paymenttype);
	  
		   
		 Mail::send(['html'=>'UpdatePaymentStatusMail'],$data,function($message) use($data)
 
   {       $message->to('mohinijha06@gmail.com')
	   ->subject('Yellow Pages – updatepaymentstatus');
       // $message->from('infoypkteam@gmail.com');
   });
   if(Mail::failures()){
	  $log=new EmailLog;
	  $log->Email=$email;
	  $log->Type=$type;
	  $log->UserId=$UserRegId;
	  $log->Type_Id=$classifiedid;
	  $log->Subject="Yellow Pages – updatepaymentstatus";
	  $log->Status='Fails';
      $log->save();	
   }
   else {
	    $log=new EmailLog;
	  $log->Email=$email;
	  $log->Type=$type;
	  $log->UserId=$UserRegId;
	  $log->Type_Id=$classifiedid;
	  $log->Subject="Yellow Pages – updatepaymentstatus";
	  $log->Status='Success';
      $log->save();	
   }
 
    }
	$this->info('Payment Status has been send successfully');
}
}