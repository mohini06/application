<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;
use App\Mail\Email;
use Mail;
use App\EmailLog;
class AniversaryWithUs extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'AniversaryWithUs:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Thanking Mail to complete one year with us';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
         $user_company1 = DB::table('companyregistration')
	    ->whereRaw('(ActualRegType)>0')
		->leftjoin('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
	    ->whereRaw('month(DateOfReg)=month(curdate()) AND day(DateOfReg)=day(curdate()) ')
		 ->select('companyregistration.DateOfReg','companyregistration.CompanyRegId','userregistration.*')
	    ->get();
      
foreach ($user_company1 as $a)
{
	    $todays=now();
	   $expirydate=$a->DateOfReg;
	   $name=$a->Name;
	   $email=$a->Email;
	   $UserRegId=$a->UserRegId;
	   $companyid=$a->CompanyRegId;
	   $phone=$a->Phone;
	   $type='Company';
	   $year=5;
	   $data=array('name'=>$name,'email'=>$email,'phone'=>$phone,'type'=>$type,'UserRegId'=>$UserRegId);
	  
		   
		 Mail::send(['html'=>'AniversaryWithUs'],$data,function($message) use($data)
 
   {   $message->to($data['email'])
	   ->subject('Yellow Pages – Thanking Mail to be with us ');
       // $message->from('infoypkteam@gmail.com');
   });
   
   if(Mail::failures()){
	  $log=new EmailLog;
	  $log->Email=$email;
	  $log->Type=$type;
	  $log->UserId=$UserRegId;
	  $log->Type_Id=$companyid;
	  $log->Subject="Yellow Pages – Thanking Mail to be with us";
	  $log->Status='Fails';
      $log->save();	   
   }
   else {
	   $log=new EmailLog;
	  $log->Email=$email;
	  $log->Type=$type;
	  $log->UserId=$UserRegId;
	  $log->Type_Id=$companyid;
	  $log->Subject="Yellow Pages – Thanking Mail to be with us";
	  $log->Status='Success';
      $log->save();
   }
	   
 }
   $user_classified1 = DB::table('classifiedregistration')
	    ->whereRaw('(ActualRegType)>0')
		->leftjoin('userregistration','userregistration.UserRegId','=','classifiedregistration.UserRegId')
	   ->whereRaw('month(PostedDate)=month(curdate()) AND day(PostedDate)=day(curdate()) ')
		
		->select('classifiedregistration.PostedDate','classifiedregistration.ClassifiedRegId','userregistration.*')
	    ->get();
      
foreach ($user_classified1 as $a)
{
	    $todays=now();
	
	   $name=$a->Name;
	   $email=$a->Email;
	   $UserRegId=$a->UserRegId;
	   $classifiedid=$a->ClassifiedRegId;
	   $type='Classified';
	 
	   $data=array('name'=>$name,'email'=>$email,'type'=>$type,'UserRegId'=>$UserRegId);
	  
		   
		 Mail::send(['html'=>'AniversaryWithUs'],$data,function($message) use($data)
 
   {       $message->to($data['email'])
	   ->subject('Yellow Pages – Thanking Mail to be with us');
       // $message->from('infoypkteam@gmail.com');
   });
   if(Mail::failures()){
	   $log=new EmailLog;
	  $log->Email=$email;
	  $log->Type=$type;
	  $log->UserId=$UserRegId;
	  $log->Type_Id=$classifiedid;
	  $log->Subject="Yellow Pages – Thanking Mail to be with us";
	  $log->Status='Fails';
      $log->save();	 
   }
   else {
	    $log=new EmailLog;
	  $log->Email=$email;
	  $log->Type=$type;
	  $log->UserId=$UserRegId;
	  $log->Type_Id=$classifiedid;
	  $log->Subject="Yellow Pages – Thanking Mail to be with us";
	  $log->Status='Success';
      $log->save();	
   }
	   
 }
 $this->info('Thanking Mailhas been send successfully'); 
    }
}
