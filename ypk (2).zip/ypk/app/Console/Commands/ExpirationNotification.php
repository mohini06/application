<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;
use App\Mail\Email;
use Mail;
use App\EmailLog;

class ExpirationNotification extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'expiration:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send Expiry Date notification to all the user ';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
	
       $user_company1 = DB::table('companyregistration')
	    ->whereRaw('(ActualRegType)>0')
		->leftjoin('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
	    ->whereRaw('DATE(ExpiryDate)= DATE_SUB(curdate(), INTERVAL 5 DAY)')
		 ->select('companyregistration.ExpiryDate','companyregistration.CompanyRegId','userregistration.*')
	    ->get();
      
foreach ($user_company1 as $a)
{
	    $todays=now();
	   $expirydate=$a->ExpiryDate;
	   $name=$a->Name;
	   $email=$a->Email;
	   $UserRegId=$a->UserRegId;
	   $companyid=$a->CompanyRegId;
	   $type='Company';
	   $pending_days=5;
	   $data=array('name'=>$name,'email'=>$email,'type'=>$type,'UserRegId'=>$UserRegId,'pending_days'=>$pending_days);
	  
		   
		 Mail::send(['html'=>'expiryemailnotification'],$data,function($message) use($data)
 
   {   $message->to($data['email'])
	   ->subject('Yellow Pages – Уведомление об истечении срока действия приобретенного вами статуса');
       // $message->from('infoypkteam@gmail.com');
   });
   
   if(Mail::failures()){
	  $log=new EmailLog;
	  $log->Email=$email;
	  $log->Type=$type;
	  $log->UserId=$UserRegId;
	  $log->Type_Id=$companyid;
	  $log->Subject="Yellow Pages – Уведомление об истечении срока действия приобретенного вами статуса";
	  $log->Status='Fails';
      $log->save();	   
   }
   else {
	   $log=new EmailLog;
	  $log->Email=$email;
	  $log->Type=$type;
	  $log->UserId=$UserRegId;
	  $log->Type_Id=$companyid;
	  $log->Subject="Yellow Pages – Уведомление об истечении срока действия приобретенного вами статуса";
	  $log->Status='Success';
      $log->save();
   }
	   
 }
  $user_company2 = DB::table('companyregistration')
	    ->whereRaw('(ActualRegType)>0')
		->leftjoin('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
	    ->whereRaw('DATE(ExpiryDate)= DATE_SUB(curdate(), INTERVAL 2 DAY)')
		->select('companyregistration.ExpiryDate','companyregistration.CompanyRegId','userregistration.*')
	    ->get();
      
foreach ($user_company2 as $a)
{
	    $todays=now();
	   $expirydate=$a->ExpiryDate;
	   $name=$a->Name;
	   $email=$a->Email;
	   $UserRegId=$a->UserRegId;
	   $pending_days=2;
	   $type='Company';
	   $data=array('name'=>$name,'email'=>$email,'type'=>$type,'UserRegId'=>$UserRegId,'pending_days'=>$pending_days);
	  
		   
		 Mail::send(['html'=>'expiryemailnotification'],$data,function($message) use($data)
 
   {       $message->to($data['email'])
	   ->subject('Yellow Pages – Уведомление об истечении срока действия приобретенного вами статуса');
       // $message->from('infoypkteam@gmail.com');
   });
   if(Mail::failures()){
	   $log=new EmailLog;
	  $log->Email=$email;
	  $log->Type=$type;
	  $log->UserId=$UserRegId;
	  $log->Type_Id=$companyid;
	  $log->Subject="Yellow Pages – Уведомление об истечении срока действия приобретенного вами статуса";
	  $log->Status='Fails';
      $log->save();	 
   }
   else {
	   $log=new EmailLog;
	  $log->Email=$email;
	  $log->Type=$type;
	  $log->UserId=$UserRegId;
	  $log->Type_Id=$companyid;
	  $log->Subject="Yellow Pages – Уведомление об истечении срока действия приобретенного вами статуса";
	  $log->Status='Success';
      $log->save();	 
   }
	   
 }
 
  $user_classified1 = DB::table('classifiedregistration')
	    ->whereRaw('(ActualRegType)>0')
		->leftjoin('userregistration','userregistration.UserRegId','=','classifiedregistration.UserRegId')
	    ->whereRaw('DATE(ExpiryDate)= DATE_SUB(curdate(), INTERVAL 5 DAY)')
		
		->select('classifiedregistration.ExpiryDate','classifiedregistration.ClassifiedRegId','userregistration.*')
	    ->get();
      
foreach ($user_classified1 as $a)
{
	    $todays=now();
	   $expirydate=$a->ExpiryDate;
	   $name=$a->Name;
	   $email=$a->Email;
	   $UserRegId=$a->UserRegId;
	   $classifiedid=$a->ClassifiedRegId;
	   $type='Classified';
	   $pending_days=5;
	   $data=array('name'=>$name,'email'=>$email,'type'=>$type,'UserRegId'=>$UserRegId,'pending_days'=>$pending_days);
	  
		   
		 Mail::send(['html'=>'expiryemailnotification'],$data,function($message) use($data)
 
   {       $message->to($data['email'])
	   ->subject('Yellow Pages – Уведомление об истечении срока действия вашего объявления');
       // $message->from('infoypkteam@gmail.com');
   });
   if(Mail::failures()){
	   $log=new EmailLog;
	  $log->Email=$email;
	  $log->Type=$type;
	  $log->UserId=$UserRegId;
	  $log->Type_Id=$classifiedid;
	  $log->Subject="Yellow Pages – Уведомление об истечении срока действия приобретенного вами статуса";
	  $log->Status='Fails';
      $log->save();	 
   }
   else {
	    $log=new EmailLog;
	  $log->Email=$email;
	  $log->Type=$type;
	  $log->UserId=$UserRegId;
	  $log->Type_Id=$classifiedid;
	  $log->Subject="Yellow Pages – Уведомление об истечении срока действия приобретенного вами статуса";
	  $log->Status='Success';
      $log->save();	
   }
	   
 }
  $user_classified2 = DB::table('classifiedregistration')
	    ->whereRaw('(ActualRegType)>0')
		->leftjoin('userregistration','userregistration.UserRegId','=','classifiedregistration.UserRegId')
	    ->whereRaw('DATE(ExpiryDate)= DATE_SUB(curdate(), INTERVAL 2 DAY)')
		
		->select('classifiedregistration.ExpiryDate','classifiedregistration.ClassifiedRegId','userregistration.*')
	    ->get();
      
foreach ($user_classified2 as $a)
{
	    $todays=now();
	   $expirydate=$a->ExpiryDate;
	   $name=$a->Name;
	   $email=$a->Email;
	   $UserRegId=$a->UserRegId;
	   $type='Classified';
	   $pending_days=2;
	   $data=array('name'=>$name,'email'=>$email,'type'=>$type,'UserRegId'=>$UserRegId,'pending_days'=>$pending_days);
	  
		   
		 Mail::send(['html'=>'expiryemailnotification'],$data,function($message) use($data)
 
   {       $message->to($data['email'])
	   ->subject('Yellow Pages – Уведомление об истечении срока действия вашего объявления');
       // $message->from('infoypkteam@gmail.com');
   });
   if(Mail::failures()){
	  $log=new EmailLog;
	  $log->Email=$email;
	  $log->Type=$type;
	  $log->UserId=$UserRegId;
	  $log->Type_Id=$classifiedid;
	  $log->Subject="Yellow Pages – Уведомление об истечении срока действия приобретенного вами статуса";
	  $log->Status='Fails';
      $log->save();	
   }
   else {
	    $log=new EmailLog;
	  $log->Email=$email;
	  $log->Type=$type;
	  $log->UserId=$UserRegId;
	  $log->Type_Id=$classifiedid;
	  $log->Subject="Yellow Pages – Уведомление об истечении срока действия приобретенного вами статуса";
	  $log->Status='Success';
      $log->save();	
   }
	   
 }
 
   $this->info('Expiry Update has been send successfully');
   
    }
}
