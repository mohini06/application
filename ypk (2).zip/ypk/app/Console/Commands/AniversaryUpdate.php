<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;
use App\Mail\Email;
use Mail;
use App\EmailLog;
class AniversaryUpdate extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'aniversary:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Congrating for Aniversary';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $user_company1 = DB::table('companyregistration')
	    ->whereRaw('(ActualRegType)>0')
		->leftjoin('userregistration','userregistration.UserRegId','=','companyregistration.UserRegId')
	    ->whereRaw('month(dateofincorporation)=month(curdate()) AND day(dateofincorporation)=day(curdate())')
		 ->select('companyregistration.dateofincorporation','companyregistration.CompanyRegId','userregistration.*')
	    ->get();
      
foreach ($user_company1 as $a)
{
	    $todays=now();
	   $expirydate=$a->dateofincorporation;
	   $name=$a->Name;
	   $email=$a->Email;
	   $UserRegId=$a->UserRegId;
	   $companyid=$a->CompanyRegId;
	   $phone=$a->Phone;
	   $type='Company';
	   $year=5;
	   $data=array('name'=>$name,'phone'=>$phone,'email'=>$email,'type'=>$type,'UserRegId'=>$UserRegId);
	  
		   
		 Mail::send(['html'=>'AniversaryCongratsMail'],$data,function($message) use($data)
 
   {   $message->to($data['email'])
	   ->subject('Yellow Pages – Congratulation Mail For your  Aniversary');
       // $message->from('infoypkteam@gmail.com');
   });
   
   if(Mail::failures()){
	  $log=new EmailLog;
	  $log->Email=$email;
	  $log->Type=$type;
	  $log->UserId=$UserRegId;
	  $log->Type_Id=$companyid;
	  $log->Subject="Yellow Pages – Congratulation Mail For your  Aniversary";
	  $log->Status='Fails';
      $log->save();	   
   }
   else {
	   $log=new EmailLog;
	  $log->Email=$email;
	  $log->Type=$type;
	  $log->UserId=$UserRegId;
	  $log->Type_Id=$companyid;
	  $log->Subject="Yellow Pages – Congratulation Mail For your  Aniversary";
	  $log->Status='Success';
      $log->save();
   }
	   
 }
 $this->info('Aniversary CongratsMail has been send successfully');
    }
}
