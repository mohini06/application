<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HeaderMenu extends Model
{
    protected $table=' headermenu';
    public $primarykey ='MenuId';
    public $timestamps=false;
}
