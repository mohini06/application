<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Subcategory;

class Category extends Model
{
    protected $table='category';
    public $primarykey ='CategoryId';
    public $timestamps=false;

    public function subcategory()
    {
        return $this->hasMany('App\SubCategory');
    }
}
