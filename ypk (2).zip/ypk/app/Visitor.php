<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Visitor extends Model
{
    protected $table='sitecounter';
    public $primarykey ='SiteCounterId';
    public $timestamps=false;
}
