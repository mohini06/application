<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('welcome');
//});

Route::post('uservalidation',array('uses'=>'RegistrationController@doLogin'));
Route::post('validateregistereduser',array('uses'=>'RegistrationController@uservalidation'));
Route::get('privacy-policy','UiController@privacyPolicy');
Route::get('userlogin','RegistrationController@showLogin');
//Route::post('/edit',array('uses'=>'ClassifiedController@edit'));
//Route::post('/ypk/updatepswd',array('uses' => 'RegistrationController@updatepswd'));
//Route::get('profile','RegistrationController@doLogin');
Route::post('profile',array('uses' => 'RegistrationController@doLogin'));
Route::post('edit',array('uses' => 'ClassifiedController@edit'));
Route::resource('adminlogin','AdminController');
Route::post('dashboard',array('uses' => 'AdminController@doLogin'));
//Route::post('userdashboard',array('uses' => 'RegistrationController@loggeduser'));
Route::get('userdashboard','RegistrationController@loggeduser');
Route::get('replytomail','RegistrationController@users_reply');
Route::post('sendreplytoadmin',array('uses'=>'RegistrationController@sendreplytoadmin'));
//Route::get('store','StoreController@index');
//Route::group(['middleware'=>'web'],function(){
//    Route::resource('home','ClassifiedController');
//
//});
//Route::get('form-validation', 'ClassifiedController@formValidation');
Route::post('form-validation', array('uses' => 'ClassifiedController@store'));
Route::get('getemail','RegistrationController@getemail');
Route::get('forgotpassword',array('uses' => 'RegistrationController@forgotpassword'));
Route::get('resetpswd',array('uses'=>'RegistrationController@resetpswd'));
Route::post('passwordupdate',array('uses'=>'RegistrationController@changelinkedpswd'));

//Route::get('api/dependent-dropdown','ClassifiedController@index');
//Route::get('/subcategory/{id}','ClassifiedController@getSubcategoryList');
Route::post('subcategory',array('uses'=>'ClassifiedController@getSubcategoryList'));




//company Controller

Route::get('company-registration','CompanyController@index');
Route::post('companyregistration',array('uses' => 'CompanyController@store'));
Route::post('subcategory_list',array('uses' => 'UiController@subcategory_list'));

Route::get('test','UiController@test');

Route::get('search',array('uses' => 'SearchController@search'));
Route::get('advsearch',array('uses' => 'SearchController@advsearch'));
Route::post('searchcompany',array('uses' => 'SearchController@searchcompany'));
Route::post('share',array('uses' => 'CompanyController@sharedetail'));
Route::get('companydetail/{id}','CompanyController@companydetail');
Route::post('claim_file',array('uses' => 'SearchController@claim_flag'));
Route::get('classifieddetail/{id}','ClassifiedController@classifieddetail');
Route::get('view/{id}','CompanyController@viewmap');
Route::get('classified_view/{id}','ClassifiedController@viewmap');
Route::post('reviewadd/{companyid}',array('uses' => 'CompanyController@reviewadd'));
Route::post('classifiedreviewadd/{classifiedregid}',array('uses' => 'ClassifiedController@reviewadd'));


//   Contact Us

Route::get('contact-us','UiController@contact');
Route::post('enquiry',array('uses'=>'UiController@enquiry'));
Route::get('classified-help','UiController@classified_help');
Route::get('company-help','UiController@company_help');
Route::get('check','UiController@checkvalidation');
Route::post('checking',array('uses'=>'UiController@checking'));


//test

Route::get('searchcat','StoreController@testcat');
Route::get('success','CompanyController@success');



//check email validation
 Route::get('check-email/{data}','RegistrationController@emailcheck');



Route::resource('/','ClassifiedController');
Route::get('post-free-classifieds','ClassifiedController@create');
Route::get('login','ClassifiedController@index');
Route::resource('userlogin','RegistrationController');
Route::post('login/', 'Auth\LoginController@login')->name('login');
Route::post('logout', 'Auth\LoginController@logout')->name('logout');

//Registration Routes...
Route::get('register/', 'Auth\RegisterController@showRegistrationForm')->name('register');
Route::post('register/', 'Auth\RegisterController@register');

// Password Reset Routes...
Route::get('password/reset', 'Auth\ForgotPasswordController@showLinkRequestForm')->name('password.request');
Route::post('password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail');
Route::get('password/reset/{token}', 'Auth\ResetPasswordController@showResetForm')->name('password.reset');
Route::post('password/reset', 'Auth\ResetPasswordController@reset');
// Route::get('/', 'HomeController@index');

Route::group(['middleware'=>'auth'], function () {
	//My Profile
Route::get('/profile','RegistrationController@myprofile');
Route::get('/review','CompanyController@review');
Route::get('/edit','ClassifiedController@edit');
Route::post('update/{id}',array('uses' => 'ClassifiedController@update'));
Route::post('storeclassified',array('uses' => 'CompanyController@storeclassified'));
Route::get('/addclassified','CompanyController@addclassified');
Route::get('/editcom','CompanyController@edit');
Route::post('updatecompanydata',array('uses' => 'CompanyController@update'));
Route::post('/updateclassified',array('uses'=>'ClassifiedController@update'));
//Review

Route::post('replyReview/{id}',array('uses' => 'CompanyController@replyReview'));
Route::get('removeReview/{id}','CompanyController@removeReview');
Route::post('replyReview_add/',array('uses' => 'ClassifiedController@replyReview_add'));
Route::get('removeReview_add/{reviewid}','ClassifiedController@removeReview_add');

// Upload product Image
Route::get('uploadprofilepic/','CompanyController@upload');
Route::get('uploadimage/{id}','RegistrationController@uploadimage');
Route::post('savecomimg',array('uses'=>'CompanyController@storeimage'));
Route::get('uploadproductimg','CompanyController@uploadproductimg');
Route::get('uploadproposal','RegistrationController@uploadproposal');
Route::post('saveproductimg',array('uses' => 'CompanyController@saveproductimg'));
Route::post('saveproposal',array('uses' => 'RegistrationController@saveproposal'));
Route::get('removeimg/{imageid}','CompanyController@destroyimage');
Route::get('removeproposal/{proposalid}','RegistrationController@destroyproposal');
Route::post('saveaddimg',array('uses'=>'ClassifiedController@storeaddprofile'));
Route::post('saveproductimg_add',array('uses' => 'ClassifiedController@saveproductimg'));
// Change password

Route::post('updatepswd',array('uses' => 'RegistrationController@updatepswd'));
Route::get('/chpswd','RegistrationController@chpswd');

//add company for user
Route::get('/addcompany_classified','ClassifiedController@addcompany');
Route::post('/storecompany',array('uses' => 'ClassifiedController@storecompany'));
});

Route::get('/chpswd/{id}','RegistrationController@chpswd');
Route::post('updatepswd/{id}',array('uses' => 'RegistrationController@updatepswd'));



//news
Route::get('news','UiController@shownews');



Route::get('test',function()
{
    return view('cat_subcat');
});





Route::get('/count', 'UiController@visitors_count');


//Mobile Api routes

Route::post('api/login', 'PassportController@login');
Route::post('api/register', 'PassportController@register');

Route::middleware('auth:api')->group(function () {
    Route::get('api/user', 'PassportController@details');

    Route::get('api/citySuggestions/{name}', 'SuggestionController@suggestionCity');
    Route::get('api/companySuggestions/{name}', 'SuggestionController@suggestionCompany');
    Route::get('api/GetVersion', 'AppController@appVersion');
    Route::get('api/BannerImages', 'BannerController@bannerCompany');
    Route::post('api/FindCompany', 'FindController@search');
    Route::get('api/company/{id}', 'SearchController@company_search');
});




