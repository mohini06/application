@extends('profilemenu')
@section('mycontent')
<div class="col-md-9">

 <ul id="tabs_classified">
    <li ><a href="#" name="tab1" class="tab_text" style="font-weight: 500"><i class="menu_icon2 fa fa-user" aria-hidden="true" ></i>{{__('message.Proposals')}}</a></li>
</ul>

<div id="tab_content">
    <div id="tab1">
	  <p>{{__('message.You can upload proposal of docs,plain text, pdf')}}</p>
     <div id="showing">
      @foreach($data as $file)

        {{--<img src="{{asset('public/ProductImages')}}/{{$file->ImageUrl}}" style="height:100px; width: 100px;">--}}

     <a class="dropdown-item" href="{{asset('public/Proposals')}}/{{$file->ProposalUrl}}"><i class="fa fa-download" aria-hidden="true"></i>{{$file->ProposalUrl}}</a>
       <a href="{{url('/removeproposal')}}/{{$file->Proposal_Id}}">{{__('message.Remove')}}</a>

      @endforeach
      <form action="{{url('/saveproposal')}}" method="post" enctype="multipart/form-data">
             <input type="hidden" name="_token" value="{{ csrf_token()}}">

         <input type="file" id="proposal" accept="application/msword,text/plain,application/pdf" name="ProposalUrl" required>
            <input type="submit" class="upload"value="{{__('message.Upload')}}" onclick ="fileValidation()" class="btn btn-lg"/>

      </form>
      </div>
    </div>
</div>
</div>
@endsection