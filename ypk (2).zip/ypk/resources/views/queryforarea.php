<?php
include "db.php";
$city_id = $_REQUEST['city_id'];
echo $sql="SELECT * FROM area where CityId=$city_id";
$result=$db->query($sql);
$output=array();
if(count($result)>0){
    while($row = $result->fetch(PDO::FETCH_ASSOC)){
        echo '<option value="">'. 'Выберите район' .'</option>';
        echo '<option value="'.$row['AreaId'].'">'.$row['AreaName'].'</option>';
    }
}else
    echo '<option>NO data available</option>';
?>