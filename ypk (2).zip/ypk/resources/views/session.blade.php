<?php
 if(!isset($user)){
    header("Location: /ypk/userlogin");
    exit();
 }
 else{
    header('location: /ypk/userdashboard');
    exit();
 }
 ?>