@extends('layouts.app')
@section('content')
     <script>
$(document).ready(function () {
         // Handler for .ready() called.
         $('html, body').animate({
             scrollTop: 560
         }, 2000);
     }); </script>
     
<div class="clearfix"></div>
<div class="row">
    <div class="col-md-12" style="padding-left: 0px;padding-right: 0px;">
        <div class="col-md-6">
            <h3 class="headerline"> {{__('message.Reply')}} </h3>
        </div>
        
    </div>
   
</div>
<!--rami-->
<div class="col-md-12 no-padding">
    <div class="content-section">

        <div class="row">

            <div class="col-md-9" style=" background: #ffffff; padding: 15px 20px;">
                <form method="POST" id="replyForadmin" action="{{url('/sendreplytoadmin')}}" role="form">
                  <input type="hidden" name="_token" value="{{ csrf_token()}}">
                  
                    <div class="row">
                    
                        <div class=" col-md-8 user-input-wrp">
                            <br/>
                            <span class="headline" style="margin-left: 4px;margin-top: 4px; position: absolute;">{{__('message.Comments')}}<span style="color:red;">*</span></span>
                             <textarea placeholder="{{__('message.This is an awesome comment box')}}" rows="50" id="userresponse" name="userresponse"  cols="40" class="responsebox ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true" style="resize:none !important;"></textarea>
       
            </div>
                    </div>
                  
                    <div class="row">
                        <div style="float:right;padding-top: 20px;padding-left: 15px;">
                            <input type="submit" class="btn-grad" value="{{__('message.Send')}}"  style=" margin-right:15px; height:40px; width:100px;" />
                            <a href="{{url('/')}}">
                            <input type="button" class="btn-grad" value="{{__('message.cancel')}}" style=" height:40px; width:100px;"/></a>
                            <p style="color: #28a745;font-size: 16px;display: inline; padding-left:10px;"> {{ session('status') }}</p>
                         </div>
                    </div>
                    
                </form>
            </div>

            <div class="col-md-3 mobile-padding">
                <!--rami-->
                <div style="background: #fff;">
                    <center>
                        <div class="post" style="padding:15px 20px;">
                            <h4>{{__('message.Post free classifieds')}}</h4>
                            <img src="{{asset('/public/Images/guarantee.png')}}" class="img-responsive guarantee" alt="guarantee" />
                            <p style="text-align: justify;">{{__('message.guarenteedescription')}} </p>

                        </div>
                    </center>
                </div>
            </div>
        </div>

    </div>
</div>
@endsection