@extends('layouts.app')
@section('content')
 <script>
$(document).ready(function () {
         // Handler for .ready() called.
         $('html, body').animate({
             scrollTop: 560
         }, 2000); 
  });  
</script>
    <div class="container">
    <div class="row">

            <div class="col-md-3" style="margin-bottom: 15px;"><!-- rami -->
               <div class="menu_container" style="text-decoration: none;">
  <a href="{{url('/profile')}}" ><div class="menu_link" >
      <div class="menu_text" ><i class="menu_icon fa fa-user" aria-hidden="true" style="color:#ffce00;"></i>{{__('message.Profile')}}</div>
      </div></a>
  <a href="{{url('/review')}}" ><div class="menu_link">
    <div class="menu_text"><i class="menu_icon fa fa-check-square-o" aria-hidden="true" style="color:#ffce00;"></i>{{__('message.Review')}}</div>
      </div></a>
  <a href="{{url('/editcom')}}"><div class="menu_link">
    <div class="menu_text"><i class="menu_icon fa fa-pencil-square-o" aria-hidden="true" style="color:#ffce00;"></i>{{__('message.Edit Details')}}</div>
      </div></a>
  <a href="{{url('/uploadproductimg')}}"><div class="menu_link">
    <div class="menu_text"><i class="menu_icon fa fa-cloud-upload" aria-hidden="true" style="color:#ffce00;"></i>{{__('message.Upload Product Image')}}</div>
      </div></a>
      <a href="{{url('/uploadproposal')}}"><div class="menu_link">
          <div class="menu_text"><i class="menu_icon fa  fa-book" aria-hidden="true" style="color:#ffce00;"></i>{{__('message.Upload Your Proposal')}} </div>
            </div></a>

  <a href="{{url('/chpswd')}}"><div class="menu_link">
    <div class="menu_text"><i class="menu_icon fa fa-key" aria-hidden="true" style="color:#ffce00;"></i>{{__('message.Change Password')}}</div>
      </div></a>

</div>

	  </div>

@yield('mycontent')
<script>

function ValidateFileUpload1() {

var fuData = document.getElementById('ImageUrl');
var FileUploadPath = fuData.value;


if (FileUploadPath == '') {
   document.getElementById('uploadMessage').innerHTML="Please Select One Image";
   return false;
} else {
    var Extension = FileUploadPath.substring(FileUploadPath.lastIndexOf('.') + 1).toLowerCase();

    if (Extension == "gif" || Extension == "png" || Extension == "bmp"
                || Extension == "jpeg" || Extension == "jpg") {


            if (fuData.files && fuData.files[0]) {

                var height = fuData.files[0].height;
                var width = fuData.files[0].width;
                if((height > 300 || width > 200)){
                    alert("Maximum file size should be 300px * 200px");
                    return;
                }else{
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('#blah').attr('src', e.target.result);
                    }

                    reader.readAsDataURL(fuData.files[0]);
                }
            }
    } 
else {
        alert("Photo only allows file types of GIF, PNG, JPG, JPEG and BMP. ");
    }
}}
$("#toggle").click(function() {
  $(this).toggleClass("on");
  $("#menu").slideToggle();
});
</script>

          </div>
  </div>
@endsection

{{--hi--}}
{{--@foreach($user as $users)--}}
{{--<label>{{$users->Name}}</label>--}}

{{--@endforeach--}}

{{--<label>{{$name}}</label>--}}

{{--<!DOCTYPE html>--}}
{{--<html lang="en">--}}
{{--<head>--}}
    {{--<meta charset="utf-8">--}}
   {{--<title>Yellow Pages Kazakhstan</title>--}}
    {{--<script src="http://demo.itsolutionstuff.com/plugin/jquery.js"></script>--}}
    {{--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/>--}}
   {{--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">--}}
  {{--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>--}}
   {{----}}
    {{--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>--}}

    {{--<!-- Styles -->--}}
  {{--<style>--}}
   {{--ul{--}}
   {{--list-style-type: none;--}}
   {{--}--}}
   {{--#menu{--}}
  {{--float: left;--}}

   {{--}--}}
   {{--hr {--}}
   {{--background-color: red;--}}
   {{--height: 1px;--}}
   {{--border: 2;--}}
    {{--}--}}

   {{--</style>--}}
{{--</head>--}}
{{--<body>--}}
{{--<div class="container-fluid">--}}
{{--<div class="row bg-danger">--}}
{{--<ul class="list-group">--}}
    {{--<li class="list-group-item" id="menu">--}}
      {{--<a href="">Add Your Company</a>--}}
    {{--</li>--}}
    {{--<li class="list-group-item" id="menu">--}}
    {{--<a href="/ypk/home/create">Post a free add</a>--}}
    {{--</li>--}}
    {{--<li class="list-group-item" id="menu">--}}
     {{--<a href="{{url('/')}}">Go Out</a>--}}
    {{--</li>--}}
     {{--</ul>--}}
{{--</div>--}}
 {{--<div class="row bg-primary text-center">--}}
    {{--<h3>Welcome to Ypk</h3>--}}
 {{--</div>--}}
 {{--<div class="row bg-success">--}}
    {{--<br>--}}
 {{--<div class="col-sm-3">--}}
 {{--<div class="row">--}}
     {{--@foreach($user as $users)--}}
     {{--<ul class="list-group">--}}

        {{--<li class="list-group-item"><a href="/ypk/profile">My Profile</a></li>--}}
        {{--<li class="list-group-item"><a href="">My  Review</a></li>--}}
        {{--<li class="list-group-item"><a href="/ypk/edit/{{$users->UserRegId}}">Edit Profile</a></li>--}}
        {{--<li class="list-group-item"><a href="/ypk/edit/{{$users->UserRegId}}">Edit Profile</a></li>--}}
        {{--<li class="list-group-item"><a href="">Upload Image</a></li>--}}
        {{--<li class="list-group-item"><a href="/ypk/chpswd?Email={{$users->Email}}">Change Password</a></li>--}}

     {{--</ul>--}}
     {{--@endforeach--}}
 {{--</div>--}}

 {{--</div>--}}
      {{--<div class="col-sm-7">--}}
      {{--<div class=""row>--}}
      {{--<div class="panel panel-primary">--}}
      {{--<div class="panel-heading">Company Details</div>--}}

      {{--<div class="panel-body">--}}
      {{--@foreach($user as $users)--}}
            {{--<strong>Name:</strong>--}}
              {{--<label>{{$users->Name}}</label>--}}

              {{--@endforeach--}}

      {{--</div>--}}
      {{--</div>--}}
      {{--</div> <!-- row end-->--}}

      {{--<div class=""row>--}}
            {{--<div class="panel panel-primary">--}}
            {{--<div class="panel-heading">Classified Details</div>--}}

            {{--<div class="panel-body">--}}
            {{--@foreach($user as $users)--}}
                  {{--<strong>Classified Title</strong>--}}
                    {{--<label>{{$users->Name}}</label>--}}

            {{--@endforeach--}}

            {{--</div>--}}
            {{--</div>--}}
            {{--</div> <!-- row end-->--}}

   {{--</div><!-- col-sm-7 end-->--}}
{{--<div class="col-sm-2"></div>--}}
{{--</div>--}}
 {{--</div>      --}}{{--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>--}}
       {{--<!-- Include all compiled plugins (below), or include individual files as needed -->--}}
       {{--<script src="{{ asset('js/bootstrap.min.js')}}"></script>--}}
{{--</body>--}}
{{--</html>--}}
