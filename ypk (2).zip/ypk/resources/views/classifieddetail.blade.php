@extends('layouts.app')
@section('title')
{{$com->ClassifiedTitle}},{{$com->CityName}}-{{$com->CategoryName}},{{$com->SubCategoryName}} - Проведение выставок и ярмарок, выставки, ярмарки, презентации, демонстрации

@stop
@section('description')
Страница.{{$com->ClassifiedTitle}} Информация о компании: адрес, телефон, официальный сайт, электронная почта, фотографии, связаться с компанией, местоположение на карте
@endsection
@section('keywords') 
{{$com->ClassifiedTitle}},{{$com->CityName}},контакты, адрес электронной почты, сайт, Расположение на карте, фото, контакт с бизнесом.
@endsection
@section('content')
<script>
$(document).ready(function () {
         // Handler for .ready() called.
         $('html, body').animate({
             scrollTop: 560
}, 2000);
 });
		 
</script>
<div class="row">
    <div class="col-md-9 top-slider">
        <div class="row">
            <div class="col-md-4">
                <h3 class="headerline"> {{__('message.Findresultfor')}} </h3>
            </div>
        </div>
        <div class="detail-wrapper">
            <div class="detail-wrapper-body">
                <div class="listing-title-bar">
				<div class="col-sm-8" style="padding:15px;">
                    <h3 class="classified_head_detail">{{$com->ClassifiedTitle}}</h3><br>
                    <span  class="mrg-l-5 category-tag">{{$com->CategoryName}}/{{$com->SubCategoryName}}</span>
                    <div>
                           <p> <i class="ti-location-pin mrg-r-5 fa fa-map-marker address_icons"></i>{{$com->CityName}} <br>
						       <i class="fa fa-phone address_icons" aria-hidden="true"></i>{{$com->Phone}}&nbsp; &nbsp;{{$com->Mobile}}<br>
                            <i class="ti-location-pin mrg-r-5"></i> 
                            <a href="{{$com->WebUrl}}" class="listing-address" target="_blank">
							<i class="fa fa-globe address_icons" aria-hidden="true"></i>{{$com->WebUrl}}</p>
                        </a>
                        <?php
                            $regtype=$com->ActualRegType; 
                          if ($regtype>0)
                          {
                            ?>
                          <div class="rating-box">
                            <div class="detail-list-rating">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <a href="#" class="detail-rating-count">5 {{__('message.Rating')}}</a>
                        </div>
                       <?php }
                        else { ?>
                            <div class="rating-box">
								<div class="detail-list-rating">
									<i class="fa fa-star"></i>
									<i class="fa fa-star-o"></i>
									<i class="fa fa-star-o"></i>
									<i class="fa fa-star-o"></i>
									<i class="fa fa-star-o"></i>
								</div>
                            <a href="#" class="detail-rating-count"> {{__('message.NoRating')}}</a>
							</div>
                    <?php   }
                       ?>       
                </div>
				</div>
				 <div class="col-md-4 ipad-responsive">
                        <!-- rami-->
						<?php 
                         $regtype=$com->ActualRegType;
						$countproductimage=count($productimage);
						$countproposal=count($proposal);
						$isProfilepic=$com->IsProfileEnabled;
						?>
					@if(($regtype>0)||($isProfilepic>0))
				  <img src="{{asset('public/ProductImages')}}/{{$com->ImageUrl}}" onerror="this.src='{{asset('public/ProductImages/no-image.png')}}'" class="search_image profile-image">
                  @if($regtype>0)
				  <img src="{{asset('public/Images/premium_ribbon.png')}}" class="detailribbon" alt="error" >			
                   @else
                   @endif					   
				   @else
				   <img src="{{asset('public/ProductImages/no-image.png')}}" onerror="this.src='{{asset('public/ProductImages/no-image.png')}}'" class="search_image profile-image">
                @endif
			   </div>
           </div>
  </div></div>
        <div class="detail-wrapper">
            <div class="detail-wrapper-header">
                <h4 style="font-size: 20px; margin: 0px;">{{__('message.Overview')}}</h4>
            </div>
            <div class="detail-wrapper-body">
                <p class="para_detail_classified">{{$com->ClassifiedContent}} </p>
            </div>
        </div>
       @if(($regtype>0)&&($countproductimage>0))
        <div class="detail-wrapper">
            <div class="detail-wrapper-header">
                <h4 style="font-size: 20px; margin: 0px;">{{__('message.Products')}}</h4>
            </div>
            <div class="detail-wrapper-body">
                <ul class="detail-check">
                     @foreach ($productimage as $pi)
                    <li><img src="{{asset('public/ProductImages/')}}/{{$pi ->ImageUrl}}" style="height: 100px; width:100px;" onerror="this.src='{{asset('public/images/no-image.png')}}'"></li>
                    {{--<li><img src="{{asset('public/ProductImages/')}}/{{$com->ImageUrl}}" onerror="this.src='{{asset('public/images/no-image.png')}}'"></li>--}}
                    @endforeach
                </ul>
            </div>
        </div>
		@else
		@endif
	    @if($countproposal>0)
        <div class="detail-wrapper">
            <div class="detail-wrapper-header">
                <h4 style="font-size: 20px; margin: 0px;">{{__('message.CompanyProposals')}}</h4>
            </div>
            <div class="detail-wrapper-body">
                <ul class="detail-check">
                      @foreach ($proposal as $posal)
                         {{--<li><img src="{{asset('public/ProductImages/')}}/{{$posal->ProposalUrl}}" style="height: 100px; width:100px;" onerror="this.src='{{asset('public/images/no-image.png')}}'"></li>--}}

                        <li><a class="dropdown-item" href="{{asset('public/Proposals/')}}/{{$posal ->ProposalUrl}}" download><i class="fa fa-download" aria-hidden="true"></i>
                        <span> {{$posal ->ProposalUrl}}</span>
                        </a></li>
                     @endforeach
                </ul>
            </div>
        </div>
        @else
		@endif

         @if($com->ActualRegType==0)
            <div class="detail-wrapper">
                <div class="detail-wrapper-header">
                    <h4  style="font-size: 20px; margin: 0px;">{{__('message.new_customers')}}</h4>
                </div>
                <div class="detail-wrapper-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h4>{{$new_company->CompanyName}}</h4>
                            <p>{{$new_company->DescribeBusiness}}</p>
                        </div>
                        <div class="col-md-6">
                            <h4>{{$new_classified->ClassifiedTitle}}</h4>
                            <p>{{$new_classified->ClassifiedContent}}</p>   
                        </div>
                    </div>    
                </div>
            </div>
        @endif
        <div class="detail-wrapper">
            <div class="detail-wrapper-header">
                <h4 style="font-size: 20px; margin: 0px;">{{__('message.Location')}}</h4>
            </div>
            <div class="detail-wrapper-body">
				<iframe src="https://maps.google.it/maps?q={{$com->CityName}},{{$com->ClassifiedTitle}}&output=embed"width="100%" height="100%" frameborder="0" style="border:1px solid #ffff00" allowfullscreen></iframe>
            </div>
        </div>
		@php $type=$com->ActualRegType;@endphp
		@if($type>0)
        <div class="detail-wrapper">
		<form method="post" id="reviewform" action="{{url('/classifiedreviewadd')}}/{{$com->ClassifiedRegId}}" role="form">
		 <input type="hidden" name="_token" value="{{ csrf_token()}}">
            <div class="detail-wrapper-header">
                 <h4 style="font-size: 20px; margin: 0px;">{{__('message.Rate')}}</h4>
				 <p class="para_detail_classified">{{__('message.writetous')}} </p>
            </div>
            <div class="detail-wrapper-body">
                <div class="row" style="padding-bottom: 10px;">
                    <div class="col-md-6 user-input-wrp">
                        <br/>
                        <input type="text" name="CommentedPerson" id="CommentedPerson"  class="inputText" style="background-color:white;" />
                        <span class="floating-label">{{__('message.Contact Name')}} <span style="color:red;">*</span></span>
                    </div>
                    <div class="col-md-6 user-input-wrp">
                        <br/>
                        <input type="text" class="inputText" id="CommentedPersonEmail" name="CommentedPersonEmail" style="background-color:white;" />
                        <span class="floating-label">{{__('message.Email Address')}}<span style="color:red;">*</span></span>
                    </div>
                </div>
                <div class="row" style="padding-bottom: 10px;">
                    <div class=" col-md-6 user-input-wrp">
                        <br/>
                        <input type="text"name="CommentedPersonPhoneNo" id="CommentedPersonPhoneNo"class="inputText phonemask"style="background-color:white;"  />
                        <span class="floating-label">{{__('message.Phonenumber')}} <span style="font-size: 11px;">(Add prefix +7 & area code) </span><span style="color:red;"> *</span></span>
                    </div>
                     <div class="col-sm-6"></div>
                </div>
                
                <div class="row" style="padding-bottom: 10px;padding-top: 20px;">
                     <div class="col-sm-6">
					 <span class="headline" style="margin-left: 4px;margin-top: 26px;position: absolute;font-weight: 600;font-size: 15px;">{{__('message.YourMessage')}}</span><br><br>
					 <textarea placeholder="{{__('message.This is an awesome comment box')}}" rows="20" name="ReviewMessage" id="ReviewMessage" cols="40" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true"></textarea>
					 </div>
					 <div class="col-sm-6"></div>
                </div>
                <div class="row">
                    <div class="col-sm-6"style="float:right;padding-top: 20px;padding-left: 15px;">

                        <input type="submit" class="btn-grad" value="{{__('message.Send')}}" style=" height:40px; width:100px;" />
                        <input type="reset" class="btn-grad" value="{{__('message.cancel')}}" style=" height:40px; width:100px;" />
                    </div>
					 <div class="col-sm-6"></div>
                </div>
            </div>
          </form>  
        </div>
@endif
  </div>
    <div class="col-md-3" style="padding-left: 5px;padding-right: 5px;">
         @include('classifieds_slide')
    </div>
</div>

<script type="text/javascript">
  $("#reviewform").validate({
     
        rules: {
            CommentedPerson: {
                required: true,
                lettersonly: true
            },
            CommentedPersonEmail: {
                required: true,
                email: true,
                email_exists: false

            },
            CommentedPersonPhoneNo: {
                required: true,
                validecode: true, 
            },
		    ReviewMessage: {
                required: true,
                maxlength: 500
            }
        },
        messages: {
                CommentedPerson: {
                required: "{{__('message.Please Enter your name')}}",
                lettersonly: "{{__('message.Please Enter only character') }}"
            },
            CommentedPersonEmail: {
                required: "{{__('message.Please Enter your email aadress')}}",
                email: "{{__('message.Please Enter valid email')}}",
                email_exists: "{{__('message.Email already exist')}}"
            },
            CommentedPersonPhoneNo: {
                required: "{{__('message.please enter mobile number')}}",
                	validecode: "{{__('message.country code should be valid')}}"
            },
			ReviewMessage: {
                required: "{{__('message.Write Something')}}",
                maxlength: "{{__('message.Maximum 500 characters')}}"
            }
        }
    });

    jQuery.validator.addMethod("lettersonly", function(value, element) {
        return this.optional(element) || /^[a-zA-Z ]*$/.test(value);
    }, "Letters only please");
</script>
@endsection