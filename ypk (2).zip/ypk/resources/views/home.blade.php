
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">


    <title>Documents</title>
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
    <!-- Styles -->
   <style>
   ul{
   list-style-type: none;
   }
   ul li{
   float: left;
   font-size: 20px;
   }
   </style>
</head>
<body>
<div class="header">
 <ul>
    <li>
      <a href="">Add Your Company</a>
    </li>
    <li>
    <a href="/YellowPages/home/create">Post a free add</a>
    </li>
    <li>
    <a href="/YellowPages/user">Logout</a>
    </li>
    <li>
      <select>
        <option>My Account</option>
        <option><a href="/YellowPages/home/create">MyProfile</a></option>
        <option><a href="">Go Out</a></option>
      </select>
    </li>
 </ul>
</div>
  <div class="container">

    <div class="row">
      <div class="col-sm-4">
      <ul>
          <li><a href="">My Profile</a></li>
          <li><a href="">My Review</a></li>
          <li><a href="">Edit Details</a></li>
          <li><a href="">Upload Product Images</a></li>
          <li><a href="">Change Password</a></li>
        </ul>
      </div>
      <div class="col-sm-8">


         <table class="table table-bordered">
           <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Email</th>
             <th>Phone</th>
           </tr>
           <tr>
             <td>{{$id}}</td>
             <td>{{$name}}</td>
             <td>{{$email}}</td>
             <td>{{$phone}}</td>
           </tr>
         </table>
         <div class="row">
         <img class="img img-responsive"height="200px" width="200px" src="C:\Users\mohinig\Pictures\Saved Pictures\pastaveg_640x480.jpg" >
         </div>
         <div class="row">
            <table class="table table-bordered">
                      <tr>
                       <th>Sl no</th>
                       <th>ClassifiedContent</th>
                       <th>CategoryCode</th>
                        <th>SubCategoryCode</th>
                      </tr>
                      <?php
                       $i=1;
                       ?>
                      @foreach($classified as $classifieds)
                      <tr>
                      <td><?php echo $i++;?></td>
                      <td>{{$classifieds->ClassifiedContent}}</td>
                      <td>{{$classifieds->CategoryCode}}</td>
                      <td>{{$classifieds->SubCategoryCode}}</td>
                      <td><a href=" classified/{ClassifiedRegId}/edit">Edit</a></td>
                      </tr>

                  @endforeach
              </table>
         </div>
      </div>
      </div>
   </div>
</body>
</html>
