@extends('profilemenu')@section('mycontent')
  <div class="col-md-9">

 <ul id="tabs_classified">
    <li ><a href="#" name="tab1" class="tab_text" style="font-weight: 500"><i class="menu_icon2 fa fa-user" aria-hidden="true" ></i>{{__('message.Proposals')}}</a></li>
</ul>

<div id="tab_content">
    <div id="tab1">
        <p>{{__('message.You can upload proposal of docs,plain text, pdf')}}</p>
             <div id="showing">
              @foreach($data as $file)
                <a class="dropdown-item" href="{{asset('public/Proposals')}}/{{$file->ProposalUrl}}"><i class="fa fa-download" aria-hidden="true"></i>{{$file->ProposalUrl}}</a>
                 <a href="{{url('/removeproposal')}}/{{$file->Proposal_Id}}">{{__('message.Remove')}}</a>
            @endforeach
             <form action="{{url('/saveproposal')}}" id="uploadproposal" class="uploadImage-choose" method="post" enctype="multipart/form-data">
             <input type="hidden" name="_token" value="{{ csrf_token()}}">
              <input type="file" id="proposal" class="button-file imageselection" accept="application/msword,text/plain, application/pdf" name="ProposalUrl" style="display:none;">
			  <a class="uploadpic">{{__('message.Choose File')}}</a>
		      <span id="selectedfilename" class="reviewer_proposal_inside">{{__('message.No File Selected')}}</span>	
			  <label  id="fnote" style="color:red;"></label><br/><br/>
              <input type="button" onclick ="validate_file()" value="{{__('message.Upload')}}" class="btn-grad upload_prp"/>
             </form>
             </div>
      </div>
    </div>
</div>
@endsection