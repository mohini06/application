
{{--hi--}}
{{--@foreach($user as $users)--}}
{{--<label>{{$users->Name}}</label>--}}

{{--@endforeach--}}

{{--<label>{{$name}}</label>--}}

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">


   <title>Yellow Pages Kazakhstan</title>
    <script src="http://demo.itsolutionstuff.com/plugin/jquery.js"></script>
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/>
   {{--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">--}}
  {{--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>--}}
   {{----}}
    {{--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>--}}

    <!-- Styles -->
   <style>
   ul{
   list-style-type: none;
   }
   #menu{
  float: left;

   }
   hr {
   background-color: red;
   height: 1px;
   border: 2;
    }

   </style>
</head>
<body>
<div class="container-fluid">
<div class="row bg-danger">
 <ul class="list-group">
    <li class="list-group-item" id="menu">
      <a href="">Add Your Company</a>
    </li>
    <li class="list-group-item" id="menu">
    <a href="/ypk/home/create">Post a free add</a>
    </li>
     <li class="list-group-item" id="menu">
     <a href="/ypk/userlogin">Go Out</a>
        </li>
     </ul>
</div>
 <div class="row bg-primary text-center">
    <h3>Welcome to Ypk</h3>
 </div>
    <div class="row bg-success">
     <div class="col-sm-2">
     <div class="row">
     <ul class="list-group">
        <li class="list-group-item"><a href="">My Profile</a></li>
        <li class="list-group-item"><a href="">My  Review</a></li>
        <li class="list-group-item"><a href="">Edit Profile</a></li>
        <li class="list-group-item"><a href="">Upload Image</a></li>
        <li class="list-group-item"><a href="/ypk/chpswd">Change Password</a></li>

     </ul>
     </div>

     </div>
     <div class="col-sm-1"></div>

      <div class="col-sm-8">
             <div class="row">
                <form  method="POST" action="/ypk/update" role="form">
                 {{--<form  method="POST" action="{{action('ClassifiedController@store')}}" >--}}

                 <input type="hidden" name="_token" value="{{ csrf_token()}}">



                  <div class="row">
                    <div class="col-sm-4">
                        <div class="form-group">
                         <label>Заголовок объявления</label>
                         <input type="text" id="title" name="ClassifiedTitle" class="form-control">

                        </div>
                    </div><!-- col-sm-6 end-->
                   <div class="col-sm-4">
                        <div class="form-group">
                          <label>Выберите свою категорию</label>
                          <select class="form-control" id="category" name="category" >

                             @foreach($category as $categories)
                               <option value="{{$categories->CategoryId}}">{{$categories->CategoryName}}</option>
                              @endforeach

                          </select>

                        </div>
                    </div><!-- col-sm-6 end-->
                     <div class="col-sm-4">
                              <div class="form-group">
                                  <label>Подкатегория</label>
                                  <select class="form-control " id="subcategory" name="subcategory" >
                                      @foreach($subcategory as $subcategories)
                                           <option value="{{$subcategories->SubCategoryId}}">{{$subcategories->SubCategoryName}}</option>
                                      @endforeach
                                  </select>


                               </div>
                            </div><!-- col-sm-6 end-->
                    </div><!-- row 1 end-->
                    <div class="row">

                       <div class="col-sm-4">
                           <div class="form-group">
                                <label>Адрес электронной почты</label>
                                <input type="email" id="title" name="email" class="form-control">

                           </div>
                        </div><!-- col-sm-6 end-->
                        <div class="col-sm-4">
                                  <div class="form-group">
                                   <label>Ваше имя </label>
                                   <input type="text" class="form-control" name="name">
                                   <span class="text-danger">{{ $errors->first('name') }}</span>
                                  </div>
                                </div><!-- col-sm-6 end-->
                                <div class="col-sm-4">
                                           <div class="form-group">
                                              <label>Город</label>
                                              <select class="form-control" id="city" name="city">
                                           @foreach($city as $cities)
                                            <option value="{{$cities->CityId}}">{{$cities->CityName}}</option>
                                           @endforeach
                                              </select>

                                           </div>
                                        </div><!-- col-sm-6 end-->

                   </div><!-- row 2 emd-->

                   <div class="row">
               <div class="col-sm-4">
                      <div class="form-group">
                        <label>Мобильный номер</label>
                        <div class="row">
                            <div class="col-sm-2">
                                <h5>&nbsp;&nbsp;&nbsp;&nbsp;+7</h5>
                            </div>
                            <div class="col-sm-10">
                                <input type="text" id="title" name="mobile" class="form-control">

                            </div>
                        </div>
                      </div>
               </div><!-- col-sm-4 end-->
               <div class="col-sm-4">
                   <div class="form-group">
                      <label>Номер телефона(С кодом города)</label>
                      <div class="row">
                      <div class="col-sm-2">
                        <h5>&nbsp;&nbsp;&nbsp;&nbsp;+7</h5>
                      </div>
                      <div class="col-sm-10">
                        <input type="text" id="title" name="phone" class="form-control">

                      </div>
                   </div>
                   </div>
               </div><!-- col-sm-6 end-->
               </div><!-- row 3 emd-->

                   <div class="row">
               <div class="col-sm-4">
                     <div class="form-group">
                      <label>Объявление</label>
                      <textarea class="form-control" name="ClassifiedContent"></textarea>

                      </div>
                      </div><!-- col-sm-12 end-->
                       <div class="col-sm-4">
                              <div class="form-group">
                                 <label> Ваш сайт (Не забудьте добавить http://)</label>
                                 <input type="url" name="Weburl" class="form-control">
                                 </div>
                              </div><!-- col-sm-8 end-->
                   </div><!-- row 4 emd-->



                   <div class="row text-right">
                   <div class="col-sm-12">
                        <div class="form-group">
                         <input type="submit" value="Reset" class="btn btn-warning">
                         <input type="submit" value="Edit" class="btn btn-success">
                        </div>
                      </div><!-- col-sm- 4end-->
                   </div><!-- row5 end-->

               </form>
             </div>
      </div>
       <div class="col-sm-1"></div>
   </div>

</div>
       {{--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>--}}
       <!-- Include all compiled plugins (below), or include individual files as needed -->
       {{--<script src="{{ asset('js/bootstrap.min.js')}}"></script>--}}
</body>
</html>

