@extends('profilemenu')
@section('mycontent')
<div class="col-md-9">
  @php       
             $classified_count=count($classifieddata);
        @endphp
    <ul id="tabs_classified">
		<li><a href="#" name="tab1" class="tab_text" style="font-weight: 500"><i class="menu_icon2 fa fa-user" aria-hidden="true" ></i> {{__('message.Profile')}}</a></li>
	 @for($i=2;$i<=$classified_count+1;$i++)
        <li><a href="#" name="tab{{$i}}" class="tab_text" style="font-weight: 500"><i class="menu_icon2 fa fa-laptop" aria-hidden="true" ></i>{{__('message.Classified')}}&nbsp;@php echo ($i-1); @endphp</a></li>
     @endfor
    </ul>
    <div id="tab_content">
	
        <div id="tab1" style="display:block !important;">
		@if($userd!=null)
			@php   
		 $imagecount=(count($dpimage));
                        
                        if ($imagecount>0)
                        {
                            $imageUrl= $dpimage[0]->ImageUrl;
                        }
                        else{
                            $imageUrl="";
                        }

    
                  $type=$userd->ActualRegType; 
				  $status_com=$userd->IsApprove;
		@endphp
            <div class="row" style="margin-top:15px;">
                <div class="col-md-3">
           
            <img src="{{asset('public/ProductImages/')}}/<?php echo $imageUrl;?>"  class="user_dashboard_profileimg" onerror="this.src='{{asset('public/Images/companyprofile.png')}}'" />
                </div>
                <div class="col-md-9">
                    <div class="sidebar">
                        <div class="row" style="margin-left:0px;">
                            <div class="col-md-12 profile-left">

                                <div class="form-group row">
                                    <label class="col-sm-4 ">{{__('message.Company Name')}}</label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static">{{$userd->CompanyName}}</p>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-4 ">{{__('message.Comapany Address')}}</label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static">{{$userd->Address1}},{{$userd->Address2}},{{$userd->CityName}},{{$userd->PostalCode}}</p>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-4 ">{{__('message.Type of Membership')}}</label>
                                    <div class="col-sm-8">
                                         @if($type>2)
                                       <p class="form-control-static">{{__('message.Premium')}} @if($status_com<1) 
											   @php echo '<label style="color:red;">'."(В ожидании одобрения администратора)".'</label>'; @endphp
										   @else
											    @php echo"" ; @endphp
										@endif</p>
									   @elseif($type>1)
									    <p class="form-control-static">{{__('message.Gold')}} @if($status_com<1) 
											   @php echo '<label style="color:red;">'."(В ожидании одобрения администратора)".'</label>'; @endphp
										   @else
											    @php echo"" ; @endphp
										@endif</p>
										@elseif($type>0)
										 <p class="form-control-static">{{__('message.Silver')}} @if($status_com<1) 
											   @php echo '<label style="color:red;">'."(В ожидании одобрения администратора)".'</label>'; @endphp
										   @else
											    @php echo"" ; @endphp
										@endif</p>
										 @else
										 <p class="form-control-static">{{__('message.free')}}
									 @if($status_com<1) 
											   @php echo '<label style="color:red;">'."(В ожидании одобрения администратора)".'</label>'; @endphp
										   @else
											    @php echo"" ; @endphp
										@endif
										
									 </p>
                                         @endif
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-4 ">{{__('message.Mobile')}}</label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static">
										<?php if(  preg_match( '/^(7)(\d{3})(\d{7})$/',  $userdata->Phone,  $matches )  && strlen($userdata->Phone)==11 )
                        {
                            $result = '+' .$matches[1] . ' (' .$matches[2] . ') ' . $matches[3];
                            echo $result;
                        }else{
                        echo $userdata->Phone;
                            }   
							?>
                                &nbsp; &nbsp; 
							<?php if(  preg_match( '/^(7)(\d{3})(\d{7})$/', $userdata->Mobile,  $matches )  && strlen($userdata->Mobile)==11 )
                        {
                            $result = '+' .$matches[1] . ' (' .$matches[2] . ') ' . $matches[3];
                            echo $result;
                        }else{
                        echo $userdata->Mobile;
                            }  
							?> 
										</p>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-4 ">{{__('message.Email Address')}}</label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static">{{$userdata->Email}}</p>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-4 ">{{__('message.Product Images')}}</label>
                                    <div class="col-sm-8 upload-product-images">
									@if(count($image)>0)
                                   @foreach($image as $imagedata)

                                     <img src="{{asset('public/ProductImages')}}/{{$imagedata->ImageUrl}}" style="height:60px; width: 60px;">
                                   @endforeach
								   @else 
								@endif

                                    </div>
                                </div>
                            </div>
                            <div class="form-group" style="margin-top:10px;">
                                <div class="col-md-12">
                                <a href="{{url('/uploadprofilepic')}}"><input type="submit" class="btn-grad-profile" value="{{__('message.Upload ProfileImage')}}"></a>
                                <a href="{{url('/addclassified')}}"><input type="submit" class="btn-grad-profile"  value="{{__('message.AddClassified') }}"></a>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			@else
				 <a href="{{url('/addcompany_classified')}}"><input type="submit" class="btn-grad-profile" value="{{__('message.AddCompany') }}"></a>
		    @endif
        </div>
      
   @if (($userd!=null)&&($type>1)||($classifieddata!=null) )
      @php $j=2; @endphp
         @if ($classified_count>=1)
         @foreach($classifieddata as $add)
	         @php $sypscription_type=$add->ActualRegType; 
				  $status=$add->IsApprove;
				  $expirydate=$add->ExpiryDate;
			 @endphp
        <div id="tab{{$j++}}">
        
          <div class="row" style="margin-top:15px;">
                <div class="col-md-3">
				@if($sypscription_type>0)
               <?php 
                        $imagecount2=count($addprofileimg->where('ClassifiedId','=',$add->ClassifiedRegId));
                        $url_profilepic=$addprofileimg->where('ClassifiedId','=',$add->ClassifiedRegId)->first();
                        if ($imagecount2>0)
                        {
                            $imageUrl_add= $url_profilepic->ImageUrl;
                        }
                        else{
                            $imageUrl_add="";
                        }
               ?>
            <img src="{{asset('public/ProductImages/')}}/<?php echo $imageUrl_add;?>" class="user_dashboard_profileimg" onerror="this.src='{{asset('public/Images/companyprofile.png')}}'" />
            @else 
	<img src="{{asset('public/Images/companyprofile.png')}}" style="border-radius: 50%; height: 175px;

            box-shadow: 0 4px 8px 0 rgba(0,0,0,.3);width: 100%; margin:10px;" onerror="this.src='{{asset('public/Images/companyprofile.png')}}'" />
        @endif     

                </div>
                <div class="col-md-9">
                    <div class="sidebar">
                        <div class="row" style="margin-left:0px;">
                            <div class="col-md-12 profile-left">

                                <div class="form-group row">
                                    <label class="col-sm-4 ">{{__('message.Add Title')}}</label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static">{{$add->ClassifiedTitle}}</p>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-4 ">{{__('message.Type of Membership')}}</label>
									
                                    <div class="col-sm-8">
                                       @if(($expirydate >= now())||empty($expirydate))
										 
                                       @if($sypscription_type>0)
                                        <p class="form-control-static">{{__('message.Premium')}}
									   @if ($status<1) 
											   @php echo '<label style="color:red;">'."(В ожидании одобрения администратора)".'</label>'; @endphp
										   @else
											    @php echo"" ; @endphp
										@endif
									</p>
                                        @else
                                         <p class="form-control-static">{{__('message.free')}}
									       @if ($status<1) 
											   @php echo '<label style="color:red;">'."(В ожидании одобрения администратора)".'</label>'; @endphp
										   @else
											    @php echo"" ; @endphp
										@endif
									 </p>
                                         @endif
										 
										@else 
											
											@php echo  '<label style="color:red;">'."Срок действия объявления истек, и он не попадет в список поиска".'</label>'; @endphp
									    @endif
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-4 ">{{__('message.Mobile')}}</label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static">
											<?php if(  preg_match( '/^(7)(\d{3})(\d{7})$/',  $userdata->Phone,  $matches )  && strlen($userdata->Phone)==11 )
                        {
                            $result = '+' .$matches[1] . ' (' .$matches[2] . ') ' . $matches[3];
                            echo $result;
                        }else{
                        echo $userdata->Phone;
                            }   
							?>
                                &nbsp; &nbsp; 
							<?php if(  preg_match( '/^(7)(\d{3})(\d{7})$/', $userdata->Mobile,  $matches )  && strlen($userdata->Mobile)==11 )
                        {
                            $result = '+' .$matches[1] . ' (' .$matches[2] . ') ' . $matches[3];
                            echo $result;
                        }else{
                        echo $userdata->Mobile;
                            }  
							?>
										</p>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-4 ">{{__('message.Email Address')}}</label>
                                    <div class="col-sm-8">
                                        <p class="form-control-static">{{$userdata->Email}}</p>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-4 ">{{__('message.Product Images')}}</label>
                                    <div class="col-sm-8 upload-product-images">
                                  @if($sypscription_type>0)
                                   @foreach($image_add->where('ClassifiedRegId','=',$add->ClassifiedRegId) as $imageadd)

                                     <img src="{{asset('public/ProductImages')}}/{{$imageadd->ImageUrl}}" style="height:60px; width: 60px;">
                                   @endforeach
                                   @else
								@endif
                                    </div>
                                </div>
                            </div>

                            <div class="form-group" style="margin-top:10px;">
                                <div class="col-md-12">
								@if($sypscription_type>0)
                                <a href="{{url('/uploadprofilepic')}}"><input type="submit" class="btn-grad-profile" value="{{__('message.Upload ProfileImage')}}"></a>
                                @else
                               <a href="{{url('/uploadprofilepic')}}"><input type="submit" class="btn-grad-profile" value="{{__('message.Upload ProfileImage')}}"></a>						
								@endif

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          </div>
        
        @endforeach
       @endif
       @else
      
       @endif

    </div>

</div>
@endsection