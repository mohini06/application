@extends('profilemenu')
@section('mycontent')
	  <div class="col-md-9">
@php   
             $classified_count=count($classifieddata);
        @endphp
 <ul id="tabs_classified">
    <li ><a href="#" name="tab1" class="tab_text" style="font-weight: 500"><i class="menu_icon2 fa fa-user" aria-hidden="true" ></i>{{__('message.Profile')}}</a></li>
  @for($i=2;$i<=$classified_count+1;$i++)
        <li><a href="#" name="tab{{$i}}" class="tab_text" style="font-weight: 500"><i class="menu_icon2 fa fa-laptop" aria-hidden="true" ></i>{{__('message.Classified')}}&nbsp;@php echo($i-1); @endphp</a></li>
     @endfor
</ul>
<div id="tab_content">
    <div id="tab1">
	@if($userd!=null)
            @php   
         
               $type=$userd->ActualRegType; 
               $profilepic=$userd->IsProfileEnabled;
        @endphp
      @if(($type>0)||($profilepic>0))
       <div id="showing">
        
      <?php 
             $imagecount=(count($data1));
            
            if ($imagecount>0)
            {
              $imageUrl= $data1[0]->ImageUrl;
            }
            else{
              $imageUrl="";
            }
         ?>

          <img src="{{asset('public/ProductImages/')}}/<?php echo $imageUrl;?>"
                   class="company_profile_img" onerror="this.src='{{asset('public/Images/companyprofile.png')}}'">

          <form action="{{url('/savecomimg/')}}" method="post" enctype="multipart/form-data">
              <input type="hidden" name="_token" value="{{ csrf_token()}}">

            <input type="file"  class="button-file" id="ImageUrl" name="ImageUrl" accept="image/gif, image/jpeg, image/png,image/jpg" >
			<label id="uploadMessage" style="color:red;"></label><br>
             <input type="button" value="{{__('message.Upload')}}" class="upload" class="btn btn-lg"/>

          </form>

       </div>
      @else
      <p>{{__('message.messageforprofilepic')}}</p>
      
       @endif
	   @else 
		    <p>{{__('message.Please add company')}}</p>
	  @endif
    </div>
   @php $j=2;@endphp
         @if ($classified_count>=1)
         @foreach($classifieddata as $add)
          <div id="tab{{$j++}}">
         @php $type2=$add->ActualRegType;   $profilepic=$add->IsProfileEnabled;@endphp
         @if(($type2>0)||($profilepic>0))
             <div id="showing">
		    
           <?php 
          
            $imageUrl= $adddp->ImageUrl;
         ?>

          <img src="{{asset('public/ProductImages/')}}/<?php echo $imageUrl;?>"
          class="company_profile_img"  onerror="this.src='{{asset('public/Images/companyprofile.png')}}'">
           
          <form action="{{url('/saveaddimg/')}}" method="post" enctype="multipart/form-data">
              <input type="hidden" name="_token" value="{{ csrf_token()}}">

            <input type="file"  class="button-file" id="ImageUrl" name="ImageUrl" accept="image/gif, image/jpeg, image/png,image/jpg">
			<label id="uploadMessage" style="color:red;"></label><br>
              <input type="button" value="Upload" class="upload" class="btn btn-lg"/>
          </form>
       </div>
        @else
       <p>{{__('message.messageforprofilepic')}}</p>
        @endif
          </div>
          @endforeach
          @endif
</div>
</div>
@endsection