@extends('profilemenu') 
@section('mycontent')
@php 
                 
     $classified_count=count($classifieddata);
             
    @endphp
<div class="col-md-9 mobile-padding-review">

    <ul id="tabs_classified">
        <li><a href="#" name="tab1" class="tab_text" style="font-weight: 500"><i class="menu_icon2 fa fa-user" aria-hidden="true" ></i>{{__('message.Comapanyreview')}}</a></li>
         @for($i=2;$i<=$classified_count+1;$i++)
        <li><a href="#" name="tab{{$i}}" class="tab_text" style="font-weight: 500"><i class="menu_icon2 fa fa-laptop" aria-hidden="true" ></i>{{__('message.Classified')}}&nbsp;@php echo ($i-1); @endphp</a></li>
         @endfor
    </ul>

    <div id="tab_content">
	 <div id="tab1">
		 @if($userd!=null)
            <div class="row" style="margin-top:15px;">
                <div class="col-md-12">
                    <div class="content">
                        <div class="limiter">
                            <div class="container-table100">
                                <div class="wrap-table100">
                                    <div class="table100 table-responsive">
                                        <table>
                                            <thead>
                                                <tr class="table100-head">
                                                    <th class="">{{__('message.Reviews')}}</th>
                                                    <th class="">{{__('message.Comments')}}</th>
                                                    <th class="">{{__('message.Date of publication')}}</th>
													<th class="">{{__('message.Proposals')}}</th>
                                                    <th class=""></th>
                                                    <th class=""></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php 
                                                 $totalcounter=0;
                                                 ?>
                                                
                                             @foreach($review as $rev)
                                                    
                                                <tr>
                                                    <td class="">{{$rev->CommentedPerson}}</td>
                                                    <td class="">{{$rev->ReviewMessage}}</td>
                                                    <td class="">{{$rev->DateOfPost}}</td>
                                                    <td class="">
													@if($rev->Proposals!="")
                                                    <a class="dropdown-item" href="{{asset('public/Proposals/')}}/{{$rev->Proposals}}" target="_blank"> <i class="fa fa-download" aria-hidden="true"></i>{{$rev->Proposals}}</a>
                                                    @else 
                                                    {{__('message.No proposal')}}
													@endif
												   </td>
                                                    <td class="">

                                                    <a href="javascript:showhide('uniquename <?php echo $totalcounter?>')" >{{__('message.Reply')}}</a></td>
                                                    <td class=""><a href="{{url('/removeReview')}}/{{$rev->ReviewId}}">{{__('message.Remove')}}</a></td>

                                                </tr>

                                      <tr style="height:0px;" >
                                        <td colspan="5" style="background-color:#fff;">
                                        <div class="reply-modal"  id="uniquename <?php echo $totalcounter?>">
                                         <form method="POST" id="replycomForm" action="{{url('/replyReview')}}/{{$rev->ReviewId}}" role="form" style="padding-top: 20px;">
                                                    <input type="hidden" name="_token" value="{{ csrf_token()}}">
                                                    <div class=" col-md-offset-4 col-md-4 user-input-wrp">
                                                       <br/>
                                                        <input type="text" class="inputText" value="{{$rev->CommentedPersonEmail}}" readonly/>
                                                        <span class="floating-label-edit">{{__('message.Email Address')}} <span style="color:red;">*</span></span>
                                                    </div>
                                                    <div class="col-md-offset-4 col-md-4 user-input-wrp review-comments-mob">
                                                        <br/>
                                                        <span class="headline" style="margin-top: 4px;position: absolute;">{{__('message.Comments')}}<span style="color:red;">*</span></span>
                                                        <textarea placeholder="{{__('message.This is an awesome comment box')}}" rows="20" name="comment" id="comment_text" cols="40" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true" required></textarea>
                                                    </div>

                                                    <div class=" col-md-offset-4 col-md-4 " style="padding-top: 20px;padding-left: 15px;">
                                                        <a href="javascript:void(0)">
                                                            <input type="submit" class="btn-grad" value="{{__('message.Send')}}" style=" height:40px; width:100px;" />
                                                        </a>
                                                        <a href="javascript:void(0)" class="cancel-modal">
                                                            <input type="button" class="btn-grad " value="{{__('message.cancel')}}" style=" height:40px; width:100px;" />
                                                        </a>
                                                    </div>
                                                </form>
                                      </div>
                                       </td>                                 
                                 </tr>  
                              <?php 
                                     $totalcounter++;
                              ?>
                            @endforeach
                                       </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			@else 
				<p>{{__('message.Please add company')}}</p>
			@endif
        </div>
       @php $j=2;@endphp
         @if ($classified_count>0)
         
         @foreach($classifieddata as $add)
	    
         <div id="tab{{$j++}}">
     
            <div class="row" style="margin-top:15px;">
  
                <div class="col-md-12">
                    <div class="content">
                        <div class="limiter">
                            <div class="container-table100">
                                <div class="wrap-table100">
                                    <div class="table100 table-responsive">
                                        <table>
                                            <thead>
                                                <tr class="table100-head">
                                                    <th>{{__('message.Reviews')}}</th>
                                                    <th>{{__('message.Comments')}}</th>
                                                    <th>{{__('message.Date of publication')}}</th>
                                                    <th></th>
                                                    <th></th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                            @php 
                                                 $totalcounter2=0;
											@endphp     
                                			     
												  @foreach($addreview->where('ClassifiedId','=',$add->ClassifiedRegId) as $rev_add)
                                                   
                                                <tr>
                                                    <td>{{$rev_add->CommentedPerson}}</td>
                                                    <td>{{$rev_add->ReviewMessage}}</td>
                                                    <td>{{$rev_add->DateOfPost}}</td>

                                                    <td>

                                                    <a href="javascript:showhide('uniquename2 <?php echo $totalcounter2?>')" >{{__('message.Reply')}}</a></td>
                                                    <td><a href="{{url('/removeReview_add')}}/{{$rev_add->ReviewId}}">{{__('message.Remove')}}</a></td>

                                                </tr>

                                      <tr style="height:0px;" >
                                        <td colspan="5" style="background-color:#fff;">
                                        <div class="reply-modal"  id="uniquename2 <?php echo $totalcounter2?>">
                                         <form method="POST" id="replyaddForm" action="{{url('/replyReview_add')}}" role="form">
                                                    <input type="hidden" name="_token" value="{{ csrf_token()}}">
                                                    <input type="hidden" name="ReviewId"value="{{$rev_add->ReviewId}}">
                                                    <div class=" col-md-offset-4 col-md-4 user-input-wrp">
                                                       <br/>
                                                        <input type="text" class="inputText" value="{{$rev_add->CommentedPersonEmail}}" readonly/>
                                                        <span class="floating-label-edit">{{__('message.Email Address')}} <span style="color:red;">*</span></span>
                                                    </div>
                                                    <div class="col-md-offset-4 col-md-4 user-input-wrp review-comments-mob">
                                                        <br/>
                                                        <span class="headline" style=" margin-top: 4px;position: absolute;">{{__('message.Comments')}}<span style="color:red;">*</span></span>
                                                        <textarea placeholder="This is an awesome comment box" rows="20" name="comment" id="comment_text" cols="40" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true" required></textarea>
                                                    </div>

                                                    <div class=" col-md-offset-4 col-md-4 " style="padding-top: 20px;padding-left: 15px;">
                                                        <a href="javascript:void(0)">
                                                            <input type="submit" class="btn-grad" value="{{__('message.Send')}}" style=" height:40px; width:100px;" />
                                                        </a>
                                                        <a href="javascript:void(0)" class="cancel-modal">
                                                            <input type="button" class="btn-grad " value="{{__('message.cancel')}}" style=" height:40px; width:100px;" />
                                                        </a>
                                                    </div>

                                                </form>
                                      </div>
                                       </td>                                 
                                 </tr>
                              <?php 
                                     $totalcounter2++;
                              ?>
                            @endforeach				
                                         
                                       </tbody>

                                        </table>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>

         @endforeach
       
       @else
       @endif
 
 </div>

</div>
        <script>
      function showhide(id) {
        var e = document.getElementById(id);
        e.style.display = (e.style.display == 'block') ? 'none' : 'block';
    }
    $(document).ready(function(){
    $(".cancel-modal").click(function(){
        $(".reply-modal").slideUp("slow");
        $(".reply-modal").css("display", "none");
    });
    });
	   $("#replycomForm").validate({

        rules: {
            comment: {
                required: true,
            }
        },
        messages: {
            comment: {
                required: "{{__('message.Please reply')}}",
			}
        }
    });
	$("#replyaddForm").validate({

        rules: {
            comment: {
                required: true,
            }

        },
        messages: {
            comment: {
                required: "{{__('message.Please reply')}}",
			}
        }
    });

    jQuery.validator.addMethod("lettersonly", function(value, element) {
        return this.optional(element) || /^[a-zA-Z ]*$/.test(value);
    }, "Letters only please");
</script>
 
@endsection