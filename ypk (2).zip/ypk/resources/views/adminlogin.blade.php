<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Documents</title>
    <!-- Styles -->
    <script src="http://demo.itsolutionstuff.com/plugin/jquery.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
</head><!-- app/views/login.blade.php -->

<body>
    <div class="container">
        <div class="row">
            <div class="col-sm-4"></div>
            <div class="col-sm-4">
                <h2>ADMIN LOGIN</h2>
                <form method="post" action="/dashboard" role="form">
                    <input type="hidden" name="_token" value="{{ csrf_token()}}">
                    <hr color="red">
                    <div class="form-group">
                        <label>User Id</label>
                        <input type="text" class="form-control" name="UserId">
                    </div><br>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" class="form-control"name="Password">
                    </div><br>
                            
                    <div class="row ">
                        <div class="col-sm-5 text-centre">
                            <input type="submit" class="form-control btn-success " value="submit">
                        </div>
                        <div class="col-sm-2"></div>
                        <div class="col-sm-5  text-centre ">
                            <input type="reset" class="form-control btn-danger " value="reset">
                        </div>             
                    </div>
                </form>
            </div>
            <div class="col-sm-4"></div>
        </div>
    </div>
</body>
 </html>