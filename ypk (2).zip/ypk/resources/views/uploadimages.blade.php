@extends('layouts.app')
@section('content')
<script src="{{asset('public/js/jquery-1.11.3.js')}}"></script>
<script src="{{asset('public/js/bootstrap.min.js')}}"></script>
<script >
						 $(window).load(function() {
							$("#flexiselDemo3").flexisel({
								visibleItems:1,
								animationSpeed: 1000,
								autoPlay: true,
								autoPlaySpeed: 5000,
								pauseOnHover: true,
								enableResponsiveBreakpoints: true,
								responsiveBreakpoints: {
									portrait: {
										changePoint:480,
										visibleItems:1
									},
									landscape: {
										changePoint:640,
										visibleItems:1
									},
									tablet: {
										changePoint:768,
										visibleItems:1
									}
								}
							});

						});
					   </script>

  <div class="row" style="margin-top: 20px;">

      <div class="col-md-3">
         <!-- uncomment code for absolute positioning tweek see top comment in css -->
         <!-- <div class="absolute-wrapper"> </div> -->
         <!-- Menu -->
         <div class="side-menu">

         <nav class="navbar navbar-default main-style" role="navigation">
         <!-- Brand and toggle get grouped for better mobile display -->
         <div class="navbar-header">
             <div class="brand-wrapper">
                 <!-- Hamburger -->
                 <button type="button" class="navbar-toggle">
                     <span class="sr-only">Toggle navigation</span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                 </button>
             </div>
         </div>

         <!-- Main Menu -->
         <div class="side-menu-container">
             <ul class="nav navbar-nav side-nav">

                 <li class="active"><a href=""><i class="fa fa-user " aria-hidden="true"></i> My Profile</a></li>

                 <li><a href="{{url('/review')}}/{{$userd->UserRegId}}"><i class="fa fa-star" aria-hidden="true"></i> My review</a></li>
     			<li><a href="{{url('/edit')}}/{{$userd->UserRegId}}"><i class="fa fa-edit " aria-hidden="true"></i> Edit</a></li>
     			<li><a href="{{url('/uploadimage')}}/{{$userd->UserRegId}}"><i class="fa fa-download" aria-hidden="true"></i> Upload Product Image</a></li>
                 <li><a href="{{url('/chpswd')}}/{{$userd->UserRegId}}"><i class="fa fa-lock" aria-hidden="true"></i> Change password</a></li>
             </ul>
         </div><!-- /.navbar-collapse -->
     </nav>
         </div>
     </div>
     {{--profile-body--}}
     <div class="col-md-9">
     	<div class="profile-body">
             <button class="accordion">MY COMPANY DETAILS</button>
     		<div class="panel">
     		    <div class="row">
     		      <br><br>
     			Минимальный размер должен быть 300 * 200 пикселей в формате jpg, jpeg, png
                Ваша регистрация бесплатна. Для загрузки изображений выберите платный статус.
                 </div>
             </div>

     		<button class="accordion">MY CLASSIFELD DETAILS</button>
     		<div class="panel">
     		   <div class="row">
     		   <br><br>
     		   Минимальный размер должен быть 300 * 200 пикселей в формате jpg, jpeg, png
     		    </div>
     		</div>
     	</div>
       </div>

	 </div><!-- row end-->
<script>
$(document).ready(function(){
$('.sp').first().addClass('active');
$('.sp').hide();
$('.active').show();

    $('#button-next').click(function(){

    $('.active').removeClass('active').addClass('oldActive');
                   if ( $('.oldActive').is(':last-child')) {
        $('.sp').first().addClass('active');
        }
        else{
        $('.oldActive').next().addClass('active');
        }
    $('.oldActive').removeClass('oldActive');
    $('.sp').fadeOut();
    $('.active').fadeIn();
    });

       $('#button-previous').click(function(){
    $('.active').removeClass('active').addClass('oldActive');
           if ( $('.oldActive').is(':first-child')) {
        $('.sp').last().addClass('active');
        }
           else{
    $('.oldActive').prev().addClass('active');
           }
    $('.oldActive').removeClass('oldActive');
    $('.sp').fadeOut();
    $('.active').fadeIn();
    });
});
</script>
<script>
$("#slideshow > div:gt(0)").hide();setInterval(function() {
$('#slideshow > div:first')
.fadeOut(500)
.next()
.fadeIn(500)
.end()
.appendTo('#slideshow');
}, 5000);

</script>
<script>
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].onclick = function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight){
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    }
  }
}
</script>
<script>
$(document).ready(function(){
    $(".nav-tabs a").click(function(){
        $(this).tab('show');
    });
});
</script>

@endsection