<?php
echo "hi";
include "db2.php";
$userid = $_REQUEST['data1'];
$password=$_REQUEST['data2'];
$sql2="SELECT UserRegId FROM userregistration where UserId=$userid";

$sql="SELECT UserRegId FROM userregistration where Email=$userid";
$sql3="SELECT UserRegId FROM userregistration where Email=$userid AND Password=$password";
$result=$db->query($sql);

$result2=$db->query($sql2);
$result3=$db->query($sql3);
  if(($result!=null)||($result2!=null))
  {
	 if($result3->num_rows>0){
	 echo "";
	 }
	 else {
		 echo "Invalid Username or Password";
	 }
  }
?>
