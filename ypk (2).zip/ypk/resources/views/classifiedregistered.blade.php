	@extends('layouts.app')
	@section('title')
	Желтые страницы Казахстана | Бесплатные объявления ::
	@stop
	@section('description', '')
	@section('keywords', 'Желтые страницы Казахстана')
	@section('content')

	<script>
		$(document).ready(function () {
			// Handler for .ready() called.
			$('html, body').animate({
				scrollTop: 560
			}, 2000); 
		});
	</script>

	<div class="row">
		<div class="col-md-9 top-slider">
			<div class="row" style="margin-bottom:10px;">
				<div class="col-md-12" >
					<h3 class="headerline" >{{__('message.Registered Classified Information')}}</h3>
				</div>
			</div>
			<div class="detail-wrapper">
				<div class="detail-wrapper-header" style="border-bottom:none;">
					<h3 style="font-size: 15px;">{{__('message.Your ad has been posted and will be published soon.')}} </h3>
				</div>
				<div class="detail-success">
					<div>
						<br>
						<h3>{{__('message.Data for your ad')}}</h3>
						<br/>
						<p>{{$userd->ClassifiedTitle}}</p>
						<p>{{$userd->ClassifiedContent}}  </p>
						<!-- <img src="img/help/menu-add-company-img.png" alt="menu-add-company" style="width:100%;margin-top:10px;"> --></div>
						<div>
							<br>
							<h4>{{__('message.Classification details')}}</h4>
							<br/>
							<p><i class="fa fa-list contact-icons" aria-hidden="true" ></i>{{$userd->CategoryName}}</p>
							<p><i class="fa fa-user contact-icons" aria-hidden="true" ></i>{{$userd->Name}}</p>
							<p><i class="fa fa-map-marker contact-icons" aria-hidden="true" ></i>{{$userd->CityName}}</p>
							<p><i class="fa fa-mobile contact-icons" aria-hidden="true" ></i>
							<?php if(  preg_match( '/^(7)(\d{3})(\d{7})$/',  $userd->Phone,  $matches )  && strlen($userd->Phone)==11 )
							{
								$result = '+' .$matches[1] . ' (' .$matches[2] . ') ' . $matches[3];
								echo $result;
							}
							else
							{
								echo "";
							}   
							?></p>
							<p>
								<i class="fa fa-phone contact-icons" aria-hidden="true" ></i>
								<?php if(  preg_match( '/^(7)(\d{3})(\d{7})$/',  $userd->Mobile,  $matches )  && strlen($userd->Mobile)==11 )
								{
								$result = '+' .$matches[1] . ' (' .$matches[2] . ') ' . $matches[3];
								echo $result;
								}
								else
								{
									echo "";
								}   
								?>
							</p>
							<p><i class="fa fa-envelope contact-icons" aria-hidden="true" ></i>{{$userd->Email}}</p>
							<p><i class="fa fa-globe contact-icons" aria-hidden="true" ></i>{{$userd->WebUrl}}</p>
						</div>
					</div>
					<ul class="success-description-text" style="list-style-type:disc">
						<li>
							<p>{{__('message.After approval of the publication of your company by the site administrator, information about your company will be displayed in the search results. The usual publication of the information is free, and is valid for 12 months.')}}</p>
						</li>
						<li>
							<p>{{__('message.Changing the status of your company from the free, to the status of "Premium", will allow 10 times to increase the number of views and responses, compared to the usual publication. Having established the status of "Premium", you can also register one "Premium-Announcement" for free.')}} </p>
						</li>
						<li>
							<p>{{__('message.After changing the free type of placement of the company in the status of "Premium", your company will be in priority as a result of the search. To update your status, please contact us by e-mail: sales@ypk.kz')}}</p>
						</li>
					</ul>
				</div>
			</div>
			<div class="col-md-3">
				@include('classifieds_slide')
			</div>
		</div>
	@endsection