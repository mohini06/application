<div class="rq-search-single">
    <div class="rq-search-content last-child">
        <span class="rq-search-heading">{{ __('message.categories') }}</span>
        <a class="nav-link" href="#" onclick="document.getElementById('id04').style.display='block'" style="width:auto;">
            <input type="text" class="rq-form-element" />
        </a>
    </div>
</div>
<div id="id04" class="modal overflow-modal">
        <!--rami-->
        <form class="modal-content download-body" action="/action_page.php">
            <div class="title-head-modal" style="background-color:#ffce00;height:50px;">
                <span onclick="document.getElementById('id04').style.display='none'" class="download-close" title="Close Modal">&times;</span>
                <h4 class="modal-title" style="padding:15px;text-align: center;">CHOOSE CATEGORY AND SUBCATEGORY</h4>
            </div>

            <div class="container-fluid">

                <div class="categories-popup">
                    <div>

               <br>

                  <div class="category-lists">
                        <?php
                        $row_count=9;
                                    $total_counter=0;

                                    ?>

                                    <?php
                                    for($i=0;$i<3;$i++){
                                        $counter=0;

                        ?>
                         <div class="col-md-4" style="border-right: 1px solid rgba(255, 255, 255, 0.4);">

                            <?php
                              for($j=$counter;$j<$row_count;$j++){
                              ?>
                              <table  cellspacing="0" style="/* border-collapse:collapse; */">
                               <tbody>
                                 <tr>
                                    <td>

                                        <a  href="javascript:showhide('uniquename<?php echo $total_counter;?>')" class="btnCategory" style="cursor:pointer;font-size:13px;" aria-hidden="true" >
                                         <span  class="fa fa-plus-circle" style="cursor:pointer;font-size:13px;">
                                            <?php echo 'hi';
                                            ?>
                                         </span>
                                     </a>
                                       <div  class="sub-category" id="uniquename<?php echo $total_counter;?>" >

                                        <table  cellspacing="0" style="border-collapse:collapse;">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <a style="cursor:pointer;font-size:13px;">hi</a>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        </div>

                                    </td>
                                 </tr>
                               </tbody>
                              <?php
                              $counter++;
                              $total_counter++;
                              }?>
                              </table>
                            </div>
                         <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </form>

    </div>
<script type="text/javascript">
      $(document).ready(function() {

        $('#CategoryCode').on('click', function() {
        var categoryID = $('#CategoryCode').document.getElementById('').innerHTML;
        alert(categoryID);

            if (categoryID) {
                $.ajax({
                    dataType: 'text',

                    type: 'POST',
                    url: 'resources/views/queryforsubcategory.php',
                    //url:'app/Http/Controllers/DynamicController@index2',
                    data: 'category_id=' + categoryID,

                    success: function(html) {
                        console.log(html);

                        $('#subcategory').html(html);
                    },
                    error: function(e) {
                        $('#subcategory').html(e);
                    }
                });
            }
        });

    });
 </script>