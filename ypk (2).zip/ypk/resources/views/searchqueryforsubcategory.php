<?php
include "db.php";
$category_id = $_REQUEST['category_id'];
echo $sql="SELECT * FROM subcategory where CategoryId=$category_id";
$result=$db->query($sql);
$output=array();
if(count($result)>0){
    while($row = $result->fetch(PDO::FETCH_ASSOC)){
        echo '<tr>'.'<td>'.'<input type="hidden" value="'.$row['SubCategoryId'].'">'.'</td>'.'<td>'.$row['SubCategoryName'].'</td>'.'</tr>';
    }
}else
    echo '';
?>