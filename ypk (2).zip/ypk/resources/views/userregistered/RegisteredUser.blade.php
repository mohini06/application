@extends('layouts.app')

@section('content')
  <h1>Add Admins</h1>
  {!! Form::open(['action'=>'AdminController@store','method'=>'POST','files'=>true]) !!}
  <div class="form-group">
   {{form::label('adtitle','Ad title')}}
   {{form::text('adtitle','',['class'=>'formcontrol'])}}
  </div>
   <div class="form-group">
    {{form::label('category','Select Your category')}}
    {{Form::select('category', ['1' => '', '2' => 'Furniture','3' => 'Food'])}}
    </div>
    <div class="form-group">
        {{form::label('subcategory','Select Sub-category')}}
        {{Form::select('subcategory', ['1' => '', '2' => 'Pasta','3' => 'Maggie'])}}
        </div>
  <div class="form-group">
     {{form::label('email','Email')}}
     {{form::text('email','')}}
    </div>
   <div class="form-group">
      {{form::label('name','YourName')}}
      {{form::text('name','')}}
     </div>
     <div class="form-group">
            {{form::label('city','City')}}
            {{Form::select('city', ['1' => '', '2' => 'Bangalore','3' => 'Chennai'])}}
      </div>
    <div class="form-group">
       {{form::label('mnumber','Mobile Number')}}
       {{form::text('mnumber','')}}
      </div>
   <div class="form-group">
      {{form::label('pnumber','Phone number')}}
      {{form::text('pnumber','')}}
     </div>

   <div class="form-group">
         {{form::label('advertisement','Advertisement')}}
         {{form::textarea('advertisement','')}}
        </div>
   <div class="form-group">
         {{form::label('url','Your Site')}}
         {{form::text('url','')}}
        </div>


      {{Form::submit('Submit',['class'=>'btn btn-primary'])}}
  {!! Form::close() !!}
@endsection