




   {{--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">--}}
  {{--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>--}}
   {{----}}
    {{--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>--}}

    <!-- Styles -->
   {{--<style>--}}
   {{--ul{--}}
   {{--list-style-type: none;--}}

   {{--}--}}


    {{--/*#head{*/--}}
    {{--/*font-size: 25px;*/--}}
    {{--/*font-weight: 5px solid white;*/--}}
    {{--/*padding: 3px;*/--}}
    {{--/*color: white;*/--}}
    {{--/*background-color: yellow;*/--}}
    {{--/*}*/--}}

   {{--</style>--}}
@extends('layouts.app')

@section('content')
<div class="clearfix"></div>
    <div class="row ">

    <div class="col-sm-8">
    <div class="row">
      <h3 class="title5" id="head" style="float: left;"><b>Опубликовать!</b></h3>
      <br>
      <a href="{{url('/classifiedhelp')}}" target="blank" style="margin-left:50%;">Помощь</a>
    </div>

     <div class="row bg-success" style="padding: 20px;">
          <p>Пожалуйста предоставьте вашу контактную информацию с точным электронным адресом и телефонным номером с кодом региона. Корректная информация обеспечит быстрый отклик на ваше объявление.</p>
      <hr>
          <form  method="POST" action="{{action('ClassifiedController@store')}}" id="registerForm" role="form">
  {{--<form  method="POST" action="{{action('ClassifiedController@store')}}" >--}}

  <input type="hidden" name="_token" value="{{ csrf_token()}}">



   <div class="row">
     <div class="col-sm-4">
         <div class="form-group">
          <label>Заголовок объявления</label>
          <input type="text" id="ClassifiedTitle" name="ClassifiedTitle" class="form-control">

         </div>
     </div><!-- col-sm-6 end-->
    <div class="col-sm-4">
         <div class="form-group">
           <label>Выберите свою категорию</label>
           <select class="form-control" id="category" name="category">
              <option value=""></option>
              @foreach($category as $categories)
                   <option value="{{$categories->CategoryId}}">{{$categories->CategoryName}}</option>
               @endforeach

           </select>

         </div>
     </div><!-- col-sm-6 end-->
      <div class="col-sm-4">
               <div class="form-group">
                   <label>Подкатегория</label>
                   <select class="form-control " id="subcategory" name="subcategory" >
                       {{--@foreach($subcategory as $subcategories)--}}
                            {{--<option value="{{$subcategories->SubCategoryId}}">{{$subcategories->SubCategoryName}}</option>--}}
                       {{--@endforeach--}}
                   </select>


                </div>
             </div><!-- col-sm-6 end-->
     </div><!-- row 1 end-->
     <div class="row">

        <div class="col-sm-4">
            <div class="form-group">
                 <label>Адрес электронной почты</label>
                 <input type="email" id="email" name="email" class="form-control">

            </div>
         </div><!-- col-sm-6 end-->
         <div class="col-sm-4">
                   <div class="form-group">
                    <label>Ваше имя </label>
                    <input type="text" class="form-control" id="name" name="name">

                   </div>
                 </div><!-- col-sm-6 end-->
                 <div class="col-sm-4">
                            <div class="form-group">
                               <label>Город</label>
                               <select class="form-control" id="city" name="city">
                               <option  value=""></option>
                            @foreach($city as $cities)
                             <option value="{{$cities->CityId}}">{{$cities->CityName}}</option>
                            @endforeach
                               </select>

                            </div>
                         </div><!-- col-sm-6 end-->

    </div><!-- row 2 emd-->

    <div class="row">
    <div class="col-sm-4">
       <div class="form-group">
         <label>Мобильный номер</label>
         <div class="row">
             <div class="col-sm-2">
                 <h5>&nbsp;&nbsp;&nbsp;&nbsp;+7</h5>
             </div>
             <div class="col-sm-10">
                 <input type="text" id="mobile" name="mobile" class="form-control">

             </div>
         </div>
       </div>
</div><!-- col-sm-4 end-->
<div class="col-sm-4">
    <div class="form-group">
       <label>Номер телефона(С кодом города)</label>
       <div class="row">
       <div class="col-sm-2">
         <h5>&nbsp;&nbsp;&nbsp;&nbsp;+7</h5>
       </div>
       <div class="col-sm-10">
         <input type="text" id="phone" name="phone" class="form-control">

       </div>
    </div>
    </div>
</div><!-- col-sm-6 end-->
</div><!-- row 3 emd-->

    <div class="row">
<div class="col-sm-4">
      <div class="form-group">
       <label>Объявление</label>
       <textarea class="form-control" name="ClassifiedContent" id="ClassifiedContent"></textarea>
        <div id="charNum">500 characters left</div>
       <i>(HTML links are not allowed.) Do not use ALL CAPITAL LETTERS)</i>

       </div>
       </div><!-- col-sm-12 end-->
        <div class="col-sm-4">
               <div class="form-group">
                  <label> Ваш сайт (Не забудьте добавить http://)</label>
                  <input type="url" name="Weburl" class="form-control" id="url">
                  </div>
               </div><!-- col-sm-8 end-->
    </div><!-- row 4 emd-->



    <div class="row text-right">
    <div class="col-sm-12">
         <div class="form-group">
          <input type="reset" value="Отмена" class="btn btn-warning">
          <input type="submit" value="Отправить" class="btn btn-success">
         </div>
       </div><!-- col-sm- 4end-->
    </div><!-- row5 end-->

</form>

    </div>
    </div>
    <div class="col-sm-4">

      <div class="row" style="background-color: slategray; padding: 30px; margin-top: 59px; margin-left: 20px; margin-right: 30px;">
          <center>
           <h3 style="color:white; fornt-size:18px;">Разместите бесплатное объявление</h3>
           <img src="{{asset('public/Images/guarantee.png')}}" class="text-center">
           <p style="font-size: 15px; color: black; margin-top: 12px;">Разместите свое объявление бесплатно и без регистрации.
              Ваше объявление будет отображаться в выбранной вами категории.
              Укажите информацию о себе: наименование организации или заголовок вашего объявления;
              к какой категории (раздел) и подкатегории (рубрика) относится ваш бизнес,
              товары или услуги; вставьте текст объявления в поле "Описание"; укажите свой телефон, мобильный номер, сайт и email
            </p>
          </center>
      </div>
    </div>
   </div>



<script type="text/javascript">
 $("#registerForm").validate({
        rules: {
            ClassifiedTitle: {
            required:true
            },
           email:{
            required:true,
            email:true
            },
          name:{
          required: true

          },
          mobile:{
          required:true,
          number:true,
          minlength:10,
          maxlength:10
          },
           phone:{
            required:true,
            number:true,
            minlength:10,
            maxlength:10
           },
           category:{
           required:true

           },
           subcategory:{
            required:true
           },
           city:{
           required:true
           }

        },
        messages:{
            ClassifiedTitle:{
                required:"Please Enter the classified title "
            },

            subcategory:{

            },
            email:{
            required:"Please enter email-id",
            email:"Please enter valid email-id"
            },
            name:{
            required:"Please enter you name"
            },
          mobile:{
          required:"Please enter mobile no",
          number:"Please enter valid mobile number",
          minlength:"minimum 10 number required",
          maxlength:"maximum 10 numbers only"
          },
           phone:{
                 required:"Please enter phone no",
                 number:"Please enter valid phone number",
                 minlength:"min 10 number required",
                 maxlength:"maximum 10 numbers only"
                 },



         category:{
         required:"Please select one category.."
        },
        subcategory:{
        required:"please select subcategory after category"
        },
        city:{
        required:"please select any one"
        }
        }
    })



</script>
       {{--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>--}}
       <!-- Include all compiled plugins (below), or include individual files as needed -->
       {{--<script src="{{ asset('js/bootstrap.min.js')}}"></script>--}}
<script>
$('#ClassifiedContent').keyup(function () {
  var max = 500;
  var len = $(this).val().length;
  if (len >= max) {
    $('#charNum').text(' you have reached the limit');
  } else {
    var char = max - len;
    $('#charNum').text(char + ' characters left');
  }
});

    $(document).ready(function(){
        $('#category').on('change',function(){
            var categoryID = $(this).val();

            if(categoryID){
                $.ajax({
                    dataType: 'text',

                     type:'POST',
                     url:'resources/views/queryforsubcategory.php',
                      //url:'app/Http/Controllers/DynamicController@index2',
                     data:'category_id='+categoryID,

                     success:function(html){
                     console.log(html);

                     $('#subcategory').html(html);
                     },
                     error:function(e){
                     $('#subcategory').html(e);
                     }
               });
            }
        });


    });
</script>
@endsection


{{--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>--}}
{{--<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>--}}
{{--<script src="http://jquery.bassistance.de/validate/additional-methods.js"></script>--}}


  {{--<script type="text/javascript" src="{{ URL::asset('js/ypk.js') }}"></script>--}}


  {{--{!! Form::open(['action'=>'ClassifiedController@store','method'=>'POST','files'=>true]) !!}--}}
  {{--<div class="form-group">--}}
   {{--{{form::label('ClassifiedTitle','Ad title')}}--}}
   {{--{{form::text('ClassifiedTitle','',['class'=>'form-control','id'=>'title'])}}--}}

  {{--</div>--}}
   {{--<div class="form-group">--}}
    {{--{{form::label('category','Select Your category')}}--}}
    {{--{!!form::select('category',$category,null,['class'=>'form-control'] )!!}--}}
    {{--</div>--}}
    {{--<div class="form-group">--}}
        {{--{{form::label('subcategory','Select Sub-category')}}--}}
      {{--{!! form::select('subcategory', $subcategory, null,['class'=>'form-control'] ) !!}--}}
        {{--</div>--}}
  {{--<div class="form-group">--}}
     {{--{{form::label('email','Email')}}--}}
     {{--{{form::text('email','',['class'=>'form-control'])}}--}}
    {{--</div>--}}
   {{--<div class="form-group">--}}
      {{--{{form::label('name','YourName')}}--}}
      {{--{{form::text('name','',['class'=>'form-control'])}}--}}
     {{--</div>--}}
     {{--<div class="form-group">--}}
            {{--{{form::label('city','City')}}--}}
            {{--{{form::select('city',$city,null,['class'=>'form-control'])}}--}}
      {{--</div>--}}
    {{--<div class="form-group">--}}
       {{--{{form::label('Mobile','Mobile Number')}}--}}
       {{--{{form::text('Mobile','',['class'=>'form-control'])}}--}}
      {{--</div>--}}
   {{--<div class="form-group">--}}
      {{--{{form::label('phone','Phone number')}}--}}
      {{--{{form::text('phone','',['class'=>'form-control'])}}--}}
     {{--</div>--}}

   {{--<div class="form-group">--}}
         {{--{{form::label('ClassifiedContent','Advertisement')}}--}}
         {{--{{form::textarea('ClassifiedContent','',['class'=>'form-control'])}}--}}
        {{--</div>--}}
   {{--<div class="form-group">--}}
         {{--{{form::label('Weburl','Your Site')}}--}}
         {{--{{form::text('Weburl','',['class'=>'form-control'])}}--}}
        {{--</div>--}}


   {{--{{Form::submit('Submit',['class'=>'btn btn-primary'],['class'=>'form-control'])}}--}}
  {{--{!! Form::close() !!}--}}






{{--<script type="text/javascript">--}}
    {{--$('#category').change(function(){--}}
    {{--var categoryID = $(this).val();--}}
    {{--if(categoryID){--}}
        {{--$.ajax({--}}
           {{--type:"GET",--}}
           {{--url:"{{url('api/get-subcategory-list')}}?CategoryId="+categoryID,--}}
           {{--success:function(res){--}}
            {{--if(res){--}}
                {{--$("#subcategory").empty();--}}
                {{--$("#subcategory").append('<option>Select</option>');--}}
                {{--$.each(res,function(key,value){--}}
                    {{--$("#subcategory").append('<option value="'+key+'">'+value+'</option>');--}}
                {{--});--}}

            {{--}else{--}}
               {{--$("#subcategory").empty();--}}
            {{--}--}}
           {{--}--}}
        {{--});--}}
    {{--}else{--}}
        {{--$("#subcategory").empty();--}}

    {{--}--}}
   {{--});--}}



