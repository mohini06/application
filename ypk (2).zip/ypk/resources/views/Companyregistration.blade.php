 @extends('layouts.app')
 @section('title')
Регистрация на Желтых Страницах Казахстана
@stop
@section('description', 'Разместите  бесплатно свою компанию на Желтых Страницах Казахстана и привлекайте новых клиентов.  Присоединяйтесь к нам, заполнив простую форму.-Place a free listing on Yellow Pages Kazakhstan and reach out to millions of people by attracting new customers as well as provide valuable information to existing customers. Fill out a simple form and join instantly.')
@section('keywords', 'Бесплатная публикация, реклама, онлайн продвижение бизнеса, онлайн реклама, бизнес маркетинг, продвижение бизнеса.-Free listing, advertising, online business promotion, online advertising, local business marketing, local business promotion.')
 @section('content')
     <script>
$(document).ready(function () {
         // Handler for .ready() called.
         $('html, body').animate({
             scrollTop: 560
         }, 2000);
     }); </script>
<div class="clearfix"></div>
<div class="row">
    <div class="col-md-9" style="padding-left: 0px;padding-right: 0px;">
        <div class="col-md-6">
            <h3 class="headerline"> {{__('message.Add your listing')}} </h3></div>
        <div class="col-md-3">
        </div>
        <div class="col-md-3">
            <a href="{{url('/company-help')}}" target="_blank">
                <h3 class="headerline" style="background-color: #ffce00; color: white; font-size: 18px; width: 30px; text-align: center;  padding: 5px; border-radius: 19px;  margin-bottom: 10px; float: right;">
        	   <i class="fa fa-info" aria-hidden="true"></i></h3></a>
        </div>
    </div>
    <div class="col-md-3">

    </div>
</div>
<!--rami-->
<div class="col-md-12 no-padding">
    <div class="content-section">

        <div class="row">

            <div class="col-md-9" style=" background: #ffffff; padding: 15px 20px;">
                <form method="POST" id="registerForm" action="{{action('CompanyController@store')}}" role="form">
                  <input type="hidden" name="_token" value="{{ csrf_token()}}">
                    <div class="row" style="padding-bottom: 10px;">
                        <div class="col-md-4 user-input-wrp">
						<br/>
                            <input type="text" class="inputText" id="CompanyName" name="CompanyName"/>
                            <span class="floating-label">{{__('message.Company Name')}}<span style="color:red;">*</span></span>
						
                        </div>
                        <div class="col-md-4  user-input-wrp">
						<br/>
  <input type="text"  class="inputText"  id="ContactName" name="ContactName" >
  <span class="floating-label">{{__('message.Contact Name')}} <span style="color:red;">*</span></span> 
                        </div>
                        <div class=" col-md-4 user-input-wrp">
					
                     <br/>
                            <input type="text" class="inputText" id="Email" name="Email" autocomplete="off"/>
                            <span class="floating-label">{{__('message.Email Address')}} <span style="color:red;">*</span></span>
                            <label id="errormessage"></label>
                        </div>
                    </div>
                    <div class="row" style="padding-bottom: 10px;">
                        <div class="col-md-4 user-input-wrp">
						
                            <br/>
                            <input type="text" class="inputText" id="UserName" name="UserName"/>
                            <span class="floating-label">{{__('message.Enter your username')}}<span style="color:red;">*</span></span>
							<label id="errormessage2"></label>
                        </div>
                        <div class="col-md-4 ">
						
                            <input type="button" id="checkuser" class="btn-grad" value="{{__('message.Check Availability')}}" style=" height:40px; width:184px;" />

                        </div>
                        <div class=" col-md-4 user-input-wrp">
                            <br/>
                            <input type="text" class="inputText" id="PostalCode" name="PostalCode"/>
                            <span class="floating-label">{{__('message.Postcode')}}<span style="color:red;">*</span></span>
                        </div>
                    </div>
                    <div class="row" style="padding-bottom: 10px;">
                        <div class="col-md-4 user-input-wrp">
						
                            <br/>
                            <input type="password" class="inputText" id="Password" name="password"/>
                            <span class="floating-label">{{__('message.Password')}} <span style="color:red;">*</span></span>
                        </div>
                        <div class="col-md-4  user-input-wrp">
                           <br/>
                            <input type="password" class="inputText" id="Confirmpassword" name="Confirmpassword" />
                            <span class="floating-label">{{__('message.Enter the password again')}}<span style="color:red;">*</span></span>
                        </div>
                           <div class="col-md-4 user-input-wrp">
                            <br/>
                            <input type="text" id="Address1" name="Address1" class="inputText"/>
                            <span class="floating-label">{{__('message.Street Address')}}<span style="color:red;">*</span></span>
                        </div>
                    </div>
                    <div class="row" style="padding-bottom: 10px;">
					<div class=" col-md-6 user-input-wrp">
                         <br/>
                            <input type="text" id="phone" name="phone"class="inputText phonemask" />
                           <span class="floating-label">{{__('message.Phonenumber')}}<span style="font-size: 11px;">{{__('message.Addprefix')}}</span><span style="color:red;">*</span></span>
                        </div>
                        <div class=" col-md-6 user-input-wrp">
                            <br/>
                            <input type="text" id="mobile" name="mobile" class="inputText2 phonemask"/>
                            <span class="floating-label">{{__('message.Mobilenumber')}}<span style="font-size: 11px;">{{__('message.Addprefix')}} </span></span>
                        </div>
                    </div>
                    <div class="row" style="padding-bottom: 10px;">
					  <div class="col-md-4  user-input-wrp">
                            <br/>
                            <input type="text" class="inputText" id="Address2" name="Address2"/>
                            <span class="floating-label">{{__('message.Building / office number')}} <span style="color:red;">*</span></span>
                        </div>
                        <div class="col-md-4 user-input-wrp">
                            <br/>
                            <select class="category" id="category" name="category">
                               <option value=""></option>
							   @foreach($category as $categories)
                                   <option value="{{$categories->CategoryId}}">{{$categories->CategoryName}}</option>
                                @endforeach
                            </select>
							 <span class="floating-label" id="categoryname">{{__('message.Select your category')}}<span style="color:red;"> * </span></span>
                        </div>
                        <div class="col-md-4  user-input-wrp">
                            <br/>
                            <select class="category" id="subcategory" name="subcategory">
                            </select>
							<span class="floating-label" id="subcategoryname">{{__('message.Select subcategory')}}<span style="color:red;"> * </span></span>
                        </div>
                    </div>
                    <div class="row" style="padding-bottom: 10px;">
					 <div class=" col-md-4 user-input-wrp">
                            <br/>
                            <input type="text" id="FaxNo" name="FaxNo" class="inputText"/>
                            <span class="floating-label">{{__('message.Fax number')}}</span>
                        </div>
                        <div class="col-md-4 user-input-wrp">
                            <br/>
                            <select class="category" id="City" name="City">
                               <option value=""></option>
                                 @foreach($city as $cities)
                                    <option value="{{$cities->CityId}}">{{$cities->CityName}}</option>
                                 @endforeach
                            </select>
							 <span class="floating-label" id="cityname">{{__('message.SelectCity')}}<span style="color:red;"> * </span></span>
                        </div>
                        <div class="col-md-4  user-input-wrp">
                            <br/>
                            <select class="category" id="Area" name="Area">
                            </select>
							 <span class="floating-label" id="areaname">{{__('message.SelectArea')}}<span style="color:red;">  </span></span>
                        </div>
                    </div>

                    <div class="row">
					  <div class=" col-md-4 user-input-wrp">
                            <br/>
                            <input type="text" id="term" name="WebsiteLink"class="inputText"  />
                            <span class="floating-label">{{__('message.Yoursite')}}{{__('message.Startwithhttp')}}</span>
                        </div>
                        <div class=" col-md-4 user-input-wrp">
                            <br/>
                            <input type="text" class="inputText date"   name="dateofincorporation"id="date" />
                            <span class="floating-label">{{__('message.DateofIncorporation')}}<span style="color:red;">*</span></span>
                        </div>
                        <div class=" col-md-4 user-input-wrp">
                            <br/>
                            <span class="headline" style="margin-left: 4px;margin-top: 4px; position: absolute;">{{__('message.Describe your business')}}<span style="color:red;">*</span></span>
                             <textarea placeholder="{{__('message.This is an awesome comment box')}}" rows="20" id="DescribeBusiness" name="DescribeBusiness"  cols="40" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true" style="resize:none !important;"></textarea>
           <div id="charNum">500 {{__('message.charactersleft')}}</div>
                      <i>({{__('message.HTML links are not allowed')}}){{__('message.Do not use ALL CAPITAL LETTERS')}}</i>
					    <h5 style="text-align: justify;width:100%; margin-top: 6px;">({{__('message.Use keywords to more easily search your company for your activity, the products and services offered')}})</h5>
            </div>
                    </div>
                    <div class="row" style="padding-top:10px;">
                        <div style="margin-left:15px;">
                            <input type="checkbox" id="myCheck" name ="myCheck" /><span class="headline hd2">{{__('message.I agree with the publication of my data')}}</span><br>
                        </div>
                    </div>
                    <div class="row">
                        <div style="float:right;padding-top: 20px;padding-left: 15px;">
                            <input type="submit" class="btn-grad" value="{{__('message.Send')}}"  style=" margin-right:15px; height:40px; width:100px;" />
                            <a href="{{url('/')}}">
							<input type="button" class="btn-grad" value="{{__('message.cancel')}}" style=" height:40px; width:100px;"/></a>
					     </div>
                    </div>
                </form>
            </div>

            <div class="col-md-3 mobile-padding">
                <!--rami-->
                <div style="background: #fff;">
                    <center>
                        <div class="post" style="padding:15px 20px;">
                            <h4>{{__('message.Post free classifieds')}}</h4>
                            <img src="{{asset('/public/Images/guarantee.png')}}" class="img-responsive guarantee" alt="guarantee" />
                            <p style="text-align: justify;">{{__('message.guarenteedescription')}} </p>
                        </div>
                    </center>
                </div>
            </div>
        </div>

    </div>
</div>
   
  <script type="text/javascript">
    var username_exists = false;
	function username_ajax(){
		    var username = $("#UserName").val();

            if ((username!="")&&(username.length >=6)) {
                $.ajax({
                    dataType: 'json',

                    type: 'POST',
                    url: 'resources/views/checkuserId.php',
                    
                    data: 'user_name=' + username,

                    success: function(html) {
					
						if(html){
							 $('#errormessage2').html('Имя пользователя доступно').show();
						}
                    },
                    error: function(e) {
                        $('#errormessage2').html(e).show();
                    }
                });
            }
	}
    $(document).ready(function() {
        $('#checkuser').on('click', function() {
			username_ajax();
        });
       
	   $( "input" ).focus(function() {
  $("#errormessage2").hide();
});
	   
    });
	
 </script>
<script type="text/javascript">

        $('#category').on('change', function() {
        var categoryID = $(this).val();
            if (categoryID) {
                $.ajax({
                    dataType: 'text',

                    type: 'POST',
                    url: 'subcategory_list',
                    data: 'category_id=' + categoryID,

                    success: function(html) {
                        console.log(html);

                        $('#subcategory').html(html);
                    },
                    error: function(e) {
                        $('#subcategory').html(e);
                    }
                });
            }
        });

 
     $(document).ready(function() {
            $('#City').on('change', function() {
				
                var cityID = $(this).val();

                if (cityID) {
                    $.ajax({
                        dataType: 'text',
                        type: 'POST',
                        url: 'resources/views/queryforarea.php',
                        data: 'city_id=' + cityID,

                        success: function(html) {
                            console.log(html);

                            $('#Area').html(html);
                        },
                        error: function(e) {
                            $('#Area').html(e);
                        }
                    });
                }
            });

        });
        $('#DescribeBusiness').keyup(function() {
                var max = 500;
                var len = $(this).val().length;
                if (len >= max) {
                    $('#charNum').text(' you have reached the limit');
                } else {
                    var char = max - len;
                    $('#charNum').text(char + '{{__('message.charactersleft')}}');
                }
            });


    $("#registerForm").submit(function(e) {
			
        e.preventDefault();
       }).validate
	   ({
  
        rules: {
            CompanyName: {
                required: true,
				
            },
            ContactName: {
                required: true,
                lettersonly: true
            },
            Email: {
                required: true,
                email: true,
                remote: {
					url: "resources/views/checkemail.php",
					type: "post",
					data: {
					  email_id: function() {
						return $( "#Email" ).val();
					  }
					}
				}

            },
            UserName: {
                required: true,
                minlength: 6,
				username_exists: false,
				  remote: {
					url: "resources/views/checkuserId.php",
					type: "post",
					data: {
					  user_name: function() {
						return $( "#UserName" ).val();
					  }
					}
				}
            },
            PostalCode: {
                required: true,
                number: true
            },
            password: {
                required: true,
				 minlength: 5,
                maxlength: 20
            },
            Confirmpassword: {
                required: true,
                equalTo: "#Password"
            },
            phone: {
                required: true,
				validecode: true, 
            },
			mobile:{
				validecode: true, 
			},

            Address1: {
                required: true
            },
            FaxNo:{
				 number: true,
                minlength: 10,
                maxlength: 10,
		       validecode: true, 
			},
            Address2: {
                required: true
            },

            City: {
                required: true
            },
            
            category: {
                required: true

            },
            subcategory: {
                required: true

            },
			 DescribeBusiness: {
                required: true,
                minlength: 30,
                maxlength: 500
            },
			dateofincorporation: {
				required : true
			},
			myCheck:{
				required:true
            },
            WebsiteLink:
            {
                valideurl : true
            }
        },
        messages: {
            CompanyName: {
                required: "{{__('message.Please Enter your company name')}}",
            },
            ContactName: {
                required: "{{__('message.Please Enter your name')}}",
                lettersonly: "{{__('message.Please Enter only character') }}"
            },
            Email: {
                required: "{{__('message.Please Enter your email aadress')}}",
                email: "{{__('message.Please Enter valid email')}}",
                remote: "{{__('message.Email already exist')}}"
            },

            UserName: {
                required: "{{__('message.Please Enter Unique User name')}}",
                minlength: "{{__('message.Please Enter Atleast 6 Characters')}}",
				username_exists:"{{__('message.Please Enter Unique User name')}}",
				 remote:"{{__('message.Please Enter Unique User name')}}",
            },
            PostalCode: {
                required: "{{__('message.Please Enter postalcode')}}",
                number: "{{__('message.Please Enter digits')}}"
            },
            password: {
                required: "{{__('message.Please enter password')}}",
				 minlength: "Minimum 5 ",
                maxlength: "Maximum 20"
            },

            Confirmpassword: {
                required: "{{__('message.Please enter password again')}}",
                equalTo: "{{__('message.Password should match with confirm password')}}"
            },
            phone: {
                required: "{{__('message.please enter mobile number')}}",
                validecode: "{{__('message.country code should be valid')}}"
            },
			FaxNo:{
				 number: "{{__('message.please enter only numbers')}}",
                minlength: "{{__('message.minimum 10 numbers required')}}",
                maxlength: "{{__('message.maximum 10 numbers only')}}",
				validecode: "{{__('message.country code should be valid')}}"
			},
			mobile:{
				validecode: "{{__('message.country code should be valid')}}"
			},
            Address1: {
                required: "{{__('message.Please enter address')}}"
            },
            Address2: {
                required: "{{__('message.Please enter address')}}"
            },
            City: {
                required: "{{__('message.Please select one city')}}"
            },
            category: {
                required: "{{__('message.Please select one category')}}"
            },
            subcategory: {
                required: "{{__('message.please select one subcategory after category')}}"
            },
			DescribeBusiness: {
                 required: "{{__('message.Write Something')}}",
                minlength: "{{__('message.Minimum 30 characters required')}}",
                maxlength: "{{__('message.Maximum 500 characters')}}"
            },
			dateofincorporation: {
				required : "{{__('message.Pleaseselectdateofincorporation')}}"
			},
			myCheck:{
				required:"{{__('message.Tick the box')}}",
            },
            WebsiteLink:
            {
                valideurl : "{{__('message.Please_enter_valide_url')}}"
            }
        },
		
		submitHandler: function(form) {
			
			var username = $("#UserName").val();

            if (username!="") {
                $.ajax({
                    dataType: 'json',

                    type: 'POST',
                    url: 'resources/views/checkuserId.php',
                    data: 'user_name=' + username,

                    success: function(html) {
						if(html.error){
							username_exists = true;
						}else{
							username_exists = false;
						}
						console.log(html);
                        $('#errormessage2').html(html.message).show();
						
						    if(username_exists==false)
										{
											form.submit();
										}
										return false;
				
                    },
                    error: function(e) {
						
                        $('#errormessage2').html(e).show();
						
                    }
                });
            }
			else {
				$('#errormessage2').html('{{__('message.Please Enter Unique User name')}}').show();
			}
			return false;
		}
    });
</script>
@endsection