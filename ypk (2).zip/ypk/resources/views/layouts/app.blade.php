<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">

<head>
<!--<script async src="https://www.googletagmanager.com/gtag/js?id=UA-108988872-1"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag() { dataLayer.push(arguments); }
gtag('js', new Date());

gtag('config', 'UA-108988872-1');
</script>-->
    <meta charset="UTF-8">
   <!-- Title -->
    <link rel="icon" href="{{asset('/public/Images/favicon.png')}}">
    <title>@yield('title')</title>
    <meta name="description" content="@yield('description')">
    <meta name="keywords" content="@yield('keywords')">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">-->

    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400" rel="stylesheet">
    
    
    <link rel="stylesheet" href="{{asset('/public/css/others/font-awesome.min.css')}}" />
    <link rel="stylesheet" href="{{asset('/public/css/new-style.css')}}" />
	 <link rel="stylesheet" href="{{asset('/public/css/easy-autocomplete.css')}}" />

    <!-- Favicon -->
   

    <!-- Core Stylesheet -->
    <link href="{{asset('/public/css/others/style.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('/public/css/bootstrap/bootstrap.css')}}" />
    <!-- Responsive CSS -->
    <link href="{{asset('/public/css/responsive/responsive.css')}}" rel="stylesheet">
    <link href="{{asset('/public/css/bootstrap/bootstrap.min.css')}}" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('/public/css/others/pe-icon-7-stroke.css')}}" />
    <!--datepickr-->
    <link rel="stylesheet" href="{{asset('/public/css/bootstrap-material-datetimepicker.css')}}" />
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,500' rel='stylesheet' type='text/css'>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link href="{{asset('public/css/ninja-slider.css')}}" rel="stylesheet" type="text/css"/>
    <script src="{{asset('public/js/ninja-slider.js')}}" type="text/javascript"></script>
    <script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
	
    <script type="text/javascript" src="http://momentjs.com/downloads/moment-with-locales.min.js"></script>
    <script type="text/javascript" src="{{asset('/public/js/bootstrap-material-datetimepicker.js')}}"></script>
    <!--/datepickr-->
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
    <script>
     
    
     
      
        $(document).ready(function() {
            $("#tab_content").find("[id^='tab']").hide(); // Hide all content
            $("#tabs_classified li:first").attr("id", "current"); // Activate the first tab
            $("#tab_content #tab1").fadeIn(); // Show first tab's content

            $('#tabs_classified a').click(function(e) {
                e.preventDefault();
                if ($(this).closest("li").attr("id") == "current") { //detection for current tab
                    return;
                } else {
                    $("#tab_content").find("[id^='tab']").hide(); // Hide all content
                    $("#tabs_classified li").attr("id", ""); //Reset id's
                    $(this).parent().attr("id", "current"); // Activate this
                    $('#' + $(this).attr('name')).fadeIn(); // Show content for the current tab
                }
            });
        });
    </script>
    <style>
       @media(min-width:1200px)and (max-width:1300px) {
.rq-search-single {
position: relative;
width: 23.5%;
}
}
@media(min-width:1350px) {
.rq-search-single {
position: relative;
width: 25%;
height: 60px;
text-align: left;
padding: 15px 0 15px 15px;
background: #fff;
}
}

        .rq-search-container {
            position: absolute;
            width: 100%;
            display: flex;
            flex-direction: row;
            align-items: flex-start;
            border-radius: 2px;
            margin: 7%;
            z-index: 0;
            top: 43%;
        }
  @media(max-width:768px) {
            .rq-search-container {
              
                margin-left:3% ! important;
             
            }
        
        }

        @media(max-width:420px) {
            .rq-search-container {
                position: absolute;
                width: 100%;
                display: block;
                flex-direction: row;
                align-items: flex-start;
                border-radius: 2px;
                margin-left: 0px ! important;
                z-index: 30;
                top: 50%;
            }
            .rq-search-single {
                position: relative;
                width: 100%;
                height: 70px;
                text-align: left;
                padding: 15px 0 15px 15px;
            }
        }
@media(max-width:320px) {
            .rq-search-container {
                position: absolute;
                width: 100%;
                display: block;
                flex-direction: row;
                align-items: flex-start;
                border-radius: 2px;
                margin-left: 0px ! important;
                z-index: 30;
                top: 50%;
            }
            .rq-search-single {
                position: relative;
                width: 100%;
                height:auto;
                text-align: left;
                padding: 15px 0 0px 15px;
            }
			.navbar-nav li a {
				font-size:12px;
			}
			.focus-image {
        font-size: 10px;
}
        }
        * {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
        }

        user agent stylesheet div {
            display: block;
        }

        .header .header-body {
            position: relative;
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            z-index: 10;
        }

        .rq-search-wrapper .rq-search-toggle {
            font-size: 24px;
            margin-bottom: 15px;
            position: relative;
            z-index: 30;
        }

        .rq-search-wrapper {
            position: relative;
        }

        .rq-search-content .rq-search-heading {
            display: block;
            font-size: 12px;
            color: #ecb510;
            font-weight: 700;
            text-transform: uppercase;
            font-family: 'Open Sans', sans-serif;
            line-height: 12px;
        }

        input[type="text"].rq-form-element {
            position: relative;
            width: 100%;
            outline: 0;
            font-family: "Open Sans";
            font-size: 14px;
        }

        .rq-search-content input[type="text"] {
            border: 0;
            color: #000000;
            font-size: 12px;
        }

        .rq-search-content {
            position: relative;
            width: 100%;
            height: 100%;
            border-right: 1px solid #ffce00;
        }

        .rq-search-content .selectize-control {
            height: 33px;
        }

        .selectize-control {
            position: relative;
        }

        .rq-search-content .selectize-control .selectize-input {
            border: 0;
            box-shadow: none;
            padding: 4px 0 11px;
            padding-left: 0px;
            border-radius: 0;
            font-size: 14px;
        }

        .selectize-control.single .selectize-input,
        .selectize-control.single .selectize-input input {
            cursor: pointer;
        }

        .selectize-input.full {
            background-color: #fff;
        }

        .selectize-input {
            border: 1px solid #d0d0d0;
            padding: 8px 8px;
            display: inline-block;
            width: 100%;
            overflow: hidden;
            position: relative;
            z-index: 1;
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.1);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.1);
            -webkit-border-radius: 3px;
            -moz-border-radius: 3px;
            border-radius: 3px;
        }

        .selectize-input,
        .selectize-control.single .selectize-input.input-active {
            background: #fff;
            cursor: text;
            display: inline-block;
        }

        .selectize-dropdown,
        .selectize-input,
        .selectize-input input {
            color: #303030;
            font-family: inherit;
            font-size: 13px;
            line-height: 18px;
            -webkit-font-smoothing: inherit;
        }

        .rq-search-content .selectize-dropdown {
            margin: -1px 0;
            border-radius: 0 0 2px 2px;
            border: 0;
            padding-bottom: 10px;
            box-shadow: 0px 4px 10px 3px rgba(0, 0, 0, 0.1);
        }

        .selectize-dropdown {
            position: absolute;
            z-index: 10;
            border: 1px solid #d0d0d0;
            background: #fff;
            margin: -1px 0 0 0;
            border-top: 0 none;
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
            -webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            -webkit-border-radius: 0 0 3px 3px;
            -moz-border-radius: 0 0 3px 3px;
            border-radius: 0 0 3px 3px;
        }

        .selectize-dropdown,
        .selectize-input,
        .selectize-input input {
            color: #303030;
            font-family: inherit;
            font-size: 13px;
            line-height: 18px;
            -webkit-font-smoothing: inherit;
        }

        ::selection {
            background-color: #ecb510;
            color: white;
        }

        select {
            -webkit-appearance: menulist;
            box-sizing: border-box;
            align-items: center;
            white-space: pre;
            -webkit-rtl-ordering: logical;
            color: black;
            background-color: white;
            cursor: default;
            border-width: 0px;
            border-style: solid;
            border-color: initial;
            border-image: initial;
            outline: none;
            margin-left: -4px;
            width: 100%;
            font-size: 14px;
        }

        .rq-search-single.search-btn .rq-search-content .rq-btn {
            font-size: 14px;
            height: 100%;
            font-weight: 700;
            text-transform: uppercase;
            font-family: 'Open Sans', sans-serif;
            border-radius: 0 2px 2px 0;
            font-weight: 700;
        }

        .rq-btn.fluid-btn {
            width: 100%;
        }

        .rq-btn-primary {
            background: #ffce00;
            color: #f5f5f5;
            padding: 10px 30px;
            border-radius: 2px;
        }

        .rq-btn {
            display: inline-block;
            margin-bottom: 0;
            font-weight: normal;
            text-align: center;
            vertical-align: middle;
            touch-action: manipulation;
            cursor: pointer;
            background-image: none;
            border: 1px solid transparent;
            white-space: nowrap;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            font-family: "Montserrat-Regular";
            text-transform: uppercase;
            -webkit-transition: 0.3s;
            -o-transition: 0.3s;
            transition: 0.3s;
            transition: all 0.3s ease;
        }

        .rq-btn-primary:hover,
        .rq-btn-primary:active,
        .rq-btn-primary:focus {
            background: #ffce00;
            color: #fff;
            border-right: 0px;
        }

        .search-btn {
            padding: 0px;
        }

        .serch-background {
            border-right: 0px;
            border-radius: 0%;
        }

        .last-child {
            border-right: 0px;
            border-radius: 0%;
        }

        .slider-index img {
            width: 100%;
            height: 635px! important;
        }

        .marquee-text {
            background: #ffce00;
            color: #000;
            font-size: 13px;
            font-weight: 500;
			
            position: relative;
        }

        .banner-sec {
            width: 100%;
            padding-top: 40px;
            padding-bottom: 40px;
        }

        .banner-sec .news-block {
            margin-bottom: 20px
        }

        .banner-sec .news-block:last-child {
            margin-bottom: 0px
        }

        .banner-sec .news-des {
            margin-bottom: 5px;
        }

        .banner-sec .title-large {
            margin: 18px 0 0
        }

        .banner-sec .time {
            margin-top: 0px;
            font-size: 13px;
        }

        .banner-sec .carousel-control.left,
        .banner-sec .carousel-control.right {
            background: none;
        }

        .banner-sec .card {
            margin-bottom: 20px;
        }

        .carousel-indicators .active {
            background-color: #ffce00;
        }

        .carousel-indicators li {
            background-color: #ffce00;
        }

        .carousel-control {
            color: #ffec00;
            width: 8%;
            opacity: 1;
        }

        .heading-title {
            color: #ffffff;
            width: 25%;
            font-size: 18px;
            background: #ffce00;
            padding: 5px;
        }

        .heading-title2 {
            color: #ffffff;
            width: 100%;
            font-size: 18px;
            background: #ffce00;
            padding: 5px;
        }

        .w3ls-portfolio-left {
            background: #ffffff;
            border: 4px solid #f2f1ef;
            height: 170px;
        }

        .portfolio-img {
            width: 40%;
            float: left;
        }

        .portfolio-description {
            width: 60%;
            float: left;
            padding: 10px 15px 0;
        }

        .portfolio-description h4 {
            text-align: left;
			display: block;
			
display: -webkit-box;
max-width: 100%;
margin: 0 auto;
line-height: 1;
-webkit-line-clamp:2;
-webkit-box-orient: vertical;
overflow: hidden;
text-overflow: ellipsis;
			
        }

        .portfolio-description a {
            color: #f7b100
        }

        .portfolio-description p {
            color: #616161;
            font-size: 13px;
            font-weight: 400;
            line-height: 1.8em;
            margin: 0;
			display: block;
			padding:15px  0px;
			height:56px;
display: -webkit-box;
max-width: 100%;
margin: 0 auto;
line-height: 1;
-webkit-line-clamp:3;
-webkit-box-orient: vertical;
overflow: hidden;
text-overflow: ellipsis;
        }

        .like-rating-box span {
            display: block;
        }

        .like-rating-box,
        .like-rating-box i {
            color: #ffce00;
        }

        .apus-footer {
            background: #121212;
            padding: 0;
            position: relative;
            color: #8d99ae;
            border-bottom: none;
            font-size: 14px;
            overflow: hidden;
        }

        .w3l_header {
            font-size: 3em;
            color: #262c38;
            letter-spacing: 1px;
            position: relative;
            font-weight: 600;
            text-align: left;
            font-family: 'Montserrat', sans-serif;
            margin-bottom: 30px;
        }

        .w3l_header span {
            color: #545151;
            font-weight: 200;
            font-family: 'Montserrat', sans-serif;
        }

        .w3l_header:after {
            border-top: 2px solid #ffce00;
            display: block;
            width: 81px;
            content: "";
            margin: 8px;
        }

        email::placeholder {
            color: white;
        }

        .img-responsive {
            padding-top: 12px;
            padding-bottom: 12px;
        }

        .navbar-nav li {
            padding-left: 14px;
            padding-right: 14px;
        }
        /*-------Right slider starts--------*/

        .tech-btm {
            margin-top: 5px;
            background: #d6e4d8;
        }

        .tech-btm.one {
            padding: 0;
            margin: 0;
        }

        .blo-top,
        .blo-top1 {
            border: 1px solid #ddd;
            padding: 12px;
            margin: 16px 0 1em 0;
            background: #79907e;
        }

        .agileits_twitter_posts {
            margin: 1em 0;
        }

        .agileits_twitter_posts ul {
            margin: 0;
            padding: 0
        }

        .tech-btm h4,
        .agileits_twitter_posts h4 {
            font-size: 1.2em;
            color: #333333;
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 0.5em;
            text-align: center;
        }

        .agileits_twitter_posts ul li {
            list-style-type: none;
            color: #fff;
            line-height: 2em;
            font-size: 0.9em;
            padding-left: 1em;
        }

        .agileits_twitter_posts ul li i {
            color: #2eacf6;
            padding-left: 0em;
            margin-right: 1em;
        }

        .tech-btm h4,
        .agileits_twitter_posts h4 {
            font-size: 13px;
            color: #333333;
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 0.5em;
            text-align: left;
        }
		.tech-btm h4{
			display: block;
display: -webkit-box;
max-width: 100%;
margin: 0 auto;
font-size: 13px;
line-height: 1;
-webkit-line-clamp:2;
-webkit-box-orient: vertical;
overflow: hidden;
text-overflow: ellipsis;
		    
}
.tech-btm p{
	padding:10px 5px 5px 0px;
			display: block;
			height:40px;
display: -webkit-box;
max-width: 100%;
margin: 0 auto;
line-height: 1;
-webkit-line-clamp:2;
-webkit-box-orient: vertical;
overflow: hidden;
text-overflow: ellipsis;
		   
}
        .blog-grids {
            border-bottom: 9px solid #f2f1ef;
            padding: 11px 0;
            background-color: #ffffff;
        }

        .blog-grids a {
            -webkit-column-rule: #fff;
            -moz-column-rule: #fff;
            -o-column-rule: #fff;
            column-rule: #fff;
        }

        .blog-grid-left {
            float: left;
            width: 36%;
        }

        .blog-grid-right {
            float: right;
            width: 54%;
            background-color: #ffffff;
            margin-left: 0.5em;
        }

        .share i {
            font-size: 20px;
            color: #ffce00;
        }

        .responsive {
            margin-left: 15px;
        }
        /*-------Right slider ends--------*/
        /* Extra styles for the cancel button */

        .cancelbtn {
            width: auto;
            padding: 10px 18px;
            background-color: #f44336;
        }
        /* Center the image and position the close button */

        .imgcontainer {
            text-align: center;
            margin: 24px 0 12px 0;
            position: relative;
        }
        /* The Modal (background) */

        .modal {
            display: none;
            /* Hidden by default */
            position: fixed;
            /* Stay in place */
            z-index: 1;
            /* Sit on top */
            left: 0;
            top: 0;
            width: 100%;
            /* Full width */
            height: 100%;
            /* Full height */
            overflow: auto;
            /* Enable scroll if needed */
            background-color: rgb(0, 0, 0);
            /* Fallback color */
            background-color: rgba(0, 0, 0, 0.4);
            /* Black w/ opacity */
            padding-top: 60px;
        }
        /* Modal Content/Box */

        .modal-content {
            background-color: #fefefe;
            margin: 5% auto 15% auto;
            /* 5% from the top, 15% from the bottom and centered */
            border: 1px solid #888;
            width: 43%;
            /* Could be more or less, depending on screen size */
        }
        /* The Close Button (x) */

        .close {
            position: absolute;
            right: 25px;
            top: -28px;
            color: #000;
            font-size: 35px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: red;
            cursor: pointer;
        }
        /* Add Zoom Animation */

        .animate {
            -webkit-animation: animatezoom 0.6s;
            animation: animatezoom 0.6s
        }

        @-webkit-keyframes animatezoom {
            from {
                -webkit-transform: scale(0)
            }
            to {
                -webkit-transform: scale(1)
            }
        }

        @keyframes animatezoom {
            from {
                transform: scale(0)
            }
            to {
                transform: scale(1)
            }
        }
        /* Change styles for span and cancel button on extra small screens */

        @media screen and (max-width: 300px) {
            span.psw {
                display: block;
                float: none;
            }
            .cancelbtn {
                width: 100%;
            }
        }

        .job-detail .box {
            background: #fff;
            margin-bottom: 30px;
            padding: 30px;
        }

        .box {
            color: black;
            background: #fff;
            font-family: 'Montserrat', sans-serif;
            font-size: 15px;
            height: auto;
            border-radius: 8px;
            font-family: "Segoe UI", Candara, "Bitstream Vera Sans", "DejaVu Sans", "Bitstream Vera Sans", "Trebuchet MS", Verdana, "Verdana Ref", sans-serif;
            line-height: 19px;
            padding: 17px;
            width: 100%;
        }

        .small-title {
            font-size: 22px;
            margin-bottom: 30px;
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            font-weight: 700;
            margin-top: 0;
            margin-bottom: 0;
        }

        ul {
            margin: 0;
            padding: 0;
        }

        .sidebar .detail-list li {
            border-bottom: 1px dotted #eee;
            padding: 7px 0;
        }

        .sidebar .detail-list li a {
            text-decoration: none;
            margin-right: 10px;
            color: #888;
            display: inline-block;
            transition: all .2s ease-in-out;
            -moz-transition: all .2s ease-in-out;
            -webkit-transition: all .2s ease-in-out;
            -o-transition: all .2s ease-in-out;
        }

        .sidebar .detail-list li .type-posts {
            color: #444;
            float: right;
        }

        .container-fluid {
            margin: 0;
        }

        .user-input-wrp {
            position: relative;
        }

        .user-input-wrp .inputText {
            width: 100%;
            float: right;
            font-size: 13px;
            color: #737373;
            outline: none;
            border: none;
            margin: 10px 0px 10px 0px;
            border-bottom: 1px solid #ddd;
        }

        .user-input-wrp .inputText:invalid {
            box-shadow: none !important;
        }

        .user-input-wrp .inputText:focus {
            border-color: #ddd;
            border-width: medium medium 2px;
        }

        .user-input-wrp .floating-label {
            position: absolute;
            pointer-events: none;
            top: 25px;
            font-size: 13px;
            font-weight: 600;
            color: #000;
            font-family: 'Open Sans', sans-serif;
            left: 15px;
            transition: 0.2s ease all;
        }

        .user-input-wrp input:focus ~ .floating-label,
        .user-input-wrp input:not(:focus):valid ~ .floating-label {
            top: 5px;
            left: 15px;
            font-size: 13px;
            opacity: 1;
        }

        .category {
            font-size: 14px;
            width: 100%;
            outline: none;
            border: none;
            font-weight: 600;
            color: #000;
            font-family: 'Open Sans', sans-serif;
            margin: 10px 0px 10px 0px;
            border-bottom: 1px solid #ddd;
        }

        textarea {
            margin-top: 30px;
            max-width: 790px;
            min-width: 250px;
            width: 250px;
            height: 100px;
            -moz-border-bottom-colors: none;
            -moz-border-left-colors: none;
            -moz-border-right-colors: none;
            -moz-border-top-colors: none;
            background: none repeat scroll 0 0 rgba(0, 0, 0, 0.01);
            border-color: -moz-use-text-color #FFFFFF #FFFFFF -moz-use-text-color;
            border-image: none;
            border-radius: 6px 6px 6px 6px;
            border-style: none solid solid none;
            border-width: medium 1px 1px medium;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12) inset;
            color: #555555;
            /* font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;*/
            font-size: 14px;
            ;
            line-height: 1.4em;
            padding: 5px 8px;
            transition: background-color 0.2s ease 0s;
            resize: both;
        }

        textarea:focus {
            background: none repeat scroll 0 0 #FFFFFF;
            outline-width: 0;
        }

        .headline {
            font-size: 14px;
            font-weight: 600;
            color: #000;
            font-family: 'Open Sans', sans-serif;
        }

        .btn-grad {
            background-color: #ffce00;
            border: none;
            border-radius: 3px;
            font-weight: 600;
            color: #000;
            font-size: 14px;
            font-family: 'Open Sans', sans-serif;
            margin-bottom: 5px;
            /* rami */
        }

        .btn-grad:hover {
            background-position: right center;
        }

        .download-body {
            width: 50%;
        }

        .download-close {
            position: absolute;
            right: 10px;
            top: 0px;
            color: #000;
            font-size: 30px;
            font-weight: bold;
            cursor: pointer;
        }

        .download-logo {
            position: absolute;
            top: 14%;
            left: 7%;
        }

        .downld-logo-height {
            height: 70px;
        }

        .btnDiv {
            margin-top: 8%;
            margin-left: 8%;
        }

        .imgclass {
            margin-top: 6%;
        }

        .download-logo h2 {
            margin-top: 15%;
        }
		.forgot-popup{
			
			width:35%;
			margin-top:160px;
		}
		.announcements,.announcements:hover,.announcements:active,.announcements:visited{
			color:black;
			text-decoration:none;
			
		}
		  
  
  
   .select_dropdown {
    max-height:180px;
    overflow: scroll;
    overflow-x: hidden;
    margin-top: 0px;
	width:100%;
}
.select_dropdown_btn::after {
display:none;
}
.caret {
	  float: right;
    margin-top: 4%;
}

#menu1 {
    width: 100%; 
    text-align: left;
	padding-left:0px;
}
.select_dropdown > li > a {
font-size:13px;
}
.select_dropdown_btn{
	font-size:13px;
}
.select_dropdown_btn:active:hover, .open > .select_dropdown_btn.select_dropdown_btn:hover, .select_dropdown_btn.active:focus, .open > .select_dropdown_btn.select_dropdown_btn:focus, .select_dropdown_btn:active.focus,.open > .select_dropdown_btn.select_dropdown_btn.focus {
    color: #000000;
    background-color: #ffffff;
    border-color: #ffffff;
	font-size:13px;
		outline:none;
}
.select_dropdown_btn:hover {
    color:#000000;
     background-color:#ffffff; 
   border-color:#ffffff; 
   	outline:none;
}
.select_dropdown_btn:focus, .select_dropdown_btn.focus {
    color:#000000;
    background-color:#ffffff;
    border-color:#ffffff;
	outline:none!important;
}
select_dropdown_btn:focus {
    outline: none;
}
.select_dropdown_btn:active, .select_dropdown_btn.active, .open > .select_dropdown_btn.select_dropdown_btn {
    color:#000000;
    background-color:#ffffff;
    border-color:#ffffff;
		outline:none;
}
.select_dropdown_btn.focus, .select_dropdown_btn:focus {
    outline:none;
    box-shadow: 0 0 0 0rem rgba(0,123,255,.25);
}
@media(max-width:768px){
		.slider-index img {
    width: 100%;
    height:auto! important;
}
.rq-search-container {
	top:0%;
	position:relative;
}
}
@media(max-width:320px){
textarea{
	min-width:200px! important;
	
	width:200px! important;
}
}

.animated-icon3 {
width: 30px;
height: 20px;
position: relative;
margin: 0px;
-webkit-transform: rotate(0deg);
-moz-transform: rotate(0deg);
-o-transform: rotate(0deg);
transform: rotate(0deg);
-webkit-transition: .5s ease-in-out;
-moz-transition: .5s ease-in-out;
-o-transition: .5s ease-in-out;
transition: .5s ease-in-out;
cursor: pointer;
}

.animated-icon3 span {
display: block;
position: absolute;
height: 3px;
width: 100%;
border-radius: 9px;
opacity: 1;
left: 0;
-webkit-transform: rotate(0deg);
-moz-transform: rotate(0deg);
-o-transform: rotate(0deg);
transform: rotate(0deg);
-webkit-transition: .25s ease-in-out;
-moz-transition: .25s ease-in-out;
-o-transition: .25s ease-in-out;
transition: .25s ease-in-out;
}
.animated-icon3 span {
background: #ffffff;
}

.animated-icon3 span:nth-child(1) {
top: 0px;
-webkit-transform-origin: left center;
-moz-transform-origin: left center;
-o-transform-origin: left center;
transform-origin: left center;
}

.animated-icon3 span:nth-child(2) {
top: 10px;
-webkit-transform-origin: left center;
-moz-transform-origin: left center;
-o-transform-origin: left center;
transform-origin: left center;
}

.animated-icon3 span:nth-child(3) {
top: 20px;
-webkit-transform-origin: left center;
-moz-transform-origin: left center;
-o-transform-origin: left center;
transform-origin: left center;
}

.animated-icon3.open span:nth-child(1) {
-webkit-transform: rotate(45deg);
-moz-transform: rotate(45deg);
-o-transform: rotate(45deg);
transform: rotate(45deg);
top: 0px;
left: 8px;
}

.animated-icon3.open span:nth-child(2) {
width: 0%;
opacity: 0;
}

.animated-icon3.open span:nth-child(3) {
-webkit-transform: rotate(-45deg);
-moz-transform: rotate(-45deg);
-o-transform: rotate(-45deg);
transform: rotate(-45deg);
top: 21px;
left: 8px;
}
.navbar-toggler{
	outline:none;
	
	border:0px;
}
button:focus {
	outline:0px;
}
    </style>
</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="ypk-load"></div>
    </div>

    <!-- ***** Header Area Start ***** -->
    <header class="header_area" id="header">
        <div class="container-fluid h-100">
            <div class="row h-100">
                <div class="col-12 h-100">
                    <nav class="h-100 navbar navbar-expand-lg">
                        <a class="navbar-brand ypk-logo-img" href="{{url('/')}}">
						<!--<img src="{{asset('/public/Images/ypk_ru.png')}}" alt="" class="logo-img-width">-->
						</a>
                        <!-- rami -->
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#dorneNav" aria-controls="dorneNav" aria-expanded="false" aria-label="Toggle navigation">  <div class="animated-icon3"><span></span><span></span><span></span></div></button>
                        <!-- Nav -->

                        <div class="collapse navbar-collapse" id="dorneNav">
                            <ul class="navbar-nav mr-auto" id="dorneMenu">
                                 <li class="nav-item focus-grid no-padding menu-style">
								<a class="nav-link" href="{{url('/company-registration')}}" style="text-align:center;">
								<div class="focus-border">
								<div class="focus-layout">
									<div class="focus-image"><i class="fa fa-list" aria-hidden="true"></i><br class="header_menu_break">{{
									__('message.AddCompany') }}</div>
								</div>
							</div>
								
                                 </a>
                                </li>
								<li class="nav-item  menu-style">
								<a class="nav-link" href="{{url('/post-free-classifieds')}}" style="text-align:center;">
								<div class="focus-border">
								<div class="focus-layout">
									<div class="focus-image"><i class="fa fa-laptop" aria-hidden="true"></i><br class="header_menu_break">{{
								__('message.AddClassified') }}</div>
								</div>
							</div>
								
                                 </a>
                                </li>
                               
                                
                                
                               

                                <li class="nav-item dropdown menu-style">
                               
                                    <a class="nav-link" href="#" id="navbarDropdown2" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								 <div class="focus-border">
								<div class="focus-layout">
									<div class="focus-image"><i class="fa fa-download" aria-hidden="true"></i><br class="header_menu_break">{{ __('message.invitation') }}</div>
								</div>
							</div>
								</a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown2">
                                        <a class="dropdown-item" href="{{asset('public/rules_ypk/Обн._Письмо-Желтые страницы.pdf')}}" target="_blank"><i class="fa fa-download icon_dist" aria-hidden="true"></i> Обн._Письмо-Желтые страницы</a>
                                        <a class="dropdown-item" href="{{asset('public/rules_ypk/Обн._Прайс ЖС-2018.pdf')}}" target="_blank"><i class="fa fa-download icon_dist" aria-hidden="true"></i>Обн._Прайс ЖС-2018</a>
								        <!-- <a class="dropdown-item" href="{{asset('public/rules_ypk/Письмо обращение-Транспорт2018.pdf')}}"><i class="fa fa-download"  aria-hidden="true">Письмо обращение-Транспорт2018</i></a>-->
                                        <a class="dropdown-item" href="{{asset('public/rules_ypk/Письмообращение-Транспорт2018.pdf')}}" target="_blank"> <i class="fa fa-download icon_dist" aria-hidden="true"></i>Письмообращение-Транспорт2018</a>
                                         <a class="dropdown-item" href="{{asset('public/rules_ypk/Прайс Транспорт-2018.pdf')}}" target="_blank"> <i class="fa fa-download icon_dist" aria-hidden="true"></i>Прайс Транспорт-2018</a>

                                    </div>
                                </li>
                              
                              @if (Auth::guest())
                                <li class="nav-item dropdown menu-style">
                                 
                                  
                                    <a class="nav-link " href="#" id="navbarDropdown2" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                 <div class="focus-border">
                                <div class="focus-layout">
                                    <div class="focus-image"><i class="fa fa-user-o" aria-hidden="true"></i><br class="header_menu_break">{{ __('message.myaccount') }}</div>
                                </div>
                            </div>
                                 </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown2">
                                        <a class="dropdown-item" href="#" id="login_mobile_close" onclick="document.getElementById('id01').style.display='block'" style="width:auto;"><img src="{{asset('public/Images/login.png')}}" style="padding-right:7px; width:37px;">{{ __('message.login') }}</a>
                                       
                                        <!-- <a class="dropdown-item" href="#">logout</a>-->
                                    </div>
                                </li>
                             @else
                                    <li class="nav-item dropdown menu-style">
                                 
                                  
                                    <a class="nav-link " href="#" id="navbarDropdown2" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                 <div class="focus-border">
                                <div class="focus-layout">
                            <div class="focus-image"><i class="fa fa-user-o" aria-hidden="true"></i><br class="header_menu_break">{{Auth::user()->Name}}</div>
                                </div>
                            </div>
                                 </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown2">
                                         <a class="dropdown-item" href="{{ route('logout') }}"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
													 {{__('message.logout')}}
                                        </a>
                                         <a class="dropdown-item"  href="{{url('/profile/')}}">{{__('message.Profile')}}</a>
                                        <form id="logout-form" action="{{route('logout')}}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
                                       
                                        <!-- <a class="dropdown-item" href="#">logout</a>-->
                                    </div>
                                </li>
                         @endguest
                                <li class="nav-item menu-style">

                                    <a class="nav-link" href="{{url('/news')}}" style="text-align:center;" target="_blank">
                                    <div class="focus-border">
                                      <div class="focus-layout">
                                        <div class="focus-image"><i class="fa fa-newspaper-o" aria-hidden="true"></i><br class="header_menu_break">{{ __('message.news') }}</div>
                                       </div>
                                    </div>
                                    </a>
                                </li>
                                <li class="nav-item menu-style">
                                    <a class="nav-link" href="#" onclick="document.getElementById('id02').style.display='block'" style="width:auto;">
									<div class="focus-border">
								<div class="focus-layout">
									<div class="focus-image"><i class="fa fa-mobile" aria-hidden="true"></i><br class="header_menu_break">{{ __('message.downloadapp') }}</div>
								</div>
							</div>
									</a>
                                	
								</li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <div id="id02" class="modal overflow-modal">
        <!--rami-->

        <form class="modal-content download-body" action="/action_page.php">

            <div class="container ">
                <div class="row">
                    <div class="col-md-12" style="padding-left: 0px;padding-right: 0px;"><img src="{{asset('/public/img/download-bg-img.jpg')}}" style="width:100%;">

                        <span onclick="document.getElementById('id02').style.display='none'" class="download-close" title="Close Modal">&times;</span>

                        <div class="download-logo">
                            <a class="ypk-logo-img0" href="{{url('/')}}"> 
							<img src="{{asset('/public/Images/ypk_ru.png')}}" alt="" class="logo-img-width downld-logo-height">
							</a>

                            <h2 style="text-transform:capitalize">{{__('message.Download the Yellow')}} <br>{{__('message.Pages of Kazakhstan')}}</h2>

                            <div class="btnDiv">
                                <a href="http://market.android.com/details?id=com.dt.mobile.ypkaz" target="_blank" style="visibility: visible;"><img src="{{asset('/public/Images/google_playstore.png')}}" class="imgclass-google"></a>
                                <br>
                                <a href="https://itunes.apple.com/tw/app/id1261723129" target="_blank" style="visibility: visible;"><img class="imgclass" src="{{asset('/public/Images/apple_playstore.png')}}"></a>

                            </div>
                        </div>

                    </div>
                </div>
            </div>

        </form>
    </div>
    <script>
        // Get the modal
        var modal = document.getElementById('id02');

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>
    <!-- ***** Header Area End ***** -->
   <div id="id01" class="modal overflow-modal">
        <!--rami-->

        
            <form class="modal-content ipad_modal_width" id="registerForm2" method="POST" class="modal-content ipad_modal_width" action="{{ route('login') }}" role="form">
                  {{ csrf_field() }}
                <div class="container ipad_modal_width_in">
                    <div class="row">
                        <div class="col-md-5 login_backgroundimg" style="padding-left: 0px;padding-right: 0px;"><img src="{{asset('/public/Images/login-backgd.png')}}" ></div>
                        <div class="col-md-7 login_mobile_size" >
                            <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
                            <div class="box">
                                <h2 class="small-title" style="margin-left: -15px; padding-bottom: 20px;">{{__('message.login')}}</h2>
                                <div class="row">
                                    <div class="user-input-wrp" style="width: 100%;">
									
									<br/>
                                        <input type="text" class="inputText" id="email" name="email" />
                                        <span class="floating-label" style="left:0px;">{{__('message.Enter your email/username')}} <span style="color:red;">*</span></span>
                                        										
                                     
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="user-input-wrp" style="width: 100%;">
                                        <br/>
                                        <input type="password" class="inputText" id="password" name="password" />
                                        <span class="floating-label" style="left:0px;">{{__('message.Password')}} <span style="color:red;">*</span></span>
									
                                    </div>
                                </div>
								<div class="row">
								    <div class="user-input-wrp" style="width: 100%;">
									 <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}> {{__('message.RememberMe')}}
                                    </label>
                                </div>
									</div>
								</div>
                                
                                <br>
                                
                                <a href="#" id="forgotpasswordlink" >
                                    <p style="margin-left:-15px;">{{__('message.Forgot your password')}}?</p>

                                </a>
								<label id="errormessage3" class="error"></label>	
                                <div class="row">
                                    <div style="float:right;padding-left:0px;margin-bottom: 10px;">

                                        <input type="submit" id="login"class="btn-grad" value="{{__('message.Send')}}" style=" height:40px; width:100px;" />

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </form>
    </div> 
	<div id="idforget-passsword" class="modal overflow-modal" ><!--rami-->

<form class="modal-content forgot-popup" method="get" id="forgotpassword_form" action="{{url('/forgotpassword')}}" role="form">
<input type="hidden" name="_token" value="{{ csrf_token()}}">
<div class="container">
<div class="row">
                        <!-- <div class="col-md-6" style="padding-left: 0px;padding-right: 0px;"><img src="{{asset('/public/Images/login-backgd.png')}}" style="width:100%;"></div>-->
<div class="col-md-12" style="margin-top: 38px;">
<span onclick="document.getElementById('idforget-passsword').style.display='none'" class="close" title="Close Modal">&times;</span>
<div class="box" style="width:100%;" id="modal-content">
<h2 class="small-title">{{__('message.Forgot Password')}}</h2>
<div class="row">
<div class="user-input-wrp" style="width:80%;margin-top:10px;padding-left:15px;">
 <input type="email" class="inputText" id="registeredemail" name="registeredemail" style="margin-top:40px;"/>
<label id="errormessage4" class="error"></label>	

<span class="floating-label">{{__('message.Please enter email-id')}}<span style="color:red;">*</span></span>
</div> 
</div>

<div class="row">
<div style="float:right;padding-top: 20px;padding-left: 15px;margin-bottom: 10px;" >
<input type="submit" class="btn-grad" value="{{__('message.Send')}}" style=" height:40px; width:100px;"/>

</div></div>
</div></div></div>
</div>


</form>
</div>
<div id="idsuccessmessage" class="modal overflow-modal" ><!--rami-->

	<form class="modal-content success-popup"  action="">

		<div class="container">
			<div class="row">
									<!-- <div class="col-md-6" style="padding-left: 0px;padding-right: 0px;"><img src="{{asset('/public/Images/login-backgd.png')}}" style="width:100%;"></div>-->
				<div class="col-md-12" style="margin-top: 38px;">
					<span onclick="document.getElementById('idsuccessmessage').style.display='none'" class="close" title="Close Modal">&times;</span>
						<div class="box" style="width:100%;" id="modal-content">

						</div>
					</div>
				</div>
		</div>


	</form>
</div>

<script>
// Get the modal
var modal = document.getElementById('idforget-passsword');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
if (event.target == modal) {
modal.style.display = "none";
}
}
</script>

    <script>
        // Get the modal
        var modal = document.getElementById('id01');

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>

    <div id="myCarousel" class="carousel slide slider-index" data-ride="carousel">

        <?php

    $carousel_page_count=(count($banner));

    ?>

            <div class="carousel-inner">
                <?php
							$counter=0;
							$active="";

							for($i=1;$i<=$carousel_page_count;$i++){
							if($i==1)
							$active="active";
							else
							$active='';
	     ?>
                    <div class="item <?php echo $active;?>">
                        <?php

                $image_url=$banner[$counter]->WebImageURL;
                $website=$banner[$counter]->NavigationUrl;

           ?>
                           <a href="<?php echo $website;?>" target="_blank"> <img src="{{url('/public/Images/')}}/<?php echo $image_url;?>" alt="Los Angeles"></a>
                    </div>
                    <?php
          $counter++;
                     }

          ?>


            </div>
              @php 
			     $search_item= isset($_GET['search_item'])?$_GET['search_item']:"";
				 $cityid         =isset($_GET['city'])?$_GET['city']:"";
				 $selected_categ=isset($_GET['selectedoption'])?$_GET['selectedoption']:"";
			  @endphp
                <!-- carousel ends-->
				 <div class="marquee-text mobile_marquee">
				
                    <marquee onmouseover="this.stop();" onmouseout="this.start();">
					@foreach($anouncement as $anouncements)
					<a href="{{$anouncements->NavigateUrl}}" class="announcements" target="_blank">!...{{$anouncements->Description}}...!</a>
					@endforeach
					
                    </marquee>
					
                </div>
                <form action="{{url('/search')}}" onsubmit="return SearchValidate()"  id="search_validation" method="GET" role="form">
                <input type="hidden" name="_token" value="{{csrf_token()}}">
                    <div class="rq-search-container container">
                        <div class="rq-search-single">
                            <div class="rq-search-content">
                                <span class="rq-search-heading">{{ __('message.keywords') }}</span>
                                <input type="text" id="search_item" value="@php echo $search_item;  @endphp"  name="search_item" class="rq-form-element" placeholder="{{ __('message.what_r_u_looking_for') }}" autocomplete="off" style="width:100%;"/>
                                 
							</div>
                            
                        </div>

                        <div class="rq-search-single">
                            <div class="rq-search-content">
                                <span class="rq-search-heading">{{ __('message.location') }}</span>
								
                                <select name="city" id="citylist" class="category-option">
                                    <option value="">{{ __('message.pick_a_location') }}</option>
                                  @foreach(json_decode(\App\Helpers\CityHelper::instance()->cityNames()) as $city)
                                        @php $selected=($city->CityId==$cityid )? "SELECTED":"";@endphp
                                        <option value="{{$city->CityId}}" {{$selected}}>{{$city->CityName}}</option>
                                    @endforeach
                                </select>
								<p id="searchalert"  class="search_eror_msg"></p>
                            </div>
                        </div>
                        <div class="rq-search-single">
                            <div class="rq-search-content last-child">
                                <span class="rq-search-heading">{{ __('message.categories') }}</span>
                                <a class="nav-link" href="#" onclick="document.getElementById('id04').style.display='block'" style="width:auto;">
                                    <input type="text" id="selectedoption" value="@php echo $selected_categ  @endphp" name="selectedoption"class="rq-form-element" placeholder="{{ __('message.categories') }}/{{__('message.subcategory')}}"  autocomplete="off" readonly/>
                                </a>
                            </div>


                        </div>
                        <div class="rq-search-single search-btn">
                            <div class="rq-search-content serch-background">
                                   <input type="submit" value="{{ __('message.search') }}" onclick="SearchValidate()" class="rq-btn rq-btn-primary fluid-btn"><i class="arrow_right"></i>
                                   <!--  <a href="search_result.html">
                                    <button class="rq-btn rq-btn-primary fluid-btn">{{ __('message.search') }} <i class="arrow_right"></i></button>
                                </a> -->
                            </div>
                        </div>
                    </div>
                   
                </form>
    <div id="id04" class="modal overflow-modal">
        <!--rami-->
        <form class="modal-content download-body choose-category-modal" action="/action_page.php">
                    <div class="title-head-modal" style="background-color:#ffce00;height:50px;">
                        <span onclick="document.getElementById('id04').style.display='none'" class="download-close" title="Close Modal">&times;</span>
                        <h4 class="modal-title" style="padding:15px;text-align: center;">{{__('message.CHOOSE CATEGORY AND SUBCATEGORY')}}</h4>
                    </div>

                    <div class="container-fluid">

                        <div class="categories-popup">
                            <div>
                                <br>

                    <div class="category-lists">
                     <?php
                     $row_count=(count($category)/3);
                                 if((count($category)%3)>0){
                                     $row_count=(count($category)/3);
                                 }
                  $total_counter=1;

                     ?>
                    @for ($i = 0; $i < 3; $i++)
                       <?php $counter=0;
                  ?>
                         <div class="col-md-4" style="border-right: 1px solid rgba(255, 255, 255, 0.4);">
                           @for($j=$counter;$j<$row_count;$j++)

                          <table  cellspacing="0" style="/* border-collapse:collapse; */">
                           <tbody>
                           @foreach($category->where('CategoryId','=',$total_counter) as $categories)
                             <tr>
                                <td>
                                <?php

                                   $totalcounter=0;
                                ?>
                                   <a  href="javascript:showhide('uniquename<?php echo $total_counter;?>')" class="btnCategory" style="cursor:pointer;font-size:13px;" aria-hidden="true" >
                                    <span  class="fa fa-plus-circle" style="cursor:pointer;font-size:13px;">
                                     </span>

                                        {{$categories->CategoryName}}
                                     </a>
                                     <div  class="sub-category" id="uniquename<?php echo $total_counter;?>" >
                                     @foreach($subcategory->where('CategoryId','=',$categories->CategoryId) as $subcategories)
                                     <table  cellspacing="0" style="border-collapse:collapse;">
                                         <tbody>
                                             <tr>
                                                 <td  class="subcateg" onclick="document.getElementById('selectedoption').value='{{$subcategories->SubCategoryName}}'; document.getElementById('id04').style.display='none'">
                                                      {{$subcategories->SubCategoryName}}
                                                 </td>
                                             </tr>
                                         </tbody>
                                     </table>
                                   @endforeach
                                   </div>
                                </td>
                             </tr>
                             @endforeach
                           </tbody>
                      <?php $counter++;
                      $total_counter++;
                      ?>
                        @endfor
                          </table>


                         </div>

                    @endfor


                    </div>

                </div>
            </div>
        </div>
    </form>

    </div>

      </div>      
                
                <div class="marquee-text desktop_marquee">
				
                    <marquee onmouseover="this.stop();" onmouseout="this.start();">
					@foreach($anouncement as $anouncements)
					<a href="{{$anouncements->NavigateUrl}}" class="announcements" target="_blank">!...{{$anouncements->Description}}...!</a>
					@endforeach
					
                    </marquee>
					
                </div>
 
            <script>
                // Get the modal
                var modal = document.getElementById('id04');

                // When the user clicks anywhere outside of the modal, close it
                window.onclick = function(event) {
                    if (event.target == modal) {
                        modal.style.display = "none";
                    }
                }
		
            </script>

            <div id="banner-sec">
            <section class="banner-sec" style="background-color: #f2f1ef;">
                <div class="container" >
				  
                    @yield('content')
                </div>
            </section>
            </div>
            <!--footer -->
            <div class="footer footer_w3layouts_section_1its">
                <div class="container">
                    <div class="footer-top">
                        <div class="col-md-5 footer-grid_section_1its_w3">
                            <div class="footer-title">
                                 <h3>{{ __('message.aboutus') }}</h3>
								
                            </div>
                            <div class="footer-text">
                                <p><span class="more">{{__('message.history')}}</span></p>
								
                                <ul class="social_section_1info">
                                    <li><a href="https://www.facebook.com/profile.php?id=100018415714082" class="w3_facebook" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                    <!--						<li><a href="#" class="w3_twitter"><i class="fa fa-twitter"></i></a></li>-->
                                    <li><a href="https://www.instagram.com/yellow_pages1995/" class="w3_instagram"target="_blank"><i class="fa fa-instagram"></i></a></li>
                                    <li><a href="https://vk.com/public149001908" class="w3_google"target="_blank"><i class="fa fa-vk"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-4 footer-grid_section_1its_w3">
                            <div class="footer-title">
                                <h3>{{ __('message.contactinfo') }}</h3>
                            </div>
                            <div class="contact-info">
                                <h4 style="text-transform:none">{{__ ('message.location')}} :</h4>
                                <p>{{__('message.address1')}}<br>
								   {{__('message.address2')}}<br>
								   {{__('message.address3')}}<br>
								   {{__('message.address4')}}
								
								</p>
                                 
                            </div>
                        </div>
                        <div class="col-md-3 footer-grid_section_1its_w3">
                            <div class="footer-title">
                                <h3>{{ __('message.usefullinks') }}</h3>
                            </div>
                            <ul class="links">
                               
                            @foreach($headermenu as $headmenu)
                                <li >
                                    {{--<div class="focus-image"><i class="fa" aria-hidden="true"><img src="{{asset('public/Images')}}/{{$headmenu->ImageUrl}}"  class=" img"></i></div>--}}
                                    <a href="{{url('/')}}/{{$headmenu->NavigationLink}}">{{$headmenu->MenuName}} </a>
                                </li>

                            @endforeach

                                <li><a href="#" onclick="document.getElementById('id01').style.display='block'" style="width:auto;">{{ __('message.login') }}</a></li>
                                <li><a href="#" onclick="document.getElementById('id02').style.display='block'" >{{ __('message.downloadapp') }}</a></li>
                                <li><a href="{{url('/contact-us')}}">{{ __('message.contactus') }}</a></li>
								<li><a href="{{url('/news')}}" target="_blank">{{ __('message.news') }}</a></li>
								<li><a href="{{url('/privacy-policy')}}" target="_blank">{{ __('message.privacy_policy') }}</a></li>
								
                            </ul>
                        </div>
                       
                        <div class="clearfix"></div>
                    </div>
                    <div class="copyright_line"></div>
                    <div class="row">
                        <div class="col-md-5">
                            <div class="copyright">
                                <p style="text-transform: none;"><span style="text-transform: capitalize">{{__ ('message.Copyrights belong to')}}</span> © 2019, www.ypk.kz.<span style="text-transform: capitalize">{{__ ('message.All rights reserved') }}</span></p>
                            </div>
                        </div>
						<div class="col-md-4 ">
                            <div class="copyright ">
							<div class="col-sm-6 counter_sitevisit"><img src="{{asset('/public/Images/google_analytics.png')}}" alt="google-analytics" style="height:44px;">  </div>
							<div class="col-sm-6 counter_sitevisit1">
                               <p style="text-transform: none">Количество посетителей<br/>
                               <span>#{{ \App\Helpers\GAHelper::instance()->uniquePageviews() }}</span></p></div>
                            </div>
                        </div>
						
                        <div class="col-md-3">
                            <div class="developer" style="float:right;">
                                <p>{{__('message.developedby')}}</p><img src="{{asset('/public/Images/dt_logo.png')}}" alt="error" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- //footer -->
            <script>
                // Get the modal
                var modal = document.getElementById('id02');

                // When the user clicks anywhere outside of the modal, close it
                window.onclick = function(event) {
                    if (event.target == modal) {
                        modal.style.display = "none";
                    }
                }
          
                // Get the modal
                var modal = document.getElementById('id04');

                // When the user clicks anywhere outside of the modal, close it
                window.onclick = function(event) {
                    if (event.target == modal) {
                        modal.style.display = "none";
                    }
                }
        
                function showhide(id) {
					$(".sub-category").not("#"+id).hide();
                    var e = document.getElementById(id);
                    e.style.display = (e.style.display == 'block') ? 'none' : 'block';
                }
    
                $(window).load(function() {
                    var boxheight = $('#myCarousel .carousel-inner').innerHeight();
                    var itemlength = $('#myCarousel .item').length;
                    var triggerheight = Math.round(boxheight / itemlength + 5);
                    $('#myCarousel .list-group-item').outerHeight(triggerheight);
                });
            </script>

            <script type="text/javascript">
                $(document).ready(function() {
                    $('.date').bootstrapMaterialDatePicker({
                        time: false,
                        lang:'ru',
						cancelText : 'ANNULER',
						okText : 'ХОРОШО',
						
						
						
                    });
					

  
				$('#login_mobile_close').click(function(){
             $(".navbar-collapse").hide();
			   });
                    $('#CategoryCode').on('click', function() {
                        var categoryID =$(this).val() ;

                        if (categoryID) {
                            $.ajax({
                                dataType: 'text',

                                type: 'POST',
                                url: 'resources/views/queryforsubcategory.php',
                                //url:'app/Http/Controllers/DynamicController@index2',
                                data: 'category_id=' + categoryID,

                                success: function(html) {
                                    console.log(html);

                                    $('.sub-category').html(html);
                                },
                                error: function(e) {
                                    $('.sub-category').html(e);
                                }
                            });
                        }
                    });

                
		  

   
   });
   
  
	$(document).ready(function() {
     $('#logina').on('click', function() {
		 
		var userId=$('#email').val();
        var Password = $('#password').val();
         
      	   $.ajax({
			   
                    dataType: 'text',
                    type: 'POST',
                    url: "{{url('/')}}/uservalidation",
                     data: {"user":userId,"pass":Password},

                     success: function(html) {
             
                    
                        
                        $('#errormessage3').html(html);
						$("#registerForm2").submit();
					
                    },
                    error: function(e) {
						 
                      
					    var response = $.parseJSON(e.responseText);
						  if(response.message) {
						
							$('#errormessage3').html(response.message);
							
						  }
								}
                }); 
		 
	 });
		
 
    });
 </script>
			<script src="{{asset('public/js/jquery.easy-autocomplete.js')}}"></script> 
            <script src="{{asset('public/js/bootstrap/popper.min.js')}}"></script>
            <!-- Bootstrap-4 js -->
            <script src="{{asset('public/js/bootstrap/bootstrap.min.js')}}"></script>

            <!-- All Plugins js -->
            <script src="{{asset('public/js/others/plugins.js')}}"></script>
            <!-- Active JS -->
            <script src="{{asset('public/js/active.js')}}"></script>
			    <script src="{{asset('public/js/jquery.mask.js')}}"></script>
			 <script src="{{asset('public/js/others/new.js')}}"></script>
            {{--
            <!-- jQuery-2.2.4 js -->--}}
<script type="text/javascript">
  
$(document).ready(function () {

  $('.navbar-toggler').on('click', function () {

    $('.animated-icon3').toggleClass('open');
  });
});


</script>
</body>

</html>