@extends('layouts.app')
@section('title')
Желтые Страницы Казахстана
@stop
@section('description', 'Желтые Страницы Казахстана – это каталог коммерческих, промышленных и государственных организаций. Всегда доступная информация по различным компаниям Казахстана, с бесплатным размещением объявлений. На Желтых Страницах Казахстана вы найдете отечественные компании разных отраслей и их контактные данные.-Yellow pages of Kazakhstan, catalogue of enterprises of organizations of industries. Available business contact information. Kazakhstan Company address directory, Online Yellow Pages and Free Classified Site. Yellow Pages Kazakhstan offers free local business listing, Search for Phone numbers, Mobile numbers, 
address and Contact Details.')
@section('keywords', 'Желтые Страницы Казахстана, бесплатные объявления, бесплатная публикация, адрес, телефон компании,Yellow Pages Kazakhstan,free classifieds,free listing,Company   Address,phone numbers')
@section('content')
   <div class="row">

              <div class="col-md-9 top-slider" >
  			<!--rami-->
  			<div class="row">
                  <div class="col-md-4" style="padding-left: 5px;padding-right: 5px;">
  			<h3 class="headerline" > {{ __('message.companylist') }} </h3>
  			</div>
  			</div>
  			<!--rami-->
  		<div class="row">
  		<?php

        $total_count=(count($companyprofile));
		$slide_per_page=8;
        $carousel_page_count=3;
		$slide_count=ceil($total_count/$slide_per_page);
	
	//	$slide_count=5;
        ?>
          <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                  <!-- Indicators -->
                   <ol class="carousel-indicators">
                  	 
                  	 <?php
                  	  for($i=0;$i<$slide_count;$i++){
                  	  ?><li data-target="#carousel-example-generic" data-slide-to="<?php echo $i?>" class="<?php if($i==0){echo 'active';} ?>" ></li><?php
                  	  }
                  	  ?>
                   </ol>
                            <div class="carousel-inner" role="listbox">
                    <?php
           							$counter=0;
           							$active="";
           							$total_counter=0;
           							for($i=0;$i<$slide_count;$i++){
           							if($i==0)
           							$active="active";
           							else
           							$active='';
								
           							?>

									
              <div class="carousel-item <?php echo $active;?>">
                             <?php

								  for($j=0;$j<$slide_per_page;$j++)
								  {
									  if($total_count>$total_counter){

						      ?>
  				  <div class="col-md-6 w3ls-portfolio-left">
  						<div class="portfolio-img event-img" >
  						<?php
                          $val="";
                          $image_url='http://'.$_SERVER['HTTP_HOST'].'/public/ProductImages/'.$companyprofile[$total_counter]->ImageUrl;

                            $regtype=$companyprofile[$total_counter]->ActualRegType;
							
                           if ($regtype>2)
                          {
                            ?>
                           <img src="<?php echo $image_url;?>"  class="key_clients_images"  onerror="this.src='{{asset('public/ProductImages/no-image.png')}}'">
                           <img src="{{asset('public/Images/premium_ribbon.png')}}" alt="error" class="key_clients_ribbons" >
                     <?php }
                        else {  ?>
                           <img src="<?php echo $image_url;?>"  class="key_clients_images"
                           onerror="this.src='{{asset('public/ProductImages/no-image.png')}}'">
                          <img src="{{asset('public/Images/gold_ribbon2.png')}}" alt="error" class="key_clients_ribbons">
                       <?php }
                       ?>
  							<div class="over-image"></div>
  						</div>
  						<div class="portfolio-description">
  						  <h4><a href="{{url('/')}}/companydetail/<?php echo $companyprofile[$total_counter]->CompanyRegId; ?>">
                          <?php echo $companyprofile[$total_counter]->CompanyName; ?></a></h4>
  						   <p>
  						   <?php
  						      $string= $companyprofile[$total_counter]->DescribeBusiness;
                            
                               echo $string;
                               ?>
                               <div class="rate">
                               <div class="like-rating-box pull-left">
                              <?php  if ($regtype>2)
                          {
                            ?>
                           <span>
                                 <i class="fa fa-star"></i>
                                 <i class="fa fa-star"></i>
                                 <i class="fa fa-star"></i>
                                 <i class="fa fa-star"></i>
                                 <i class="fa fa-star"></i>
                               </span>
                               5 Rated
                     <?php }
                        else {  ?>
                           <span>
                                 <i class="fa fa-star"></i>
                                 <i class="fa fa-star"></i>
                                 <i class="fa fa-star"></i>
                                 <i class="fa fa-star"></i>
                                 <i class="fa fa-star-o"></i>
                               </span>
                               4 Rated
                       <?php }
                       ?>
                               
                               </div>
                                                                                                    <!-- <div class="like-rating-box pull-left"> -->
                                                                        							<!-- <img src="img/gold.png" alt="error"/> -->

                                                                        							<!-- </div> --> <!-- rami-->
                               <div class="pull-right share"><span><i class="fa fa-share-alt share-action-btn" data-CompanyRegId="<?php echo $companyprofile[$total_counter]->CompanyRegId; ?>" aria-hidden="true"></i></span></div>
                              
 </div>
  						   </p>

  						</div>
                          <div class="clearfix"></div>
						 
  				  </div>
                       <?php
									  }else{?>
									   <div class="col-md-6 w3ls-portfolio-left">
											<div class="portfolio-img event-img" >
												<img src="{{asset('public/ProductImages/no-image.png')}}"  class="key_clients_images" >
											</div>
											<div class="portfolio-description">
											<p style="margin-top:33px;">{{__('message.slogan for company')}}</p>
											</div>
										</div>
						
									<?php
									  }
                                    $total_counter++;
									
								  }
				      ?>

                </div>
				
									
				

                <?php
            	}
            ?>
            </div>

  		   <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
      <i class="fa fa-chevron-left"></i><!-- rami-->
      <!-- <span class="sr-only">Previous</span> -->
    </a>
          <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
       <i class="fa fa-chevron-right"></i><!-- rami-->
    </a>
                </div>
  			  </div>
        </div>
  	  <!-- rami-->
  	 <div class="col-md-3" style="padding-left: 5px;padding-right: 5px;">
         @include('classifieds_slide')
     </div>
            </div>
<div id="id03" class="modal overflow-modal" ><!--rami-->
  
  <form  method="post" id="share_detail"class="modal-content2 mail-cover " action="{{url('/share')}}"role="form">
   <input type="hidden" name="_token" value="{{ csrf_token()}}">
	<input type="hidden" name="CompanyRegId" id="CompanyRegId" value="">
    <div class="container">
        <div class="row">
            <div class="col-md-12" style="text-align: center;padding: 30px;">
                <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-8"><img src="{{asset('public/Images/Mail.png')}}" class="image-responsive" style="width:100%;"></div><div class="col-md-2"></div>
                </div>
    <span onclick="document.getElementById('id03').style.display='none'" class="download-close" title="Close Modal">&times;</span>
     <div class="mail-text" style="padding-top: 20px;">
	         
				
                <input type="email" class="mail-input" name="user_mail" id="user_mail"Placeholder="{{__('message.Please enter Email')}}"><button type="submit" class="mail-button"><img src="{{asset('public/Images/send.png')}}"></button><label for="user_mail" class="error"></label>
           
				</div>
   
   </div>
      </div>
    </div>

    
  </form>
</div>
@endsection