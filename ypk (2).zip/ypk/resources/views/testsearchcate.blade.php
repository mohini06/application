<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <title>Yellow Pages Of Kazakhstan</title>
      <link rel="icon" href="{{ asset('/public/Images/icon.png') }} ">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimuum-scale=1, maximum-scale=1">
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta http-equiv="x-ua-compatible" content="IE=11,10,9">
      <meta name="keywords" content="Ypin" />
      <link rel="stylesheet" href="{{ asset('/public/bootstrap/css/bootstrap.min.css') }}"/>
      <link rel="stylesheet" href="{{ asset('/public/css/style.css') }}"/>
      <link rel="stylesheet" href="{{ asset('/public/css/responsive.css') }}"/>
      <link rel="stylesheet" href="{{ asset('/public/css/font-awesome.min.css') }}"/>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
      <link rel="stylesheet" href="{{ asset('/public/css/flexslider.css') }}"/>
      <script src="{{asset('/public/js/jquery-1.11.3.js')}}"></script>
      <script src="{{asset('/public/js/bootstrap.min.js')}}"></script>
      <script src="{{asset('/public/js/ypk.js')}}"></script>
   </head>

<body>
  <table>
  <a href="#" data-toggle="modal" data-target="#categModal" style="text-decoration: none;">
  <input type="text" value="Категория/Подкатегория" >
  </a>
      {{--@foreach($category as $searchcat)--}}
        {{--<tr>--}}
          {{--<td> <input type="hidden" id="categid" value="{{$searchcat->CategoryId}}">{{$searchcat->CategoryName}}</td>--}}

          {{--<td>--}}
               {{--<table class="table table-border" id="searchsubcat">--}}

               {{--</table>--}}
          {{--</td>--}}
        {{--</tr>--}}
      {{--@endforeach--}}
  </table>
<!-- Modal -->
<!-- Modal -->

       <div class="modal fade" id="categModal" role="dialog">
		    <div class="modal-dialog" style="width:70%;margin-top: 11%;">
<!-- Modal content-->
    	    <div class="modal-content list-content">
    		<div class="modal-header category-head">
	    	  <button type="button" class="close" data-dismiss="modal">&times;</button>
			   <h4 class="modal-title list-head">ВЫБЕРИТЕ КАТЕГОРИЮ И ПОДКАТЕГОРИЮ</h4>
			</div>
			<div class="modal-body list-body">

			    <div class="category-lists">

			 <?php
			$row_count=(count($category)/3);
			if((count($category)%3)>0){
			    $row_count=(count($category)/3);
			}
            $total_counter=0;
			for($i=0;$i<3;$i++){
			    $counter=0;
			    ?>
			    <div class="col-md-4" style="height:320px !important;"><?php
			    for($j=$counter;$j<$row_count;$j++){
                    ?>
                    <table id="search-category" cellspacing="0" style="border-collapse:collapse;">
                    <thead></thead>
                      <tbody>
                      <tr>
                      <td>
                      <td>
                      <span class="fa fa-plus-circle" aria-hidden="true"></span>
                      <span style="cursor:pointer;font-size:13px;"><?php echo $category[$total_counter]->CategoryName;?></span>
                      <input type="hidden" id="category" value="<?php echo $category[$total_counter]->CategoryId;?>">
                         </td>
                      </tr>
                      <tr>
                        <table id="subcategory" class=" table table-bordered" >
                           <tr><td>mango</td></tr>
                           <tr><td>mango</td></tr>
                           <tr><td>mango</td></tr>
                           <tr><td>mango</td></tr>
                           <tr><td>mango</td></tr>
                           <tr><td>mango</td></tr>

                        </table>
                      </tr>
                      </tbody><?php
                      $total_counter++;
                        $counter++;
                      			    }  ?>
                    </table>
{{--                    <a href="#" style="font-size: 10px;"><i class="fa fa-plus-circle" aria-hidden="true" id="category1"></i>--}}

			    </div>
			    <?php
			}
			?>
		       </div>
         </div>
         </div>
		 </div>
        </div>
     </div>
     <script>
          $(document).ready(function(){
                $('#category').on('change',function(){
                    var categoryID = $(this).val();

                    if(categoryID){
                        $.ajax({
                            dataType: 'text',

                             type:'POST',
                             url:'resources/views/queryforsubcategory.php',
                              //url:'app/Http/Controllers/DynamicController@index2',
                             data:'category_id='+categoryID,

                             success:function(html){
                             console.log(html);

                             $('#subcategory').html(html);
                             },
                             error:function(e){
                             $('#subcategory').html(e);
                             }
                       });
                    }
                });
            });
     </script>
     </body>
     </html>