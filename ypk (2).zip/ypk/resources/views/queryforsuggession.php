<?php
include "db.php";
$phrase = $_REQUEST['phrase'];

$sql="SELECT CompanyName FROM companyregistration where CompanyName LIKE '%$phrase%' LIMIT 8";
$result=$db->query($sql);
$output=array();
    while($row = $result->fetch(PDO::FETCH_ASSOC))
    {
        $data["name"]=$row['CompanyName'];
		$output[]=$data;
    }
header('Content-type: application/json');
echo json_encode($output);
?>