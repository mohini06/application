
@extends('layouts.app')

@section('content')
  <h2 class="text-center">Add  Classified</h2>
  <hr color="red">
  <form  method="POST" action="/ypk/form-validation" role="form">
  {{--<form  method="POST" action="{{action('ClassifiedController@store')}}" >--}}
  @if(count($errors))
  			<div class="alert alert-danger">
  				<strong>Whoops!</strong> There were some problems with your input.

  			</div>
  		@endif
  <input type="hidden" name="_token" value="{{ csrf_token() }}">



   <div class="row">
     <div class="col-sm-6">
         <div class="form-group">
          <label>Ad Title</label>
          <input type="text" id="title" name="ClassifiedTitle" class="form-control">
          <span class="text-danger">{{ $errors->first('ClassifiedTitle') }}</span>
         </div>
     </div><!-- col-sm-6 end-->
    <div class="col-sm-6">
         <div class="form-group">
           <label>Select Your category</label>
           <select class="form-control  " id="category" name="category" >

              @foreach($category as $categories)
                <option value="{{$categories->CategoryId}}">{{$categories->CategoryName}}</option>
               @endforeach

           </select>
           <span class="text-danger">{{ $errors->first('category') }}</span>
         </div>
     </div><!-- col-sm-6 end-->
     </div><!-- row 1 end-->
     <div class="row">
       <div class="col-sm-6">
          <div class="form-group">
              <label>Select Your SubCategory</label>
              <select class="form-control " id="subcategory" name="subcategory" >
                  @foreach($subcategory as $subcategories)
                                                  ` <option value="{{$subcategories->SubCategoryId}}">{{$subcategories->SubCategoryName}}</option>
                                                  @endforeach
              </select><option value="">Select Category</option>

                <span class="text-danger">{{ $errors->first('subcategory') }}</span>
           </div>
        </div><!-- col-sm-6 end-->
        <div class="col-sm-6">
            <div class="form-group">
                 <label>Email</label>
                 <input type="email" id="title" name="email" class="form-control">
                   <span class="text-danger">{{ $errors->first('email') }}</span>
            </div>
         </div><!-- col-sm-6 end-->

    </div><!-- row 2 emd-->

    <div class="row">
        <div class="col-sm-6">
          <div class="form-group">
           <label>Your name</label>
           <input type="text" class="form-control" name="name">
             <span class="text-danger">{{ $errors->first('name') }}</span>
          </div>
        </div><!-- col-sm-6 end-->
        <div class="col-sm-6">
           <div class="form-group">
              <label>Select City</label>
              <select class="form-control" id="city" name="city">
           @foreach($city as $cities)
            <option value="{{$cities->CityId}}">{{$cities->CityName}}</option>
           @endforeach
              </select>
                <span class="text-danger">{{ $errors->first('city') }}</span>
           </div>
        </div><!-- col-sm-6 end-->
    </div><!-- row 3 emd-->

    <div class="row">
       <div class="col-sm-6">
       <div class="form-group">
         <label>Mobile Number</label>
         <input type="tel" class="form-control" name="mobile">
         <span class="text-danger">{{ $errors->first('mobile') }}</span>
        </div>
       </div><!-- col-sm-6 end-->
       <div class="col-sm-6">
       <div class="form-group">
         <label>Phone Number</label>
         <input type="tel" class="form-control" name="phone">
           <span class="text-danger">{{ $errors->first('phone') }}</span>
         </div>
       </div><!-- col-sm-6 end-->
    </div><!-- row 4 emd-->

    <div class="row">
      <div class="col-sm-12">
      <div class="form-group">
       <label>Classified Content</label>
       <textarea class="form-control" name="ClassifiedContent"></textarea>
         <span class="text-danger">{{ $errors->first('ClassifiedContent') }}</span>
       </div>
       </div><!-- col-sm-12 end-->
    </div><!-- row5 end-->

    <div class="row">
    <div class="col-sm-8">
    <div class="form-group">
       <label>Url</label>
       <input type="url" name="Weburl" class="form-control">
       </div>
    </div><!-- col-sm-8 end-->
    <div class="col-sm-4">
      <div class="form-group">
      <label></label>
    <input type="submit" class="btn-success form-control">
      </div>
    </div><!-- col-sm- 4end-->
    </div><!-- row6 end-->

</form>
  {{--{!! Form::open(['action'=>'ClassifiedController@store','method'=>'POST','files'=>true]) !!}--}}
  {{--<div class="form-group">--}}
   {{--{{form::label('ClassifiedTitle','Ad title')}}--}}
   {{--{{form::text('ClassifiedTitle','',['class'=>'form-control','id'=>'title'])}}--}}

  {{--</div>--}}
   {{--<div class="form-group">--}}
    {{--{{form::label('category','Select Your category')}}--}}
    {{--{!!form::select('category',$category,null,['class'=>'form-control'] )!!}--}}
    {{--</div>--}}
    {{--<div class="form-group">--}}
        {{--{{form::label('subcategory','Select Sub-category')}}--}}
      {{--{!! form::select('subcategory', $subcategory, null,['class'=>'form-control'] ) !!}--}}
        {{--</div>--}}
  {{--<div class="form-group">--}}
     {{--{{form::label('email','Email')}}--}}
     {{--{{form::text('email','',['class'=>'form-control'])}}--}}
    {{--</div>--}}
   {{--<div class="form-group">--}}
      {{--{{form::label('name','YourName')}}--}}
      {{--{{form::text('name','',['class'=>'form-control'])}}--}}
     {{--</div>--}}
     {{--<div class="form-group">--}}
            {{--{{form::label('city','City')}}--}}
            {{--{{form::select('city',$city,null,['class'=>'form-control'])}}--}}
      {{--</div>--}}
    {{--<div class="form-group">--}}
       {{--{{form::label('Mobile','Mobile Number')}}--}}
       {{--{{form::text('Mobile','',['class'=>'form-control'])}}--}}
      {{--</div>--}}
   {{--<div class="form-group">--}}
      {{--{{form::label('phone','Phone number')}}--}}
      {{--{{form::text('phone','',['class'=>'form-control'])}}--}}
     {{--</div>--}}

   {{--<div class="form-group">--}}
         {{--{{form::label('ClassifiedContent','Advertisement')}}--}}
         {{--{{form::textarea('ClassifiedContent','',['class'=>'form-control'])}}--}}
        {{--</div>--}}
   {{--<div class="form-group">--}}
         {{--{{form::label('Weburl','Your Site')}}--}}
         {{--{{form::text('Weburl','',['class'=>'form-control'])}}--}}
        {{--</div>--}}


   {{--{{Form::submit('Submit',['class'=>'btn btn-primary'],['class'=>'form-control'])}}--}}
  {{--{!! Form::close() !!}--}}



@endsection
{{--<script src="{{ asset('js/app.js') }}"></script>--}}
 {{--<script src="{{ asset('js/custom.js') }}"></script>--}}
{{--<script>--}}
{{--$(document).ready(function(){--}}
{{--$('.dyanmic').change(function(){--}}
  {{--if($(this).val()!=='')--}}
  {{--{--}}
  {{--var select=$(this).attr("CategoryId");--}}
  {{--var value=$(this).val();--}}
  {{--var dependent=$(this).data('dependent');--}}
  {{--var _token=$('input[name="_token]').val();--}}
  {{--$.ajax({--}}
  {{--url:"{{route('ClassifiedController.fetch')}}",method="POST" data:(select:select,--}}
  {{--value:value,_token:_token,dependent:dependent)}--}}
  {{--});--}}
  {{--}--}}
{{--});--}}
{{--});--}}
{{--</script>--}}



<script type="text/javascript">
    $(document).ready(function() {
        $('select[name="category"]').on('change', function() {
            var CategoryID = $(this).val();
            if(CategoryID) {
                $.ajax({
                    url: '/ClassifiedRegistration/ajax/'+CategoryID,
                    type: "GET",
                    dataType: "json",
                    success:function(data) {


                        $('select[SubCategoryName="subcategory"]').empty();
                        $.each(data, function(key, value) {
                            $('select[name="subcategory"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });


                    }
                });
            }else{
                $('select[SubCategoryName="subcategory"]').empty();
            }
        });
    });
</script>