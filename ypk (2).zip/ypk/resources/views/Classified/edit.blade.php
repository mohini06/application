



  <h1>Edit Admins</h1>
  {!! Form::open(['action'=>['RegistrationController@update',$classified->ClassifiedRegId],'method'=>'POST']) !!}
  <div class="form-group">
    {{form::label('ClassifiedContent','Content')}}
     {{form::text('ClassifiedContent',$classified->ClassifiedContent,['class'=> 'form-control'])}}
  </div>
   <div class="form-group">
      {{form::label('CategoryCode','Category')}}
       {{form::text('CategoryCode',$classified->CategoryCode,['class'=> 'form-control'])}}
    </div>
    <div class="form-group">
          {{form::label('SubCategoryCode','Company')}}
           {{form::text('SubCategoryCode',$classified->SubCategoryCode,['class'=> 'form-control'])}}
     </div>
     {{Form::hidden('_method','PUT')}}
      {{Form::submit('Submit',['class'=>'btn btn-primary'])}}
  {!! Form::close() !!}
