@extends('layouts.app')
@section('title')
Желтые страницы Казахстана | Бесплатные объявления ::
@stop
@section('description', '')
@section('keywords', 'Желтые страницы Казахстана')
@section('content')
<script>
	$(document).ready(function () 
	{
        // Handler for .ready() called.
        $('html, body').animate({
            scrollTop: 560
        }, 2000);
    });  
</script>

<div class="container">
    <div class="row">
        <div class="col-md-9 top-slider">
			<div class="row">
                <div class="col-md-12" >
					<h3 class="headerline" >{{__('message.How to register a company in')}}ypk.kz?</h3>
				</div>
			</div>
			<div class="detail-wrapper">
				<div class="detail-wrapper-header">
					<h3 style="font-size: 20px;">{{__('message.Step')}}1 </h3>
				</div>
				<div class="detail-wrapper-body">
					<span class="help-text">{{__('message.Click')}}</span>
					<a href="add_your_company.html" style="font-size: 16px;font-weight:bold;color: #000;" target="_blank">"{{__('message.Add your company')}}"</a>
					<span class="help-text">
						{{__('message.from the main menu')}}.{{__('message.It is free')}}.
					</span>
					<img src="{{asset('public/img/help/menu-add-company-img.png')}}" alt="menu-add-company" style="width:100%;margin-top:10px;">
				</div>
			</div>
			<div class="detail-wrapper">
				<div class="detail-wrapper-header">
					<h4  style="font-size: 20px; margin: 0px;">{{__('message.Step')}}2</h4>
				</div>
				<div class="detail-wrapper-body">
					<span class="help-text">{{__('message.Fill in the required field marked with')}}</span>
					<span class="help-text" style="color:red;">*</span>
					<span class="help-text">{{__('message.and fill in the exact information. Up-to-date information will help potential users to become interested in your company')}}</span>
					<img src="{{asset('public/img/help/add-details-img.jpg')}}" alt="menu-add-company" style="width:100%;margin-top:10px;">
				</div>
			</div>
			<div class="detail-wrapper">
				<div class="detail-wrapper-header">
					<h4 style="font-size: 20px; margin: 0px;">{{__('message.Step')}}3</h4>
				</div>
			<div class="detail-wrapper-body">
                <span class="help-text">{{__('message.Click the')}}</span>
				<span class="help-text" style="font-weight:bold;">"{{__('message.Send')}}"</span>
				<span class="help-text"> {{__('message.button . The user will receive a notification letter from ypk.kz that you have successfully registered.')}}</span>
			</div>
		</div>
	</div>
	<div class="col-md-3">
		@include('classifieds_slide')
	</div>
</div>
@endsection