@extends('profilemenu')
@section('mycontent')
<div class="col-md-4">
	<!--<div id="toggle">

  <div class="one"></div>
  <div class="two"></div>
  <div class="three"></div>
</div>-->

<!--<div id="menu">-->
    <div class="sidebar">
    <div class="box">
<h2 class="small-title">{{__('message.Change Password')}}</h2>
 <form method="post" id="linkepswd"action="{{url('/passwordupdate')}}" role="form">
 <input type="hidden" name="_token" value="{{ csrf_token()}}">
 <input type="hidden" name="id" value="{{$userd->UserRegId}}">
        <div class="row">
       <div class="user-input-wrp" style="width: 100%;">
  <br/>
  <input type="text" class="inputText"id="npswd" name="npswd" required />
  <span class="floating-label">{{__('message.New Password')}}  <span style="color:red;"></span></span>
</div>
        </div>
        <div class="row">
        <div class="user-input-wrp" style="width: 100%;">
  <br/>
  <input type="text" class="inputText" name="cnfpass" required />
  <span class="floating-label">{{__('message.Retype Password')}}<span style="color:red;"></span></span>
</div>
        </div>
        <div class="row">
        <div style="float:right;padding-top: 20px;padding-left: 15px;" >

        <input type="submit" class="btn-grad" value="{{__('message.Update')}}" style=" height:40px; width:100px;"/>
        </div>
        </div>
</form>
</div>
    </div>
<!--</div>-->



</div>
<script>
  $("#linkepswd").validate({
	   rules: {
		    npswd: {
                required: true,
				 minlength: 5,
                maxlength: 20

            },
            cnfpass: {
                required: true,
                equalTo: "#npswd"
            },
	   },
        messages: {
			 npswd: {
                required: "{{__('message.Please enter password')}}",
				 minlength: "Minimum 5 ",
                maxlength: "Maximum 20"
            },

            cnfpass: {
                required: "{{__('message.Please enter password again')}}",
                equalTo: "{{__('message.Password should match with confirm password')}}"
            },
		}
	   
	      });
</script>
@endsection