@extends('layouts.app') 
 @section('title')
Адреса в справочнике Желтые Страницы Казахстана

@stop
@section('description')
<?php 
  $category_name= isset($cat_subcat->CategoryName)? $cat_subcat->CategoryName:"";
  $subcategory_name= isset($cat_subcat->SubCategoryName)? "/".$cat_subcat->SubCategoryName:"";
  $cityn=isset($city__name->CityName)? $city__name->CityName.',':"";
 ?>
{{$cityn}}{{$get_search_item}}{{$category_name}}{{$subcategory_name}}:С адресом, контактным именем и телефонными номерами
@endsection
@section('keywords', 'Бесплатная публикация, адреса, телефон, найти адрес')
@section('content')

 <script>
$(document).ready(function () {
         // Handler for .ready() called.
         $('html, body').animate({
             scrollTop: 560
         }, 2000); 
  }); 
</script>
<?php 
  $category_name= isset($cat_subcat->CategoryName)? $cat_subcat->CategoryName:"";
  $subcategory_name= isset($cat_subcat->SubCategoryName)? "/".$cat_subcat->SubCategoryName:"";
 ?>
<div class="row">
    <div class="col-md-9 top-slider">
        <div class="row">
            <div class="col-md-7">
                <h3 class="headerline">{{__('message.Find result for')}} {{$category_name}}{{$subcategory_name}}</h3>
                <!-- rami-->
            </div>
            <div class="col-md-1">
                <h3 style="float: right;">{{__('message.Filter')}}</h3>
            </div>
			<!--<div class="col-md-3">
               <a href="#" class="select-category-head" onclick="document.getElementById('id06').style.display='block'"><h3 class="headerline" >By Company Name</h3></a>
            </div>-->
            <div class="col-md-4">
                <a href="#" class="select-category-head" onclick="document.getElementById('id05').style.display='block'"><h3 class="headerline" >{{__('message.Select Category')}}</h3></a>
            </div>
        </div>

        <div id="id05" class="modal overflow-modal" ><!--rami-->
          <form  class="modal-content download-body category-mdal-width" action="{{url('/advsearch')}}"  id="advsearch_validation" method="get" role="form">
                <input type="hidden" name="_token" value="{{csrf_token()}}">
      
           <div class="title-head-modal" style="background-color:#ffce00;height:50px;">
                <span onclick="document.getElementById('id05').style.display='none'" class="download-close" title="Close Modal">&times;</span>
                  <h4 class="modal-title" style="padding:15px;text-align: center;">{{__('message.CHOOSE CATEGORY AND SUBCATEGORY')}}</h4>
                </div>
               
        <div class="wrap" style="margin-top:10px;margin-bottom:10px;">
           <div class="search">
              <input type="text" style="color:black;" id="searchTerm" name="selectedsubcat"class="searchTerm" placeholder="{{__('message.Select Category')}}">
			        
           <button type="submit" class="searchButton">
                <i class="fa fa-search"></i>
             </button>
            <!--  <input type="submit" class="searchButton">  <i class="fa fa-search"></i> -->
           
           </div>
        </div>
        
		  <div class="container-fluid">

            <div class="categories-popup" style="margin-top:60px;">

                 <div>
                       <br>

           <div class="category-lists">
                 <?php
                 $row_count=(count($category)/3);
                             if((count($category)%3)>0){
                                 $row_count=(count($category)/3);
                             }
              $total_counter=0;

                 ?>
                @for ($i = 0; $i < 3; $i++)
                   <?php $counter=0;
              ?>
                         <div class="col-md-4" style="border-right: 1px solid rgba(255, 255, 255, 0.4);">
                           @for($j=$counter;$j<$row_count;$j++)

                          <table  cellspacing="0" style="/* border-collapse:collapse; */">
                           <tbody>
                           @foreach($category->where('CategoryId','=',$total_counter) as $categories)
                             <tr>
                                <td>
                                <?php

                                   $totalcounter=0;
                                ?>
                                  <a  href="javascript:showhide('unique<?php echo $total_counter;?>')" class="btnCategory" style="cursor:pointer;font-size:13px;" aria-hidden="true" >
                                    <span  class="fa fa-plus-circle" style="cursor:pointer;font-size:13px;">
                                     </span>

                                        {{$categories->CategoryName}}
                                     </a>
                                     <div  class="sub-category" id="unique<?php echo $total_counter;?>" >
                                     @foreach($subcategory->where('CategoryId','=',$categories->CategoryId) as $subcategories)
                                     <table  cellspacing="0" style="border-collapse:collapse;">
                                         <tbody>
                                             <tr>
                                                 <td  onclick="document.getElementById('searchTerm').value='{{$subcategories->SubCategoryName}}'">
                                                      {{$subcategories->SubCategoryName}}
                                                 </td>
                                             </tr>
                                         </tbody>
                                     </table>
                                   @endforeach
                                   </div>
                                </td>
                             </tr>
                             @endforeach
                           </tbody>
                      <?php $counter++;
                      $total_counter++;
                      ?>
                        @endfor
                          </table>


                         </div>

                    @endfor


                    </div>
                 </div>

            </div>

        </div>



       </form>
        </div>
		   @if(count($companydata)>=1)
			
				  @foreach($companydata as $companydetail )
				
				  @php
				    $type=$companydetail->type;
					if($type=="Company")
					{
					   $url=url('/companydetail');
					   $view=url('/view');
					}
					else{
						$url=url('/classifieddetail');
					   $view=url('/classified_view');
					}
				  @endphp
        <div class="row">

            <div class="job-list" style="width:100%;">
                <div class="row">
                    <div class="col-md-2 ipad-responsive">
                        <!-- rami-->
                        <div class="thumb">
					
						 <a href="{{$url}}/{{$companydetail->CompanyRegId}}">
                            <img src="{{asset('public/ProductImages')}}/{{$companydetail->ImageUrl}}" onerror="this.src='{{asset('public/ProductImages/no-image.png')}}'" class="search_image"></a>
                        </div>
                    </div>
                    <div class="col-md-10">
                        <div class="job-list-content">
                            <div class="row search_header">
                                <h4 class=""><a href="{{$url}}/{{$companydetail->CompanyRegId}}" class="search_name" style="text-decoration: none;" >{{$companydetail->CompanyName}}</a></h4>
                            </div>
                            <div class="row search_paragraph" style="margin-top:20px;">
                                <p class="describe-business-details">{{$companydetail->DescribeBusiness}}</p>
                            </div>
                            <div class="job-tag" style="margin-top:50px;">

                            </div>
                        </div>
                    </div>
                </div>

                <div class="row" style="font-size: 14px; color: #999;">
                    <!--rami-->

                    <div class="col-md-7 ">
                        <div class="row">
                            <div class="co-md-3">
                                <span style="padding-right: 10px;padding-left: 10px;"><i class="fa fa-phone" style="color:#ffce00; font-size: 20px; padding:6px;"></i>{{$companydetail->Phone}}</span>
                            </div>
                            <div class="co-md-3">
                                <span style="padding-right: 10px;padding-left: 10px;"><i class="fa fa-map-marker" style="color:#ffce00; font-size: 20px; padding:6px;"></i> {{$companydetail->Address1}}{{$companydetail->CityName}}</span>
                            </div>
                            <div class="co-md-3">
							@php 
							
						  $var = $companydetail->WebsiteLink;
                          if($var!="")
						  {
							 if((strpos($var, 'https') === 0)||(strpos($var, 'http') === 0))
								 {
							   $link= $var;
							   
							}
							
							else {
							 
							   $link= 'http://'.$var;
							  
							} 
						  }
						  else
						  {
							  $link="";
							  
						  }
							
							@endphp
                                <span style="padding-right: 10px;padding-left: 10px;"><i class="fa fa-globe" style="color:#ffce00; font-size: 20px; padding:6px;"></i><a href="{{$link}}" target="_blank">{{$var}}</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5 ">

                       <a href="{{$url}}/{{$companydetail->CompanyRegId}}" ><input type="button" class="btn-grad search_btn_map" value="{{__('message.Learn more')}}"  /></a>
                       <a href="{{$view}}/{{$companydetail->CompanyRegId}}" ><input type="button" class="btn-grad search_btn_map" value="{{__('message.View map')}}"  /></a>
                    </div>
                </div>
                <!--rami-->

            </div>

        </div>
        @endforeach
	{{ $companydata->appends(request()->query())->links() }} 
	
		@else 
            <p style="font-size:20px;"> {{__('message.No Data found')}}</p>
	@endif
    </div>

    <script>
    // Get the modal
    var modal = document.getElementById('id05');

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
    </script>

    <div class="col-md-3" style="padding-left: 5px;padding-right: 5px;">
       @include('classifieds_slide')
    </div>
</div>
@endsection