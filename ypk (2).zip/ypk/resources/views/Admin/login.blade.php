<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">


    <title>Documents</title>

    <!-- Styles -->

</head><!-- app/views/login.blade.php -->

<body>
    <center>
    <h2>ADMIN LOGIN</h2>
     {!! Form::open(array('url' => 'dashboard')) !!}
  <div class="form-group">
   {{form::label('UserName','User Name')}}
   {{form::text('UserName','',['class'=>'formcontrol'])}}
  </div>

   <div class="form-group">
    {{form::label('Passsword','Password')}}
    {{form::password('Password','',['class'=>'formcontrol'])}}
    </div>

     {{Form::submit('Submit',['class'=>'btn btn-primary'])}}
     {{Form::reset('Cancel',['class'=>'btn btn-primary'])}}
  {!! Form::close() !!}
  </center>
</body>
 </html>
