@extends('layouts.app')
@section('content')
<script src="{{asset('public/js/jquery-1.11.3.js')}}"></script>
<script src="{{asset('public/js/bootstrap.min.js')}}"></script>
<script >
						 $(window).load(function() {
							$("#flexiselDemo3").flexisel({
								visibleItems:1,
								animationSpeed: 1000,
								autoPlay: true,
								autoPlaySpeed: 5000,
								pauseOnHover: true,
								enableResponsiveBreakpoints: true,
								responsiveBreakpoints: {
									portrait: {
										changePoint:480,
										visibleItems:1
									},
									landscape: {
										changePoint:640,
										visibleItems:1
									},
									tablet: {
										changePoint:768,
										visibleItems:1
									}
								}
							});

						});
					   </script>
 <div class="row" style="margin-top: 20px;">
    <div class="col-md-3">
    <!-- uncomment code for absolute positioning tweek see top comment in css -->
    <!-- <div class="absolute-wrapper"> </div> -->
    <!-- Menu -->
    <div class="side-menu">

    <nav class="navbar navbar-default main-style" role="navigation">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
        <div class="brand-wrapper">
            <!-- Hamburger -->
            <button type="button" class="navbar-toggle">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>




        </div>

    </div>

    <!-- Main Menu -->
    <div class="side-menu-container">
        <ul class="nav navbar-nav side-nav">

          <li class="active"><a href="my account_page.html"><i class="fa fa-user " aria-hidden="true"></i> My Profile</a></li>

                           <li><a href="Edit Details.html"><i class="fa fa-star" aria-hidden="true"></i> My review</a></li>
               			<li><a href="{{url('/edit')}}/{{$userd->UserRegId}}"><i class="fa fa-edit " aria-hidden="true"></i> Edit</a></li>
               			<li><a href="upload product images.html"><i class="fa fa-download" aria-hidden="true"></i> Upload Product Image</a></li>


                           <li><a href="Change Password.html"><i class="fa fa-lock" aria-hidden="true"></i> Change password</a></li>


        </ul>
    </div><!-- /.navbar-collapse -->
</nav>
    </div>
</div>



<!--------------------code for accordin--------------------------------------->
<div class="col-md-9">
	<div class="profile-body">
        <button class="accordion">COMPANY EDIT DETAILS</button>
	  <div class="panel">
		<div class="row">
			<div class="col-md-12 profile-left">
			    <div class="cont-detail"style="background:none;">
                      <p>Enter your details below</p>
                    <div class="row row-wrap">
                        <div class="col-md-4">
						    <div class="form-group form-group-label-highlight">
                                <label>Company Name<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>User Id<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>Address<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>

							<div class="form-group form-group-label-highlight">
                                <label>Category<span class="imp">*</span></label>
                                <select id="country" onchange="change_country(this.value)" class="frm-field required">
										<option value="null">Title</option>
											<option>Mr.</option>
											<option>Ms</option>
											<option>Mrs</option>
											</select>

                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>Area<span class="imp">*</span></label>
                                <select id="country" onchange="change_country(this.value)" class="frm-field required">
										<option value="null">Title</option>
											<option>Mr.</option>
											<option>Ms</option>
											<option>Mrs</option>
											</select>

                            </div>
							<div class="form-group form-group-label-anim">
                                <label>Fax Number<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">

                            </div>
						    <div class="form-check">
								<label class="form-check-label">
								  <input type="checkbox" class="form-check-input">
								 I agree the terms and conditions
								</label>
							</div>

							<div class="form-group form-group-label-anim">
                                 <label class="form-check-label">
									<input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked>
										premium<br>
									<img src="images/free-yellowpages.png">

								 </label>
							</div>

                        </div>
						<div class="col-md-4">

                            <div class="form-group form-group-label-highlight">
                                <label>Contact Name<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>Password<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>Address2<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
                           <div class="form-group form-group-label-highlight">
                                <label>Sub Category<span class="imp">*</span></label>
                                <select id="country" onchange="change_country(this.value)" class="frm-field required">
										<option value="null">Title</option>
											<option>Mr.</option>
											<option>Ms</option>
											<option>Mrs</option>
											</select>

                            </div>
							<div class="form-group form-group-label-anim">
                                <label>Phone Number<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">

                            </div>
							<div class="form-group form-group-label-anim">
                                <label>	Website Link<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">

                            </div>
							<br><br>
							<div class="form-group form-group-label-anim">
                                 <label class="form-check-label">
									<input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked>
										Gold<br>
									<img src="images/gold-yellowpages.png">

								 </label>
							</div>


                        </div>

						<div class="col-md-4">

                            <div class="form-group form-group-label-highlight">
                                <label>Email Address<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>ReEnter Password<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>Pin Code<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>City<span class="imp">*</span></label>
                                <select id="country" onchange="change_country(this.value)" class="frm-field required">
										<option value="null">Title</option>
											<option>Mr.</option>
											<option>Ms</option>
											<option>Mrs</option>
											</select>

                            </div>
                            <div class="form-group form-group-label-anim">
                                <label>Mobile Number<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">

                            </div>
							<div class="form-group form-group-label-anim">
                                <label>Describe Your Business<span class="imp">*</span></label>
                                <textarea rows="2" cols="32" placeholder=""></textarea>

                            </div>
							<br>
							<div class="form-group form-group-label-anim">
                                 <label class="form-check-label">
									<input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked>
										Silver<br>
									<img src="images/free-yellowpages.png">

								 </label>
							</div>
							<input class="btn btn-primary pull-right ipt-rgt" type="submit" value="Cancel" style="padding: 7px 26px;">
							<input class="btn btn-primary pull-right ipt-rgt" type="submit" value="Next" style="padding: 7px 26px;">

                        </div>
					</div>
                </div>
            </div>
		</div>
      </div>

		<button class="accordion">CLASSIFELD EDIT DETAILS</button>
		<div class="panel">
		    <div class="row">
				<div class="col-md-12 profile-left">
				  <div class="container" style="width: 100%;margin: 0;">

					  <ul class="nav nav-tabs">
						<li class="active"><a href="#home">My profile</a></li>
						<li><a href="#menu1">Test Detail</a></li>

					  </ul>

					  <div class="tab-content">
						<div id="home" class="tab-pane active">
						    <div class="cont-detail"style="background:none;">
                      <p>Enter your details below</p>
                    <div class="row row-wrap">
                        <div class="col-md-4">
						    <div class="form-group form-group-label-highlight">
                                <label>Company Name<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>User Id<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>Address<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>

							<div class="form-group form-group-label-highlight">
                                <label>Category<span class="imp">*</span></label>
                                <select id="country" onchange="change_country(this.value)" class="frm-field required">
										<option value="null">Title</option>
											<option>Mr.</option>
											<option>Ms</option>
											<option>Mrs</option>
											</select>

                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>Area<span class="imp">*</span></label>
                                <select id="country" onchange="change_country(this.value)" class="frm-field required">
										<option value="null">Title</option>
											<option>Mr.</option>
											<option>Ms</option>
											<option>Mrs</option>
											</select>

                            </div>
							<div class="form-group form-group-label-anim">
                                <label>Fax Number<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">

                            </div>
						    <div class="form-check">
								<label class="form-check-label">
								  <input type="checkbox" class="form-check-input">
								 I agree the terms and conditions
								</label>
							</div>

							<div class="form-group form-group-label-anim">
                                 <label class="form-check-label">
									<input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked>
										premium<br>
									<img src="images/free-yellowpages.png">

								 </label>
							</div>

                        </div>
						<div class="col-md-4">

                            <div class="form-group form-group-label-highlight">
                                <label>Contact Name<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>Password<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>Address2<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
                           <div class="form-group form-group-label-highlight">
                                <label>Sub Category<span class="imp">*</span></label>
                                <select id="country" onchange="change_country(this.value)" class="frm-field required">
										<option value="null">Title</option>
											<option>Mr.</option>
											<option>Ms</option>
											<option>Mrs</option>
											</select>

                            </div>
							<div class="form-group form-group-label-anim">
                                <label>Phone Number<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">

                            </div>
							<div class="form-group form-group-label-anim">
                                <label>	Website Link<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">

                            </div>
							<br><br>
							<div class="form-group form-group-label-anim">
                                 <label class="form-check-label">
									<input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked>
										Gold<br>
									<img src="images/gold-yellowpages.png">

								 </label>
							</div>


                        </div>

						<div class="col-md-4">

                            <div class="form-group form-group-label-highlight">
                                <label>Email Address<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>ReEnter Password<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>Pin Code<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>City<span class="imp">*</span></label>
                                <select id="country" onchange="change_country(this.value)" class="frm-field required">
										<option value="null">Title</option>
											<option>Mr.</option>
											<option>Ms</option>
											<option>Mrs</option>
											</select>

                            </div>
                            <div class="form-group form-group-label-anim">
                                <label>Mobile Number<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">

                            </div>
							<div class="form-group form-group-label-anim">
                                <label>Describe Your Business<span class="imp">*</span></label>
                                <textarea rows="2" cols="32" placeholder=""></textarea>

                            </div>
							<br>
							<div class="form-group form-group-label-anim">
                                 <label class="form-check-label">
									<input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked>
										Silver<br>
									<img src="images/free-yellowpages.png">

								 </label>
							</div>
							<input class="btn btn-primary pull-right ipt-rgt" type="submit" value="Cancel" style="padding: 7px 26px;">
							<input class="btn btn-primary pull-right ipt-rgt" type="submit" value="Next" style="padding: 7px 26px;">

                        </div>
					</div>
                </div>






						</div>
						<div id="menu1" class="tab-pane fade" style="background: transparent;">
						    <div class="cont-detail" style="background:none;">
                      <p>Enter your details below</p>
                    <div class="row row-wrap">
                        <div class="col-md-4">
						    <div class="form-group form-group-label-highlight">
                                <label>Company Name<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>User Id<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>Address<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>

							<div class="form-group form-group-label-highlight">
                                <label>Category<span class="imp">*</span></label>
                                <select id="country" onchange="change_country(this.value)" class="frm-field required">
										<option value="null">Title</option>
											<option>Mr.</option>
											<option>Ms</option>
											<option>Mrs</option>
											</select>

                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>Area<span class="imp">*</span></label>
                                <select id="country" onchange="change_country(this.value)" class="frm-field required">
										<option value="null">Title</option>
											<option>Mr.</option>
											<option>Ms</option>
											<option>Mrs</option>
											</select>

                            </div>
							<div class="form-group form-group-label-anim">
                                <label>Fax Number<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">

                            </div>
						    <div class="form-check">
								<label class="form-check-label">
								  <input type="checkbox" class="form-check-input">
								 I agree the terms and conditions
								</label>
							</div>

							<div class="form-group form-group-label-anim">
                                 <label class="form-check-label">
									<input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked>
										premium<br>
									<img src="images/free-yellowpages.png">

								 </label>
							</div>

                        </div>
						<div class="col-md-4">

                            <div class="form-group form-group-label-highlight">
                                <label>Contact Name<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>Password<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>Address2<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
                           <div class="form-group form-group-label-highlight">
                                <label>Sub Category<span class="imp">*</span></label>
                                <select id="country" onchange="change_country(this.value)" class="frm-field required">
										<option value="null">Title</option>
											<option>Mr.</option>
											<option>Ms</option>
											<option>Mrs</option>
											</select>

                            </div>
							<div class="form-group form-group-label-anim">
                                <label>Phone Number<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">

                            </div>
							<div class="form-group form-group-label-anim">
                                <label>	Website Link<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">

                            </div>
							<br><br>
							<div class="form-group form-group-label-anim">
                                 <label class="form-check-label">
									<input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked>
										Gold<br>
									<img src="images/gold-yellowpages.png">

								 </label>
							</div>


                        </div>

						<div class="col-md-4">

                            <div class="form-group form-group-label-highlight">
                                <label>Email Address<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>ReEnter Password<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>Pin Code<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">
                            </div>
							<div class="form-group form-group-label-highlight">
                                <label>City<span class="imp">*</span></label>
                                <select id="country" onchange="change_country(this.value)" class="frm-field required">
										<option value="null">Title</option>
											<option>Mr.</option>
											<option>Ms</option>
											<option>Mrs</option>
											</select>

                            </div>
                            <div class="form-group form-group-label-anim">
                                <label>Mobile Number<span class="imp">*</span></label>
                                <input class="form-control" placeholder="Write something" type="text">

                            </div>
							<div class="form-group form-group-label-anim">
                                <label>Describe Your Business<span class="imp">*</span></label>
                                <textarea rows="2" cols="32" placeholder=""></textarea>

                            </div>
							<br>
							<div class="form-group form-group-label-anim">
                                 <label class="form-check-label">
									<input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked>
										Silver<br>
									<img src="images/free-yellowpages.png">

								 </label>
							</div>
							<input class="btn btn-primary pull-right ipt-rgt" type="submit" value="Cancel" style="padding: 7px 26px;">
							<input class="btn btn-primary pull-right ipt-rgt" type="submit" value="Next" style="padding: 7px 26px;">

                        </div>
					</div>
                </div>
						</div>

					  </div>
					</div>

				</div>
		    </div>
		</div>



	</div>
</div>
 </div>
 <script>
 var acc = document.getElementsByClassName("accordion");
 var i;

 for (i = 0; i < acc.length; i++) {
   acc[i].onclick = function() {
     this.classList.toggle("active");
     var panel = this.nextElementSibling;
     if (panel.style.maxHeight){
       panel.style.maxHeight = null;
     } else {
       panel.style.maxHeight = panel.scrollHeight + "px";
     }
   }
 }
 </script>
 <script>
 $(document).ready(function(){
     $(".nav-tabs a").click(function(){
         $(this).tab('show');
     });
 });
 </script>

@endsection

{{--hi--}}
{{--@foreach($user as $users)--}}
{{--<label>{{$users->Name}}</label>--}}

{{--@endforeach--}}

{{--<label>{{$name}}</label>--}}

{{--<!DOCTYPE html>--}}
{{--<html lang="en">--}}
{{--<head>--}}
    {{--<meta charset="utf-8">--}}


   {{--<title>Yellow Pages Kazakhstan</title>--}}
    {{--<script src="http://demo.itsolutionstuff.com/plugin/jquery.js"></script>--}}
     {{--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/>--}}
   {{--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">--}}
  {{--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>--}}
   {{----}}
    {{--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>--}}

    {{--<!-- Styles -->--}}
   {{--<style>--}}
   {{--ul{--}}
   {{--list-style-type: none;--}}
   {{--}--}}
   {{--#menu{--}}
  {{--float: left;--}}

   {{--}--}}
   {{--hr {--}}
   {{--background-color: red;--}}
   {{--height: 1px;--}}
   {{--border: 2;--}}
    {{--}--}}

   {{--</style>--}}
{{--</head>--}}
{{--<body>--}}
{{--<div class="container-fluid">--}}
{{--<div class="row bg-danger">--}}
 {{--<ul class="list-group">--}}
    {{--<li class="list-group-item" id="menu">--}}
      {{--<a href="">Add Your Company</a>--}}
    {{--</li>--}}
    {{--<li class="list-group-item" id="menu">--}}
    {{--<a href="/ypk/home/create">Post a free add</a>--}}
    {{--</li>--}}
     {{--<li class="list-group-item" id="menu">--}}
     {{--<a href="/ypk/userlogin">Go Out</a>--}}
        {{--</li>--}}
     {{--</ul>--}}
{{--</div>--}}
 {{--<div class="row bg-primary text-center">--}}
    {{--<h3>Welcome to Ypk</h3>--}}
 {{--</div>--}}
    {{--<div class="row bg-success">--}}
     {{--<div class="col-sm-2">--}}
     {{--<div class="row">--}}
     {{--<ul class="list-group">--}}
        {{--<li class="list-group-item"><a href="/ypk/profile">My Profile</a></li>--}}
        {{--<li class="list-group-item"><a href="">My  Review</a></li>--}}
        {{--<li class="list-group-item"><a href="">Edit Profile</a></li>--}}
        {{--<li class="list-group-item"><a href="">Upload Image</a></li>--}}
        {{--<li class="list-group-item"><a href="/ypk/chpswd">Change Password</a></li>--}}

     {{--</ul>--}}
     {{--</div>--}}

     {{--</div>--}}
     {{--<div class="col-sm-1"></div>--}}

      {{--<div class="col-sm-8">--}}
             {{--<div class="row">--}}

                {{--<form  method="POST" action="/ypk/update/" role="form">--}}
                 {{--<form  method="POST" action="{{action('ClassifiedController@store')}}" >--}}

                 {{--<input type="hidden" name="_token" value="{{ csrf_token()}}">--}}



                  {{--<div class="row">--}}
                    {{--<div class="col-sm-4">--}}
                        {{--<div class="form-group">--}}
                         {{--<label>Заголовок объявления</label>--}}
                         {{--<input type="text" id="title" name="ClassifiedTitle" class="form-control">--}}

                        {{--</div>--}}
                    {{--</div><!-- col-sm-6 end-->--}}
                   {{--<div class="col-sm-4">--}}
                        {{--<div class="form-group">--}}
                          {{--<label>Выберите свою категорию</label>--}}
                          {{--<select class="form-control" id="category" name="category" >--}}

                             {{--@foreach($category as $categories)--}}
                               {{--<option value="{{$categories->CategoryId}}">{{$categories->CategoryName}}</option>--}}
                              {{--@endforeach--}}

                          {{--</select>--}}

                        {{--</div>--}}
                    {{--</div><!-- col-sm-6 end-->--}}
                     {{--<div class="col-sm-4">--}}
                              {{--<div class="form-group">--}}
                                  {{--<label>Подкатегория</label>--}}
                                  {{--<select class="form-control " id="subcategory" name="subcategory" >--}}

                                  {{--</select>--}}


                               {{--</div>--}}
                            {{--</div><!-- col-sm-6 end-->--}}
                    {{--</div><!-- row 1 end-->--}}
                    {{--<div class="row">--}}

                       {{--<div class="col-sm-4">--}}
                           {{--<div class="form-group">--}}
                                {{--<label>Адрес электронной почты</label>--}}
                                {{--<input type="email" id="title" name="email" class="form-control" readonly>--}}

                           {{--</div>--}}
                        {{--</div><!-- col-sm-6 end-->--}}
                        {{--<div class="col-sm-4">--}}
                                  {{--<div class="form-group">--}}
                                   {{--<label>Ваше имя </label>--}}
                                   {{--<input type="text" class="form-control" name="name" readonly>--}}
                                   {{--<span class="text-danger">{{ $errors->first('name') }}</span>--}}
                                  {{--</div>--}}
                                {{--</div><!-- col-sm-6 end-->--}}
                                {{--<div class="col-sm-4">--}}
                                           {{--<div class="form-group">--}}
                                              {{--<label>Город</label>--}}
                                              {{--<select class="form-control" id="city" name="city">--}}
                                           {{--@foreach($city as $cities)--}}
                                            {{--<option value="{{$cities->CityId}}">{{$cities->CityName}}</option>--}}
                                           {{--@endforeach--}}
                                              {{--</select>--}}

                                           {{--</div>--}}
                                        {{--</div><!-- col-sm-6 end-->--}}

                   {{--</div><!-- row 2 emd-->--}}

                   {{--<div class="row">--}}
               {{--<div class="col-sm-4">--}}
                      {{--<div class="form-group">--}}
                        {{--<label>Мобильный номер</label>--}}
                        {{--<div class="row">--}}
                            {{--<div class="col-sm-2">--}}
                                {{--<h5>&nbsp;&nbsp;&nbsp;&nbsp;+7</h5>--}}
                            {{--</div>--}}
                            {{--<div class="col-sm-10">--}}
                                {{--<input type="text" id="title" name="mobile" class="form-control">--}}

                            {{--</div>--}}
                        {{--</div>--}}
                      {{--</div>--}}
               {{--</div><!-- col-sm-4 end-->--}}
               {{--<div class="col-sm-4">--}}
                   {{--<div class="form-group">--}}
                      {{--<label>Номер телефона(С кодом города)</label>--}}
                      {{--<div class="row">--}}
                      {{--<div class="col-sm-2">--}}
                        {{--<h5>&nbsp;&nbsp;&nbsp;&nbsp;+7</h5>--}}
                      {{--</div>--}}
                      {{--<div class="col-sm-10">--}}
                        {{--<input type="text" id="title" name="phone" class="form-control">--}}

                      {{--</div>--}}
                   {{--</div>--}}
                   {{--</div>--}}
               {{--</div><!-- col-sm-6 end-->--}}
               {{--</div><!-- row 3 emd-->--}}

                   {{--<div class="row">--}}
               {{--<div class="col-sm-4">--}}
                     {{--<div class="form-group">--}}
                      {{--<label>Объявление</label>--}}
                      {{--<textarea class="form-control" name="ClassifiedContent"></textarea>--}}

                      {{--</div>--}}
                      {{--</div><!-- col-sm-12 end-->--}}
                       {{--<div class="col-sm-4">--}}
                              {{--<div class="form-group">--}}
                                 {{--<label> Ваш сайт (Не забудьте добавить http://)</label>--}}
                                 {{--<input type="url" name="Weburl" class="form-control">--}}
                                 {{--</div>--}}
                              {{--</div><!-- col-sm-8 end-->--}}
                   {{--</div><!-- row 4 emd-->--}}



                   {{--<div class="row text-right">--}}
                   {{--<div class="col-sm-12">--}}
                        {{--<div class="form-group">--}}
                         {{--<input type="reset" value="Clear" class="btn btn-warning">--}}
                         {{--<input type="submit" value="Update" class="btn btn-success">--}}
                        {{--</div>--}}
                      {{--</div><!-- col-sm- 4end-->--}}
                   {{--</div><!-- row5 end-->--}}

               {{--</form>--}}

             {{--</div>--}}
      {{--</div>--}}
       {{--<div class="col-sm-1"></div>--}}
   {{--</div>--}}

{{--</div>--}}
{{--<script type="text/javascript">--}}
 {{--$("#registerForm").validate({--}}
        {{--rules: {--}}
            {{--ClassifiedTitle: {--}}
            {{--required:true--}}
            {{--},--}}
           {{--email:{--}}
            {{--required:true,--}}
            {{--email:true--}}
            {{--},--}}
          {{--name:{--}}
          {{--required: true--}}

          {{--},--}}
          {{--mobile:{--}}
          {{--required:true,--}}
          {{--number:true,--}}
          {{--minlength:10,--}}
          {{--maxlength:10--}}
          {{--},--}}
           {{--phone:{--}}
            {{--required:true,--}}
            {{--number:true,--}}
            {{--minlength:10,--}}
            {{--maxlength:10--}}
           {{--},--}}
           {{--category:{--}}
           {{--required:true--}}

           {{--},--}}
           {{--subcategory:{--}}
            {{--required:true--}}
           {{--},--}}
           {{--city:{--}}
           {{--required:true--}}
           {{--}--}}

        {{--},--}}
        {{--messages:{--}}
            {{--ClassifiedTitle:{--}}
                {{--required:"its a mandatory field... "--}}
            {{--},--}}

            {{--subcategory:{--}}

            {{--},--}}
            {{--email:{--}}
            {{--required:"Please enter email-id",--}}
            {{--email:"Please enter valid email-id"--}}
            {{--},--}}
            {{--name:{--}}
            {{--required:"Please enter you name"--}}
            {{--},--}}
          {{--mobile:{--}}
          {{--required:"Please enter mobile no",--}}
          {{--number:"Please enter valid mobile number",--}}
          {{--minlength:"minimum 10 number required",--}}
          {{--maxlength:"maximum 10 numbers only"--}}
          {{--},--}}
           {{--phone:{--}}
                 {{--required:"Please enter phone no",--}}
                 {{--number:"Please enter valid phone number",--}}
                 {{--minlength:"min 10 number required",--}}
                 {{--maxlength:"maximum 10 numbers only"--}}
                 {{--},--}}



         {{--category:{--}}
         {{--required:"Please select one category.."--}}
        {{--},--}}
        {{--subcategory:{--}}
        {{--required:"please select subcategory after category"--}}
        {{--},--}}
        {{--city:{--}}
        {{--required:"please select any one"--}}
        {{--}--}}
        {{--}--}}
    {{--})--}}



{{--</script>--}}
       {{--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>--}}
       {{--<!-- Include all compiled plugins (below), or include individual files as needed -->--}}
       {{--<script src="{{ asset('js/bootstrap.min.js')}}"></script>--}}
{{--<script>--}}
{{--$('#ClassifiedContent').keyup(function () {--}}
  {{--var max = 500;--}}
  {{--var len = $(this).val().length;--}}
  {{--if (len >= max) {--}}
    {{--$('#charNum').text(' you have reached the limit');--}}
  {{--} else {--}}
    {{--var char = max - len;--}}
    {{--$('#charNum').text(char + ' characters left');--}}
  {{--}--}}
{{--});--}}

    {{--$(document).ready(function(){--}}
        {{--$('#category').on('change',function(){--}}
            {{--var categoryID = $(this).val();--}}

            {{--if(categoryID){--}}
                {{--$.ajax({--}}
                    {{--dataType: 'text',--}}

                     {{--type:'POST',--}}
                     {{--url:'../resources/views/queryforsubcategory.php',--}}
                      {{--//url:'app/Http/Controllers/DynamicController@index2',--}}
                     {{--data:'category_id='+categoryID,--}}

                     {{--success:function(html){--}}
                     {{--console.log(html);--}}

                     {{--$('#subcategory').html(html);--}}
                     {{--},--}}
                     {{--error:function(e){--}}
                     {{--$('#subcategory').html(e);--}}
                     {{--}--}}
               {{--});--}}
            {{--}--}}
        {{--});--}}


    {{--});--}}
{{--</script>--}}
       {{--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>--}}
       {{--<!-- Include all compiled plugins (below), or include individual files as needed -->--}}
       {{--<script src="{{ asset('js/bootstrap.min.js')}}"></script>--}}
{{--</body>--}}
{{--</html>--}}
