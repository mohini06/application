<?php
    include "db2.php";
    $username= $_REQUEST['userId'];
    $sql="SELECT * FROM userregistration where UserId or Email= '$username'";

    $result=$db->query($sql);
    if($result->num_rows>0)
    {
        echo 'User Id Already Exists';
    }
    else
    {
        echo 'User Name Available';
    }
?>