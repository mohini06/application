@extends('profilemenu')
@section('mycontent')
<div class="col-md-4">
    <div class="sidebar">
    <div class="box">
<h2 class="small-title" style="margin-bottom:20px! important;">{{__('message.Change Password')}}</h2>
 <form method="post" id="chpswd"action="{{url('/updatepswd')}}" role="form">
 <input type="hidden" name="_token" value="{{ csrf_token()}}">
        <div class="row login-password">
       <div class="user-input-wrp" style="width: 100%;">
  <br/>
  <input type="text" class="inputText"id="npswd" name="npswd" />
  <span class="floating-label">{{__('message.New Password')}} <span style="color:red;"></span></span>
</div>
        </div>
		 <br/>
        <div class="row login-password" >
        <div class="user-input-wrp" style="width: 100%;">
  <br/>
  <input type="text" class="inputText" name="cnfpass" />
  <span class="floating-label">{{__('message.Retype Password')}}<span style="color:red;"></span></span>
</div>
        </div>
        <div class="row">
        <div style="float:right;padding-top: 20px;padding-left: 15px;" >

        <input type="submit" class="btn-grad" value="{{__('message.Update')}}" style=" height:40px; width:100px;"/>
		
                           {{ session('status') }}
                     
        </div>
        </div>
</form>
</div>
    </div>
<!--</div>-->



</div>
<script>
  $("#chpswd").validate({
	   rules: {
		    npswd: {
                required: true,
				 minlength: 5,
                maxlength: 20

            },
            cnfpass: {
                required: true,
                equalTo: "#npswd"
            },
	   },
        messages: {
			 npswd: {
                required: "{{__('message.Please enter password')}}",
				 minlength: "Minimum 5 ",
                maxlength: "Maximum 20"
            },

            cnfpass: {
                required: "{{__('message.Please enter password again')}}",
                equalTo: "{{__('message.Password should match with confirm password')}}"
            },
		}
	   
	      });
</script>
@endsection