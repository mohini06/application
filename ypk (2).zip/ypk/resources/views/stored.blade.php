hi
<table>
 <tr>
  <th>Admin Id</th>
  <th>Admin Name</th>
  <th>UserName</th>
  <th>Password</th>
 <tr>
  @foreach($user as $admin)
<tr>
   <td>{{$admin->AdminId}}</td>
   <td>{{$admin->AdminName}}</td>
   <td>{{$admin->UserName}}</td>
   <td>{{$admin->Password}}</td>
</tr>
@endforeach

</table>

<table>
 <tr>
  <th>Admin Id</th>
  <th>Admin Name</th>
  <th>UserName</th>
  <th>Password</th>
 <tr>
  @foreach($user1 as $admin1)
<tr>
   <td>{{$admin1->AdminId}}</td>
   <td>{{$admin1->AdminName}}</td>
   <td>{{$admin1->UserName}}</td>
   <td>{{$admin1->Password}}</td>
</tr>
@endforeach

</table>