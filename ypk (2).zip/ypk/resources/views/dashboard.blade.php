@extends('layouts.app2')
@section('content')
<h5>COMPANY SEARCH/ANNONCEMENTS</h5>
<div class="row">
<div class="col-sm-4">
  <div class="form-group">
  <select class="form-control ">
    <option value="">AD</option>
    <option value="">Company</option>
    <option value="">Classified</option>
  </select>
  </div>
  </div>
  <div class="col-sm-6">
    <div class="form-group">
      <input type="text" class="form-control">
      </div>
  </div>
<div class="col-sm-2">
   <input type="submit" class="btn btn-primary" value="Search">
</div>

</div>
<table class="table table-bordered">
<tr>
 <th>Sl no</th>
 <th>Name</th>
 <th>Classified Title</th>
 <th>Post Date</th>
 <th>Is Approve</th>
 <th>Phone</th>
 <th>Action</th>
</tr>
<?php
 $i=1;
 ?>
  @foreach($classified as $classifieds)
  <tr>
  <td><?php echo $i++;?></td>
  <td>{{$classifieds->Name}}</td>
  <td>{{$classifieds->ClassifiedTitle}}</td>
  <td>{{$classifieds->PostedDate}}</td>
  <td></td>
  <td>{{$classifieds->Phone}}</td>
  <td><a href="">Edit</a></td>
  </tr>
  @endforeach
</table>
@endsection