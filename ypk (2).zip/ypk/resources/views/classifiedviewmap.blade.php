@extends('layouts.app') 
@section('content')
<script type="text/javascript">
    $(document).ready(function () 
    {
        // Handler for .ready() called.
        $('html, body').animate({
            scrollTop: 560
        }, 2000); 
    }); 
</script>

<div class="row" style="margin-bottom:10px;"><!--rami-->
    <div class="col-md-9" style="padding-left: 0px;padding-right: 0px;">
        <div class="col-md-4">
            <h3 class="headerline"> Map view </h3>
        </div>
        <div class="col-md-5">
        </div>
        <div class="col-md-3">
        </div>
    </div>
</div><!--rami-->
<iframe src="https://maps.google.it/maps?q={{$com->CityName}}&output=embed" width="100%" height="600" frameborder="0" style="border:0" allowfullscreen></iframe>
								
@endsection