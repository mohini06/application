<?php
include "db2.php";
$username= $_REQUEST['user_name'];
$sql="SELECT * FROM userregistration where UserId= '$username'";

$result=$db->query($sql);
if($result->num_rows>0)
{
	$output['error']=true;
	$output['message']='Введите уникальное имя пользователя';
    echo(json_encode(false));
}
else
{
    
	$output['error']=false;
	$output['message']='Имя пользователя доступно';
	echo(json_encode(true));

}

?>