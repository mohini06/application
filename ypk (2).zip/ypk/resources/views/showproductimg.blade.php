@extends('profilemenu')
@section('mycontent')
<div class="col-md-9">

@php  
             $classified_count=count($classifieddata);
        @endphp
 <ul id="tabs_classified">

        <li><a href="#" name="tab1" class="tab_text" style="font-weight: 500"><i class="menu_icon2 fa fa-user" aria-hidden="true" ></i> {{__('message.Profile')}}</a></li>
      @for($i=2;$i<=$classified_count+1;$i++)
        <li><a href="#" name="tab{{$i}}" class="tab_text" style="font-weight: 500"><i class="menu_icon2 fa fa-laptop" aria-hidden="true" ></i>{{__('message.Classified')}}&nbsp;@php echo ($i-1); @endphp</a></li>
     @endfor
 </ul>

<div id="tab_content">
@if($userd!=null)
@php $type=$userd->ActualRegType;   @endphp
    
	 <div id="tab1">
     
      <p>{{__('message.imagevalidation')}}</p>
     <div id="showing">
   	  @php $data_count=count($data); @endphp	
@if($type>2)	  
	  @if($data_count<5)
      
        @foreach($data as $image)
          <a href="{{url('/removeimg')}}/{{$image->ImageId}}"><i class="fa fa-times-circle remove-image-icon"></i></a>
          <img src="{{asset('public/ProductImages')}}/{{$image->ImageUrl}}" style="height:100px;width: 150px;">
		  @endforeach
          <form action="{{url('/saveproductimg')}}"  class="uploadImage-choose" id="uploadImage" method="post" enctype="multipart/form-data">
      <input type="hidden" name="_token" value="{{ csrf_token()}}">
     
      <input type="file" id="ImageUrl" class="button-file" name="ImageUrl" accept="image/gif, image/jpeg, image/png,image/jpg">
	  <label id="uploadMessage" style="color:red;"></label><br>
		
       <input type="button" value="{{__('message.Upload')}}" class="upload" class="btn btn-lg"/>

      </form>
    
	 @else
		  @foreach($data as $image)
	           <a href="{{url('/removeimg')}}/{{$image->ImageId}}"><i class="fa fa-times-circle remove-image-icon"></i></a>

		 <img src="{{asset('public/ProductImages')}}/{{$image->ImageUrl}}" style="height:100px;width: 150px;">

		  @endforeach

		  @endif
@elseif($type>1)
@if($data_count<3)
      
        @foreach($data as $image)
         <a href="{{url('/removeimg')}}/{{$image->ImageId}}"><i class="fa fa-times-circle remove-image-icon"></i></a>

          <img src="{{asset('public/ProductImages')}}/{{$image->ImageUrl}}" style="height:100px;width: 150px;">

		  @endforeach
          <form action="{{url('/saveproductimg')}}" class="uploadImage-choose"  id="uploadImage" method="post" enctype="multipart/form-data">
      <input type="hidden" name="_token" value="{{ csrf_token()}}">
     
      <input type="file" id="ImageUrl" class="button-file" name="ImageUrl" accept="image/gif, image/jpeg, image/png,image/jpg">
	  <label id="uploadMessage" style="color:red;"></label><br>
		
        <input type="button" value="{{__('message.Upload')}}" class="upload" class="btn btn-lg"/>

      </form>
    
	 @else
		  @foreach($data as $image)
	           <a href="{{url('/removeimg')}}/{{$image->ImageId}}"><i class="fa fa-times-circle remove-image-icon"></i></a>

		 <img src="{{asset('public/ProductImages')}}/{{$image->ImageUrl}}" style="height:100px;width: 150px;">

		  @endforeach
	  @endif
	 @elseif($type>0)
	   @if($data_count<1)
      
        @foreach($data as $image)
  <a href="{{url('/removeimg')}}/{{$image->ImageId}}"><i class="fa fa-times-circle remove-image-icon"></i></a>
          <img src="{{asset('public/ProductImages')}}/{{$image->ImageUrl}}" style="height:100px;width: 150px;">

       
		  @endforeach
          <form action="{{url('/saveproductimg')}}" id="uploadImage" method="post" class="uploadImage-choose" enctype="multipart/form-data">
      <input type="hidden" name="_token" value="{{ csrf_token()}}">
     
      <input type="file" id="ImageUrl" name="ImageUrl" class="button-file" accept="image/gif, image/jpeg, image/png,image/jpg">
	  <label id="uploadMessage" style="color:red;"></label><br>
		
        <input type="button" class="upload" value="{{__('message.Upload')}}" class="btn btn-lg"/>

      </form>
    
	 @else
		  @foreach($data as $image)
	     <a href="{{url('/removeimg')}}/{{$image->ImageId}}"><i class="fa fa-times-circle remove-image-icon"></i></a>
		 <img src="{{asset('public/ProductImages')}}/{{$image->ImageUrl}}" style="height:100px;width: 150px;">

      
		  @endforeach
	  @endif
	  @else
    <script>
   document.getElementById('notification').innerHTML="{{__('message.messafeforfree')}}";
	  </script>
	@endif 
      </div>
@else
  <p>{{__('message.Please add company')}} </p>
@endif
    </div>
     @php $j=2;@endphp
         @if ($classified_count>=1)
         @foreach($classifieddata as $add)
        <div id="tab{{$j++}}">
            @php $type_add=$add->ActualRegType; @endphp
            @if($type_add>0)
               <p>{{__('message.imagevalidation')}}</p>
                  <div id="showing">
                   @php $image_count=count($add_productimage->where('ClassifiedRegId','',$add->ClassifiedRegId)) ; @endphp
                   @foreach($add_productimage->where('ClassifiedRegId','',$add->ClassifiedRegId) as $image)
                                     <a href="{{url('/removeimg')}}/{{$image->ImageId}}"><i class="fa fa-times-circle remove-image-icon"></i></a>

                      <img src="{{asset('public/ProductImages')}}/{{$image->ImageUrl}}" style="height:100px;width: 150px;">
                 @endforeach
				 @if($image_count<10)
                  <form action="{{url('/saveproductimg_add')}}" class="uploadImage-choose"  id="uploadImage" method="post" enctype="multipart/form-data">
                  <input type="hidden" name="_token" value="{{ csrf_token()}}">
                 <input type="hidden" name="ClassifiedRegId"value="{{$add->ClassifiedRegId}}">
                  <input type="file" class="button-file" id="ImageUrl" name="ImageUrl" accept="image/gif, image/jpeg, image/png,image/jpg">
                <label id="uploadMessage" style="color:red;"></label><br>
                <input type="button" value="{{__('message.Upload')}}" class="upload" class="btn btn-lg"/>

                  </form>
				@else
					  <input type="submit" value="{{__('message.Upload')}}" onclick="alert('{{__('message.Вы загрузили максимальное количество изображений')}}')"class="btn btn-lg"/>
				  @endif
                  </div>
              @else
              <p>{{__('message.messafeforfree')}}</p>
            @endif
           
          </div>
         @endforeach
         @endif
</div>
</div>
@endsection