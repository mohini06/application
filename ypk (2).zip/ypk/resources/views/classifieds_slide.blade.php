 <h3 class="headerline">{{ __('message.classifiedlist') }}</h3>
  <!-- rami-->
  <?php
    $total_count=(count($classifiedprofile));
    $slide_per_page=6;
    $carousel_page_count=3;
    $slide_count=ceil($total_count/$slide_per_page);
  ?>
  <div id="carousel-example-generic-ads" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
      <ol class="carousel-indicators">
        <?php
          for($i=0;$i<$slide_count;$i++)
          {
        ?>
            <li data-target="#carousel-example-generic-ads" data-slide-to="<?php echo $i?>" class="<?php if($i==0){echo 'active';} ?>" ></li>
        <?php
          }
        ?>

        </ol>
          <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
            <?php
              $counter=0;
              $active="";
              $total_counter=0;
              for($i=0;$i<$slide_count;$i++)
              {
                if($i==0)
                {
                  $active="active";
                }
                else
                {
                  $active='';  
                }
            ?>
              <div class="carousel-item <?php echo $active;?>">
                <div class="tech-btm">
                  <?php
                    for($j=0;$j<6;$j++)
                    {
                      if($total_count>$total_counter)
                      {
                  ?>
                        <div class="blog-grids">
                          <div class="blog-grid-left">
                            <img src="{{asset('public/ProductImages/')}}/<?php echo $classifiedprofile[$total_counter]->ImageUrl; ?>"  class="responsive classified_slide_img"
                               onerror="this.src='{{asset('public/ProductImages/no-image.png')}}'">
                          </div>
                          <div class="blog-grid-right">
                            <h4>
                              <a href="{{url('/')}}/classifieddetail/<?php echo $classifiedprofile[$total_counter]->ClassifiedRegId; ?>"> 
                                <?php echo $classifiedprofile[$total_counter]->ClassifiedTitle; ?>
                              </a>
                            </h4>
                            <p>
                              <?php
                                $string= $classifiedprofile[$total_counter]->ClassifiedContent;
                                echo $string;
                              ?>
                            </p>
                            </div>
                            <div class="clearfix"></div>
                          </div>
                      <?php
                        }
                        else
                        { 
                      ?>
                    <div class="blog-grids">
                      <div class="blog-grid-left" >
                        <img src="{{asset('public/ProductImages/no-image.png')}}" class="responsive classified_slide_img">
                      </div>
                      <div class="blog-grid-right">
                        <p style="margin-top:16px;">{{__('message.slogan for company')}}</p>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                    <?php
                    }
                    $total_counter++;
                    }
                    ?>
                    </div>
                 </div>
                <?php }?>
                 </div>
                  <a class="left carousel-control" href="#carousel-example-generic-ads" data-slide="prev">
                      <i class="fa fa-chevron-left"></i>
                      <!-- rami-->
                  </a>
                  <a class="right carousel-control" href="#carousel-example-generic-ads" data-slide="next">
                     <i class="fa fa-chevron-right"></i>
                     <!-- rami-->
                  </a>
                </div> 
