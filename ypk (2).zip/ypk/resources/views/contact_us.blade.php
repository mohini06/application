@extends('layouts.app')
@section('title')
Контакты Желтых Страниц Казахстана -YPK.KZ
@stop
@section('description', 'Контактная информация об административном офисе Желтых Страниц Казахстана и нашем техническом партнере Филиале Дата Темплейт Инфотех Приват Лимитед в Казахстане - Contact information about the administrative office and  Research and development centre of Yellow Pages Kazakhstan ,Data Template Infotech Kazakhstan.')
@section('keywords', 'Алматы Желтые Страницы Казахстана, адрес, справка, компания, телефон -Almaty Yellow pages kazakhstan, address, reference, company, phone numbers')
@section('content')
 <script>
$(document).ready(function () {
         // Handler for .ready() called.
         $('html, body').animate({
             scrollTop: 560
         }, 2000);  
});
</script>
   <div class="row" >
           
            <div class="col-md-9 top-slider">
			<div class="row">
                  <div class="col-md-4" >
			<h3 class="headerline" > {{ __('message.contactus') }} </h3>
			</div>
			</div>
			<div class="detail-wrapper" style="background-color:#f2f1ef;">
								<div class="detail-wrapper-body">
									<div class="listing-title-bar">
										<h3 style="font-size: 27px;">{{__('message.title')}}</h3>
                                        <div class="row">
										<div class="col-md-6"><br><br>
                                            <h4 style="font-size: 20px; margin: 0px;">{{__('message.adminoffice')}}</h4>
											<a href="#listing-location" class="listing-address" style="text-decoration: none;">
												
												ТОО "Интернешнл Елоу Пэйдж Мэнеджемент Групп" <br>
                                               International Yellow Pages Management Group <br>
                                               г. Алматы, ул. Елебекова, дом 12/1<br>
                                             Республика Казахстан
											</a>
											
											
										</div>
                                        <div class="col-md-6"><br><br>
                                            <h4 style="font-size: 20px; margin: 0px;">{{__('message.centerforresearch')}}</h4>
											<a href="#listing-location" class="listing-address" style="text-decoration: none;">
												
												Филиал Дата Темплейт Инфотех Прайвет Лимитед<br> 
в Республике Казахстан <br>
г. Алматы, пр. Абая, 153,офис 27, 050009<br>
                                             
Email: sales@ypk.kz
											</a>
											
											
										</div>
                                        </div>
									</div>
								</div>
							</div>	

							<div class="detail-wrapper" style="background-color:#f2f1ef;">
								<div class="detail-wrapper-header">
									<h4 style="font-size: 20px; margin: 0px;">{{__('message.location')}}</h4>
								</div>
								<div class="detail-wrapper-body">
                                    <iframe src="https://maps.google.com/maps?q=43.327422,76.920506 &hl=es;z=4&amp;output=embed" width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen></iframe>
							</div></div>

							<div class="detail-wrapper" style="background-color:#f2f1ef;">
								<div class="detail-wrapper-header">
									<h4  style="font-size: 20px; margin: 0px;">{{__('message.writetous')}}</h4>
								</div>
								<div class="detail-wrapper-body">
								<form method="post" id="enquiry_form"action="{{url('/enquiry')}}"role="form">
								<input type="hidden" name="_token" value="{{ csrf_token()}}">
								<div class="row" style="padding-bottom: 10px;">
                    <div class="col-md-6 user-input-wrp">
  <br/>
                       <input type="text" class="inputText" id="uname" name="uname" required />
                        <span class="floating-label">{{__('message.Contact Name')}} <span style="color:red;">*</span></span>
</div>
                     <div class="col-md-6 user-input-wrp">
  <br/>
  <input type="text" class="inputText" id="umail"name="umail" required/>
                        <span class="floating-label">{{__('message.Email Address')}} <span style="color:red;">*</span></span>
</div>
                    
                    </div> 
                       <div class="row" style="padding-bottom: 10px;">             
                                     <div class=" col-md-6 user-input-wrp">
  <br/>
                       <input type="text" id="unumber" class="inputText phonemask"  name="unumber" />
                         
                         <span class="floating-label" >{{__('message.Phonenumber')}}<span style="font-size: 11px;">{{__('message.Addprefix')}}</span><span style="color:red;"></span></span>
                         
                           </div>
                         <div class=" col-md-6 user-input-wrp">
  <br/>
                       <input type="text" id="umobile" name="umobile"class="inputText phonemask" />
                         
                         <span class="floating-label" >{{__('message.Mobilenumber')}}<span style="font-size: 11px;">{{__('message.Addprefix')}} </span></span>
                         
</div>
                                    
                                    </div>
                                     <span class="headline"  style="margin-left: 4px;
    margin-top: 26px;
    position: absolute;font-weight: 600;font-size: 15px;">{{__('message.yourmessage')}}<span style="color:red;">* </span></span>
                                     <div class="row" style="padding-bottom: 10px;padding-top: 20px;">
                        <div class="col-md-3">
                   <!-- <textarea placeholder="{{__('message.This is an awesome comment box')}}" rows="20" name="comment_text" id="comment_text" cols="40" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true"></textarea> -->
                    <textarea placeholder="{{__('message.This is an awesome comment box')}}" rows="20" id="comment_text" name="comment_text"  cols="40" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true" required></textarea>
					</div>
					</div>
								<div class="row">
                        <div style="float:right;padding-top: 20px;padding-left: 15px;" >
                        
                             <input type="submit" class="btn-grad" value="{{__('message.Send')}}" style=" height:40px; width:100px;"/>
							  <input type="button" class="btn-grad" value="{{__('message.cancel')}}" style=" height:40px; width:100px;"/>
                        </div>
                    </div>
								</form>	
								</div>
							</div>
						</div>

	  <div class="col-md-3">
	      @include('classifieds_slide')
	  </div>
          </div>
		  <script type="text/javascript">
		  
    $("#enquiry_form").validate({

        rules: {
            uname: {
                required: true,
			    lettersonly: true
            },
            umail: {
                required: true,
                email: true,
                email_exists: false
            },
            unumber: {
                 required: true,
                validecode: true ,
            },
			umobile:{
				validecode: true ,
			},
			 comment_text: {
                required: true
            }
        },
        messages: {
           
            uname: {
                required: "{{__('message.Please Enter your name')}}",
                lettersonly: "{{__('message.Please Enter only character') }}"
            },
            umail: {
                required: "{{__('message.Please Enter your email aadress')}}",
                email: "{{__('message.Please Enter valid email')}}",
                email_exists: "{{__('message.Email already exist')}}"

            },
            unumber: {
              required: "Введите номер мобильного телефона",
                validecode: "код страны должен быть действительным"
            },
			umobile:{
				validecode: "код страны должен быть действительным"
			},
			comment_text: {
                 required: "{{__('message.Write Something')}}",
            }
        }
    });

    jQuery.validator.addMethod("lettersonly", function(value, element) {
        return this.optional(element) || /^[a-zA-Z ]*$/.test(value);
    }, "Letters only please");

		  </script>
@endsection