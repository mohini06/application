<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<html xmlns="http://www.w3.org/1999/xhtml">

<head runat="server">

<title>Желтые страницы Казахстана | Бесплатные объявления ::</title>
<link rel="shortcut icon" href="Images/favicon.png" />
</head>
<body style="margin:0;">
<div>
<img src="coming-soon.png" style="width:100%;"/>

</div>

</body>
</html>
