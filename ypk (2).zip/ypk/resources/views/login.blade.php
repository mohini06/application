<!-- app/views/login.blade.php -->

           @section('content')
           <form method="post" action="/ypk/profile" role="form">
             <input type="hidden" name="_token" value="{{ csrf_token()}}">
                     <h3>Существующий пользователь</h3>
                     <hr color="red">
                         <div class="form-group">
                             <label>Введите имя пользователя или электронной почты</label>
                             <input type="text" class="form-control" name="UserId">
                         </div>
                         <div class="form-group">
                              <label>Пароль</label>
                              <input type="password" class="form-control" name="Password">
                         </div>
                         <div class="form-group">
                         <input type="submit" class="form-control btn-success" value="Логин">
                         </div>
                         <div class="form-group text-right">
                         <a href="/ypk/getemail">Забыли пароль?</a>
                       </div>
           </form>
           @endsection