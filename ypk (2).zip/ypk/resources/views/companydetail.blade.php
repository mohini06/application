@extends('layouts.app') 
    @section('title')
        {{$com->CompanyName}},{{$com->CityName}},{{$com->Address1}},{{$com->Address2}},{{$com->CategoryName}},{{$com->SubCategoryName}} - Доставка корреспонденции, доставка писем, доставка посылок
    @stop
    @section('description')
        Страница.{{$com->CompanyName}} Информация о компании: адрес, телефон, официальный сайт, электронная почта, фотографии, связаться с компанией, местоположение на карте
    @endsection
    @section('keywords')
        {{$com->CompanyName}},{{$com->CityName}},{{$com->Address1}},{{$com->Address2}}контакты, адрес электронной почты, сайт, Расположение на карте, фото, контакт с бизнесом.
    @endsection

@section('content')
<script type="text/javascript">
$(document).ready(function () {
         // Handler for .ready() called.
         $('html, body').animate({
             scrollTop: 560
         }, 2000); 
});  
   function lightbox(idx) {
            //show the slider's wrapper: this is required when the transitionType has been set to "slide" in the ninja-slider.js
            var ninjaSldr = document.getElementById("ninja-slider");
            ninjaSldr.parentNode.style.display = "block";

            nslider.init(idx);

            var fsBtn = document.getElementById("fsBtn");
            fsBtn.click();
        }

        function fsIconClick(isFullscreen, ninjaSldr) { //fsIconClick is the default event handler of the fullscreen button
            if (isFullscreen) {
                ninjaSldr.parentNode.style.display = "none";
            }
        }
</script>
<div class="row">

    <div class="col-md-9 top-slider">

        <div class="row">
            <div class="col-md-4">
                <h3 class="headerline">{{__('message.Findresultfor')}}  </h3>
            </div>
        </div>
        <div class="detail-wrapper">
        <div class="detail-wrapper-body">
      <div class="listing-title-bar">
          <div class="col-sm-8" style="padding:15px;">
                    <h3 class="classified_head_detail">{{$com->CompanyName}}</h3><br>
                    <span class="mrg-l-5 category-tag">{{$com->CategoryName}}/{{$com->SubCategoryName}}</span>
        <div>
                        
                               <p> <i class="ti-location-pin mrg-r-5 fa fa-map-marker address_icons"></i>{{$com->Address1}},{{$com->Address2}},{{$com->CityName}},{{$com->PostalCode}} <br>
                 <i class="fa fa-phone address_icons" aria-hidden="true"></i>
                 <?php if(  preg_match( '/^(7)(\d{3})(\d{7})$/',  $com->Phone,  $matches )  && strlen($com->Phone)==11 )
                        {
                            $result = '+' .$matches[1] . ' (' .$matches[2] . ') ' . $matches[3];
                            echo $result;
                        }else{
                        echo $com->Phone;
                            }   
              ?>
                                &nbsp; &nbsp; 
              <?php if(  preg_match( '/^(7)(\d{3})(\d{7})$/', $com->Mobile,  $matches )  && strlen($com->Mobile)==11 )
                        {
                            $result = '+' .$matches[1] . ' (' .$matches[2] . ') ' . $matches[3];
                            echo $result;
                        }else{
                        echo $com->Mobile;
                            }  
              ?><br>
            <?php  
                
                          $var = $com->WebsiteLink;
                          if($var!="")
              {
              if((strpos($var, 'https:') === 0)||(strpos($var, 'http:') === 0))
              {
                                $link= $var;
              }
              else 
              { 
                                $link= 'http://'.$var;
              } 
              }
              else
              {
                            $link="";
              }
                        
            ?>
              
            <a href="{{$link}}" class="listing-address" target="_blank">
            <i class="fa fa-globe address_icons" aria-hidden="true"></i>
            {{$link}}
            
            </p>
                        </a>
                        <?php
                          

                            $regtype=$com->ActualRegType; ?>
                          @if($regtype>2)
                         
                          <div class="rating-box">
                            <div class="detail-list-rating">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <a href="#" class="detail-rating-count">5 {{__('message.Rating')}}</a>
                        </div>
                    
                        @elseif($regtype>1) 
                           <div class="rating-box">
                            <div class="detail-list-rating">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-o"></i>
                            </div>
                            <a href="#" class="detail-rating-count">4 {{__('message.Rating')}}</a>
                        </div>
                      
                        @elseif($regtype>0)
                             <div class="rating-box">
                            <div class="detail-list-rating">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                            </div>
                            <a href="#" class="detail-rating-count">3 {{__('message.Rating')}}</a>
                           </div>
                    
          @else
               <div class="rating-box">
                            <div class="detail-list-rating">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                            </div>
                            <a href="#" class="detail-rating-count"> {{__('message.NoRating')}}</a>
                           </div>
          @endif
           
                        
                    
                </div>
            </div>
       <div class="col-md-4 ipad-responsive">
                        <!-- rami-->
            <?php 
                         $regtype=$com->ActualRegType;
             $countproductimage=count($productimage);
            $countproposal=count($proposal);
            
            ?>
            @if($regtype>2)
              
              @if($com->ImageUrl !="")
                  <img src="{{asset('public/ProductImages')}}/{{$com->ImageUrl}}" onerror="this.src='{{asset('public/ProductImages/no-image.png')}}'" class="search_image profile-image">
                 
                            @else 
                                 <img src="{{asset('public/ProductImages/no-image.png')}}" class="search_image profile-image">
               
                            @if (Auth::guest())
                <a href="#" onclick="document.getElementById('id01').style.display='block'" class="profileimagelink" style="width:auto;">{{ __('message.Upload ProfileImage') }}</a>                            

                @else
                  @if($com->UserRegId == Auth::user()->UserRegId )
                  <a href="{{url('/profile/')}}"  class="profileimagelink" style="width:auto;">{{ __('message.Upload ProfileImage') }}</a>  
                  @else 
                  <p class="para_detail_classified">{{__('message.Please login with a valid company user')}}</p>   
                    @endif           

                @endguest          
                  
              @endif   
               <img src="{{asset('public/Images/premium_ribbon.png')}}" class="detailribbon" >    
                @elseif($regtype>1)
                      @if($com->ImageUrl !="")
                  <img src="{{asset('public/ProductImages')}}/{{$com->ImageUrl}}" onerror="this.src='{{asset('public/ProductImages/no-image.png')}}'" class="search_image profile-image">
                 
                            @else 
                                 <img src="{{asset('public/ProductImages/no-image.png')}}" class="search_image profile-image">
                     @if (Auth::guest())
                <a href="#" onclick="document.getElementById('id01').style.display='block'" class="profileimagelink" style="width:auto;">{{ __('message.Upload ProfileImage') }}</a>                            

                @else
                  @if($com->UserRegId == Auth::user()->UserRegId )
                  <a href="{{url('/profile/')}}"  class="profileimagelink" style="width:auto;">{{ __('message.Upload ProfileImage') }}</a>  
                  @else 
                  <p class="para_detail_classified">{{__('message.Please login with a valid company user')}}</p>   
                    @endif           

                @endguest
              @endif
        <img src="{{asset('public/Images/gold_ribbon2.png')}}" alt="error" class="detailribbon" >
                 @elseif($regtype>0) 
              @if($com->ImageUrl !="")
                  <img src="{{asset('public/ProductImages')}}/{{$com->ImageUrl}}" onerror="this.src='{{asset('public/ProductImages/no-image.png')}}'" class="search_image profile-image">
                 
                            @else 
                                 <img src="{{asset('public/ProductImages/no-image.png')}}" class="search_image profile-image">
                     @if (Auth::guest())
                <a href="#" onclick="document.getElementById('id01').style.display='block'" class="profileimagelink" style="width:auto;">{{ __('message.Upload ProfileImage') }}</a>                            

                @else
                  @if($com->UserRegId == Auth::user()->UserRegId )
                  <a href="{{url('/profile/')}}"  class="profileimagelink" style="width:auto;">{{ __('message.Upload ProfileImage') }}</a>  
                  @else 
                  <p class="para_detail_classified">{{__('message.Please login with a valid company user')}}</p>   
                    @endif           

                @endguest
              @endif
        <img src="{{asset('public/Images/silver_ribbon.png')}}" alt="error" class="detailribbon">
                @else
         <img src="{{asset('public/ProductImages/no-image.png')}}" onerror="this.src='{{asset('public/ProductImages/no-image.png')}}'" class="search_image profile-image">
             @if (Auth::guest())
                <a href="#" onclick="document.getElementById('id01').style.display='block'" class="profileimagelink" style="width:auto;">{{ __('message.Upload ProfileImage') }}</a>                            

                @else
                  @if($com->UserRegId == Auth::user()->UserRegId )
                  <a href="{{url('/profile/')}}"  class="profileimagelink" style="width:auto;">{{ __('message.Upload ProfileImage') }}</a>  
                  @else 
                  <p class="para_detail_classified">{{__('message.Please login with a valid company user')}}</p>   
                    @endif           

                @endguest
        
                @endif
      </div>
      </div>
        </div>
</div>
        <div class="detail-wrapper">
            <div class="detail-wrapper-header">
                <h4 style="font-size: 20px; margin: 0px;">{{__('message.Overview')}}</h4>
            </div>
            <div class="detail-wrapper-body">
                <p class="para_detail_classified">{{$com->DescribeBusiness}} </p>
        @php  $claim=$com->ClaimFlag;
        @endphp
        @if($claim<1)
          <a href="#" onclick="document.getElementById('id06').style.display='block'" aria-hidden="true">
        <i class="fa fa-file-text-o" aria-hidden="true" style="font-size: 14px;"> </i>
        <p style="font-size: 15px; color:black; line-height: 1.8;">Ваша компания?</p>
        </a>
        @else
        @endif
            </div>
        </div>
        
         @if(($regtype>0)&&($countproductimage>0))
    <div class="detail-wrapper">
        <div class="detail-wrapper-header">
         <h4  style="font-size: 20px; margin: 0px;">{{__('message.Products')}}</h4>
        </div>
        <div class="detail-wrapper-body">
         <ul class="detail-check">
     <?php $p=0;?>
         @foreach ($productimage as $pi)
                    <li><img src="{{asset('public/ProductImages/')}}/{{$pi ->ImageUrl}}" class="product_images" onclick="lightbox(<?php echo $p++; ?>)" onerror="this.src='{{asset('public/images/no-image.png')}}'"></li>
                    {{--<li><img src="{{asset('public/ProductImages/')}}/{{$com->ImageUrl}}" onerror="this.src='{{asset('public/images/no-image.png')}}'"></li>--}}
                     
    @endforeach
          
          
         </ul>
                                       <div style="display:none;">
        <div id="ninja-slider">
            <div class="slider-inner">
                <ul class="detail-check">
         @foreach ($productimage as $pi)

                    <li><a class="ns-img" href="{{asset('public/ProductImages/')}}/{{$pi ->ImageUrl}}"></a></li>
                     
    @endforeach
                    
                </ul>
                <div id="fsBtn" class="fs-icon" title="Expand/Close"></div>
            </div>
        </div>


    </div>
        </div>
       </div>
     @else
        <div class="detail-wrapper">
        <div class="detail-wrapper-header">
         <h4  style="font-size: 20px; margin: 0px;">{{__('message.Products')}}</h4>
        </div>
        <div class="detail-wrapper-body">
           @if (Auth::guest())
      <a href="#" onclick="document.getElementById('id01').style.display='block'" class="noitmesavailable" style="width:auto;">{{ __('message.Upload Product Images') }}</a>                            

      @else
        @if($com->UserRegId == Auth::user()->UserRegId )
         <a href="{{url('/profile/')}}"  class="noitmesavailable" style="width:auto;">{{ __('message.Upload Product Images') }}</a>  
               @else 
        <p class="para_detail_classified">{{__('message.Please login with a valid company user')}}</p>   
               @endif          

      @endguest
        
    </div>
       </div>

    @endif
   
        <div class="detail-wrapper">
            <div class="detail-wrapper-header">
                <h4 style="font-size: 20px; margin: 0px;">{{__('message.CompanyProposals')}}</h4>
            </div>
            <div class="detail-wrapper-body">
                  @if($countproposal>0)
                <ul class="detail-check">
                      @foreach ($proposal as $posal)
                         {{--<li><img src="{{asset('public/ProductImages/')}}/{{$posal->ProposalUrl}}" style="height: 100px; width:100px;" onerror="this.src='{{asset('public/images/no-image.png')}}'"></li>--}}

                        <li><a class="dropdown-item" href="{{asset('public/Proposals/')}}/{{$posal ->ProposalUrl}}" download><i class="fa fa-download" aria-hidden="true"></i>
                        <span> {{$posal ->ProposalUrl}}</span>
                        </a></li>
                     @endforeach

                </ul>
                @else
                  @if (Auth::guest())
            <a href="#" onclick="document.getElementById('id01').style.display='block'" class="noitmesavailable" style="width:auto;">{{ __('message.Upload Proposals') }}</a>                            

              @else
              @if($com->UserRegId == Auth::user()->UserRegId )
               <a href="{{url('/profile/')}}"  class="noitmesavailable" style="width:auto;">{{ __('message.Upload Proposals') }}</a>  
                    @else 
           <p class="para_detail_classified">{{__('message.Please login with a valid company user')}}</p>   
                    @endif           

             @endguest               
       
             @endif
            </div>
        </div>

        @if($com->ActualRegType==0)
            <div class="detail-wrapper">
                <div class="detail-wrapper-header">
                    <h4  style="font-size: 20px; margin: 0px;">{{__('message.new_customers')}}</h4>
                </div>
        
                <div class="detail-wrapper-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h4>{{$new_company->CompanyName}}</h4>
                            <p>{{$new_company->DescribeBusiness}}</p>
                        </div>
                        <div class="col-md-6">
                            <h4>{{$new_classified->ClassifiedTitle}}</h4>
                            <p>{{$new_classified->ClassifiedContent}}</p>   
                        </div>
                    </div>    
                </div>
            </div>
        @endif

        <div class="detail-wrapper">
            <div class="detail-wrapper-header">
                <h4 style="font-size: 20px; margin: 0px;">{{__('message.Location')}}</h4>
            </div>
            <div class="detail-wrapper-body">
               
        <iframe src="https://maps.google.it/maps?q={{$com->Address1}},{{$com->Address2}},{{$com->CityName}},{{$com->PostalCode}}&output=embed"width="100%" height="100%" frameborder="0" style="border:1px solid #ffff00" allowfullscreen></iframe>
            </div>
        </div>
    @if (Auth::guest())
    @php  
         $name="";
       $email="";
       $phone="";  
     @endphp
    @else 
      @php  
         $name=Auth::user()->Name;
         $email=Auth::user()->Email;
         $phone=Auth::user()->Phone;  
      @endphp
    @endguest
           <form method="post" id="reviewform" action="{{url('/reviewadd')}}/{{$com->CompanyRegId}}" role="form" enctype="multipart/form-data">
     <input type="hidden" name="_token" value="{{ csrf_token()}}">
        <div class="detail-wrapper">
    
            <div class="detail-wrapper-header">
                 <h4 style="font-size: 20px; margin: 0px;">{{__('message.Rate')}}</h4>
                 <p style="font-size: 15px; color: #677782; line-height: 1.8;">{{__('message.writetous')}} </p>
            </div>

            <div class="detail-wrapper-body">
          
           
                <div class="row" style="padding-bottom: 10px;">
                    <div class="col-md-6 user-input-wrp">
                        <br/>
                        <input type="text" name="CommentedPerson" id="CommentedPerson"  value="{{$name}}" class="inputText" style="background-color:white;" />
                        <span class="floating-label">{{__('message.Contact Name')}} <span style="color:red;">*</span></span>
                    </div>
                    <div class="col-md-6 user-input-wrp">
                        <br/>
                        <input type="text" class="inputText" id="CommentedPersonEmail" value="{{$email}}" name="CommentedPersonEmail" style="background-color:white;" />
                        <span class="floating-label">{{__('message.Email Address')}}<span style="color:red;">*</span></span>
                    </div>

                </div>
                <div class="row" style="padding-bottom: 10px;">
                    <div class=" col-md-6 user-input-wrp">
                        <br/>
                        <input type="text"name="CommentedPersonPhoneNo" value="{{$phone}}"id="CommentedPersonPhoneNo"class="inputText phonemask"style="background-color:white;" />

                        <span class="floating-label">{{__('message.Phonenumber')}}<span style="font-size: 11px;">{{__('message.Addprefix')}}</span><span style="color:red;"> *</span></span>

                    </div>
                    
                       <div class="col-sm-offset-1 col-sm-4">
                       
                         <div class="reviewer_proposal" >
                  @if (Auth::guest())
                        
                                  <p>{{__('message.Please_login_upload_proposal')}}</p>
                                  <input type="button" name="" value="{{__('message.login')}}" onclick="document.getElementById('id01').style.display='block'" class="btn-grad reviewer_proposal_button">
                        @else
                         <?php 
                         if($companylist!="")
                         {


                                  if($companylist->ActualRegType>0)
                                  {
                                    ?>
                                    <input type="file" id="Proposalforu" accept="application/msword,text/plain, application/pdf" name="Proposalforu" style="display: none;">

                                       <a class="uploadproposal" id="falseinput">{{__('message.Upload')}}</a><br/>
                                       <span id="selected_filename" class="reviewer_proposal_inside d-block mt-3">{{__('message.Share Your Proposals')}}</span>
                                   <?php   
                                    }
                                   else 
                                   {

                                      // $date=date('Y-m-d',strtotime($companylist->DateOfReg));
                                       $dateofreg_plus_3= strtotime(date('Y-m-d', strtotime($companylist->DateOfReg. ' + 3 months')));
                                       if($dateofreg_plus_3>=strtotime(date('Y-m-d')))
                                  {
                                    ?>
                                       <input type="file" id="Proposalforu" accept="application/msword,text/plain, application/pdf" name="Proposalforu" style="display: none;">

                                       <a class="uploadproposal" id="falseinput">{{__('message.Upload')}}</a><br>
                                       <span id="selected_filename" class="reviewer_proposal_inside d-block mt-3">{{__('message.Share Your Proposals')}}</span>
                                       <?php
                                   }
                                        else {?>
                                    
                                      <p>{{__('message.Please_become_a_paid_member_to_upload_proposal_for_this_company')}}</p>   

                                  <?php  }
                                   
                                  }

                            }
                            else 
                            { ?>
                                  <p>{{__('message.Please_login_as_a_company_user_to_upload_your_proposal_for_this_company')}}</p>
                             <?php
                             }?> 
                                         
                       @endguest
                      </div>

                     </div>
                </div>
                
                <div class="row" style="padding-bottom: 10px;padding-top: 5px;">
                     <div class="col-md-6 col-sm-12">
              <span class="headline" style="margin-left: 4px;margin-top: 0px;position: absolute;font-weight: 600;font-size: 15px;">{{__('message.YourMessage')}}<span style="color:red;"> *</span></span><br>
              <textarea placeholder="{{__('message.This is an awesome comment box')}}" rows="20" name="ReviewMessage" id="ReviewMessage" cols="40" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true"></textarea>
           </div>
           <div class="col-md-6  col-sm-12">
                         
                     </div>
                </div>
                <div class="row">
                    <div class="col-sm-6"style="float:right;padding-top: 20px;padding-left: 15px;">

                        <input type="submit" class="btn-grad" value="{{__('message.Send')}}" onclick="validate_file2()" style=" height:40px; width:100px;" />
                        <input type="reset" class="btn-grad" value="{{__('message.cancel')}}" style=" height:40px; width:100px;" />
                    </div>
           <div class="col-sm-6"></div>
                </div>
      
            </div>
            
        </div>
</form>
    </div>

    <div class="col-md-3" style="padding-left: 5px;padding-right: 5px;">
         @include('classifieds_slide')
    </div>
</div>
@if (!Auth::guest())
    @if($com->UserRegId == Auth::user()->UserRegId )
    <div class="row">
    <div class="col-md-9">
        <div class="detail-wrapper">
            <div class="detail-wrapper-header">
                <h4 style="font-size: 20px; margin: 0px;">{{__('message.Number_of_visitors')}}</h4>
            </div>
            <div class="detail-wrapper-body">
                <div class="row">
                    <div class="col-md-4 col-sm-12"><p>{{__('message.Last_week')}} : #{{$visitors_count->p_lastWeek}}</p></div>
                    <div class="col-md-4 col-sm-12"><p>{{__('message.Last_Month')}} : #{{$visitors_count->p_lastMonth}}</p></div>
                    <div class="col-md-4 col-sm-12"><p>{{__('message.Current_Month')}} : #{{$visitors_count->p_thisMonth}}</p> </div>
                </div>        
            </div>
        </div>                       
    </div>
    </div>
    @endif          
@endif

<div id="id06" class="modal overflow-modal" ><!--rami-->
  
  <form method="POST" class="modal-content download-body claim-modal" action="{{url('/claim_file')}}" id="claimForm"  role="form" style="overflow-y:auto;overflow-x:hidden;">
  <input type="hidden" name="_token" value="{{ csrf_token()}}"> 
  <input type="hidden" name="old_email" value="{{$com->Email}}">
  <input type="hidden" id="companyreid" name="companyreid" value="{{$com->CompanyRegId}}">
    <div class="title-head-modal" style="background-color:#ffce00;height:50px;">
    <span onclick="document.getElementById('id06').style.display='none'" class="download-close" title="Close Modal">&times;</span>
    <h4 class="modal-title" style="padding:10px;text-align: center;">Заявить, что это ваша компания</h4>
  </div>
     <div class="container">
     <div class="row">
      <h4 class="modal-title" style="padding:15px;text-align:left;">ИНСТРУКЦИИ</h4><hr>
    <p class="para_detail_classified" style="padding:0px 15px;">Эта компания зарегистрированна под Email:<a href="#"style="color:blue;">{{$com->Email}}</a> если вы владелец этой компании, зайдите в логин, нажмите ссылку "Забыли пароль", указав зарегистрированный в контактах Email, и вам на эту почту будет сброшена ссылка для обновления пароля.</p>
       </p>
   
     <p class="para_detail_classified"  style="padding:0px 15px;">Если указанный здесь, ваш Email не верный, заполните форму ниже и мы свяжемся с вами в ближайшее время.
     </p>
     </div>
     
  <!--  <form method="POST" id="claimForm" action="{{url('/claim_file')}}" role="form">
    <input type="hidden" name="_token" value="{{ csrf_token()}}">-->
     <div class="row">
     <div class="col-md-6 user-input-wrp">
        <br/>
      <input type="text" class="inputText" id="email_id" name="email_id"/>
      <span class="floating-label">{{__('message.Email Address')}} <span style="color:red;">*</span></span>
      
     </div>
      <div class="col-md-6 user-input-wrp">
      <br/>
      <input type="text" id="phonenumber" name="phonenumber"class="inputText phonemask" />
      <span class="floating-label">{{__('message.Phonenumber')}}<span style="font-size: 11px;">{{__('message.Addprefix')}}</span><span style="color:red;">*</span></span>
    </div>
     </div>
     <div class="row">
      <div class=" col-md-6 user-input-wrp">
                            <br/>
                            <span class="headline" style="margin-left: 4px;margin-top: 4px; position: absolute;">{{__('message.Comments')}}<span style="color:red;">*</span></span>
                             <textarea placeholder="{{__('message.This is an awesome comment box')}}" rows="10" id="comment" name="comment"  cols="80" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true" style="resize:none !important; padding-bottom:10px;"></textarea>
          
            </div>
            
    </div>
     </div>
        <div class="row">
    
    <div class="col-sm-12 user-input-wrp">
     <div style="float:right;padding-right:20px;">
     <input type="submit" class="btn-grad" id="test" value="{{__('message.Send')}}" style=" margin-left:0px; height:40px; width:120px;" />
    <input type="button" class="btn-grad" onclick="document.getElementById('id06').style.display='none'" value="{{__('message.cancel')}}" style=" height:40px; width:120px;"/>
     </div>
    </div>
     </div>
    <!--   </form>-->
   </div>
  </form>
</div>
<script type="text/javascript">
  $("#reviewform").validate({
     
        rules: {
            CommentedPerson: {
                required: true,
                lettersonly: true
            },
            CommentedPersonEmail: {
                required: true,
                email: true,
                email_exists: false
            },
            CommentedPersonPhoneNo: {
                required: true,
                validecode: true, 
            },
        ReviewMessage: {
                required: true,
                maxlength: 500
            }
        },
        messages: {
                CommentedPerson: {
                required: "{{__('message.Please Enter your name')}}",
                lettersonly: "{{__('message.Please Enter only character') }}"
            },
            CommentedPersonEmail: {
                required: "{{__('message.Please Enter your email aadress')}}",
                email: "{{__('message.Please Enter valid email')}}",
                email_exists: "{{__('message.Email already exist')}}"

            },
            CommentedPersonPhoneNo: {
                required: "{{__('message.please enter mobile number')}}",
                validecode: "{{__('message.country code should be valid')}}"
            },
      ReviewMessage: {
                required: "{{__('message.Write Something')}}",
                maxlength: "{{__('message.Maximum 500 characters')}}"
            }
        }
    });

    jQuery.validator.addMethod("lettersonly", function(value, element) {
        return this.optional(element) || /^[a-zA-Z ]*$/.test(value);
    }, "Letters only please");

</script>
@endsection