<?php
echo 'hi';
require("db2.php");
$id = $_GET['ID'];
$query = "SELECT * FROM subcategory WHERE CategoryId=$id";
$getd = mysql_query($query);
while ($result = mysql_fetch_array($getd)) {
    echo '<a class="btnCategory" href="getdata.php?id=' . $result['SubCategoryId'] . '">' .$result['SubCategoryName'] . '</a></p>';
}
?>