@extends('layouts.app')
@section('content')
<form method="post" action="{{url('/forgotpassword')}}" role="form">
  <input type="hidden" name="_token" value="{{ csrf_token()}}">
          <h3>Get Forgot Password</h3>
          <hr color="red">
              <div class="form-group">
                  <label>Enter your Registered Email</label>
                  <input type="email" class="form-control" name="email">
              </div>

              <div class="form-group">
              <input type="submit" class="form-control btn-success " value="submit">
              </div>

</form>
@endsection