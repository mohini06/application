@extends('layouts.app')
@section('content')
<script>
$(document).ready(function () {
         // Handler for .ready() called.
         $('html, body').animate({
             scrollTop: 560
         }, 2000); 
  }); 
</script>
<div class="row">
                       <!--rami-->
   <div class="col-md-9" style="padding-left: 0px;padding-right: 0px;">
       <div class="col-md-6">
           <h3 class="headerline ">{{__('message.Publish Your Add')}}  </h3></div>
       <div class="col-md-3">

       </div>
       <div class="col-md-3">
           <a href="{{url('/classifiedhelp')}}" target="_blank">
               <h3 class="headerline" style="background-color: #ffce00; color: white; font-size: 18px; width: 30px; text-align: center;  padding: 5px; border-radius: 19px;  margin-bottom: 10px; float: right;"> <i class="fa fa-info" aria-hidden="true"></i></h3></a>
       </div>
   </div>
   <div class="col-md-3">
   </div>

</div>
<!--rami-->
<div class="col-md-12 no-padding">
   <div class="content-section">

       <div class="row">

           <div class="col-md-9" style=" background: #ffffff;padding: 15px 20px;">
              <form  method="POST" action="{{url('storeclassified')}}" id="registerForm" role="form">
               <input type="hidden" name="_token" value="{{ csrf_token()}}">
               <br>
               <h4 style="font-weight: 400;">{{__('message.headings')}} </h4>
               <br>

               <div class="row" style="padding-bottom: 10px;">
                   <div class="col-md-4 user-input-wrp">
                       <br/>
                       <input type="text" id="ClassifiedTitle" name="ClassifiedTitle" class="inputText" required/>
                       <span class="floating-label">{{__('message.Add Title')}} <span style="color:red;">*</span></span>
                   </div>
                   <div class="col-md-4 user-input-wrp">
                       <br/>
                       <select class="category" id="category" name="category">
                           <option value="">{{__('message.Select one Category')}}</option>
                          @foreach($category as $categories)
                           <option value="{{$categories->CategoryId}}">{{$categories->CategoryName}}</option>
                          @endforeach
                       </select>
					   <span class="floating-label" id="categoryname">{{__('message.Select one Category')}}<span style="color:red;"> * </span></span>
                   </div>
                   <div class="col-md-4 user-input-wrp">
                       <br/>
                       <select class="category" id="subcategory" name="subcategory">

                       </select>
					    <span class="floating-label" id="subcategoryname">{{__('message.Select subcategory')}}<span style="color:red;"> * </span></span>
                   </div>
               </div>
               <div class="row" style="padding-bottom: 10px;">
                   <div class="col-md-4 user-input-wrp">
                       <br/>
                       <span class="floating-label-edit">{{__('message.Email Address')}}</span>
                       <input type="text" class="inputText" value="{{$user->Email}}" readonly />
                       {{--<input type="text" class="inputText" id="email" name="email" value="{{$user->Email}}" readonly/>--}}
                       {{--<span class="floating-label"> <span style="color:red;">*</span></span>--}}

                   </div>
                   <div class=" col-md-4 user-input-wrp">
                       <br/>
                       <input type="text" class="inputText" id="name"  value="{{$user->Name}}"name="name" readonly/>
                       <span class="floating-label">{{__('message.Your name')}}<span style="color:red;">*</span></span>
                   </div>
                   <div class="col-md-4 user-input-wrp">
                       <br/>
                       <select class="category"  id="city" name="city">
                           <option  value="">{{__('message.Select City')}} </option>
                         @foreach($city as $cities)
                           <option value="{{$cities->CityId}}">{{$cities->CityName}}</option>
                         @endforeach
                       </select>
				   <span class="floating-label" id="cityname">{{__('message.Select City')}} <span style="color:red;"> * </span></span>
					   
                   </div>
               </div>
               <div class="row" style="padding-bottom: 10px;">
                   <div class=" col-md-4 user-input-wrp">
                       <br/>
                       <input type="text" id="mobile" name="mobile"  value="<?php if($user->Mobile!="")
                       {
                         if(preg_match( '/^(7)(\d{3})(\d{7})$/',  $user->Mobile,  $matches )  && strlen($user->Mobile)==11)
                        {
                            $result = '+' .$matches[1] . ' (' .$matches[2] . ') ' . $matches[3];
                            echo $result;
                        }else{
                        echo $user->Mobile;
                            }   
                       }
                       else {
                         echo "";
                       }
                      
							?>" class="inputText phonemask"/>

                       <span class="floating-label">{{__('message.Mobile number')}} <span style="font-size: 11px;">{{__('message.Add prefix +7')}}  </span></span>

                   </div>
                   <div class=" col-md-4 user-input-wrp">
                       <br/>
                       <input type="text" class="inputText" name="Weburl"  id="url"/>
                       <span class="floating-label">{{__('message.Your site')}}<span style="font-size: 11px;">{{__('message.Startwithhttp')}} </span></span>

                   </div>

                   <div class=" col-md-4 user-input-wrp">
                       <br/>
                       <input type="text" id="phone" name="phone" class="inputText phonemask"  value="<?php if(  preg_match( '/^(7)(\d{3})(\d{7})$/',  $user->Phone,  $matches )  && strlen($user->Phone)==11 )
                        {
                            $result = '+' .$matches[1] . ' (' .$matches[2] . ') ' . $matches[3];
                            echo $result;
                        }else{
                        echo $user->Phone;
                            }   
							?> "  />

                       <span class="floating-label">{{__('message.Phone number')}} <span style="font-size: 11px;">{{__('message.Add prefix +7 & area code')}} </span><span style="color:red;"> *</span></span>

                   </div>

               </div>
               <div class="row">
                   <div class=" col-md-4 user-input-wrp">
                       <br/>
                       <input type="text" class="inputText date" name="dateofincorporation"id="dateofincorporation" />
                       <span class="floating-label"> {{__('message.Date of Incorporation')}}<span style="color:red;">*</span></span>
                   </div>
                   <div class=" col-md-8 user-input-wrp">
                       <br/>
                       <span class="headline" style="margin-left: 4px;margin-top: 4x;position: absolute;">{{__('message.Advertisement')}}<span style="color:red;">*</span></span>
                       <textarea placeholder="{{__('message.This is an awesome comment box')}}" rows="20" name="ClassifiedContent" id="ClassifiedContent" cols="40" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true"></textarea>
                       <div id="charNum">{{__('message.500 characters left')}}</div>
                        <i>{{__('message.(HTML links are not allowed.) Do not use ALL CAPITAL LETTERS)')}}</i>

                       <h5 style="text-align: justify;width:50%; margin-top: 6px;">({{__('message.Use keywords to more easily search your company for your activity, the products and services offered')}})</h5>
                   </div>
               </div>

               <div class="row">
                   <div style="float:right;padding-top: 20px;padding-left: 15px;">
                       <a href="{{url('/')}}"><input type="button" class="btn-grad" value="{{__('message.cancel')}}"" style=" height:40px; width:100px;" /></a>
                       <input type="submit" class="btn-grad" value="{{__('message.Send')}}" style=" height:40px; width:100px;" />
                   </div>
               </div>
               </form>
           </div>
           <div class="col-md-3 mobile-padding">
               <!--rami-->
               <div style="background: #fff;">
                   <center>
                       <div class="post" style="padding:15px 20px;">
                            <h4>{{__('message.Post free classifieds')}}</h4>
                            <img src="{{asset('/public/Images/guarantee.png')}}" class="img-responsive guarantee" alt="guarantee" />
                            <p style="text-align: justify;">{{__('message.guarenteedescription')}} </p>

                        </div>
                   </center>
               </div>
           </div>
       </div>
   </div>
</div>

     <script type="text/javascript">
       var email_exists = false;
         $(document).ready(function() {
             $('#email').on('blur', function() {
                 var emailID = $("#email").val();

                 if (emailID) {
                     $.ajax({
                         dataType: 'text',

                         type: 'POST',
                         url: 'resources/views/checkemail.php',
                         //url:'app/Http/Controllers/DynamicController@index2',
                         data: 'email_id=' + emailID,

                         success: function(html) {

                             if (html == "Email Id Already Exists") {

                                 email_exists = true;

                             }
     //                        console.log(html);

                             $('#errormessage').html(html);
                         },
                         error: function(e) {
                             $('#errormessage').html(e);
                         }
                     });
                 }
             });

         });
 $("#registerForm").validate( {

    rules: {
        ClassifiedTitle: {
                  required: true
			           
        } ,
         email: {
                  required:true,
                  email:true
            }    , 
        name: {
                required: true,
					      lettersonly: true
                }
                , mobile: {
                   
					
					validecode: true,
					
                },
				phone:{
					 required: true, 
					validecode: true, 
				},

         category: {
                    required: true
                }
                , 
        subcategory: {
                    required: true
                }, 

                city: {
                 
                    required: true
                },
				dateofincorporation: {
				required : true
			    },
				ClassifiedContent:{
					required: true,
                minlength: 30,
                maxlength: 500
				}
            },

             messages: {
                ClassifiedTitle: {
                    required: "{{__('message.Please Enter the classified title')}} "
					
                }
                , category: {
					 required: "{{__('message.Please select one category')}}"
                }
                
                , email: {
                    required: "{{__('message.Please Enter your email aadress')}}",
                email: "{{__('message.Please Enter valid email')}}",
                }
                , name: {
                    required: "{{__('message.Please Enter your name')}}",
                lettersonly: "{{__('message.Please Enter only character') }}"
                }
                , mobile: {
                   
               	validecode: "{{__('message.country code should be valid')}}"
                },
				phone:{
				required: "{{__('message.please enter mobile number')}}",
				validecode: "{{__('message.country code should be valid')}}"
				}

                , category: {
                    required: "{{__('message.Please select one category')}}"
                }
                , subcategory: {
                    required: "{{__('message.please select one subcategory after category')}}"
                }
                , city: {
                    required: "{{__('message.Please select one city')}}"
                },
				dateofincorporation: {
				required : "{{__('message.Pleaseselectdateofincorporation')}}"
			    },
				ClassifiedContent:{
					required: "{{__('message.Write Something')}}",
                minlength: "{{__('message.Minimum 30 characters required')}}",
                maxlength: "{{__('message.Maximum 500 characters')}}"
				}

        }
	 });
		   jQuery.validator.addMethod("lettersonly", function(value, element) {
        return this.optional(element) || /^[a-zA-Z ]*$/.test(value);
    }, "Letters only please");
	
	 jQuery.validator.addMethod("validecode", function(value, element) {
        return this.optional(element) || /^[7]\d{9}$/.test(value);
    }, "Valid Country Code");
         </script>
       {{--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>--}}
       <!-- Include all compiled plugins (below), or include individual files as needed -->
       {{--<script src="{{ asset('js/bootstrap.min.js')}}"></script>--}}
<script>
$('#ClassifiedContent').keyup(function () {
  var max = 500;
  var len = $(this).val().length;
  if (len >= max) {
    $('#charNum').text(' you have reached the limit');
  } else {
    var char = max - len;
    $('#charNum').text(char + ' {{__('message.characters left')}}');
  }
});

    $(document).ready(function(){
        $('#category').on('change',function(){
            var categoryID = $(this).val();


            if(categoryID){
                $.ajax({
                    dataType: 'text',

                     type:'POST',
                     url:'../resources/views/queryforsubcategory.php',
                      //url:'app/Http/Controllers/DynamicController@index2',
                     data:'category_id='+categoryID,

                     success:function(html){
                     console.log(html);

                     $('#subcategory').html(html);
                     },
                     error:function(e){
                     $('#subcategory').html(e);
                     }
               });
            }
        });


    });
</script>
@endsection


{{--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>--}}
{{--<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>--}}
{{--<script src="http://jquery.bassistance.de/validate/additional-methods.js"></script>--}}


  {{--<script type="text/javascript" src="{{ URL::asset('js/ypk.js') }}"></script>--}}


  {{--{!! Form::open(['action'=>'ClassifiedController@store','method'=>'POST','files'=>true]) !!}--}}
  {{--<div class="form-group">--}}
   {{--{{form::label('ClassifiedTitle','Ad title')}}--}}
   {{--{{form::text('ClassifiedTitle','',['class'=>'form-control','id'=>'title'])}}--}}

  {{--</div>--}}
   {{--<div class="form-group">--}}
    {{--{{form::label('category','Select Your category')}}--}}
    {{--{!!form::select('category',$category,null,['class'=>'form-control'] )!!}--}}
    {{--</div>--}}
    {{--<div class="form-group">--}}
        {{--{{form::label('subcategory','Select Sub-category')}}--}}
      {{--{!! form::select('subcategory', $subcategory, null,['class'=>'form-control'] ) !!}--}}
        {{--</div>--}}
  {{--<div class="form-group">--}}
     {{--{{form::label('email','Email')}}--}}
     {{--{{form::text('email','',['class'=>'form-control'])}}--}}
    {{--</div>--}}
   {{--<div class="form-group">--}}
      {{--{{form::label('name','YourName')}}--}}
      {{--{{form::text('name','',['class'=>'form-control'])}}--}}
     {{--</div>--}}
     {{--<div class="form-group">--}}
            {{--{{form::label('city','City')}}--}}
            {{--{{form::select('city',$city,null,['class'=>'form-control'])}}--}}
      {{--</div>--}}
    {{--<div class="form-group">--}}
       {{--{{form::label('Mobile','Mobile Number')}}--}}
       {{--{{form::text('Mobile','',['class'=>'form-control'])}}--}}
      {{--</div>--}}
   {{--<div class="form-group">--}}
      {{--{{form::label('phone','Phone number')}}--}}
      {{--{{form::text('phone','',['class'=>'form-control'])}}--}}
     {{--</div>--}}

   {{--<div class="form-group">--}}
         {{--{{form::label('ClassifiedContent','Advertisement')}}--}}
         {{--{{form::textarea('ClassifiedContent','',['class'=>'form-control'])}}--}}
        {{--</div>--}}
   {{--<div class="form-group">--}}
         {{--{{form::label('Weburl','Your Site')}}--}}
         {{--{{form::text('Weburl','',['class'=>'form-control'])}}--}}
        {{--</div>--}}


   {{--{{Form::submit('Submit',['class'=>'btn btn-primary'],['class'=>'form-control'])}}--}}
  {{--{!! Form::close() !!}--}}


{{--<script type="text/javascript">--}}
    {{--$('#category').change(function(){--}}
    {{--var categoryID = $(this).val();--}}
    {{--if(categoryID){--}}
        {{--$.ajax({--}}
           {{--type:"GET",--}}
           {{--url:"{{url('api/get-subcategory-list')}}?CategoryId="+categoryID,--}}
           {{--success:function(res){--}}
            {{--if(res){--}}
                {{--$("#subcategory").empty();--}}
                {{--$("#subcategory").append('<option>Select</option>');--}}
                {{--$.each(res,function(key,value){--}}
                    {{--$("#subcategory").append('<option value="'+key+'">'+value+'</option>');--}}
                {{--});--}}

            {{--}else{--}}
               {{--$("#subcategory").empty();--}}
            {{--}--}}
           {{--}--}}
        {{--});--}}
    {{--}else{--}}
        {{--$("#subcategory").empty();--}}

    {{--}--}}
   {{--});--}}