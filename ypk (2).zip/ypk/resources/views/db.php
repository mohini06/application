<?php
$db = new PDO('mysql:charset=utf8mb4; host=94.247.135.2; dbname=yellowpageskz', "ypksite", "l&&ph]7C$=5u;{W");
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
?>