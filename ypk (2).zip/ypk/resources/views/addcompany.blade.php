 
 @extends('layouts.app')
 @section('content')
     <script>
$(document).ready(function () {
         // Handler for .ready() called.
         $('html, body').animate({
             scrollTop: 560
         }, 2000);
     }); </script>
<div class="clearfix"></div>
<div class="row">
    <div class="col-md-9" style="padding-left: 0px;padding-right: 0px;">
        <div class="col-md-4">
            <h3 class="headerline"> {{__('message.Add your listing')}} </h3>
        </div>
        <div class="col-md-5">
        </div>
        <div class="col-md-3">
            <a href="{{url('/companyhelp')}}" target="_blank">
                <h3 class="headerline" style="background-color: #ffce00; color: white; font-size: 18px; width: 30px; text-align: center;  padding: 5px; border-radius: 19px;  margin-bottom: 10px; float: right;">
        	        <i class="fa fa-info" aria-hidden="true"></i>
                </h3>
            </a>
        </div>
    </div>
    <div class="col-md-3"></div>
</div>
<!--rami-->
<div class="col-md-12 no-padding">
    <div class="content-section">
        <div class="row">
            <div class="col-md-9" style=" background: #ffffff; padding: 15px 20px;">
                <form method="POST" id="registerForm" action="{{url('/storecompany')}}" role="form">
                    <input type="hidden" name="_token" value="{{ csrf_token()}}">
                    <div class="row" style="padding-bottom: 10px;">
                        <div class="col-md-4 user-input-wrp">
                            <br/>
                            <input type="text" class="inputText" id="CompanyName" name="CompanyName"/>
                            <span class="floating-label">{{__('message.Company Name')}} <span style="color:red;">*</span></span>
                        </div>
                        <div class="col-md-4  user-input-wrp">
                            <br/>
                            <input type="text" class="inputText" id="ContactName" name="ContactName"/>
                            <span class="floating-label">{{__('message.Contact Name')}} <span style="color:red;">*</span></span>
                        </div>
                        <div class=" col-md-4 user-input-wrp">
                            <br/>
                           <span class="floating-label-edit">{{__('message.Email Address')}}<span style="color:red;">*</span> </span>
                           <input type="text" class="inputText"  id="Email" name= "Email" value="{{$user->Email}}" />
                        </div>
                    </div>
                    <div class="row" style="padding-bottom: 10px;">
                        <div class="col-md-4 user-input-wrp">
                            <br/>
							<span class="floating-label-edit">{{__('message.Enter your username')}}<span style="color:red;">*</span></span>
                            <input type="text" class="inputText" id="UserName" name="UserName" value="{{$user->UserId}}" readonly />
							<label id="errormessage2"></label>
                        </div>
                        <div class="col-md-4 ">
                            <input type="button" id="checkuser" class="btn-grad" value="{{__('message.Check Availability')}}" style=" height:40px; width:184px;" />
                        </div>
                        <div class=" col-md-4 user-input-wrp">
                            <br/>
                            <input type="text" class="inputText" id="PostalCode" name="PostalCode"/>
                            <span class="floating-label">{{__('message.Postcode')}}<span style="color:red;">*</span></span>
                        </div>
                    </div>
                    <div class="row" style="padding-bottom: 10px;">
                        <div class="col-md-4 user-input-wrp">
                            <br/>
                            <span class="floating-label-edit">{{__('message.Password')}} <span style="color:red;">*</span></span>
							<input type="password" class="inputText"  id="password" name="password" value="{{$user->Password}}" readonly />
                        </div>
						
                        <div class="col-md-4  user-input-wrp">
                            <br/>
							<span class="floating-label-edit">{{__('message.Enter the password again')}}<span style="color:red;">*</span></span>
                            <input type="password" class="inputText" id="Confirmpassword" name="Confirmpassword" value="{{$user->Password}}" readonly />
                            
                        </div>
						 <div class="col-md-4 user-input-wrp">
                            <br/>
                            <input type="text" id="Address1" name="Address1" class="inputText" />
                            <span class="floating-label">{{__('message.Street Address')}}<span style="color:red;">*</span></span>
                        </div>
                        
                    </div>
                    <div class="row" style="padding-bottom: 10px;">
						<div class=" col-md-6 user-input-wrp">
                            <br/>
                            <input type="text" id="phone" name="phone" class="inputText phonemask "  />
                            <span class="floating-label">{{__('message.Phonenumber')}}
                                <span style="font-size: 11px;">{{__('message.Addprefix')}}</span>
                                <span style="color:red;">*</span>
                            </span>
                        </div>
                        <div class=" col-md-6 user-input-wrp">
                            <br/>
                            <input type="text" id="mobile" name="mobile" class="inputText2 phonemask"/>
                            <span class="floating-label">{{__('message.Mobilenumber')}}
                                <span style="font-size: 11px;">{{__('message.Addprefix')}} </span>
                            </span>
                        </div>
                    </div>
                    <div class="row" style="padding-bottom: 10px;">
					 <div class="col-md-4  user-input-wrp">
                            <br/>
                            <input type="text" class="inputText" id="Address2" name="Address2" required/>
                            <span class="floating-label">{{__('message.Building / office number')}} <span style="color:red;">*</span></span>
                        </div>
                        <div class="col-md-4 user-input-wrp">
                            <br/>
                            <select class="category" id="category" name="category">
                               <option value=""></option>
							   @foreach($category as $categories)
                                   <option value="{{$categories->CategoryId}}">{{$categories->CategoryName}}</option>
                                @endforeach
                            </select>
							 <span class="floating-label" id="categoryname">{{__('message.Select your category')}}<span style="color:red;"> * </span></span>
                        </div>
                        <div class="col-md-4  user-input-wrp">
                            <br/>
                            <select class="category" id="subcategory" name="subcategory">
                            </select>
							<span class="floating-label" id="subcategoryname">{{__('message.Select subcategory')}}<span style="color:red;"> * </span></span>
                        </div>
                        
                    </div>
                    <div class="row" style="padding-bottom: 10px;">
					<div class=" col-md-4 user-input-wrp">
                            <br/>
                            <input type="text" id="term2" name="FaxNo" class="inputText"/>
                            <span class="floating-label">{{__('message.Fax number')}}</span>
                        </div>
                        <div class="col-md-4 user-input-wrp">
                            <br/>
                            <select class="category" id="City" name="City">
                               <option value=""></option>
                                 @foreach($city as $cities)
                                    <option value="{{$cities->CityId}}">{{$cities->CityName}}</option>
                                 @endforeach
                            </select>
							 <span class="floating-label" id="cityname">{{__('message.SelectCity')}}<span style="color:red;"> * </span></span>
                        </div>
                        <div class="col-md-4  user-input-wrp">
                            <br/>
                            <select class="category" id="Area" name="Area">
                            </select>
							 <span class="floating-label" id="areaname">{{__('message.SelectArea')}}<span style="color:red;"> </span></span>
                        </div>
                    </div>

                    <div class="row">
                        <div class=" col-md-4 user-input-wrp">
                            <br/>
                            <input type="text" class="inputText date"   name="dateofincorporation" id="date" required />
                            <span class="floating-label">{{__('message.DateofIncorporation')}}
                                <span style="color:red;">*</span>
                            </span>
                        </div>
                        <div class=" col-md-4 user-input-wrp">
                            <br/>
                            <span class="headline" style="margin-left: 4px;margin-top: 4px; position: absolute;">{{__('message.Describe your business')}}
                                <span style="color:red;">*</span>
                            </span>
                            <textarea placeholder="{{__('message.This is an awesome comment box')}}" rows="20" id="DescribeBusiness" name="DescribeBusiness"  cols="40" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true" required></textarea>
                            <div id="charNum">500 {{__('message.charactersleft')}}</div>
                            <i>( {{__('message.HTML links are not allowed')}}){{__('message.Do not use ALL CAPITAL LETTERS')}}</i>
                        </div>
			            <div class=" col-md-4 user-input-wrp">
                            <br/>
                            <input type="text" id="term" name="WebsiteLink"class="inputText"  />
                            <span class="floating-label">{{__('message.Yoursite')}}{{__('message.Startwithhttp')}}</span>
                        </div>
                    </div>
                    <div class="row" style="padding-top:10px;">
                        <div style="margin-left:15px;">
                            <input type="checkbox" id="myCheck" name ="myCheck" /><span class="headline hd2">{{__('message.I agree with the publication of my data')}}</span><br>
							 <b><label id="error_msg3"></label></b>
                        </div>
                    </div>
                    <div class="row">
                        <div style="float:right;padding-top: 20px;padding-left: 15px;">
                            <input type="submit" class="btn-grad" value="{{__('message.Send')}}" onclick="testcheck()" style=" height:40px; width:100px;" />
                            <a href="{{url('/')}}">
							<input type="button" class="btn-grad" value="{{__('message.cancel')}}" style=" height:40px; width:100px;"/></a>
					     </div>
                    </div>
                </form>
            </div>

            <div class="col-md-3 mobile-padding">
                <!--rami-->
                <div style="background: #fff;">
                    <center>
                        <div class="post" style="padding:15px 20px;">
                            <h4>{{__('message.Post free classifieds')}}</h4>
                            <img src="{{asset('/public/Images/guarantee.png')}}" class="img-responsive guarantee" alt="guarantee" />
                            <p style="text-align: justify;">{{__('message.guarenteedescription')}} </p>
                        </div>
                    </center>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    var email_exists = false;
    $(document).ready(function() {
        $('#Email').on('blur', function() {
            var emailID = $("#Email").val();
            if (emailID) {
                $.ajax({
                    dataType: 'text',
                    type: 'POST',
                    url: 'resources/views/checkemail.php',
                    //url:'app/Http/Controllers/DynamicController@index2',
                    data: 'email_id=' + emailID,

                    success: function(html) 
                    {
                        if (html == "Email Id Already Exists") 
                        {
                            email_exists = true;
                        }
                        $('#errormessage').html(html);
                    },
                    error: function(e) {
                        $('#errormessage').html(e);
                    }
                });
            }
        });
    });
 </script>
<script type="text/javascript">
    $(document).ready(function() 
    {
        $('#category').on('change', function() 
        {
            var categoryID = $(this).val();
            if (categoryID) 
            {
                $.ajax({
                    dataType: 'text',
                    type: 'POST',
                    url: 'resources/views/queryforsubcategory.php',
                    data: 'category_id=' + categoryID,
                    success: function(html) 
                    {
                        $('#subcategory').html(html);
                    },
                    error: function(e) 
                    {
                        $('#subcategory').html(e);
                    }
                });
            }
        });
    });
     $(document).ready(function() 
     {
            $('#City').on('change', function() 
            {
                var cityID = $(this).val();
                if (cityID)
                {
                    $.ajax({
                        dataType: 'text',
                        type: 'POST',
                        url: 'resources/views/queryforarea.php',
                        //url:'app/Http/Controllers/DynamicController@index2',
                        data: 'city_id=' + cityID,
                        success: function(html) 
                        {
                            $('#Area').html(html);
                        },
                        error: function(e) 
                        {
                            $('#Area').html(e);
                        }
                    });
                }
            });
        });
        $('#DescribeBusiness').keyup(function() {
                var max = 500;
                var len = $(this).val().length;
                if (len >= max) {
                    $('#charNum').text(' you have reached the limit');
                } else {
                    var char = max - len;
                    $('#charNum').text(char + '{{__('message.charactersleft')}}');
                }
            });

    $("#registerForm").validate(
        {
        rules: {
            CompanyName: {
                required: true,
				lettersonly: true
            },
            ContactName: {
                required: true,
                lettersonly: true
            },
            PostalCode: {
                required: true,
                number: true
            },
             phone: {
                required: true,
				validecode: true
            },
			mobile:{
				validecode: true, 
			},
            Address1: {
                required: true
            },
            Address2: {
                required: true
            },
			FaxNo:{
				 number: true,
                 minlength: 10,
                 maxlength: 10,
		         validecode: true, 
			},
			City: {
                required: true
            },
            category: {
                required: true
            },
            subcategory: {
                required: true
            },
			 DescribeBusiness: {
                required: true,
                minlength: 30,
                maxlength: 500
            },
			dateofincorporation: {
				required : true
			},
			myCheck:{
				required:true
			}
        },
        messages: {
            CompanyName: {
                required: "{{__('message.Please Enter your company name')}}",
				lettersonly: "{{__('message.Please Enter only character') }}"
            },
            ContactName: {
                required: "{{__('message.Please Enter your name')}}",
                lettersonly: "{{__('message.Please Enter only character') }}"
            },
            PostalCode: {
                required: "{{__('message.Please Enter postalcode')}}",
                number: "{{__('message.Please Enter digits')}}"
            },
            phone: {
                required: "{{__('message.please enter mobile number')}}",
				validecode: "{{__('message.country code should be valid')}}"
            },
			mobile:{
					validecode: "{{__('message.country code should be valid')}}"
			},
            Address1: {
                required: "{{__('message.Please enter address')}}"
            },
            Address2: {
                required: "{{__('message.Please enter address')}}"
            },
			FaxNo:{
				 number: "{{__('message.please enter only numbers')}}",
                minlength: "{{__('message.minimum 10 numbers required')}}",
                maxlength: "{{__('message.maximum 10 numbers only')}}",
				validecode: "{{__('message.country code should be valid')}}"
			},
            City: {
                required: "{{__('message.Please select one city')}}"
            },
            category: {
                required: "{{__('message.Please select one category')}}"
            },
            subcategory: {
                required: "{{__('message.please select one subcategory after category')}}"
            },
			DescribeBusiness: {
                 required: "{{__('message.Write Something')}}",
                minlength: "{{__('message.Minimum 30 characters required')}}",
                maxlength: "{{__('message.Maximum 500 characters')}}"
            },
			dateofincorporation: {
				required : "{{__('message.Pleaseselectdateofincorporation')}}"
			},
			myCheck:{
				required:"{{__('message.Tick the box')}}"
			}
        }
    });

    jQuery.validator.addMethod("lettersonly", function(value, element) {
        return this.optional(element) || /^[a-zA-Z ]*$/.test(value);
    }, "Letters only please");

</script>


@endsection