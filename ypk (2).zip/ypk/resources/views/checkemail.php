<?php
include "db2.php";
$email_id = $_REQUEST['email_id'];
$sql="SELECT * FROM userregistration where Email= '$email_id'";

$result=$db->query($sql);
if($result->num_rows>0){
	$output['error']=true;
	$output['message']='Электронная почта уже существует';
	echo(json_encode(false));
	//return true;
    
}else{
	$output['error']=false;
	$output['message']='';
	echo(json_encode(true));
	//return false;
}

?>