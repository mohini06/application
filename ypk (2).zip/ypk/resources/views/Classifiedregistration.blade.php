@extends('layouts.app')
 @section('title')
Публикация объявлений на Желтых Страницах Казахстана
@stop
@section('description', 'Продвигайте свои товары и услуги с помощью Желтых Страниц Казахстана. Выберите подходящую подкатегорию для ваших товаров и услуг, и повышайте его видимость, для привлечения большего числа клиентов.- Promote your product or services with Yellow Pages Kazakhstan. Select the most suitable medium of advertising for your product/Services and increase its visibility so that new customers can easily find it.')
@section('keywords', 'Бесплатная публикация, реклама, онлайн продвижение бизнеса, онлайн реклама, бизнес маркетинг, продвижение бизнеса.- Free listing, advertising, online business promotion, online advertising, local business marketing, local business promotion.')
@section('content')
<script>
    $(document).ready(function () 
    {
        // Handler for .ready() called.
        $('html, body').animate({
            scrollTop: 560
        }, 2000); 
    });  
</script>
    <div class="row">
        <!--rami-->
        <div class="col-md-9" style="padding-left: 0px;padding-right: 0px;">
            <div class="col-md-6">
                <h3 class="headerline">{{__('message.Publish Your Add')}}  </h3>
            </div>
            <div class="col-md-3"></div>
            <div class="col-md-3">
                <a href="{{url('/classified-help')}}" target="_blank">
                    <h3 class="headerline" style="background-color: #ffce00; color: white; font-size: 18px; width: 30px; text-align: center;  padding: 5px; border-radius: 19px;  margin-bottom: 10px; float: right;"> <i class="fa fa-info" aria-hidden="true"></i></h3>
                </a>
            </div>
        </div>
        <div class="col-md-3">
        </div>
    </div>
    <!--rami-->
    <div class="col-md-12 no-padding">
        <div class="content-section">
            <div class="row">
                <div class="col-md-9" style=" background: #ffffff;padding: 15px 20px;">
                    <form  method="POST" action="{{action('ClassifiedController@store')}}" id="registerForm" role="form">
                        <input type="hidden" name="_token" value="{{ csrf_token()}}">
                        <br>
                        <h4 style="font-weight: 400;">{{__('message.headings')}} </h4>
                        <br>
                        <div class="row" style="padding-bottom: 10px;">
                            <div class="col-md-4 user-input-wrp">
                                <br/>
                                <input type="text" class="inputText"  id="ClassifiedTitle" name="ClassifiedTitle">
                                <span class="floating-label">{{__('message.Add Title')}} <span style="color:red;">*</span></span>
                                <label id="errormessage"></label>
                            </div>
                            <div class="col-md-4 user-input-wrp">
                                <br/>
                                <select class="category" id="category" name="category">
                                    <option value=""></option>
                                    @foreach($category as $categories)
                                        <option value="{{$categories->CategoryId}}">{{$categories->CategoryName}}</option>
                                    @endforeach
                                </select>
                                <span class="floating-label" id="categoryname">{{__('message.Select one Category')}}<span style="color:red;"> * </span></span>
                            </div>
                            <div class="col-md-4 user-input-wrp">
                                <br/>
                                <select class="category" id="subcategory" name="subcategory"></select>
                                <span class="floating-label" id="subcategoryname">{{__('message.Select subcategory')}}<span style="color:red;"> * </span></span>
                            </div>
                        </div>
                        <div class="row" style="padding-bottom: 10px;">
                            <div class="col-md-4 user-input-wrp">
                                <br/>
                                <input type="text" class="inputText" id="email" name="email">
                                <span class="floating-label">{{__('message.Email Address')}} <span style="color:red;">*</span></span>
                                <label id="errormessage"></label>
                            </div>
                            <div class=" col-md-4 user-input-wrp">
                                <br/>
                                <input type="text" class="inputText" id="name" name="name">
                                <span class="floating-label">{{__('message.Your name')}}<span style="color:red;">*</span></span>
                            </div>
                            <div class="col-md-4 user-input-wrp">
                                <br/>
                                <select class="category" id="city" name="city">
                                    <option value=""></option>
                                    @foreach($city as $cities)
                                        <option value="{{$cities->CityId}}">{{$cities->CityName}}</option>
                                    @endforeach
                                </select>
                                <span class="floating-label" id="cityname">{{__('message.Select City')}} <span style="color:red;"> * </span></span>
                            </div>
                        </div>
                        <div class="row" style="padding-bottom: 10px;">
                            <div class=" col-md-4 user-input-wrp">
                                <br/>
                                <input type="text" id="mobile" name="mobile" class="inputText phonemask" />
                                <span class="floating-label">{{__('message.Mobile number')}} <span style="font-size: 11px;">{{__('message.Add prefix +7')}}  </span></span>
                            </div>
                            <div class=" col-md-4 user-input-wrp">
                                <br/>
                                <input type="text" class="inputText" name="Weburl"  id="url"/>
                                <span class="floating-label">{{__('message.Your site')}}<span style="font-size: 11px;">{{__('message.Startwithhttp')}} </span><span style="color:red;"> </span></span>
                            </div>
                            <div class=" col-md-4 user-input-wrp">
                                <br/>
                                <input type="text" id="phone" name="phone" class="inputText phonemask"/>
                                <span class="floating-label">{{__('message.Phone number')}} <span style="font-size: 11px;">{{__('message.Add prefix +7 & area code')}} </span><span style="color:red;"> *</span></span>
                            </div>
                        </div>
                        <div class="row">
                            <div class=" col-md-4 user-input-wrp">
                                <br/>
                                <input type="text" class="inputText date" name="dateofincorporation"id="date" />
                                <span class="floating-label"> {{__('message.Date of Incorporation')}}<span style="color:red;">*</span></span>
                            </div>
                            <div class=" col-md-8 user-input-wrp">
                                <br/>
                                <span class="headline" style="margin-left: 4px;margin-top: 4x;position: absolute;">{{__('message.Advertisement')}}<span style="color:red;">*</span></span>
                                <textarea placeholder="{{__('message.This is an awesome comment box')}}" rows="20" name="ClassifiedContent" id="ClassifiedContent" cols="40" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true" style="resize:none! important;"></textarea>
                                <div id="charNum">{{__('message.500 characters left')}}</div>
                                <i>{{__('message.(HTML links are not allowed.) Do not use ALL CAPITAL LETTERS)')}}</i>
                                <h5 style="text-align: justify;width:50%; margin-top: 6px;">({{__('message.Use keywords to more easily search your company for your activity, the products and services offered')}})</h5>
                            </div>
                        </div>
                        <div class="row">
                            <div style="float:right;padding-top: 20px;padding-left: 15px;">
                            <input type="submit" class="btn-grad" value="{{__('message.Send')}}" style=" margin-right:15px;height:40px; width:100px;" />
                            <a href="{{url('/')}}">
                            <input type="button" class="btn-grad" value="{{__('message.cancel')}}" style=" height:40px; width:100px;" />
                            </a>
                            </div>
                        </div>
                    </form>
                </div>
            <div class="col-md-3 mobile-padding">
                <!--rami-->
                <div style="background: #fff;">
                    <center>
                        <div class="post" style="padding:15px 20px;">
                            <h4>{{__('message.Post free classifieds')}}</h4>
                            <img src="{{asset('/public/Images/guarantee.png')}}" class="img-responsive guarantee" alt="guarantee" />
                            <p style="text-align: justify;">{{__('message.guarenteedescription')}} </p>
                        </div>
                    </center>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $("#registerForm").validate( 
        {
            rules: 
            {
                ClassifiedTitle: 
                {
                    required: true        
                },
                email: 
                {
                    required:true,
                    email:true
                }, 
                name: 
                {
                    required: true,
                    lettersonly: true
                }, 
                mobile: 
                {
                    validecode: true,
                },
                phone:
                {
                    required: true, 
                    validecode: true, 
                },
                category: 
                {
                    required: true
                }, 
                subcategory: 
                {
                    required: true
                }, 
                city: 
                {
                    required: true
                },
                dateofincorporation: 
                {
                    required : true
                },
                ClassifiedContent:
                {
                    required: true,
                    minlength: 30,
                    maxlength: 500
                }
            },
             messages: 
            {
                ClassifiedTitle: 
                {
                    required: "{{__('message.Please Enter the classified title')}} "		
                }, 
                category: 
                {
                    required: "{{__('message.Please select one category')}}"
                }, 
                email: 
                {
                    required: "{{__('message.Please Enter your email aadress')}}",
                    email: "{{__('message.Please Enter valid email')}}",
                }, 
                name: 
                {
                    required: "{{__('message.Please Enter your name')}}",
                    lettersonly: "{{__('message.Please Enter only character') }}"
                }, 
                mobile: 
                {
                    validecode: "{{__('message.country code should be valid')}}"
                },
                phone:{
                    required: "{{__('message.please enter mobile number')}}",
                    validecode: "{{__('message.country code should be valid')}}"
                }, 
                category: 
                {
                    required: "{{__('message.Please select one category')}}"
                }, 
                subcategory: 
                {
                    required: "{{__('message.please select one subcategory after category')}}"
                }, 
                city: 
                {
                    required: "{{__('message.Please select one city')}}"
                },
                dateofincorporation: 
                {
                required : "{{__('message.Pleaseselectdateofincorporation')}}"
                },
                ClassifiedContent:
                {
                    required: "{{__('message.Write Something')}}",
                    minlength: "{{__('message.Minimum 30 characters required')}}",
                    maxlength: "{{__('message.Maximum 500 characters')}}"
                }
            }
	    });
</script>
<script>
    $('#ClassifiedContent').keyup(function () 
    {
        var max = 500;
        var len = $(this).val().length;
        if (len >= max) 
        {
            $('#charNum').text(' you have reached the limit');
        } 
        else 
        {
            var char = max - len;
            $('#charNum').text(char + ' {{__('message.characters left')}}');
        }       
    });

    $(document).ready(function()
    {
        $('#category').on('change',function()
        {
            var categoryID = $(this).val();
            if(categoryID)
            {
                $.ajax({
                    dataType: 'text',
                     type:'POST',
                     url:'resources/views/queryforsubcategory.php',
                      //url:'app/Http/Controllers/DynamicController@index2',
                     data:'category_id='+categoryID,
                     success:function(html)
                     {
                        $('#subcategory').html(html);
                     },
                     error:function(e)
                     {
                        $('#subcategory').html(e);
                     }
               });
            }
        });
    });
</script>
@endsection