@extends('layouts.app')

 @section('title')
Желтые страницы Казахстана | Бесплатные объявления ::
@stop
@section('keywords', 'Желтые страницы Казахстана')
@section('description', '')

@section('content')
<script>
$(document).ready(function () {
         // Handler for .ready() called.
         $('html, body').animate({
             scrollTop: 560
         }, 2000); 
  }); 
</script>
 <div class="container">
    <div class="row">
        <div class="col-md-9 top-slider">
			<div class="row">
                <div class="col-md-12" >
					<h3 class="headerline" >{{__('message.How to place free ads?')}}</h3>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12">
					<span class="help-text-content" style="font-size:15px ! important;">{{__('message.messageregiter')}}</span>
				</div>
			</div>
			<div class="detail-wrapper">
				<div class="detail-wrapper-header">
					<h3 style="font-size: 20px;">{{__('message.Step')}}1 </h3>
				</div>
				<div class="detail-wrapper-body">
					<span class="help-text">{{__('message.Click on')}}</span>
					<a href="Post_add.html" style="font-size: 16px;font-weight:bold;color: #000;">"{{__('message.AddClassified')}}"</a>
					<span class="help-text">{{__('message.from the main menu.')}}</span>
  					<img src="{{asset('public/img/help/menu-add-classified-img.png')}}" alt="menu-add-company" style="width:100%;margin-top:10px;" target="_blank">
				</div>
			</div>
			<div class="detail-wrapper">
				<div class="detail-wrapper-header">
					<h4  style="font-size: 20px; margin: 0px;">{{__('message.Step')}}2</h4>
				</div>
				<div class="detail-wrapper-body">
					<span class="help-text">{{__('message.Fill in the required field marked with')}}</span>
					<span class="help-text" style="color:red;">*</span>
					<span class="help-text">{{__('message.todo')}}
						<span class="help-text" style="font-weight:bold;">"{{__('message.Send')}}"</span>
						{{__('message.button')}}
					</span>
					<img src="{{asset('public/img/help/post-add-img.jpg')}}" alt="menu-add-company" style="width:100%;margin-top:10px;">
				</div>
			</div>
		</div>
		<div class="col-md-3">
			@include('classifieds_slide')
        </div>
  	</div>
@endsection