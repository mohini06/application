@extends('profilemenu') 
@section('mycontent')
<div class="col-md-9">
 @php  
                   
             $classified_count=count($classifieddata);
            
			 
        @endphp
    <ul id="tabs_classified">
      
		
        <li><a href="#" name="tab1" class="tab_text" style="font-weight: 500"><i class="menu_icon2 fa fa-user" aria-hidden="true" ></i> {{__('message.Comapany Details')}}</a></li>
       
		
         @for($i=2;$i<=$classified_count+1;$i++)
        <li><a href="#" name="tab{{$i}}" class="tab_text" style="font-weight: 500"><i class="menu_icon2 fa fa-laptop" aria-hidden="true" ></i>@php echo "Объявление".($i-1); @endphp</a></li>
        
     @endfor
    </ul>

    <div id="tab_content">
         
	 <div id="tab1">
     
		@if($userd!=null)
			
		@php 
			     $city_id= isset($_GET['city'])?$_GET['city']:"";
				 $categ_id         =isset($_GET['category'])?$_GET['category']:"";
				 $subcateg_id=isset($_GET['subcategory'])?$_GET['subcategory']:"";
			  @endphp
            <form method="POST" id="editcompanyform" action="{{url('/updatecompanydata')}}" role="form">
                <input type="hidden" name="_token" value="{{ csrf_token()}}">
                <div class="row" style="margin-top:15px;">

                    <div class="col-md-12">
                        <div class="sidebar">
                            <div class="row" style="margin-left:0px;">
                                <div class="col-md-12 profile-left">
                                    <div class="content">
                                        <div class="row" style="padding-bottom: 10px;">
                                            <div class="col-md-4 user-input-wrp">
                                                <br/>
                                                <span class="floating-label-edit">{{__('message.Company Name')}}<span style="color:red;">*</span></span>
                                                <input type="text" class="inputText" id="CompanyName" name="CompanyName" value="{{$userd->CompanyName}}" />

                                            </div>
                                            <div class="col-md-4  user-input-wrp">
                                                <br/>
                                                <span class="floating-label-edit">{{__('message.Contact Name')}}<span style="color:red;">*</span></span>
                                                <input type="text" class="inputText"  id="ContactName"name="ContactName" value="{{$user->Name}}" />

                                            </div>
                                            <div class=" col-md-4 user-input-wrp">
                                                <br/>
                                                <span class="floating-label-edit">{{__('message.Email Address')}}<span style="color:red;">*</span> </span>
                                                <input type="text" class="inputText"  id="Email" name= "Email" value="{{$user->Email}}" readonly />

                                            </div>
                                        </div>
                                        <div class="row" style="padding-bottom: 10px;">
                                            <div class="col-md-4 user-input-wrp">
                                                <br/>
                                                <span class="floating-label-edit">{{__('message.Enter your username')}}<span style="color:red;">*</span></span>
                                                <input type="text" class="inputText" id="UserName" name="UserName" value="{{$user->UserId}}" readonly />
                                            </div>
                                            <!--<div class="col-md-4 ">
                                                 <input type="button" id="checkuser"class="btn-grad" value="{{__('message.Check Availability')}}" style=" height:40px; width:185px;" />

                                            </div>-->
                                            <div class=" col-md-4 user-input-wrp">
                                                <br/>
                                                <span class="floating-label-edit">{{__('message.Postcode')}}<span style="color:red;">*</span></span>
                                                <input type="text" class="inputText"  id="PostalCode" name="PostalCode" value="{{$userd->PostalCode}}" />

                                            </div>
											<div class="col-md-4 user-input-wrp">
                                                <br/>
                                                <span class="floating-label-edit">{{__('message.Password')}} <span style="color:red;">*</span></span>
                                                <input type="password" class="inputText"  id="password" name="password" value="{{$user->Password}}" readonly />

                                            </div>
                                        </div>
                                        <div class="row" style="padding-bottom: 10px;">
                                            
                                           <!-- <div class="col-md-4  user-input-wrp">

                                            </div>-->
                                            <div class=" col-md-6 user-input-wrp">
                                                <br/>

                                                <span class="floating-label-edit">{{__('message.Phonenumber')}}<span style="font-size: 11px;">{{__('message.Addprefix')}}</span><span style="color:red;">*</span></span>
                                                <input type="text" class="inputText phonemask edit_profilePhone"  id="phone" name="phone" value="{{$user->Phone}}" />

                                            </div>
											 <div class=" col-md-6 user-input-wrp">
                                                <br/>
                                                <span class="floating-label-edit">{{__('message.Mobilenumber')}}<span style="font-size: 11px;">{{__('message.Addprefix')}} </span></span>
                                                <input type="text" class="inputText phonemask edit_profilePhone" id="mobile" name="mobile" value="{{$user->Mobile}}" />

                                            </div>
                                        </div>
                                        <div class="row" style="padding-bottom: 10px;">
                                            <div class="col-md-4 user-input-wrp">
                                                <br/>
                                                <span class="floating-label-edit">{{__('message.Street Address')}}<span style="color:red;">*</span> </span>
                                                <input type="text" class="inputText"id="Address1" name="Address1" value="{{$userd->Address1}}" />

                                            </div>
                                            <div class="col-md-4  user-input-wrp">
                                                <br/>
                                                <input type="text" class="inputText" id="Address2" name="Address2" value="{{$userd->Address2}}" />
                                                <span class="floating-label-edit">{{__('message.Building / office number')}} <span style="color:red;">*</span></span>
                                            </div>
                                           
											  <div class=" col-md-4 user-input-wrp">
                                                <br/>

                                                <span class="floating-label-edit">{{__('message.Fax number')}} </span>
                                                <input type="text" class="inputText" id="FaxNo" name="FaxNo" value="{{$userd->FaxNo}}" />

                                            </div>
                                        </div>
                                        <div class="row" style="padding-bottom: 10px;">
                                            <div class="col-md-4 user-input-wrp">
                                                <br/>
                                                <select class="category" id="category" name="category">
                                                 
                                                    @foreach($category as $categories)
                                                        @if($userd->CategoryCode == $categories->CategoryId)
                                                     <option value="{{$userd->CategoryCode}}" selected>{{$userd->CategoryName}}</option>
													   @else
														<option value="{{$categories->CategoryId}}">{{$categories->CategoryName}}</option>
													   @endif
												    @endforeach
                                                </select>
												<span class="floating-label" id="categoryname">{{__('message.Select your category')}}<span style="color:red;"> * </span></span>
                                            </div>
                                            <div class="col-md-4  user-input-wrp">
                                                <br/>
												 
                                                <select class="category"  id="subcategory" name="subcategory">
                                                  <option value="{{$userd->SubCategoryCode}}" >{{$userd->SubCategoryName}}</option>
												 </select>		
													   
                                               
												<span class="floating-label" id="categoryname">{{__('message.Select subcategory')}}<span style="color:red;"> * </span></span>
                                            </div>
                                          
											<div class=" col-md-4 user-input-wrp">
                                                <br/>
												   
                                                <span class="floating-label-edit">{{__('message.Yoursite')}}{{__('message.Startwithhttp')}}</span>
                                                <input type="text" class="inputText" id="WebsiteLink" name="WebsiteLink" value="{{$userd->WebsiteLink}}" />

                                            </div>
                                        </div>
                                        <div class="row" style="padding-bottom: 10px;">
                                            <div class="col-md-6 user-input-wrp">
                                                <br/>
                                                <select class="category" name="City" id="City">
                                                    <option value="{{$userd->City}}" style="font-weight: 600">{{$userd->CityName}}</option>
                                                    @foreach($city as $cities)
                                                    <option value="{{$cities->CityId}}">{{$cities->CityName}}</option>
                                                    @endforeach
                                                </select>
												<span class="floating-label" id="cityname">{{__('message.SelectCity')}}<span style="color:red;"> * </span></span>
                                            </div>
                                            <div class="col-md-6  user-input-wrp">
                                                <br/>
                                                <select class="category" id="Area" name="Area">
                                                    <option value="{{$userd->AreaId}}" style="font-weight: 600">{{$userd->AreaName}}</option>

                                                </select>
												 <span class="floating-label" id="areaname">{{__('message.SelectArea')}}</span>
												
                                            </div>
                                            
                                        </div>
                                       
                                        <div class="row">
                                            <div class=" col-md-4 user-input-wrp">
                                                <br/>
                                                <span class="floating-label-edit">{{__('message.DateofIncorporation')}} </span>
                                                <input type="text" class="inputText date" value="{{$userd->dateofincorporation}}"  name="dateofincorporation" id="date" />

                                            </div>
                                            <div class=" col-md-8 user-input-wrp">
                                                <br/>
                                                <span class="headline" style="margin-left: 4px;margin-top: 4px;position: absolute;">{{__('message.Describe your business')}}<span style="color:red;">*</span></span>
                                                <textarea placeholder="{{__('message.This is an awesome comment box')}}" value="" rows="20"  id="DescribeBusiness" name="DescribeBusiness"  cols="40" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true" style="resize:none! important;">{{$userd->DescribeBusiness}}</textarea>
                                             <div id="charNum">500 {{__('message.charactersleft')}}</div>
                      <i>( {{__('message.HTML links are not allowed')}}){{__('message.Do not use ALL CAPITAL LETTERS')}}</i>
            </div>
											</div>
                                        </div>
                                        <div class="row" style="padding-top:10px;">
                                            <div style="margin-left:15px;">
                                                <input type="checkbox"  id="myCheck" name ="myCheck"  /><span class="headline hd2">{{__('message.I agree with the publication of my data')}}</span>
                                             <b><label id="error_msg3"></label></b>
											</div>
                                        </div>
                                        <div class="row">
                                            <div style="float:right;padding-top: 20px;padding-left: 15px;">
                                                <input type="reset" class="btn-grad" value="{{__('message.cancel')}}" style=" height:40px; width:100px;" />
                                                <input type="submit" class="btn-grad" value="{{__('message.update')}}" onclick="testcheck()" style=" height:40px; width:100px;" />
                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
					</form>
			@else
				<p>{{__('message.Please add company')}}</p>
		     @endif
                </div>
			
         @php $j=2; @endphp   
       @if ($classified_count>=1)
         @foreach($classifieddata as $add)
	        <div id="tab{{$j}}">
			<form method="POST" id="editclassifiedform{{$j}}" class="classified_form" action="{{url('/updateclassified')}}" role="form">
			   <input type="hidden" name="ClassifiedRegId" value="{{$add->ClassifiedRegId}}">
                <input type="hidden" name="_token" value="{{ csrf_token()}}">
                <div class="row" style="margin-top:15px;">

                    <div class="col-md-12">
                        <div class="sidebar">
                            <div class="row" style="margin-left:0px;">
                                <div class="col-md-12 profile-left">
                                    <div class="content">
                                        <div class="row" style="padding-bottom: 10px;">
                                            <div class="col-md-4 user-input-wrp">
                                                <br/>
                                                <span class="floating-label-edit">{{__('message.Add Title')}}<span style="color:red;">*</span></span>
                                                <input type="text" class="inputText" id="ClassifiedTitle{{$j}}" name="ClassifiedTitle" value="{{$add->ClassifiedTitle}}" />

                                            </div>
                                            <div class="col-md-4  user-input-wrp">
                                                <br/>
                                                <span class="floating-label-edit">{{__('message.Contact Name')}}<span style="color:red;">*</span></span>
                                                <input type="text" class="inputText"  id="ContactName{{$j}}"name="ContactName" value="{{$user->Name}}" />

                                            </div>
                                            <div class=" col-md-4 user-input-wrp">
                                                <br/>
                                                <span class="floating-label-edit">{{__('message.Email Address')}}<span style="color:red;">*</span> </span>
                                                <input type="text" class="inputText"  id="Email{{$j}}" name= "Email" value="{{$user->Email}}" readonly />

                                            </div>
                                        </div>
                                       
                                        <div class="row" style="padding-bottom: 10px;">
                                              
                                         
                                            <div class=" col-md-6 user-input-wrp">
                                                <br/>

                                                <span class="floating-label-edit">{{__('message.Phonenumber')}}<span style="font-size: 11px;">({{__('message.Addprefix')}})</span><span style="color:red;">*</span></span>
                                                <input type="text" class="inputText phonemask edit_profilePhone"  id="phone{{$j}}" name="phone" value="{{$user->Phone}}" />

                                            </div>
											<div class=" col-md-6 user-input-wrp">
                                                <br/>
                                                <span class="floating-label-edit">{{__('message.Mobilenumber')}}<span style="font-size: 11px;">({{__('message.Addprefix')}}) </span></span>
                                                <input type="text" class="inputText phonemask edit_profilePhone" id="mobile{{$j}}" name="mobile" value="{{$user->Mobile}}" />

                                            </div>
                                        </div>
                                   
                                        <div class="row" style="padding-bottom: 10px;">
                                            <div class="col-md-4 user-input-wrp">
                                                <br/>
                                                <select class="category" id="category{{$j}}" name="category">
                                                    <option value="{{$add->CategoryCode}}">{{$add->CategoryName}}</option>
                                                    @foreach($category as $categories)
                                                    <option value="{{$categories->CategoryId}}">{{$categories->CategoryName}}</option>
                                                    @endforeach
                                                </select>
												<span class="floating-label" id="categoryname">{{__('message.Select your category')}}<span style="color:red;"> * </span></span>
                                            </div>
                                            <div class="col-md-4  user-input-wrp">
                                                <br/>
                                                <select class="category"  id="subcategory{{$j}}" name="subcategory">
                                                    <option value="{{$add->SubCategoryCode}}" style="font-weight: 600">{{$add->SubCategoryName}}</option>

                                                </select>
												<span class="floating-label" id="categoryname">{{__('message.Select subcategory')}}<span style="color:red;"> * </span></span>
                                            </div>
                                            <div class=" col-md-4 user-input-wrp">
                                                <br/>
                                                <span class="floating-label-edit">{{__('message.Yoursite')}}({{__('message.Startwithhttp')}})</span>
                                                <input type="text" class="inputText" id="WebUrl{{$j}}" name="WebUrl" value="{{$add->WebUrl}}" />

                                            </div>
                                        </div>
                                       
                                        
                                        <div class="row">
                                            <div class=" col-md-4 user-input-wrp">
                                                <br/>
                                                <span class="floating-label-edit">{{__('message.DateofIncorporation')}} </span>
                                                <input type="text" class="inputText date" value="{{$add->dateofincorporation}}" name="dateofincorporation" id="date" />

                                            </div>
                                            <div class=" col-md-8 user-input-wrp">
                                                <br/>
                                                <span class="headline" style="margin-left: 4px;margin-top: 4px;position: absolute;">{{__('message.Describe your business')}}<span style="color:red;">*</span></span>
                                                <textarea placeholder="{{__('message.This is an awesome comment box')}}" value="" rows="20"  id="ClassifiedContent{{$j}}" name="ClassifiedContent"  cols="40" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true" style="resize:none! important;">{{$add->ClassifiedContent}}</textarea>
                                             <div id="charNum">500 {{__('message.charactersleft')}}</div>
                      <i>( {{__('message.HTML links are not allowed')}}){{__('message.Do not use ALL CAPITAL LETTERS')}}</i>
            </div>
											</div>
                                        </div>
                                       
                                        <div class="row">
                                            <div style="float:right;padding-top: 20px;padding-left: 15px;">
                                                <input type="reset" class="btn-grad" value="{{__('message.cancel')}}" style=" height:40px; width:100px;" />
                                                <input type="submit" class="btn-grad" value="{{__('message.update')}}" onclick="testcheck()" style=" height:40px; width:100px;" />
                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
					</form>
			</div>
			  <script src="{{asset('public/js/others/new.js')}}"></script>
			@php $j++;@endphp
		
	     @endforeach
		 
        @else
		@endif

        

    </div>
</div>
<script>
    $(document).ready(function() {
		
        $('select[name="category"]').on('change', function() {
            var categoryID = $(this).val();

            if (categoryID) {
                $.ajax({
                    dataType: 'text',

                    type: 'POST',
                    url: '../resources/views/queryforsubcategory.php',
                    data: 'category_id=' + categoryID,

                    success: function(html) {

                        $('select[name="subcategory"]').html(html);
                    },
                    error: function(e) {
                        $('select[name="subcategory"]').html(e);
                    }
                });
            }
        });

    
        $('#City').on('change', function() {
            var cityID = $(this).val();

            if (cityID) {
                $.ajax({
                    dataType: 'text',

                    type: 'POST',
                    url: '../resources/views/queryforarea.php',
                    data: 'city_id=' + cityID,

                    success: function(html) {
                        console.log(html);

                        $('#Area').html(html);
                    },
                    error: function(e) {
                        $('#Area').html(e);
                    }
                });
            }
        });

    });
    $('#DescribeBusiness').keyup(function() {
        var max = 500;
        var len = $(this).val().length;
        if (len >= max) {
            $('#charNum').text(' you have reached the limit');
        } else {
            var char = max - len;
            $('#charNum').text(char + ' {{__('message.charactersleft')}}');
        }
    });
	
	$("#editcompanyform").validate({

        rules: {
            CompanyName: {
                required: true
			
            },
            ContactName: {
                required: true,
                lettersonly: true
            },
            Email: {
                required: true,
                email: true,
                email_exists: false

            },
            UserName: {
                required: true,
                minlength: 6,
              
            },
            PostalCode: {
                required: true,
                number: true
            },
           
           
            phone: {
                required: true,
               validecode: true, 
            },
			mobile:{
				
                validecode: true, 
			},

            Address1: {
                required: true
            },

            Address2: {
                required: true
            },

            City: {
                required: true
            },
            
            category: {
                required: true

            },
            subcategory: {
                required: true

            },
			 DescribeBusiness: {
                required: true,
                minlength: 30,
                maxlength: 500
            },
			dateofincorporation: {
				required : true
			},
			myCheck:{
				required:true
			},

        },
        messages: {
            CompanyName: {
                required: "{{__('message.Please Enter your company name')}}"
				

            },
            ContactName: {
                required: "{{__('message.Please Enter your name')}}",
                lettersonly: "{{__('message.Please Enter only character') }}"

            },
            Email: {
                required: "{{__('message.Please Enter your email aadress')}}",
                email: "{{__('message.Please Enter valid email')}}",
                email_exists: "{{__('message.Email already exist')}}"

            },

            UserName: {
                required: "{{__('message.Please Enter Unique User name')}}",
                minlength: "{{__('message.Please Enter Atleast 6 Characters')}}"
                
            },
            PostalCode: {
                required: "{{__('message.Please Enter postalcode')}}",
                number: "{{__('message.Please Enter digits')}}"
            },
           
            phone: {
                required: "{{__('message.please enter mobile number')}}",
              validecode: "{{__('message.country code should be valid')}}"  
            },
			mobile:{
				
               validecode: "{{__('message.country code should be valid')}}"
			},

            Address1: {
                required: "{{__('message.Please enter address')}}"
            },

            Address2: {
                required: "{{__('message.Please enter address')}}"
            },

            City: {
                required: "{{__('message.Please select one city')}}"
            },
            
            category: {
                required: "{{__('message.Please select one category')}}"

            },
            subcategory: {
                required: "{{__('message.please select one subcategory after category')}}"

            },
			DescribeBusiness: {
                 required: "{{__('message.Write Something')}}",
                  minlength: "{{__('message.Minimum 30 characters required')}}",
                maxlength: "{{__('message.Maximum 500 characters')}}"
            },
			dateofincorporation: {
				required : "{{__('message.Pleaseselectdateofincorporation')}}"
			},
			myCheck:{
				required:"{{__('message.Tick the box')}}",
			},
        }
    });

 $("form.classified_form").each(function(){
	 $(this).validate( {
        
    rules: {
        ClassifiedTitle: {
                  required: true
			            
        } ,
         email: {
                  required:true,
                  email:true
            }, 
        name: {
                required: true,
			    lettersonly: true
                }, 
                mobile: {
					validecode: true
                },
				phone:{
					 required: true, 
					validecode: true, 
				},
         category: {
                    required: true
                }
                , 
        subcategory: {
                    required: true
                }, 
                city: {
                    required: true
                },
				dateofincorporation: {
				required : true
			    },
				ClassifiedContent:{
					required: true,
                minlength: 30,
                maxlength: 500
				}
            },

             messages: {
                ClassifiedTitle: {
                    required: "{{__('message.Please Enter the classified title')}} "
                }, 
                category: {
					 required: "{{__('message.Please select one category')}}"
                }, 
                email: {
                    required: "{{__('message.Please Enter your email aadress')}}",
                email: "{{__('message.Please Enter valid email')}}",
                }
                , name: {
                    required: "{{__('message.Please Enter your name')}}",
                lettersonly: "{{__('message.Please Enter only character') }}"
                }, 
                mobile: {
              	validecode: "{{__('message.country code should be valid')}}"
                },
				phone:{
				required: "{{__('message.please enter mobile number')}}",
				validecode: "{{__('message.country code should be valid')}}"
				}, 
                category: {
                    required: "{{__('message.Please select one category')}}"
                }, 
                subcategory: {
                    required: "{{__('message.please select one subcategory after category')}}"
                }, 
                city: {
                    required: "{{__('message.Please select one city')}}",
                },
				dateofincorporation: {
				required : "Выберите дату регистрации",
			    },
				ClassifiedContent:{
				required: "Написать текст",
                minlength: "{{__('message.Minimum 30 characters required')}}",
                maxlength: "{{__('message.Maximum 500 characters')}}"
				}
        }
	 });
	 });
</script>
@endsection