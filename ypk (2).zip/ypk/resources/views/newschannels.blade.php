@extends('layouts.app')

@section('title')
Новости: Желтые Страницы Казахстана
@stop
@section('description', '')
@section('keywords', 'Новости: Желтые Страницы Казахстана')
@section('content')

 <script>
$(document).ready(function () {
         // Handler for .ready() called.
         $('html, body').animate({
             scrollTop: 560
         }, 2000); 
  }); 
</script>

<div class="row">
    <div class="col-md-9 top-slider">
        <!--rami-->
        <div class="row">
            <div class="col-md-4" style="padding-left: 5px;padding-right: 5px;">
                <h3 class="headerline">{{ __('message.news') }} </h3>
            </div>
        </div>
        <!--rami-->
        <div class="row" style="margin-top:5px;">
            <div class="col-md-6 main-news-div" style="width:100%;">
                <div class="border-eff">
                    <div class="inner">
                        <a href="https://abctv.kz/ru" target="_blank"> <img src="{{asset('public/img/news/new-channel.jpg')}}" alt="news1" class="news-images" target="_blanck" /> </a>
                        <div class="channel-name">
                            <a href="https://abctv.kz/ru" target="_blank">ATAMEKEN BUSINESS</a>
                        </div>
                        <div class="channel-icon">
                            <a href="https://abctv.kz/ru" target="_blank"><i class="fa fa-link"></i></a>
                        </div>
                        <div class="content-heading">
                            <h4><a href="https://abctv.kz/ru" class="news-title" target="_blank">Atameken Business: Новости Казахстана</a></h4>
                        </div>
                    </div>
                </div>
            </div>
           <div class="col-md-6 main-news-div" style="width:100%;">
                <div class="border-eff">
                    <div class="inner">
                        <a href="https://24.kz/ru/" target="_blank"> <img src="{{asset('public/img/news/24kz.jpg')}}" alt="news1" class="news-images" target="_blanck" /> </a>
                        <div class="channel-name">
                            <a href="https://24.kz/ru/" target="_blank">Хабар 24</a>
                        </div>
                        <div class="channel-icon">
                            <a href="https://24.kz/ru/" target="_blank"><i class="fa fa-link"></i></a>
                        </div>
                        <div class="content-heading">
                            <h4><a href="https://24.kz/ru/" class="news-title" target="_blank">Хабар 24: Новости Казахстана</a></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
    </div>
    <!-- rami-->
     	 <div class="col-md-3" style="padding-left: 5px;padding-right: 5px;">
           @include('classifieds_slide')
         </div>
</div>

@endsection