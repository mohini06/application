<?php
//Database credentials
$dbHost     = '94.247.135.2';
$dbUsername = 'ypksite';
$dbPassword = 'l&&ph]7C$=5u;{W';
$dbName     = 'yellowpageskz';

//Connect and select the database
$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
?>