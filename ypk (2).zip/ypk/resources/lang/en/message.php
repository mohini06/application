<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */
//menu
    'myaccount'=>'My Account',
    'invitation'=>'Invitation For Cooperation',
    'news'=>'News',
    'downloadapp'=>'Download App',
    'login'=>'Login',


    //Banner

    'keywords'=>'Key Words',
    'what_r_u_looking_for'=>'What are you looking for?',
    'location'=>'Location',
    'pick_a_location'=>'Pick a Location',
    'search'=>'Search',
    'categories'=>'Categories',

    //content

    'companylist'=>'Key Clients',
    'classifiedlist'=>'New Ads',

    //footer

    'aboutus'=>'About Us',
    //content for about us
    'history'=>'',
    'contactinfo'=>'Contact Us',
    //content for  contact info
    'address'=>'Data Infotech Private Limited in the Republic of Kazakhstan,Almaty, Abay Ave., 153, office 3, 050009.

                    Tel :+7 (727) 2506315, 2509664

                    Phone : +7 (701) 3167341

                    Email : sales@ypk.kz',
    'usefullinks'=>'Usefull Links',
    'home'=>'Home',
    'contactus'=>'Contact Us',
    'subscribe'=>'Subscribe',
    'By subscribing to our mailing list you will always get latest news and updates from us'=>
        'By subscribing to our mailing list you will always get latest news and updates from us',
    'enterurmail'=>'Enter your Email',
    'Copyrights belong to © 2018, ypk.kz.All rights reserved'=>
        'Copyrights belong to © 2018, ypk.kz.All rights reserved',
    'developedby'=>'Developed By',

    //Company Registration
    'Add your listing'=>'Add your listing',
    'Company Name'=>'Company Name',
    'Contact Name'=>'Contact Name',
    'Email Address'=>'Email Address',
    'Enter your username'=>'Enter your username',
    'Check Availability'=>'Check Availability',
    'Postcode'=>'Postcode',
    'Password'=>'Password',
    'Enter the password again'=>'Enter the password again',
    'Add prefix +7 & area code'=>'Add prefix +7 & area code',
    'Street Address'=>'Street Address',
    'Building / office number'=>'Building / office number',
    'Mobile number'=>'Mobile number',
    'Select your category'=>'Select your category',
    'Select subcategory'=>'',
    'Fax number'=>'Fax number',
    'Select City'=>'Select City',
    'Select Area'=>'Select Area',
    'Your site'=>'Your site',
    'Date of Incorporation'=>'Date of Incorporation',
    'Describe your business'=>'Describe your business',
    'This is an awesome comment box'=>'This is an awesome comment box',
    '500 characters left'=>'500 characters left',
    '(HTML links are not allowed.) Do not use ALL CAPITAL LETTERS'=>
        '(HTML links are not allowed.) Do not use ALL CAPITAL LETTERS',
    'I agree with the publication of my data'=>'I agree with the publication of my data',
    'Send'=>'Send',
    'Cancel'=>'Cancel',
    'Post free classifieds'=>'Post free classifieds',
    ' Post free classifieds with Yellow pages india.
     No registration is required for posting ads.
     Your classified will be directly mailed to the members of the category chosen by you.
     Please provide your exact contact details (phone number and Email address).
    Only those companies listed in yellow pages india will contact you'=>'',

    //companyregistration validation

    'Please Enter your company name'=>'Please Enter your company name',
    'Please Enter your name'=>'Please Enter your name',
    'Please Enter only character'=>'Please Enter only character',
    'Please Enter your email aadress'=>'Please Enter your email aadress',
    'Please Enter valid email'=>'Please Enter valid email',
    'Email already exist'=>'Email already exist',
    'Please Enter Unique User name'=>'Please Enter Unique User name',
    'Please Enter Atleast 6 Characters'=>'Please Enter Atleast 6 Characters',
    'Size should not be more than 12'=>'Size should not be more than 12',
    'Please Enter postalcode'=>'Please Enter postalcode',
    'Please Enter digits'=>'Please Enter digits',
    'Please enter password'=>'Please enter password',
    'Please enter password again'=>'Please enter password again',
    'Password should match with confirm password'=>'Password should match with confirm password',
    'please enter mobile number'=>'please enter mobile number',
    'please enter only numbers'=>'please enter only numbers',
    'minimum 10 numbers required'=>'minimum 10 numbers required',
    'maximum 10 numbers only'=>'maximum 10 numbers only',
    'Please enter address'=>'Please enter address',
    'Please enter address' =>'Please enter address',
    'Please select one city'=>'Please select one city',
    'please select one area after city'=>'please select one area after city',
    'Please select one category'=>'Please select one category',
    'please select one subcategory after category'=>'please select one subcategory after category',
    'Letters only please'=>'Letters only please',

    //Classified Registration

    'Publish Your Add'=>'Publish Your Add',
    'Please provide your contact information with the exact email address and phone number with the area code.
    Correct information will ensure a quick response to your ad. '=>
    '',
    'Add Title'=>'Add Title',
    'Select one Category'=>'Select one Category',
    'Email address'=>'Email address',
    'Your name'=>'Your name',
    'Select City'=>'Select City',
    'Mobile number'=>'Mobile number',
    'Add prefix +7'=>'Add prefix +7',
    'Your site'=>'Your site',
    'Start with http'=>'Start with http',
    'Phone number'=>'Phone number',
    'Add prefix +7 & area code'=>'Add prefix +7 & area code',
    'Date of Incorporation'=>'Date of Incorporation',
    'Advertisement'=>'Advertisement',
    '500 characters left'=>'500 characters left',
    '(HTML links are not allowed.) Do not use ALL CAPITAL LETTERS)'=>
    '',
    'Use keywords to more easily search your company for your activity, the products and services offered'
    =>'',
    'Cancel'=>'Cancel',
    'Publish'=>'Publish',
    'Post a free ad'=>'Post a free ad',


    //Classified Registration Validation

    'Please Enter the classified title'=>'Please Enter the classified title',
    'Please enter email-id'=>'Please enter email-id',
    'Please enter valid email-id'=>'Please enter valid email-id',
    'Please enter you name'=>'Please enter you name',
    'Please enter mobile no'=>'Please enter mobile no',
    'Please enter valid mobile number'=>'Please enter valid mobile number',
    'minimum 10 number required'=>'minimum 10 number required',
    'maximum 10 numbers only'=>'maximum 10 numbers only',
    'Please select one category..'=>'Please select one category..',
    'please select subcategory after category'=>'please select subcategory after category',
    'please select any one'=>'please select any one',
    'characters left'=>'characters left',


  //company registration help page

    'How to register a company in'=>'How to register a company in',
    'Step '=>'Step ',
    'Click'=>'Click',
    'Add your company'=>'Add your company',
    'from the main menu'=>'from the main menu',
    'It is free'=>'It is free',
    'Fill in the required field marked with'=>'Fill in the required field marked with',


	'Please_login_upload_proposal' => 'Please Login with the valid company user',













];
