	<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */
	
  'free'=>'Бесплатно',
  'Premium'=>'Премиум',
  'Gold'=>'Золотой',
  'Silver'=>'Серебряный',
  //menu
    'myaccount'=>'Мой Аккаунт',
    'invitation'=>'Приглашение к сотрудничеству',
    'news'=>'Новости',
    'downloadapp'=>'Загрузить приложение',
    'login'=>'Aвторизоваться',
	'logout'=>'Выйти',
    'Please enter Email'=>'Адрес электронной почты',
	'Please enter password'=>'Пожалуйста введите пароль',
	'AddCompany'=>'Добавить компанию бесплатно',
	'AddClassified'=>'Разместить бесплатное объявление',
     'RememberMe'=>'Запомни меня',
	 'privacy_policy'=>'Политика конфиденциальности ',
	 'Download the Yellow'=>'Скачать желтые',
	 'Pages of Kazakhstan'=>'Страницы Казахстана',
  //Banner
    'keywords'=>'ключевые слова',
    'what_r_u_looking_for'=>'Я ищу',
    'location'=>'место нахождения',
    'pick_a_location'=>'выбрать место',
    'search'=>'Поиск',
    'categories'=>'категория',
     'Enter Category/ search Text'=>'Введите категорию / текст поиска',
	 'update'=>'Обновить',
	 'CHOOSE CATEGORY AND SUBCATEGORY'=>'ВЫБЕРИТЕ КАТЕГОРИЮ И ПОДКАТЕГОРИЮ',
    'Select Category'=>'Выберите категорию',
	'subcategory'=>'подкатегория',
	//content
    
    'companylist'=>'Ключевые клиенты',
    'classifiedlist'=>'Новые объявления',
	'slogan for company'=>'ЗДЕСЬ МОГЛА БЫТЬ ВАША РЕКЛАМА ',
//Search List
'Find result for'=>'Найти Результат Для ',
'Filter'=>'Фильтр',
'No Data found'=>'записей не найдено',
'Learn more'=>'Узнать больше',
'View map'=>'Посмотреть Карту',
 // Contact Us
 'title'=>'Желтые страницы Казахстана',
 'adminoffice'=>'Офис администратора',
 'centerforresearch'=>'Центр исследований и разработок',
 'location'=>'Место нахождения',
 'writetous'=>'Напишите Нам',
 'yourmessage'=>'Ваше сообщение',
    //footer
    'aboutus'=>'О нас',
       //content for about us
    'history'=>'Компания «International Yellow Pages Management Group» начала свою деятельность в Республике Казахстан с 1995 года.   На протяжении многих лет мы представляем международный бренд «Желтые страницы» в виде печатного издания – индустриально-коммерческого справочника «Yellow Pages of Kazakhstan», веб-сайта: www.ypk.kz и мобильного приложения «Желтые страницы Казахстана». Вы можете найти любую интересующую вас информацию по коммерческим и государственным компаниям Казахстана, некоммерческим и неправительственным организациям, используя поиск по названию, ключевым словам и имеющимся категориям/подкатегориям. Также вы сможете зарегистрировать на платной/бесплатной основе свою компанию или подать частное объявление.',
    'contactinfo'=>'Контактная информация',
       //content for  contact info
    'address1'=>'050009, Республика Казахстан, г. Алматы, пр. Абая, 153, оф.27',

	'address2'=>'Tel. :+7 (727) 3900830, 3900154',

 	'address3'=>'Phone : +7 (701) 3167341, +7 (701) 7594545',
 	'address3'=>'Phone : +7 (701) 3167341, +7 (701) 7594545',

	'address4'=>'e-mail : sales@ypk.kz',
    'usefullinks'=>'Полезные ссылки',
    'home'=>'Главная',
    'contactus'=>'Свяжитесь с нами',
    'subscribe'=>'Подписаться',
    'By subscribing to our mailing list you will always get latest news and updates from us'=>
    'Подписавшись, вы всегда будете в курсе последних новостей и обновлений',
    'enterurmail'=>'Введите адрес электронной почты',
    'Copyrights belong to'=>'Авторские права принадлежат',
	'All rights reserved'=>'Все права защищены',
    'developedby'=>'Разработано',

    //Company Registration
    'Add your listing'=>'Добавить компанию бесплатно',
    'Company Name'=>' Название компании',
    'Contact Name'=>'Контактное лицо',
    'Check Availability'=>'Проверить',
    'Email Address'=>'Адрес электронной почты',
    'Enter your username'=>'Введите имя пользователя',
    'Postcode'=>'Почтовый индекс',
    'Password'=>'Пароль',
    'Enter the password again'=>'Введите пароль повторно',
    'Phonenumber'=>'Номер телефона',
    'Addprefix'=>'(Добавьте +7 и код города)',
    'Street Address'=>'Название улицы',
    'Building / office number'=>'Номер здания / офиса',
    'Mobilenumber'=>'Мобильный номер',
    'Select your category'=>'Выберите категорию',
    'Select subcategory'=>'Выберите подкатегорию',
    'Fax number'=>'Номер факса',
    'SelectCity'=>'Выберите город',
    'SelectArea'=>'Выберите область',
    'Yoursite'=>'Ваш сайт',
	'Startwithhttp'=>'(Начать с http://)',
    'DateofIncorporation'=>'Дата основания',
    'Describe your business'=>'Описание',
    'This is an awesome comment box'=>'Комментарии с  использованием ключевых слов',
    'charactersleft'=>'Осталось символов',
    'HTML links are not allowed'=>'Ссылки HTML не допускаются',
	'Do not use ALL CAPITAL LETTERS'=>'Не используйте ЗАГЛАВНЫЕ БУКВЫ',
    'I agree with the publication of my data'=>'Я согласен с публикацией моих данных',
    'Send'=>'Отправить',
    'cancel' =>'Отмена',
    'Post free classifieds'=>'Разместить объявление',
    'guarenteedescription'=>'Опубликовать бесплатное объявление в  Желтых страницах. Для размещения объявления регистрация не требуется. Ваше объявление будет отправлено непосредственно по выбранной вами категории. Укажите точные контактные данные (номер телефона и адрес электронной почты). ',
   'country code should be valid'=>'
   код страны должен быть действительным',
    //companyregistration validation

    'Please Enter your company name'=>'Введите название вашей компании',
    'Please Enter your name'=>'Пожалуйста, введите ваше имя',
    'Please Enter only character'=>'Пожалуйста, введите только буквы',
    'Please Enter your email aadress'=>'Пожалуйста, введите адрес электронной почты',
    'Please Enter valid email'=>'Введите действующий адрес электронной почты',
    'Email already exist'=>'Электронная почта уже существует',
    'Please Enter Unique User name'=>'Введите уникальное имя пользователя',
    'Please Enter Atleast 6 Characters'=>'Пожалуйста, введите минимум 6 символов',
    'Size should not be more than 12'=>'Не должен превышать 12',
    'Please Enter postalcode'=>'Введите почтовый индекс',
    'Please Enter digits'=>'Введите цифры',
    'Please enter password'=>'Пожалуйста введите пароль',
    'Please enter password again'=>'Введите пароль повторно',
    'Password should match with confirm password'=>'Пароль должен совпадать с подтвержденным паролем',
    'please enter mobile number'=>'Введите Номер телефона',
    'please enter only numbers'=>'Введите только цифры',
    'minimum 10 numbers required'=>'Требуется минимум 10 цифр',
    'maximum 10 numbers only'=>'Максимум 10 цифр',
    'Please enter address'=>'Введите адрес',
    'Please select one city'=>'Выберите один город',
    'please select one area after city'=>'Выберите одну область Выберите одну область',
    'Please select one category'=>'Выберите одну категорию',
    'please select one subcategory after category'=>'Выберите одну подкатегорию',
    'Letters only please'=>'Только буквы',
	'This field is required'=>'Это поле обязательно к заполнению',
    'Maximum 500 characters'=>'Максимум 500 символов',
	'Minimum 30 characters required'=>'Минимум 30 символов',
	'Write Something'=>'Написать текст',
	'Pleaseselectdateofincorporation'=>'Выберите дату регистрации',
	'Tick the box'=>'Поставьте галочку',
	'characters left'=>'Осталось символов',
    'country code should be valid'=>'код страны должен быть действительным',
    'Please_enter_valide_url' => 'Пожалуйста, введите валидный URL',
    //Classified Registration

    'Publish Your Add'=>'Опубликуйте ваше объявление',
    'headings'=>'Пожалуйста, предоставьте свою контактную информацию с точным адресом электронной почты и номер телефона с кодом города.
    Правильная информация обеспечит быстрый ответ на ваше объявление',
    'Add Title'=>'Добавить заголовок',
    'Select one Category'=>'Выберите одну категорию',
    'Email address'=>'E-mail адрес',
    'Your name'=>'Контактное лицо',
    'Select City'=>'Выберите город',
    'Mobile number'=>'Мобильный номер',
    'Add prefix +7'=>'(Добавьте +7)',
    'Your site'=>'Ваш сайт',
    'Start with http'=>'Начать с http://',
    'Phone number'=>'Номер телефона',
    'Add prefix +7 & area code'=>'(Добавьте +7)',
    'Date of Incorporation'=>'Дата основания',
    'Advertisement'=>'Реклама',
    '500 characters left'=>'500 Осталось символов',
    '(HTML links are not allowed.) Do not use ALL CAPITAL LETTERS)'=>
    '(HTML ссылки не допускаются.) Не используйте ЗАГЛАВНЫЕ БУКВЫ)',
    'Use keywords to more easily search your company for your activity, the products and services offered'
    =>'Используйте ключевые слова для эффективного поиска предлагаемых товаров и услуг',
    'Cancel'=>'Отменить',
    'Publish'=>'Опубликовать',
    'Post a free ad'=>'Разместить бесплатное объявление',
   //company registration success message
   'Registered Company Information'=>'Информация о зарегистрированной компании',
   'Your company registered successfully'=>'
Ваша компания успешно зарегистрирована',
   'Description'=>'Описание',
   'Your Registration Data'=>'Ваши регистрационные данные',
   'After approval of the publication of your company by the site administrator, information about your company will be displayed in the search results. The usual publication of the information is free, and is valid for 12 months.'=>
   'После одобрения публикации вашей компании администратором сайта, информация о вашей компании будет отображаться в результатах поиска. Обычная публикация информации бесплатна и действительна в течение 12 месяцев.',
   'Changing the status of your company from the free, to the status of "Premium", will allow 10 times to increase the number of views and responses, compared to the usual publication. Having established the status of "Premium", you can also register one "Premium-Announcement" for free.'=>
   'Изменение статуса вашей компании с бесплатного на статус «Премиум» позволит в 10 раз увеличить количество просмотров и откликов по сравнению с обычной публикацией. Установив статус «Премиум», вы также можете бесплатно опубликовать одно «Премиум-объявление».',
   'After changing the free type of placement of the company in the status of "Premium", your company will be in priority as a result of the search. To update your status, please contact us by e-mail: sales@ypk.kz'=>
   'После изменения бесплатного размещения компании в статусе «Премиум», ваша компания будет в приоритете в результате поиска. Чтобы обновить свой статус,свяжитесь с нами по электронной почте: sales@ypk.kz',
    //Classified Registration Validation

    'Please Enter the classified title'=>'Пожалуйста, введите название объявления',
    'Please enter email-id'=>'Пожалуйста, введите адрес электронной почты',
    'Please enter valid email-id'=>'
Пожалуйста, введите действительный адрес электронной почты',
    'Please enter you name'=>'Пожалуйста, введите ваше имя',
    
   //Classified Registration Success message
   'Registered Classified Information'=>'Информация об объвлении',
   'Your ad has been posted and will be published soon.'=>'Ваше объявление принято и будет опубликовано в ближайшее время.',
   'Data for your ad'=>'Данные для вашего объявления',
   'Classification details'=>'Детали объявления',
   
  //company registration help page

    'How to register a company in'=>'
Как зарегистрировать компанию в',
    'Step'=>'шаг',
    'Click'=>'Нажмите',
    'Add your company'=>'Добавьте свою компанию',
    'from the main menu'=>'из главного меню',
    'It is free'=>'Это бесплатно',
    'Fill in the required field marked with'=>'Заполните отмеченные поля',
'and fill in the exact information. Up-to-date information will help potential users to become interested in your company'=>'и заполните точную информацию. Актуальная информация поможет потенциальным пользователям заинтересоваться вашей компанией
',
'Click the'=>'Нажмите на',
'button . The user will receive a notification letter from ypk.kz that you have successfully registered.'=>'кнопка Пользователь получит письмо с уведомлением от ypk.kz, о том что вы успешно зарегистрированы.',
//Classified registration help page
'How to place free ads?'=>'Как разместить бесплатную рекламу?',
'messageregiter'=>'Вы можете разместить объявление в Желтых страницах Казахстана без регистрации. Это бесплатно. Просто заполните необходимую информацию и разместите свое объявление. Вы можете сделать это в течение нескольких секунд.',
'Click on'=>'Нажмите на',
'from the main menu.'=>'из главного меню.',

'todo'=>'и введите точную информацию, она поможет вам найти потенциальных клиентов',
'button'=>'кнопка',
//Login Popup
'Enter your email/username'=>'Введите адрес электронной почты',
'Forgot your password'=>'Забыли пароль',
'Forgot Password'=>'Забыли пароль',
'Login'=>'Авторизоваться',
'Enter your registered email'=>'Введите зарегистрированный адрес электронной почты',
//Company Details Page
'Findresultfor'=>'Найти результат для',
'Overview'=>'Описание',
'Products'=>'Изображения продукта/товара',
'CompanyProposals'=>'Коммерческое предложение',
'Location'=>'Месторасположение',
'Rate'=>'Связаться с компанией',
'writetous'=>'Вы можете написать напрямую используя форму ниже',
'YourMessage'=>'Ваше сообщение',
'Rating'=>'Рейтинг',
'NoRating'=>'Нет рейтинга',
'Comments'=>'Комментарий',

'Please_login_upload_proposal' => 'Для загрузки коммерческого предложения,просим Вас зарегистрироваться',
'Please_become_a_paid_member_to_upload_proposal_for_this_company' => 'Пожалуйста, станьте платным участником, чтобы загрузить предложение для этой компании',
'Please_login_as_a_company_user_to_upload_your_proposal_for_this_company' => 'Пожалуйста, войдите как зарегистрированный пользователь, чтобы загрузить свое предложение для этой компании',
'new_customers' => 'Новые Ключевые партнеры',
'Number_of_visitors' => 'Количество посетителей',
'Last_week' => 'Прошедшая неделя',
'Last_Month' => 'Прошедший месяц',
'Current_Month' => 'Текущий месяц',

//My Profile
    'Profile'=>'Профиль',
	'Review'=>'Почта',
	'Edit Details'=>'Редактировать детали',
	'Upload Product Image'=>'Изображения продукта/товара',
	'Upload Your Proposal'=>'Коммерческое предложение',
	'Change Password'=>'Изменить пароль',
	'Please reply'=>'Ответьте, пожалуйста',
	'Please select image to upload'=>'Выберите изображение для загрузки',
	'Please add company'=>'Пожалуйста, добавьте компанию',
	'Classified'=>'Объявление',
	'Classified Expired and will not come under search_list'=>'Срок действия объявления истек, и оно не отображается в поисковике',
//User Details
'Comapany Address'=>'Адрес компании',
'Type of Membership'=>'Статус',
'Mobile'=>'Номер телефона',
'email Address'=>'E-mail адрес',
'Product Images'=>'Изображения товара',
'Upload ProfileImage'=>'Изображение профиля',
'Add Classified'=>'Добавить объявление',
'Two'=>'Два',
//Comapany review
'Comapanyreview'=>'Описание компании',
'Classified'=>'Объявление',
'Reviews'=>'Отзывы',
'Comments'=>'Комментарии',
'Date of publication'=>'Дата публикации',
'Reply'=>'Ответить',
'Remove'=>'Удалить',
'No Proposal'=>'Нет предложений',

//Edit Company Details
'Comapany Details'=>'Сведения о компании',
'Enter your mail id'=>'Введите адрес электронной почты',
//Product Image
'CompanyProductImages'=>'Изображения продукта/товара',
'imagevalidation'=>'Минимальный размер должен быть 300 * 200 пикселей в формате jpg, jpeg, png',
'messafeforfree'=>'Пожалуйста, сделайте себя платным участником, чтобы загружать изображения продуктов',
'messageforprofilepic'=>'Пожалуйста, сделайте себя платным участником, чтобы загрузить изображения профиля.',
'You have uploaded maximum number of images'=>'Вы загрузили максимальное количество изображений
',
//Proposals
'Proposals'=>'Коммерческое предложение',
'Remove'=>'Удалить',
'Upload'=>'Загрузить',
'No File Selected'=>'Файл не выбран',
'You can upload proposal of docs,plain text, pdf'=>'Вы можете загрузить коммерческое предложение, документы, текст, PDF',
'Choose File'=>'Выберите файл',
//Change Password
'Change Password'=>'Изменить пароль',
'New Password'=>'Новый пароль' ,
'Retype Password'=>'Введите пароль повторно',
'Update'=>'Обновить',
'Share Your Proposals'=>'Поделитесь своими предложениями',

//Email Template
'Post your classified now'=>'Разместите свое объявление сейчас',
'Upgrade your listing and Enjoy more benefits now'=>'Обновите свой статус и получите больше преимуществ сейчас',
'Post Now'=>'Опубликовать сейчас',
'Reply'=>'Ответить',
'Premium Member'=>'Премиум статус',
'Gold Member'=>'Золотой статус',
'Silver Member'=>'Серебряный статус',
'Read more'=>'Читать дальше (Раздель "Приглашение к сотрудничеству")',
'Upload Product Images'=>'Загрузить изображения продукта',
'Please login with a valid company user'=>'Для загрузки коммерческого предложения,просим Вас зарегистрироваться',
 'Upload Proposals'=>'Загрузить Коммерческое предложение',
];
