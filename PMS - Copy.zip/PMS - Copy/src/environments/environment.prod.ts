export const environment = {
  production: true,
  apiurl:"http://realtycare.xyz:8002/"
};
