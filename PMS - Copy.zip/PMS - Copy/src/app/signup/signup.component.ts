import { Router } from '@angular/router';

import { SignupService } from './../_services/signup.service';
import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

import { ValidateEmailService } from '../_services/validate-email.service';
import { OtpverificationService } from '../_services/otpverification.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AlertService } from '../_services/alert.service';
import { PassMatch } from './_helpers/must-match.validator';




export interface DialogData {
  otp: string;
  name: string;
}
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})



export class SignupComponent {
  title = '  Property Manager Platform ';
  signupcomponent = " Register ";
  otpVerifyForm: FormGroup;
  registerationForm: FormGroup;
  submitted = false;

  displaymsg = "";
  errormessage = "";
  public show = false;
  public regForm = true;
  public otpForm = false;
  showStyle = false;
  email_entered = "";
  errormessage2 = "";
  animal: any;
  otp: any;
  emailPattern: string = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}";
  data: any;
  success: string;
  constructor(public dialog: MatDialog,
    private formBuilder: FormBuilder,
    private otpverificationser: OtpverificationService,
    private regserve: SignupService,
    private validateemail: ValidateEmailService,
    private alert: AlertService,
    private router: Router) { }

  ngOnInit() {
    if ((localStorage.getItem("currUser")) && (localStorage.getItem("currUser"))) {
      this.router.navigate(['/dashboard/pmhome']);
    }
    else {
      localStorage.clear();
    }

    this.registerationForm = this.formBuilder.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirm_password: ['', Validators.required],

    },
      {
        validator: PassMatch.Match("password", "confirm_password")
      }

    );
    this.otpVerifyForm = this.formBuilder.group({
      otpVerification: ['', Validators.required],
    });
  }

  get name() { return this.registerationForm.get('name'); }
  get email() { return this.registerationForm.get('email'); }
  get password() { return this.registerationForm.get('password'); }
  get confirm_password() { return this.registerationForm.get('confirm_password'); }
  get otpVerification() { return this.otpVerifyForm.get('otpVerification'); }

  otpPopup() {
    this.otpverificationser.sendOtp(this.email.value)
      .subscribe(data => {


        if (data.status == 200) {
          this.errormessage = "";
          this.displaymsg = "OTP send Successfully";
        }
        else {
          this.displaymsg = "";
          this.errormessage = data.msg;
        }


      },
        error => {

          this.router.navigate(['/signup']);

        })
    this.alert.error("Please fill all the fields")
    this.router.navigate(['/signup']);
  }
  // const dialogRef = this.dialog.open(OtpdialogComponent, {
  //   width: '350px',
  //   data: {email: this.email.value, otp: this.otp}
  // });

  // dialogRef.afterClosed().subscribe(result => {
  //   console.log('The dialog was closed');
  //   this.animal = result;
  // });

  otpValidation() {
    // this.showfield=true;
    this.otpverificationser.verifyOtp(this.otpVerification.value)
      .subscribe(data => {

        //  localStorage.setItem('currUser', JSON.stringify(data.token));
        // localStorage.setItem('message', JSON.stringify(data.msg)); 
        // alert(JSON.stringify(data.msg))
        //  this.router.navigate(['/login']);

        this.errormessage = "";
      },
        error => {
          this.errormessage = "please enter the OTP";
          this.router.navigate(['/signup']);

        })

    // alert('Please check your email, OTP hasbeen send')
  }
  otpReSend() {
    this.submitted = true;
    if ((this.errormessage2 != "") || (this.registerationForm.invalid)) {


      this.alert.error("Please fill all the fields")
      this.regForm = true;
      this.otpForm = false;
      return
    }
    else {

      this.regForm = false;
      this.otpForm = true;

      this.otpverificationser.resendOtp(this.registerationForm.value)
        .subscribe(data => {

          //  localStorage.setItem('currUser', JSON.stringify(data.token));
          // localStorage.setItem('message', JSON.stringify(data.msg)); 
          // alert(JSON.stringify(data.msg))
          //  this.router.navigate(['/login']);
          this.displaymsg = "Otp has been resend successfully";
          this.errormessage = "";
        },
          error => {
            this.displaymsg = "";
            this.errormessage = "please enter valid email";
            this.router.navigate(['/signup']);

          })
    }
  }
  onbackClick() {

    this.regForm = true;
    this.otpForm = false;

  }
  onSubmit() {
    // console.log('hi')
    this.submitted = true;
    if (this.errormessage2 == "") {

      if (this.otpVerifyForm.invalid) {
        // console.log('hello')
        return;
      }
      else {
        // console.log('helldedeo')
        this.otpverificationser.verifyOtp(this.otpVerification.value)
          .subscribe(data => {

            //  localStorage.setItem('currUser', JSON.stringify(data.token));
            // localStorage.setItem('message', JSON.stringify(data.msg)); 
            // alert(JSON.stringify(data.status))
            //  this.router.navigate(['/login']);
            if (data.status == 200) {
              this.regserve.signup(this.registerationForm.value)
                .subscribe(data => {

                  //  localStorage.setItem('currUser', JSON.stringify(data.token));
                  // localStorage.setItem('message', JSON.stringify(data.msg)); 
                  //  alert(JSON.stringify(data.msg))
                  //  this.router.navigate(['/login']);

                  if (data.status == 200) {
                    this.errormessage = "";
                    this.displaymsg = "Account has been created please login";
                  }
                  else {
                    this.errormessage = "Account creation failed please try again";
                  }
                  // this.show = false;   
                },
                  error => {
                    this.errormessage = "please enter valid email and password";
                    this.router.navigate(['/signup']);

                  })
            }


          },
            error => {
              this.errormessage = "please enter valid OTP";
              this.router.navigate(['/signup']);

            })


      }
    }
    else {
      this.errormessage = "please enter valid email";
    }


    // this.router.navigate(['/login']);

    // console.log(this.registerationForm.value)
    // this.regserve.signup(this.registerationForm.value)
    // .subscribe(data=>
    //  {

    //    localStorage.setItem('currUser', JSON.stringify(data.token));


    //    this.router.navigate(['/login']);

    //  },
    //    error => {
    //      this.success="please enter valid email and password" ;
    //      this.router.navigate(['/signup']);

    //    })





    // this.submitted = true;

    // // stop here if form is invalid
    // if (this.registerationForm.invalid) {
    //     return;
    // }

    // alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerationForm.value))
  }

  emailExist() {
    if(this.registerationForm.invalid){
      return
    }
    this.validateemail.validateEmail(this.email.value)
      .subscribe(data => {

      if (data.status == 200) {
        console.log('200')
         // this.displaymsg ="email already exists";
          // this.errormessage="";
          this.regForm = true;
          this.otpForm = false; 
          console.log('400')
          }
        else {
          this.regForm = false;
          this.otpForm = true;
          this.errormessage2 = "";
          console.log('success')
          // this.errormessage2 = "success";
          // this.errormessage2 = " ";
        }
        this.otpPopup()
      },
        error => {
          console.log('before navigate')
          this.errormessage2 = "email already exists";

          this.router.navigate(['/signup']);

        })


  }

}


  // @Component({
  //   selector: 'emailVerification',
  //   templateUrl: 'emailVerification.component.html',
  // })
  // export class emailVerification {

  //   constructor(
  //     public dialogRef: MatDialogRef<emailVerification>,
  //     @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

  //   onNoClick(): void {
  //     this.dialogRef.close();
  //   }

  // }