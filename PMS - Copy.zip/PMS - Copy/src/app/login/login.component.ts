import { AuthService } from './../_services/auth.service';
import { Component, OnInit, EventEmitter } from '@angular/core';
import {FormControl, Validators, FormGroup, FormBuilder} from '@angular/forms';
import { Router } from '@angular/router';
import { PassMatch } from '../signup/_helpers/must-match.validator';

@Component({
   selector: 'app-login',
   templateUrl: './login.component.html',
   styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  findaccountform:FormGroup;
  otpVerifyForm:FormGroup;
  savePswdForm:FormGroup;
  public findacct=false;
  public loginform=true;
  public otpform=false;
  public passwordform=false;
  name: any;
  constructor(private auth: AuthService, private router:Router,private formBuilder: FormBuilder) { }

  ngOnInit() {
    if((localStorage.getItem("currUser"))&&(localStorage.getItem("currUser")))
    {
      this.router.navigate(['/dashboard/pmhome']);
    }
  else{
    localStorage.clear();
  }
  this.loginForm = this.formBuilder.group({
   
    email: ['', [Validators.required, Validators.email ]],
    password: ['', [Validators.required, Validators.minLength(6)]],
  
    
  })
  this.findaccountform=this.formBuilder.group({
    email: ['', [Validators.required, Validators.email ]]
  })
  this.otpVerifyForm=this.formBuilder.group({
    otp: ['', [Validators.required]]
  })
  this.savePswdForm=this.formBuilder.group({
    password: ['', [Validators.required, Validators.minLength(6)]],
      confirm_password: ['', Validators.required],
  },
  {
    validator: PassMatch.Match("password","confirm_password")
  }) 
  }

  scheman="";
  role="";
  value: any;
title = ' Property Manager Platform ';
logincomponent= " Login ";
success="";
errormessage="";
hide:boolean=false;
// email = new FormControl('', [Validators.required, Validators.email]);
// // email = new FormControl('', [Validators.required]);
//   password=  new FormControl('', [Validators.required]);

  // getErrorMessage() {
  //   return this.email.hasError('required') ? 'Please enter your email' :
  //       this.email.hasError('pattern') ? 'Please enter a valid email' :''
  //       ;
  // }

  // getErrorMessageforPassword(){
  //  return this.password.hasError('required') ? 'Please enter your password' :'';
  //     }

  get email() { return this.loginForm.get('email'); }
  get password() { return this.loginForm.get('password'); }
  get forgotmail(){return this.findaccountform.get('email');}
  get forgotpswd(){return this.savePswdForm.get('password');}
  get cnfrmforgotpswd(){return this.savePswdForm.get('confirm_password');}

  onSubmit(){
    // localStorage.setItem('currshema', JSON.stringify('pm1'));
   
   this.auth.getShcemaName(this.email.value)
   .subscribe(data=>
    {
      this.scheman=data.schema_name;
  
      // alert (this.scheman)
          localStorage.setItem('currshema', JSON.stringify(this.scheman));
          this.loginWithSchema()
      
    })    // console.log(this.email.value)
    
     
}


loginWithSchema()
{
  if(this.loginForm.invalid){
    return
  }
  else {
    this.auth.login(this.email.value,this.password.value)
    .subscribe(data=>
     {
            
       localStorage.setItem('currshema', JSON.stringify(data.schema_name));
       localStorage.setItem('currUser', JSON.stringify(data.token));
       localStorage.setItem('user_id', JSON.stringify(data.user_id));
      //  localStorage.setItem('user_name', JSON.stringify(data.name));
       
         //  alert(data.token)
        // this.router.navigate(['/dashboard/pmhome']);
        this.name=data.name;
        localStorage.setItem('user_name', JSON.stringify(this.name));
       this.role=data.role;
       localStorage.setItem('user_role', JSON.stringify(this.role));
       if(this.role=="Property Manager"){

       
         this.router.navigate(['/dashboard/pmhome']);
     
       }
       else if(this.role=="Owner") {
               this.router.navigate(['/dashboard/ohome']);
             }
       else if(this.role=="Tenant")
       {
        this.router.navigate(['/dashboard/thome']);
       }
       else {
         this.success="Role is not assigned to the user" ;
         this.router.navigate(['']);
       }
     },
       error => {
         
         this.success="invalid email/password" ;
         this.router.navigate(['']);
       //console.log(error.error.statusDetails.statusMessage)
       })
  }
  
}

findaccount(){
  this.loginform=false;
  this.otpform=false;
  this.passwordform=false;
  this.findacct=true;
  
}
sendOtp(){
  if(this.findaccountform.invalid){
    return
  }
  else {
  

  this.auth.sendOtp(this.findaccountform.value)
        .subscribe(data => {

        
          if (data.status == 200) {
            localStorage.setItem('currshema', JSON.stringify(data.schema_name));
            // this.alert.success ="";
            this.errormessage = "";
            this.loginform=false;
            this.otpform=true;
            this.passwordform=false;
            this.findacct=false; 
           
          }
          else {
           
            this.errormessage = data.msg;
          }
  })
}
}

verifyOtp()
{
  if(this.otpVerifyForm.invalid){
    return
  }
  else{

  this.auth.verifyOtp(this.otpVerifyForm.value)
  .subscribe(data => {

  
    if (data.status == 200) {
      this.loginform=false;
      this.otpform=false;
      this.passwordform=true;
      this.findacct=false; 
      this.errormessage = "";
     
    }
    else {
     
      this.errormessage = data.msg;
    }
})
  }
}

savePswd(){
  // alert('ok1')
  if(this.savePswdForm.invalid){
    // alert('ok5')
    return
  }
  else {
    // alert('ok2')
  this.auth.savePswd(this.forgotmail.value,this.forgotpswd.value,this.cnfrmforgotpswd.value)
  .subscribe(data => {

    // alert('ok3')
    if (data.status == "password reset successfully") {
  this.loginform=true;
  this.otpform=false;
  this.passwordform=false;
  this.findacct=false;
  this.errormessage = "";
     
    }
    
    else {
  // this.loginform=true;
  // this.otpform=false;
  // this.passwordform=false;
  // this.findacct=false;
  // this.errormessage = "";
    //  alert('ok4')
      // this.errormessage = "Password reset successfully";
    }
}) 
  }
}
}
    
   




  
 
    

  



