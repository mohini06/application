import { Jwtinterceptor } from './jwtinterceptor';

describe('Jwtinterceptor', () => {
  it('should create an instance', () => {
    expect(new Jwtinterceptor()).toBeTruthy();
  });
});
