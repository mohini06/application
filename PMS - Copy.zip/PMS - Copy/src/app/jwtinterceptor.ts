import { LoaderService } from './_services/loader.service';
import { environment } from './../environments/environment';
import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';
// import { JwtHelperService } from '@auth0/angular-jwt';
import { NgIf } from '@angular/common';

@Injectable()

export class Jwtinterceptor implements HttpInterceptor{

    auth: any;

    constructor(private route: ActivatedRoute,private loaderService: LoaderService,
        private router: Router) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        // add authorization header with jwt token if available
       
        this.showLoader();
        let baseurl = "";
        let reqUrl = "";
        let token="";
        let currentSchema=JSON.parse(localStorage.getItem('currshema'));
        let role=JSON.parse(localStorage.getItem('user_role'));
        let currentUser = JSON.parse(localStorage.getItem('currUser'));
        if (currentUser ) {
        token=currentUser;
        }
       
      
            baseurl = environment.apiurl;
            reqUrl=baseurl+request.url
            if((request.url=='schema/')||(request.url=='email_valid/')||(request.url=='registration_otp/')||(request.url=='validate_otp/')||(request.url=='registration/')||(request.url=='resend_otp/')||(request.url=='forgot_password_otp/'))
            {
                reqUrl=baseurl+request.url

            }
            else
            {
                 reqUrl = reqUrl.replace("http://", "http://"+ currentSchema+".");
                 console.log(reqUrl) 
            }
           

            // reqUrl = request.url 
            console.log(reqUrl)
            // console.log(token)
            request = request.clone({
                url: reqUrl,
                setHeaders: {
                  'Authorization': `JWT ${token}`,
                    // 'Content-Type': 'application/json' 
                }
            });
        
 
        return next.handle(request).pipe(tap((event: HttpEvent<any>) => {
            if (event instanceof HttpResponse) {
                console.log("success inter")
                this.onEnd();
            }
        },
            (err: any) => {
                console.log("error inter")

                this.onEnd();
            }));
          
    }
 private onEnd(): void {
        this.hideLoader();
    }

    private showLoader(): void {
        this.loaderService.show();
    }

    private hideLoader(): void {
        this.loaderService.hide();
    }
}
   


  

