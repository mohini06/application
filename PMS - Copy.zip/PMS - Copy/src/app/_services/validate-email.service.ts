import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ValidateEmailService {
  apiurl = environment.apiurl
  constructor(private http: HttpClient) { }

  validateEmail(email:any){
    return this.http.post<any>('email_valid/',{email:email})
    .pipe(map(validateEmail => {
    return validateEmail;
    }));
  }

// owenerEmail(email:any){
//     return this.http.post<any>('email_valid/',{email:email})
//     .pipe(map(owenerEmail => {
//     return owenerEmail;
//     }));
//   }
  
// tenantEmail(email:any){
//   return this.http.post<any>('tenant-email-validation/',{email:email})
//   .pipe(map(tenantEmail => {
//   return tenantEmail;
//   }));
// }
}
