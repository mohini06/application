import { TestBed } from '@angular/core/testing';

import { ViewownerService } from './viewowner.service';

describe('ViewownerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ViewownerService = TestBed.get(ViewownerService);
    expect(service).toBeTruthy();
  });
});
