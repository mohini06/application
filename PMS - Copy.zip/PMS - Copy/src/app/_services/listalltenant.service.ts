import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ListalltenantService {

  constructor(private http: HttpClient) { }

  getAllTenant(){
    
    return this.http.get<any>('list-tenant/')
  .pipe(map(getAllTenant => {
  return getAllTenant;
  }));
  }
  getAllUnselectedProperty(){
    
    return this.http.get<any>('list-property-unselected-tenant/')
  .pipe(map(getAllUnselectedProperty => {
  return getAllUnselectedProperty;
  }));
  }
}
