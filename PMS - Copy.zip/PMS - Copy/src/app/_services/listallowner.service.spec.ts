import { TestBed } from '@angular/core/testing';

import { ListallownerService } from './listallowner.service';

describe('ListallownerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ListallownerService = TestBed.get(ListallownerService);
    expect(service).toBeTruthy();
  });
});
