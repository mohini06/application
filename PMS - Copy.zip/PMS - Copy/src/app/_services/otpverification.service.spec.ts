import { TestBed } from '@angular/core/testing';

import { OtpverificationService } from './otpverification.service';

describe('OtpverificationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: OtpverificationService = TestBed.get(OtpverificationService);
    expect(service).toBeTruthy();
  });
});
