import { TestBed } from '@angular/core/testing';

import { ViewpropertyService } from './viewproperty.service';

describe('ViewpropertyService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ViewpropertyService = TestBed.get(ViewpropertyService);
    expect(service).toBeTruthy();
  });
});
