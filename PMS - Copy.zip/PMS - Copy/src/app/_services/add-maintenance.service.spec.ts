import { TestBed } from '@angular/core/testing';

import { AddMaintenanceService } from './add-maintenance.service';

describe('AddMaintenanceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AddMaintenanceService = TestBed.get(AddMaintenanceService);
    expect(service).toBeTruthy();
  });
});
