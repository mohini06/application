import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
providedIn: 'root'
})

export class AuthService {
schemaName=""; 
user_id=""; 
rolepermission:any;
apiurl = environment.apiurl
constructor(private http: HttpClient) { }

 
getShcemaName(username:any){
    return this.http.post<any>('schema/',{username:username.toLowerCase()})
    .pipe(map(getShcemaName => {
    return getShcemaName;
    }));
}
// getUserid(userid:any){
//   return this.http.post<any>('schema/',{userid:userid})
//   .pipe(map(getUserid => {
//   return getUserid;
//   }));
// }
login(username:any,password:any)
{
    if (localStorage.getItem('currshema')) {    
   this.schemaName=localStorage.getItem('currshema').replace(/['"]+/g, '');

// alert(this.schemaName)
return this.http.post<any>('login/',{username:username.toLowerCase(),password:password})
.pipe(map(login => {
  
  this.rolepermission=login.role;
  console.log(this.rolepermission)
return login;
}));
}
}
// isLoggedIn()
// {
//     if (localStorage.getItem('currUser')) {
        
//         // logged in so return true
//         return true;
//     }
// }

sendOtp(formdata:any){
   
  return this.http.post<any>('forgot_password_otp/',formdata)
  .pipe(map(sendOtp => {
  return sendOtp;
  }));
  
}
verifyOtp(formdata:any)
{
  console.log('yes')
 return this.http.post<any>('validate_otp/',formdata)
 .pipe(map(verifyOtp => {
 return verifyOtp;
 }));
}
savePswd(username:any,password:any,confirm_password:any){
  return this.http.post<any>('forgot_password/',{username:username,password:password,confirm_password:confirm_password})
  .pipe(map(savePswd => {
  return savePswd;
  }));
}
changePswd(current_password:any,new_password:any,confirm_password:any,user_id:any){

  
  return this.http.post<any>('change_password/',{current_password:current_password,new_password:new_password,confirm_password:confirm_password,user_id:user_id})
  .pipe(map(changePswd => {
  return changePswd;
  }));
}
logout() {
    localStorage.removeItem('currUser');
    localStorage.removeItem('currshema');
  }

}