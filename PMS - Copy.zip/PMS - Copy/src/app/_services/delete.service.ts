import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class DeleteService {
 
  constructor(private http: HttpClient) { }
deletePropertyService(deleteID:any){
  return this.http.delete<any>('delete-property/'+deleteID+'/')

}
deleteOwnerService(deleteID:any){
  return this.http.delete<any>('delete-landlord/'+deleteID+'/')

}
deleteTenantService(deleteID:any){
  return this.http.delete<any>('delete-tenant/'+deleteID+'/')

}
deletemaintenanceService(deleteID:any){
  return this.http.delete<any>('delete-maintenance/'+deleteID+'/')

}

}
