import { TestBed } from '@angular/core/testing';

import { AddtenantService } from './addtenant.service';

describe('AddtenantService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AddtenantService = TestBed.get(AddtenantService);
    expect(service).toBeTruthy();
  });
});
