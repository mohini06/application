import { TestBed } from '@angular/core/testing';

import { IssuetypesService } from './issuetypes.service';

describe('IssuetypesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: IssuetypesService = TestBed.get(IssuetypesService);
    expect(service).toBeTruthy();
  });
});
