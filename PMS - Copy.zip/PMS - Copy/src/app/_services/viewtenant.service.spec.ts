import { TestBed } from '@angular/core/testing';

import { ViewtenantService } from './viewtenant.service';

describe('ViewtenantService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ViewtenantService = TestBed.get(ViewtenantService);
    expect(service).toBeTruthy();
  });
});
