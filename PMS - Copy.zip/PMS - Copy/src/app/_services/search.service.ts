import { environment } from './../../environments/environment.prod';
import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {map, tap} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SearchService {

  
  constructor(private http: HttpClient) { }
  
  search(textdata): Observable<any> {
if(textdata){

    return this.http.get<any>('dashboardsearch/?search='+ textdata)
    .pipe(
      tap((response) => {
        response = response.search_details
          // .map(user => new User(user.type, user.text,user.id))
          // Not filtering in the server since in-memory-web-api has somewhat restricted api
          // .filter(user => user.text.includes(textdata))

        return response;
      })
      );
    }else{
      // alert("data not found")
      return;
    }
  }
 
 

  getSearchlist(serachId:any){
    
    return this.http.get<any>('search/?search='+serachId)
  }

  getSearchlistDashboard(text:any){
    
    return this.http.get<any>('dashboardsearch/?search='+text)
  }
  getSearchlistProperty(serachId:any){
    return this.http.get<any>('property-search/?search='+serachId.search_key)
  }
  getSearchlistOwner(serachId:any) {
    return this.http.get<any>('owner-search/?search='+serachId.search_key)

  }
  getSearchlistTenant(serachId:any){
    return this.http.get<any>('tenant-search/?search='+serachId.search_key)

  }
  getSearchlistMaintenance(serachId:any){
    return this.http.get<any>('maintenance-search/?search='+serachId.search_key)

  }
}  


export class User {
  constructor(public type: any, public text: any,public id: any) {}
}

export interface IUserResponse {
  
  search_details: User[];
}