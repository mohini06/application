import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { environment } from './../../environments/environment.prod';
import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class PmdashboardService {
apiurl = environment.apiurl;
  constructor(private http: HttpClient) { }

  getNewMaintenaceRequest(){
  return  this.http.get<any>('dashboardrequestcount/')
  .pipe(map(getNewMaintenaceRequest => {
    return getNewMaintenaceRequest;
    }));
  }
//   getUpdatedMaintenaceRequest(){
//     return this.http.get<any>(this.apiurl + 'maintenanceupdatedrequest')
//     .pipe(map(getUpdatedMaintenaceRequest => {
// return getUpdatedMaintenaceRequest;
//     }))
//   }
}
