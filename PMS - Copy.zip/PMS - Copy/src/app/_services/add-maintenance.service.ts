import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { DatePipe } from '@angular/common';
@Injectable({
  providedIn: 'root'
})
export class AddMaintenanceService {
 
  constructor(private http: HttpClient,private datepipe:DatePipe) { }
  transformDate(date) {
    return this.datepipe.transform(date, 'yyyy-MM-dd'); 
  }
  addMaintenance(formData:any){
    
    formData.requested_date=this.transformDate(formData.requested_date)
    formData.work_start_date=this.transformDate(formData.work_start_date)
    formData.due_date=this.transformDate(formData.due_date)
        // formData.issue_type=formData.issue+'-'+formData.subissuetype;

    // console.log(formData)
    //    return this.http.post<any>(this.apiurl+'add-maintenance/',formData)
    // .pipe(map(addMaintenance => {
    // return addMaintenance;
    // }));
       
    return this.http.post<any>('add-maintenance/',formData)
    .pipe(map(addMaintenance => {
    return addMaintenance;
    }));
  
  }
  updateMaintenance(formData:any,id){
    
    
    formData.requested_date=this.transformDate(formData.requested_date)
    formData.work_start_date=this.transformDate(formData.work_start_date)
    formData.due_date=this.transformDate(formData.due_date)
    // formData.issue_type=formData.issue+'-'+formData.subissuetype;

    // console.log(formData)
  
      
       return this.http.put<any>('update-maintenance/'+id+'/',formData)
    .pipe(map(updateMaintenance => {
    return updateMaintenance;
    }));
  
  }
  // addImage(uploadData:any){
  //   // console.log(img)
  //   return this.http.post<any>('add-maintenance-images/',uploadData)
  //   .pipe(map(addImage => {
  //   return addImage;
  //   }));
  // }
  // addVideo(uploadData:any){
  //   return this.http.post<any>('add-maintenance-videos/',uploadData)
  //   .pipe(map(addVideo => {
  //   return addVideo;
  //   }));
  // }


  getlistAllMaintenance(){
    return this.http.get<any>('list-maintenance/')
    .pipe(map(getlistAllMaintenance => {
      return getlistAllMaintenance;
      }));
  }
  viewMaintenanceDetail(id){
    return this.http.get<any>('list-maintenance/'+id+'/')
    .pipe(map(viewMaintenanceDetail => {
      return viewMaintenanceDetail;
    
      }));
  
  }
  viewMaintenanceHistory(id){
    return this.http.get<any>('maintenance-history/'+id+'/')
    .pipe(map(viewMaintenanceHistory => {
      return viewMaintenanceHistory;
    }))
  }
}
