import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SignupService {
  apiurl = environment.apiurl
  constructor(private http: HttpClient) { }

  signup(formData: any) {

    // return this.http.post<any>(this.apiurl+'tenant-reg/',{name:'mohini',password:'data@123',email:'mohini23@gmail.com',confirm_password:'data@123'})
    // .pipe(map(signup => {
    // return signup;
    // }));
    // return this.http.post<any>('http://192.168.137.14:8080/tenant-reg/',formData)
    // .pipe(map(signup => {
    // return signup;
    // }));

    return this.http.post<any>('registration/', formData)
      .pipe(map(signup => {
        return signup;
      }));
  }
  isLoggedIn() {
    if (localStorage.getItem('currUser')) {
      // logged in so return true
      return true;
    }
  }

}


