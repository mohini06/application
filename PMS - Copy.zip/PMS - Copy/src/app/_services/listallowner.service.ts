import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import {
  Router,
  NavigationEnd,
  ActivatedRoute,
  ActivatedRouteSnapshot,
  NavigationStart
} from "@angular/router";
@Injectable({
  providedIn: 'root'
})
export class ListallownerService {
 
  constructor(private http: HttpClient,private route: ActivatedRoute) { }
  
  getAllOwner(){
   
    
    return this.http.get<any>('list-landlord/')
  .pipe(map(getAllOwner => {
  return getAllOwner;
  }));
  
  }
  getAllUnselectedProperty(){
 
    return this.http.get<any>('list-property-unselected-owner/')
  .pipe(map(getAllUnselectedProperty => {
  return getAllUnselectedProperty;
  }));
  }
  getfiveUnselectedProperty(){
    return this.http.get<any>('unselected-list-property//')
    .pipe(map(getfiveUnselectedProperty => {
    return getfiveUnselectedProperty;
    }));
  }
}
