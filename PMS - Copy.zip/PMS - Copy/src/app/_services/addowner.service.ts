import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class AddownerService {
  
  constructor(private http: HttpClient) { }
  addOwner(formData:any){
    // return this.http.post<any>(this.apiurl+'add-landlord/',
    // formData)
    // .pipe(map(addOwner => {
    // return addOwner;
    // }));
 
    return this.http.post<any>('add-landlord/',formData)
    .pipe(map(addMaintenance => {
    return addMaintenance;
    }));
  
   
  }
  sendDefaultPswd(email:any){
    return this.http.post<any>('owner-registration/',{email:email})
    .pipe(map(sendDefaultPswd => {
    return sendDefaultPswd;
    }));
  }
updateOwner(formData:any,id){

    return this.http.put<any>('update-landlord/'+id + '/',
    formData)
    .pipe(map(updateOwner => {
    return updateOwner;
    }));
  }
}
