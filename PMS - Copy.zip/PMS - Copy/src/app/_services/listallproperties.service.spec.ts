import { TestBed } from '@angular/core/testing';

import { ListallpropertiesService } from './listallproperties.service';

describe('ListallpropertiesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ListallpropertiesService = TestBed.get(ListallpropertiesService);
    expect(service).toBeTruthy();
  });
});
