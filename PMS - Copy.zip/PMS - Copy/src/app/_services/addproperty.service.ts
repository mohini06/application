import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { DatePipe } from '@angular/common';
@Injectable({
  providedIn: 'root'
})
export class AddpropertyService {
  // parkingflag: boolean = false;
  // val;

 
  constructor(private http: HttpClient, private datepipe: DatePipe) { }
  transformDate(date) {
    return this.datepipe.transform(date, 'yyyy-MM-dd');
  }

  // getFurnishdetail() {
  //   return this.http.get<any>('property-furnished/')
  //     .pipe(map(getFurnishdetail => {
  //       return getFurnishdetail;
  //     }));
  // }
  // getFurnishSubtypeDtetail(id) {
  //   return this.http.get<any>('property-furnished-data/', { params: { propertyfurnishedid: id } })
  //     .pipe(map(getFurnishSubtypeDtetail => {
  //       return getFurnishSubtypeDtetail;
  //     }));
  // }
  getFurnishdetail() {
      return this.http.get<any>('property-furnished/')
        .pipe(map(getFurnishdetail => {
          return getFurnishdetail;
        }));
    }
  getAmenties() {

    return this.http.get<any>('property-amentities/')
      .pipe(map(getAmenties => {
        return getAmenties;
      }));
  }
  getpropertytype() {
    return this.http.get<any>('property-type/')
      .pipe(map(getpropertytype => {
        return getpropertytype;
      }));
  }
  getTenanttype(id) {
    return this.http.get<any>('tenant-type/', { params: { propertytypeid: id } })
      .pipe(map(getTenanttype => {
        return getTenanttype;
      }));
  }
  addProperty(formData: any) {
    
    formData.available_from = this.transformDate(formData.available_from)
    formData.available_to = this.transformDate(formData.available_to)
    if (localStorage.getItem('currshema')) {    
     
    return this.http.post<any>('add-property/',
      formData)
      .pipe(map(addProperty => {
        return addProperty;
      }));
    }
  }
  updateProperty(formData: any, id) {
   
    formData.available_from = this.transformDate(formData.available_from)
    formData.available_to = this.transformDate(formData.available_to)
    if (localStorage.getItem('currshema')) {    
     
    return this.http.put<any>('update-property/' + id + '/',
      formData)
      .pipe(map(updateProperty => {
        return updateProperty;
      }));
    }
  }
}
