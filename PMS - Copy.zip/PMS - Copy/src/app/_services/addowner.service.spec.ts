import { TestBed } from '@angular/core/testing';

import { AddownerService } from './addowner.service';

describe('AddownerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AddownerService = TestBed.get(AddownerService);
    expect(service).toBeTruthy();
  });
});
