import { TestBed } from '@angular/core/testing';

import { ListalltenantService } from './listalltenant.service';

describe('ListalltenantService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ListalltenantService = TestBed.get(ListalltenantService);
    expect(service).toBeTruthy();
  });
});
