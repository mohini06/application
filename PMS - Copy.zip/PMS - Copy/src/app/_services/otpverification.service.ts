import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class OtpverificationService {
  apiurl = environment.apiurl
  constructor(private http: HttpClient) { }
  sendOtp(email:any){
   
    return this.http.post<any>('registration_otp/',{email:email})
    .pipe(map(sendOtp => {
    return sendOtp;
    }));
    
  }
resendOtp(formdata:any)
{
  return this.http.post<any>('resend_otp/',{email:formdata.email})
  .pipe(map(resendOtp => {
  return resendOtp;
  }));
}
  verifyOtp(otp:any)
  {
    console.log('yes')
   return this.http.post<any>('validate_otp/',{otp:otp})
   .pipe(map(verifyOtp => {
   return verifyOtp;
   }));
  }
 
}
