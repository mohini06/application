import { TestBed } from '@angular/core/testing';

import { PmdashboardService } from './pmdashboard.service';

describe('PmdashboardService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PmdashboardService = TestBed.get(PmdashboardService);
    expect(service).toBeTruthy();
  });
});
