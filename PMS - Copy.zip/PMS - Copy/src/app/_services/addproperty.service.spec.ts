import { TestBed } from '@angular/core/testing';

import { AddpropertyService } from './addproperty.service';

describe('AddpropertyService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AddpropertyService = TestBed.get(AddpropertyService);
    expect(service).toBeTruthy();
  });
});
