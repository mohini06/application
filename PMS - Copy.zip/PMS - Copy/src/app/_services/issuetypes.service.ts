import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class IssuetypesService {
 
  constructor(private http: HttpClient) { }

  getIssue(){

    return this.http.get<any>('issue-type/')
  .pipe(map(getIssue => {
  return getIssue;
  }));
  }
 getSubIssue(id:any){
  let params = new HttpParams();
  return this.http.get<any>('sub-issue-type/',{params:{id:id}})
  .pipe(map(getSubIssue => {
  return getSubIssue;
  }));
 }
}
