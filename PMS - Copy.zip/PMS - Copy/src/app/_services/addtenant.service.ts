import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AddtenantService {
 
  constructor(private http: HttpClient) { }
  addTenant(formData:any){
   
    return this.http.post<any>('add-tenant/',
    formData)
    .pipe(map(addTenant => {
    return addTenant;
    }));
  
  }
  sendDefaultPswd(email:any){
    return this.http.post<any>('tenant-registration/',{email:email})
    .pipe(map(sendDefaultPswd => {
    return sendDefaultPswd;
    }));
  }
updateTenant(formData:any,id){
 
    return this.http.put<any>('update-tenant/'+ id + '/',
    formData)
    .pipe(map(updateTenant => {
    return updateTenant;
    }));
  }
  
}
