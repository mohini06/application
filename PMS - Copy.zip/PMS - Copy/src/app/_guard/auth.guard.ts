import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot,Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(private router: Router) { }

  getSchema(){
  //   if (schemaName.getItem('currshema')) {
  //     // logged in so return true
  //     return true;
  // }else{
  // // not logged in so redirect to login page with the return url
  // this.router.navigate(['']);
  // return false;
  // }
  }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      if (localStorage.getItem('currUser')) {
          // logged in so return true
          return true;
      }else{
      // not logged in so redirect to login page with the return url
      this.router.navigate(['']);
      return false;
  }
  //  if (localStorage.getItem('currshema')) {
  //       // logged in so return true
  //       return true;
  //   }else{
  //   // not logged in so redirect to login page with the return url
  //   this.router.navigate(['']);
  //   return false;
  //   }
 
}
  

}