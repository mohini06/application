import { from } from 'rxjs';

import { Jwtinterceptor } from './jwtinterceptor';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgScrollbarModule } from 'ngx-scrollbar';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { AppRoutingModule } from './app-routing.module';
import { MatTabsModule, MatDatepickerModule, MatSlideToggleModule, MatButtonToggleModule, MatDividerModule, MatStepperModule, MatDialogModule, MatExpansionModule, MatBadgeModule, MatListModule, MatNativeDateModule, MatFormFieldModule, MatButtonModule, MatCheckboxModule,MatRadioModule, MatToolbarModule, MatInputModule, MatProgressSpinnerModule, MatCardModule, MatMenuModule, MatIconModule, MatSelectModule, MatSidenavModule, MatSliderModule, MatChipsModule, MatTableModule, MatGridListModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { DashboardModule } from './dashboard/dashboard.module';
import { DialogOverviewExampleDialog } from './dashboard/property/add-property/dialog-overview-example-dialog';
import { DialogOverviewTenanttypDialog } from './dashboard/property/add-property/dialog-overview-tenanttyp-dialog';
// import { DialogOverviewTenantnoDialog } from './dashboard/property/add-property/dialog-overview-tenantno-dialog';
import { MatFileUploadModule } from 'angular-material-fileupload/matFileUpload.module';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ConfirmationDialogComponent } from './confirmation-dialog/confirmation-dialog.component';

import { MatDialog } from '@angular/material';


// import { ImageDialog } from './dashboard/maintenance/view-maintenace/view-maintenace.component';





@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    PageNotFoundComponent,
    ConfirmationDialogComponent,


   

  
  ],
  imports: [
    DashboardModule,
    MatTabsModule,
    MatDatepickerModule,
    MatSlideToggleModule, MatButtonToggleModule, MatDividerModule,
    MatDialogModule,
    MatStepperModule,
    MatExpansionModule,
    NgMultiSelectDropDownModule,
    NgScrollbarModule,
    MatListModule,
    MatBadgeModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    MatNativeDateModule,
    MatFormFieldModule,
    MatButtonModule,
    MatCheckboxModule,
    MatRadioModule,
    MatToolbarModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatCardModule,
    MatMenuModule,
    MatIconModule,
    MatSelectModule,
    MatMenuModule,
    MatSidenavModule,
    MatSliderModule,
    MatChipsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    MatGridListModule,
    MatTableModule,
    MatFileUploadModule,

  ],
  providers: [ 
    {
    provide: HTTP_INTERCEPTORS,
    useClass: Jwtinterceptor,
    multi: true
  }
],
  entryComponents: [DialogOverviewExampleDialog,DialogOverviewTenanttypDialog],
  bootstrap: [AppComponent]
})
export class AppModule { }
