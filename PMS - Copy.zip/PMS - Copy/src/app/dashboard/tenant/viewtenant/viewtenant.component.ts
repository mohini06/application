import { environment } from 'src/environments/environment';
import { Component, OnInit, Inject } from '@angular/core';
import { ViewtenantService } from './../../../_services/viewtenant.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfirmationDialogComponent, ConfirmDialogModel } from './../../../confirmation-dialog/confirmation-dialog.component';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-viewtenant',
  templateUrl: './viewtenant.component.html',
  styleUrls: ['./viewtenant.component.css']
})
export class ViewtenantComponent implements OnInit {
  data: any;
  breakpoint: number;
  result: string = '';
  imagesStored: any;
  filesStored: any;
  schemaname = localStorage.getItem('currshema').replace(/['"]+/g, '');
  apiurl = environment.apiurl;


  constructor(public dialog: MatDialog, public router: Router, private viewtenantservice: ViewtenantService, private route: ActivatedRoute) { }

  ngOnInit() {
    console.log(this.apiurl)

    this.getTenantdetail(this.route.snapshot.queryParams['data']);
    // console.log(this.route.snapshot.queryParams['data'])
    this.breakpoint = (window.innerWidth <= 800) ? 2 : 2;

  }
  getTenantdetail(id) {


    this.viewtenantservice.getTenantDetail(id)
      .subscribe(data => {
        this.data = data;
        this.imagesStored = data['images'];
        this.filesStored = data['files'];
        console.log(this.apiurl)
        this.apiurl = this.apiurl.replace("http://", "http://" + this.schemaname + ".").slice(0, -1);
        console.log(this.apiurl)

        //   this.imagesStored=data.images;
        //   this.filesStored=this.data.files;
        // this.apiurl=this.apiurl.slice(0,-1);

      },
        error => {



        })
  }
  onResize(event) {
    this.breakpoint = (event.target.innerWidth <= 800) ? 2 : 2;
  }
  editTenant(tenantId: string) {
    this.router.navigate(['/dashboard/add_tenant'], { queryParams: { data: tenantId } })
  }
  openImageDialog(path) {
    const dialogRef = this.dialog.open(ImageTenantDialog, {

      data: { attacpath: path }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log(`Dialog result: ${result}`);
    });
  }
  confirmDialog(id): void {
    const message = `Are you sure you want to delete?`;

    const dialogData = new ConfirmDialogModel("Confirm Action", message, id, "tenant");

    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      maxWidth: "400px",
      data: dialogData
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      this.result = dialogResult;
    });
  }
}
@Component({
  selector: 'image_tenant-dialog',
  templateUrl: 'image_tenant-dialog.html',
})

export class ImageTenantDialog {
  schemaname = localStorage.getItem('currshema').replace(/['"]+/g, '');
  apiurl = environment.apiurl.replace("http://", "http://" + this.schemaname + ".").slice(0, -1);
  constructor(
    public dialogRef: MatDialogRef<ImageTenantDialog>,
    @Inject(MAT_DIALOG_DATA) public data: attchment, private Router: ActivatedRoute) { }


}
export interface attchment {
  url: string;
  path: string;
  attacpath;
}
