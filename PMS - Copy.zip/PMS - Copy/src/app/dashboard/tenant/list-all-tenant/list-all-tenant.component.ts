import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ListalltenantService } from 'src/app/_services/listalltenant.service';
import { DataService } from 'src/app/_services/data.service';

@Component({
  selector: 'app-list-all-tenant',
  templateUrl: './list-all-tenant.component.html',
  styleUrls: ['./list-all-tenant.component.css']
})
export class ListAllTenantComponent implements OnInit {

  data: any[];
  id: any;
  tenants: boolean = true;
  constructor(private dataService: DataService, public router: Router, private listtenants: ListalltenantService) { }

  ngOnInit() {
    this.searchData()
    this.getTenant();
  }


  getTenant() {
    this.listtenants.getAllTenant()
      .subscribe(data => {
        this.data = data;
        if (this.data.length > 0) {

          this.tenants = false
        }
        else {

          this.tenants = true
        }
        //  console.log(this.data)
      },
        error => {

          this.data = [];

        })

  }
  searchData() {
    this.dataService.searchValue.subscribe(data => {

      // console.log(data)
      if (data.type == "tenant") {
        // console.log(data)
        this.data = data.data
      }

    },
      error => {

        // console.log(error)
      })
  }

  getId(tenantId: string) {

    this.router.navigate(['/dashboard/view_tenant'], { queryParams: { data: tenantId } })
  }


}
