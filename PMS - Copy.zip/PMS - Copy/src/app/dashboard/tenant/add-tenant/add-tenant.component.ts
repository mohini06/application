import { ListalltenantService } from './../../../_services/listalltenant.service';
import { ValidateEmailService } from "./../../../_services/validate-email.service";
import { ViewtenantService } from "./../../../_services/viewtenant.service";
import { Component, OnInit } from "@angular/core";
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators
} from "@angular/forms";
import { Router, ActivatedRoute } from "@angular/router";
import { AddtenantService } from "./../../../_services/addtenant.service";
import { ListallpropertiesService } from "./../../../_services/listallproperties.service";
import { FileUploader, FileLikeObject } from "ng2-file-upload";
import { AlertService } from './../../../_services/alert.service';
import { DatePipe } from "@angular/common";
import { environment } from 'src/environments/environment';

export interface Property {
  value: string;
  viewValue: string;
}

@Component({
  selector: "app-add-tenant",
  templateUrl: "./add-tenant.component.html",
  styleUrls: ["./add-tenant.component.css"]
})
export class AddTenantComponent implements OnInit {
  public uploaderImg: FileUploader = new FileUploader({
    // allowedFileType: ['png', 'jpg','jpeg','PNG','JPG','JPEG']
  });
  public uploaderfile: FileUploader = new FileUploader({
    // allowedFileType: ['txt', 'pdf','doc']
  });
  urlId;
  imagesStored: any;
  filesStored: any;
  schemaname = localStorage.getItem('currshema').replace(/['"]+/g, '');
  apiurl = environment.apiurl;
  rowData;
  public datedetails = false;
  addtenant: FormGroup;
  submitted = false;
  show: boolean = false;
  errormessage2 = "";
  property: Property[] = [
    { value: "0", viewValue: "john" },
    { value: "1", viewValue: "Steve" },
    { value: "2", viewValue: "Mical" }
  ];
  minDate: Date;
  iserrror: boolean = false;
  isEnabled: boolean = false;
  // date_details: boolean;
  constructor(
    private route: ActivatedRoute,
    private viewTenant: ViewtenantService,
    private validateemail: ValidateEmailService,
    private listproperties: ListallpropertiesService,
    private formBuilder: FormBuilder,
    public addtenantservice: AddtenantService,
    private router: Router,
    private unselectedProperty: ListalltenantService,
    private alert: AlertService, private datepipe: DatePipe,
  ) { }

  ngOnInit() {
    this.getData();
    this.getPropertyList(event);
    this.addtenant = this.formBuilder.group(
      {
        first_name: ["", [Validators.required, Validators.pattern('^[a-zA-Z \-\']+')]],
        additional_info: [""],
        email: ["", [Validators.required, Validators.email]],
        contact_no: ["", Validators.required],
        image: [""],
        propertyid: ["", Validators.required],
        file: [""],
        start_date: [""],
        end_date: [""],
        id: []
      },
      {
        // validator: MustMatch('password', 'confirm_password'),
        // emailvalidator: EmailExist('email')
      }
    );
    this.addtenant.valueChanges.subscribe(res => {
      this.minDate = new Date(res.start_date);
    });
  }

  get first_name() {
    return this.addtenant.get("first_name");
  }
  get additional_info() {
    return this.addtenant.get("additional_info");
  }
  get email() {
    return this.addtenant.get("email");
  }
  get contact_no() {
    return this.addtenant.get("contact_no");
  }
  get propertyid() {
    return this.addtenant.get("propertyid");
  }
  get image() {
    return this.addtenant.get("image");
  }
  get file() {
    return this.addtenant.get("file");
  }
  get start_date() {
    return this.addtenant.get("start_date");
  }
  get end_date() {
    return this.addtenant.get("end_date");
  }
  get id() {
    return this.addtenant.get("id");
  }

  getData() {
    this.urlId = this.route.snapshot.queryParamMap.get("data");
    this.viewTenant.getTenantDetail(this.urlId).subscribe(
      data => {
        this.rowData = data;
        this.imagesStored = data['images'];

        console.log(this.imagesStored)
        this.filesStored = data['files'];


        this.apiurl = this.apiurl.replace("http://", "http://" + this.schemaname + ".").slice(0, -1);


        this.setFormValue();
      },
      error => { }
    );
  }
  // Set Form Data
  setFormValue() {
    this.first_name.setValue(this.rowData.first_name);
    this.additional_info.setValue(this.rowData.additional_info);
    this.email.setValue(this.rowData.email);
    this.contact_no.setValue(this.rowData.contact_no);
    this.propertyid.setValue(this.rowData.propertyid);
    this.start_date.setValue(this.rowData.start_date);
    this.end_date.setValue(this.rowData.end_date);
    // this.images.setValue(this.rowData.images)
    // this.files.setValue(this.rowData.files)
    this.id.setValue(this.rowData.id);
    // console.log('hi',this.rowData)
    this.isEnabled = true;
  }

  tenantEditSave() {
    if (this.id.value) {
      console.log(this.id.value)
      this.updateTenant();
    } else {
      this.addTenant();
    }
  }


  getPropertyList(event: any) {
    this.listproperties.getlimitedProperty().subscribe(
      data => {
        this.property = data;
        // console.log(this.property);
        //  if(data.property_name.value!=" "){
        //   this.date_details=true;
        //  }else{
        //    this.date_details=false;
        //  }
        // console.log(data.property_name);
      },
      error => {
        this.property = [];
      }
    );
  }
  showOther(event) {
    console.log(event);
    // this.issueotherdetails = true;
    let target = event.source.selected._element.nativeElement;
    let selectedData = {
      // id: event.value,
      name: target.innerText.trim()
    };
    console.log(selectedData);
    if (selectedData.name == '') {
      this.datedetails = false;
      // this.subissueotherdetails = true;
      // console.log(name);
      return;
    } else {
      this.datedetails = true;
      // this.subissueotherdetails = false;
      // console.log(name);
    }
  }
  getImages(): FileLikeObject[] {
    return this.uploaderImg.queue.map(fileItem => {
      return fileItem.file;
    });
  }
  getAttachments(): FileLikeObject[] {
    return this.uploaderfile.queue.map(fileItem => {
      return fileItem.file;
    });
  }
  // Add Tenant
  addTenant() {
    this.submitted = true;
    if (this.addtenant.invalid) {
      return;
    } else {

      const formData = new FormData();
      formData.append("first_name", this.addtenant.value.first_name);
      formData.append("additional_info", this.addtenant.value.additional_info);
      formData.append("email", this.addtenant.value.email);
      formData.append("contact_no", this.addtenant.value.contact_no);
      formData.append("propertyid", this.addtenant.value.propertyid);
      // formData.append("start_date", this.addtenant.value.start_date);
      // formData.append(
      //   "start_date",
      //   this.transformDate(this.addtenant.value.start_date)
      // );

      formData.append(
        "start_date",
        this.addtenant.value.start_date
          ? this.transformDate(this.addtenant.value.start_date)
          : ""
      );
      // formData.append("end_date", this.addtenant.value.end_date);
      // formData.append(
      //   "end_date",
      //   this.transformDate(this.addtenant.value.end_date)
      // );
      formData.append(
        "end_date",
        this.addtenant.value.end_date
          ? this.transformDate(this.addtenant.value.end_date)
          : ""
      );
      let attachments = this.getAttachments();
      attachments.forEach(attachment => {
        formData.append("files", attachment.rawFile, attachment.name);
      });
      let Images = this.getImages();
      Images.forEach(Image => {
        formData.append("images", Image.rawFile, Image.name);
      });
      this.addtenantservice.sendDefaultPswd(this.email.value).subscribe
        (
          data => {
            if (this.errormessage2 == "") {

              this.addtenantservice.addTenant(formData).subscribe(
                data => {
                  this.alert.success("Tenant Added Successfully");
                  setTimeout(() => {
                    // this.alert.removeAlert();
                    // this.emitEventToChild()
                    this.router.navigate(["/dashboard/list_all_tenant"]);
                  }, 4000);

                },
                error => {
                  this.alert.error("Tenant not added please try again");
                  // this.router.navigate(["/dashboard/add_tenant"]);
                }
              );
            }

            else {
              this.alert.error("Tenant not added please try again");
              return;
            }
          },
          error => {
            this.alert.error("Owner not added please try again")
            this.router.navigate(["/dashboard/add_owner"]);
          })


    }
  }
  // Update Tenant
  updateTenant() {
    this.submitted = true;
    if (this.addtenant.invalid) {
      return;
    } else {
      const formData = new FormData();
      formData.append("first_name", this.addtenant.value.first_name);
      formData.append("additional_info", this.addtenant.value.additional_info);
      formData.append("email", this.addtenant.value.email);
      formData.append("contact_no", this.addtenant.value.contact_no);
      formData.append("propertyid", this.addtenant.value.propertyid ? this.addtenant.value.propertyid : '');
      // formData.append("start_date", this.addtenant.value.start_date);
      // formData.append(
      //   "start_date",
      //   this.transformDate(this.addtenant.value.start_date)
      // );
      formData.append(
        "start_date",
        this.addtenant.value.start_date
          ? this.transformDate(this.addtenant.value.start_date)
          : ""
      );
      // formData.append("end_date", this.addtenant.value.end_date);
      // formData.append(
      //   "end_date",
      //   this.transformDate(this.addtenant.value.end_date)
      // );
      formData.append(
        "end_date",
        this.addtenant.value.end_date
          ? this.transformDate(this.addtenant.value.end_date)
          : ""
      );
      formData.append("id", this.addtenant.value.id);

      let attachments = this.getAttachments();
      attachments.forEach(attachment => {
        formData.append("files", attachment.rawFile, attachment.name);
      });
      let Images = this.getImages();
      Images.forEach(Image => {
        formData.append("images", Image.rawFile, Image.name);
      });
      this.addtenantservice
        .updateTenant(formData, this.addtenant.value.id)
        .subscribe(
          data => {
            this.alert.success("Tenant updated Successfully");
            setTimeout(() => {
              // this.alert.removeAlert();
              // this.emitEventToChild()
              this.router.navigate(["/dashboard/view_tenant"], {
                queryParams: { data: data.id }
              });
            }, 4000);

          },
          error => {
            this.alert.error("Tenant not updated please try again");
          }
        );
    }
  }

  emailExist() {
    setTimeout(() => {
      this.validateemail.validateEmail(this.email.value).subscribe(
        data => {
          if (data.msg == "") {
            this.iserrror = false;
            this.errormessage2 = "";

          } else {
            this.errormessage2 = data.msg;
            console.log(this.errormessage2)
          }
        },
        error => {
          this.errormessage2 = "Email-id Already Exists";
          this.iserrror = true;
          this.router.navigate(["/dashboard/add_tenant"]);
        }
      );
    }, 3000);
    // console.log("email", this.email.value);

  }

  onKeyPress(type: any, event) {
    if (type == "Float") {
      let charCode = event.which ? event.which : event.keyCode;
      if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
      return true;
    }
    if (type == "Number") {
      const charCode = event.which ? event.which : event.keyCode;
      if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
      }
      return true;
    }
    if (type == "RemovingfirstSpace") {
      if (event.which === 32 && event.target.selectionStart === 0) {
        return false;
      }
      return true;
    }
  }
  transformDate(date) {
    return this.datepipe.transform(date, "yyyy-MM-dd");
  }
}
