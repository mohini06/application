import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchpropertylistComponent } from './searchpropertylist.component';

describe('SearchpropertylistComponent', () => {
  let component: SearchpropertylistComponent;
  let fixture: ComponentFixture<SearchpropertylistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchpropertylistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchpropertylistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
