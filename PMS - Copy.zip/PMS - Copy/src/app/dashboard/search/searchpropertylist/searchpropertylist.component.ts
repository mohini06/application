import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchpropertylist',
  templateUrl: './searchpropertylist.component.html',
  styleUrls: ['./searchpropertylist.component.css']
})
export class SearchpropertylistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
