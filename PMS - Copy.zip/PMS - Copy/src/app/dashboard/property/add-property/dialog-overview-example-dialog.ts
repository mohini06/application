import { Component, Inject } from "@angular/core";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import {
  FormGroup,
  FormBuilder,
  FormControl,
  Validators
} from "@angular/forms";
// import { Furnishtype } from "./add-property.component";
import { AddpropertyService } from "src/app/_services/addproperty.service";
@Component({
  selector: "dialog-overview-example-dialog",
  templateUrl: "dialog-overview-example-dialog.html",
  styleUrls: ["dialog-overview-example-dialog.css"]
})
export class DialogOverviewExampleDialog {
  furnishtypeform: FormGroup;
  Furnishingtypes:any;
  
  checked = false;
  myModel = true;
  
  constructor(
    private formBuilder: FormBuilder,
    private addpropertyservice: AddpropertyService,
    public dialogRef: MatDialogRef<DialogOverviewExampleDialog>,
    // @Inject(MAT_DIALOG_DATA) public data: Furnishtype
  ) {}

  ngOnInit() {
    this.furnishtypeform = this.formBuilder.group({
      furnishedtypes: [""]
    });
    // this.getfurnishsubtypelist();
    // console.log(this.data.Furnishingtype_id);
  }

  // getfurnishsubtypelist() {
  //   this.addpropertyservice
  //     .getFurnishSubtypeDtetail(this.data.Furnishingtype_id)
  //     .subscribe(
  //       res => {
  //         this.Furnishingtypes = res;
  //         console.log(res)
  //       },
  //       error => {
  //         this.Furnishingtypes = [];
  //       }
  //     );
  // }
  openDialogtenant() {

  }

  submit(furnishtypeform) {
    console.log(furnishtypeform.value.furnishedtypes)
    this.dialogRef.close(furnishtypeform.value.furnishedtypes);

  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}
