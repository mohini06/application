import { Component,Optional, Inject } from "@angular/core";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import {
  FormGroup,
  FormBuilder,
  FormControl,
  Validators
} from "@angular/forms";
import { Propertytype } from "./add-property.component";
import { AddpropertyService } from "src/app/_services/addproperty.service";

@Component({
  selector: "dialog-overview-tenanttyp-dialog",
  templateUrl: "dialog-overview-tenanttyp-dialog.html",
  styleUrls: ["dialog-overview-tenanttyp-dialog.css"]
})
export class DialogOverviewTenanttypDialog {

    tenanttypeform: FormGroup;
  Tenanttypes:any;
  Tenantnumber:any;
  public tenant_no = false;

tenantnos: string[] = ['01', '02', '03', '04', '05'];
  rowData: any;
  constructor(
    private formBuilder: FormBuilder,
    private addpropertyservice: AddpropertyService,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<DialogOverviewTenanttypDialog>,
    //  @Inject(MAT_DIALOG_DATA) public data: Propertytype
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    this.tenanttypeform = this.formBuilder.group({
        tenanttype: ["", Validators.required],
        no_of_tenants: ["", Validators.required]
    });
    this.gettenanttypelist();
    // this.setFormValue();
  }
// get tenanttype() {
//     return this.tenanttypeform.get("tenanttype");
//   }
//   get no_of_tenants() {
//     return this.tenanttypeform.get("no_of_tenants");
//   }
//   setFormValue(){
//     this.submit(this.tenanttype.value);
//     this.tenanttype.setValue(this.rowData.tenanttype);
//     this.no_of_tenants.setValue(this.rowData.no_of_tenants);
//   }
  gettenanttypelist() {
    this.addpropertyservice
      .getTenanttype(this.data.Propertytype_id)
      .subscribe(
        res => {
          this.Tenanttypes = res;
          console.log(res)
        },
        error => {
          this.Tenanttypes = [];
        }
      );
  }

  submit(tenanttypeform) {
    console.log(tenanttypeform.value);
    this.dialogRef.close(tenanttypeform.value);
    // console.log(tenanttypeform.value.no_of_tenants);
    // this.dialogRef.close(tenanttypeform.value.no_of_tenants);
  }
 
  showOther(tenant_type): void {
    if (tenant_type == "Multi Tenant") {
     
      this.tenant_no = true;
      
   
    } else {
      this.tenant_no = false;
      return;
    }
  }


}
