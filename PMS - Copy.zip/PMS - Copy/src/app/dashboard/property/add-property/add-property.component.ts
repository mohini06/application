import { ViewpropertyService } from "./../../../_services/viewproperty.service";
import { Component, OnInit, Inject } from "@angular/core";
import { STEPPER_GLOBAL_OPTIONS } from "@angular/cdk/stepper";
import {
  FormGroup,
  FormBuilder,
  FormControl,
  Validators
} from "@angular/forms";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { AddpropertyService } from "src/app/_services/addproperty.service";
import { Router, ActivatedRoute } from "@angular/router";
import { DialogOverviewExampleDialog } from "./dialog-overview-example-dialog";
import { DialogOverviewTenanttypDialog } from "./dialog-overview-tenanttyp-dialog";
import { ListallownerService } from "src/app/_services/listallowner.service";
import { ListalltenantService } from "src/app/_services/listalltenant.service";
import { filter } from "rxjs/operators";

import { FileUploader, FileLikeObject, FileItem } from "ng2-file-upload";

import { DatePipe } from "@angular/common";
import { from } from "rxjs";
import { AlertService } from 'src/app/_services/alert.service';
import { environment } from 'src/environments/environment';

export interface Type {
  value: string;
  viewValue: string;
}

// export interface Furnishtype {
//   Furnishingtype_id: number;
//   Furnishingtype_name: string;
// }

export interface Propertytype {
  Propertytype_id: number;
  Propertytype_name: string;
}



// export interface Rent {
//   value: string;
//   viewValue: string;
// }
export interface Bed {
  value: number;
  viewValue: string;
}

export interface Bath {
  value: number;
  viewValue: string;
}
// export interface Furnish {
//   value: string;
//   viewValue: string;
// }
// export interface selectedfurnishedsubtype {
//   furnishedsubtype_id: string;
//   furnishedsubtype_name: string;
// }
export interface selecttenanttype {
  tenanttype_id: string;
  tenanttype_name: string;
}
export interface Landlord {
  value: string;
  viewValue: string;
}
export interface Tenant {
  value: string;
  viewValue: string;
}
export interface Furnish {
  value: string;
  viewValue: string;
}
export interface Amenitie {
  value: string;
  viewValue: string;
}
@Component({
  selector: "app-add-property",
  templateUrl: "./add-property.component.html",
  styleUrls: ["./add-property.component.css"],
  providers: [
    {
      provide: STEPPER_GLOBAL_OPTIONS,
      useValue: { displayDefaultIndicatorType: true }
    }
  ]
})
export class AddPropertyComponent implements OnInit {
  dialogRef: MatDialogRef<DialogOverviewExampleDialog>;
  dialogReff: MatDialogRef<DialogOverviewTenanttypDialog>;
  // this.dialogRef = this.dialog.open(DialogOverviewExampleDialog);
  urlId;
  rowData;
  result: any;
  public property_tab = true;
  public owner_tab = false;
  public tenant_tab = false;
  displaymsg = "";
  submitted = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  formGroup: FormGroup;
  errormessage = "";
  ownervariable = "";
  landlord: any;
  tenant: any;
  amenitie: any;
  furnished_types: any;
  // furnishedsubtype: any;
  propertytp: any;
  tenanttp: any;
  tenantno: any;
  parkingflag: boolean;
  parkingValue;
  public uploaderImg: FileUploader = new FileUploader({
    // allowedFileType: ['png', 'jpg','jpeg','PNG','JPG','JPEG']
  });
  public uploaderfile: FileUploader = new FileUploader({
    // allowedFileType: ['txt', 'pdf','doc']
  });
  // types: Type[] = [
  //   { value: "Independent", viewValue: "Independent" },
  //   { value: "Apartment", viewValue: "Apartment" },
  //   { value: "Commercial", viewValue: "Commercial" },
  //   { value: "Bungalow", viewValue: "Bungalow" }
  // ];
  // rents: Rent[] = [
  //   { value: "Rent", viewValue: "Rent" },
  //   { value: "Lease", viewValue: "Lease" }
  // ];
  beds: Bed[] = [
    { value: 0, viewValue: "00" },
    { value: 1, viewValue: "01" },
    { value: 2, viewValue: "02" },
    { value: 3, viewValue: "03" },
    { value: 4, viewValue: "04" },
    { value: 5, viewValue: "05" }
  ];
  bathss: Bath[] = [
    { value: 0, viewValue: "00" },
    { value: 1, viewValue: "01" },
    { value: 2, viewValue: "02" },
    { value: 3, viewValue: "03" },
    { value: 4, viewValue: "04" },
    { value: 5, viewValue: "05" },

  ];

  // furnishedsubtypedata: {
  //   furnishedsubtype_id: string;
  //   furnishedsubtype_name: string;
  // };

  tenanttypedata: {
    tenanttype_id: string;
    tenanttype_name: string;

  }
  Propertytype_id: string;
  Propertytype_name: string;
  furnished_name: string;
  // Furnishingtype_id: string;
  amentities_name: string;
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  minDate: Date;
  imagesStored: any;
  filesStored: any;
  schemaname = localStorage.getItem('currshema').replace(/['"]+/g, '');
  apiurl = environment.apiurl;
  data: any;
  constructor(
    private formBuilder: FormBuilder,
    private datepipe: DatePipe,
    private route: ActivatedRoute,
    private viewProperty: ViewpropertyService,
    public dialog: MatDialog,
    private addpropertyservice: AddpropertyService,
    private router: Router,
    private listowners: ListallownerService,
    private listtenants: ListalltenantService,
    private alert: AlertService
  ) {
    this.firstFormGroup = new FormGroup({

    });
  }

  ngOnInit() {
    this.getFurnishdetail(event);
    this.getAmenities(event);
    this.getData();
    this.getOwnerList(event);
    // this.getTenantList();
    this.getPropertytype(event);

    this.firstFormGroup = this.formBuilder.group({
      property_name: ["", Validators.required],
      description: [""],
      // prop_type: ["", Validators.required],
      // rent_lease: [""],
      land_size: [""],
      carpet_area: [""],
      state: ["", [Validators.required]],
      address: ["", Validators.required],
      pincode: ["", Validators.required],
      bed: ["", Validators.required],
      baths: ["", Validators.required],
      furnished_type: [],
      // furnishedtypes: [],
      propertytype: ["", Validators.required],
      tenanttype: [],
      no_of_tenants: [],
      id: []
    });

    this.secondFormGroup = this.formBuilder.group({
      amentities: [],
      parking: [""],
      pets: [""],
      balcony: [""],
      smoking: [""],
      property_price: ["", Validators.required],
      maintenance_fee: ["", Validators.required],
      commission_offered: ["", Validators.required],
      deposite_amt: ["", Validators.required],
      available_from: ["", Validators.required],
      available_to: ["", Validators.required],
      prop_owner: [""],
      prop_tenant: [""],
      image: [""],
      file: [""]
    });
    this.secondFormGroup.valueChanges.subscribe(res => {
      this.minDate = new Date(res.available_from);
    });
  }

  get property_name() { return this.firstFormGroup.get("property_name"); }
  get id() {
    return this.firstFormGroup.get("id");
  }
  get description() {
    return this.firstFormGroup.get("description");
  }
  get propertytype() {
    return this.firstFormGroup.get("propertytype");
  }
  get tenanttype() {
    return this.tenanttype;
    console.log(this.tenanttype)
  }
  get no_of_tenants() {
    return this.no_of_tenants;
  }
  // get rent_lease() {
  //   return this.firstFormGroup.get("rent_lease");
  // }
  get land_size() {
    return this.firstFormGroup.get("land_size");
  }
  get carpet_area() {
    return this.firstFormGroup.get("carpet_area");
  }
  get state() {
    return this.firstFormGroup.get("state");
  }
  get address() {
    return this.firstFormGroup.get("address");
  }
  get pincode() {
    return this.firstFormGroup.get("pincode");
  }
  get bed() {
    return this.firstFormGroup.get("bed");
  }
  get baths() {
    return this.firstFormGroup.get("baths");
  }
  get furnished_type() {
    return this.firstFormGroup.get("furnished_type");
  }
  // get furnishedtypes() {
  //   return this.furnishedtypes;
  // }
  get property_price() {
    return this.secondFormGroup.get("property_price");
  }
  get maintenance_fee() {
    return this.secondFormGroup.get("maintenance_fee");
  }
  get commission_offered() {
    return this.secondFormGroup.get("commission_offered");
  }
  get deposite_amt() {
    return this.secondFormGroup.get("deposite_amt");
  }
  get available_from() {
    return this.secondFormGroup.get("available_from");
  }
  get available_to() {
    return this.secondFormGroup.get("available_to");
  }
  get prop_owner() {
    return this.secondFormGroup.get("prop_owner");
  }
  get amentities() {
    return this.secondFormGroup.get("amentities");
  }
  get prop_tenant() {
    return this.secondFormGroup.get("prop_tenant");
  }
  get image() {
    return this.secondFormGroup.get("image");
  }
  get file() {
    return this.secondFormGroup.get("file");
  }
  get parking() {
    return this.secondFormGroup.get("parking");
  }
  get pets() {
    return this.secondFormGroup.get("pets");
  }
  get balcony() {
    return this.secondFormGroup.get("balcony");
  }
  get smoking() {
    return this.secondFormGroup.get("smoking");
  }
  setFormValue() {
    console.log(this.rowData.no_of_tenants)
    this.property_name.setValue(this.rowData.property_name);
    this.description.setValue(this.rowData.description);
    this.propertytype.setValue(this.rowData.propertytype);
    // this.openDialogtenant(this.propertytype.value);
    this.tenanttp = this.rowData.tenanttype;
    this.tenantno = this.rowData.no_of_tenants;
    // this.tenanttype.setValue(this.rowData.tenanttyp);
    // this.rent_lease.setValue(this.rowData.rent_lease);
    this.land_size.setValue(this.rowData.land_size);
    this.carpet_area.setValue(this.rowData.carpet_area);
    this.state.setValue(this.rowData.state);
    this.address.setValue(this.rowData.address);
    this.pincode.setValue(this.rowData.pincode);
    this.bed.setValue(this.rowData.bed);
    this.baths.setValue(this.rowData.baths);
    this.furnished_type.setValue(this.rowData.furnished_id);
    // this.furnishedtypes.setValue(this.rowData.furnishedsubtype);
    this.amentities.setValue(this.rowData.amentities_id);
    this.property_price.setValue(this.rowData.property_price);
    this.maintenance_fee.setValue(this.rowData.maintenance_fee);
    this.commission_offered.setValue(this.rowData.commission_offered);
    this.deposite_amt.setValue(this.rowData.deposite_amt);
    this.available_from.setValue(this.rowData.available_from);
    this.available_to.setValue(this.rowData.available_to);
    this.prop_owner.setValue(this.rowData.prop_owner);
    this.prop_tenant.setValue(this.rowData.prop_tenant);
    this.parking.setValue(this.rowData.parking);
    if (this.rowData.parking == 0 || this.rowData.parking == 1 || this.rowData.parking == 2) {
      this.parkingflag = true
    }
    else {
      this.parkingflag = false
    }
    this.pets.setValue(this.rowData.pets);
    this.balcony.setValue(this.rowData.balcony);
    this.smoking.setValue(this.rowData.smoking);
    // this.images.setValue(this.rowData.images)
    // this.files.setValue(this.rowData.files)
    this.id.setValue(this.rowData.id);
  }


  // openDialog(furnish_id): void {
  //   console.log(furnish_id)
  //   if (furnish_id < 3) {
  //     this.dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
  //       width: "300px",

  //       data: { Furnishingtype_id: furnish_id }
  //     });

  //     this.dialogRef.afterClosed().subscribe(result => {
  //       console.log(result);
  //       this.furnishedsubtype = ''
  //       this.furnishedsubtype = result;

  //     });
  //   } else {
  //     return;
  //   }
  // }


  openDialogtenant(property_id): void {
    console.log(property_id)
    if (property_id < 4) {
      this.dialogReff = this.dialog.open(DialogOverviewTenanttypDialog, {
        width: "360px",
        data: { Propertytype_id: property_id }
      });

      this.dialogReff.afterClosed().subscribe(result => {
        console.log(result);
        this.tenanttp = ''
        this.tenanttp = result.tenanttype;
        console.log(this.tenanttp)
        this.tenantno = ''
        if (this.tenanttp == "Single Tenant") {
          console.log("this.tenanttp")
          this.tenantno = 1;
        } else {
          this.tenantno = result.no_of_tenants || 1;
          console.log(this.tenantno)
        }
      });
    } else {
      return;
    }
  }
  openImageDialog(path) {
    const dialogRef = this.dialog.open(ImageAddPropDialog, {

      data: { attacpath: path }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log(`Dialog result: ${result}`);
    });
  }
  getFurnishdetail(event: any) {
    this.addpropertyservice.getFurnishdetail().subscribe(
      data => {
        this.furnished_types = data;
        console.log(this.furnished_types);
      },
      error => {
        this.furnished_types = [];
      }
    );
  }

  getPropertytype(event: any) {
    this.addpropertyservice.getpropertytype().subscribe(
      data => {
        this.propertytp = data;
        console.log(this.propertytp);
      },
      error => {
        this.propertytp = [];
      }
    );
  }
  getAmenities(event: any) {
    this.addpropertyservice.getAmenties().subscribe(
      data => {
        this.amenitie = data;
        // console.log(this.amenitie);
      },
      error => {
        this.amenitie = [];
      }
    );
  }
  getOwnerList(event: any) {
    this.listowners.getAllOwner().subscribe(
      data => {
        this.landlord = data;
        // console.log(this.landlord);
      },
      error => {
        this.landlord = [];
      }
    );
  }

  // getTenantList() {
  //   this.listtenants.getAllTenant().subscribe(
  //     data => {
  //       this.tenant = data;
  //     },
  //     error => {
  //       this.tenant = [];
  //     }
  //   );
  // }

  // csvInputChange(fileInputEvent: any) {
  //   console.log(fileInputEvent.target.files[0]);
  // }
  getImages(): FileLikeObject[] {
    return this.uploaderImg.queue.map(fileItem => {
      return fileItem.file;
    });
  }
  getAttachments(): FileLikeObject[] {
    return this.uploaderfile.queue.map(fileItem => {
      return fileItem.file;
    });
  }
  // Add Property
  addProperty() {
    this.submitted = true;
    if (this.firstFormGroup.invalid || this.secondFormGroup.invalid) {
      return;
    } else {
      const formData = new FormData();
      formData.append("property_name", this.firstFormGroup.value.property_name);
      formData.append("description", this.firstFormGroup.value.description);
      // formData.append("prop_type", this.firstFormGroup.value.prop_type);
      // formData.append("rent_lease", this.firstFormGroup.value.rent_lease);
      formData.append("land_size", this.firstFormGroup.value.land_size);
      formData.append("carpet_area", this.firstFormGroup.value.carpet_area);
      formData.append("state", this.firstFormGroup.value.state);
      formData.append("address", this.firstFormGroup.value.address);
      formData.append("pincode", this.firstFormGroup.value.pincode);
      formData.append("bed", this.firstFormGroup.value.bed);
      formData.append("baths", this.firstFormGroup.value.baths);
      formData.append(
        "furnished_type",
        JSON.stringify(this.firstFormGroup.value.furnished_type ? this.firstFormGroup.value.furnished_type : '')
      );
      console.log(this.firstFormGroup.value.furnished_type)
      // formData.append("furnished", this.firstFormGroup.value.furnished);
      formData.append("propertytype", this.firstFormGroup.value.propertytype);
      formData.append("tenanttype", this.tenanttp);
      formData.append("no_of_tenants", this.tenantno);
      // var stringWithoutSingleQuotes = this.furnishedsubtype.replace(/'/g, "")
      // formData.append("furnishedtypes", this.furnishedsubtype.replace(/'/g, ""));
      // formData.append("furnishedtypes", JSON.stringify(this.furnishedsubtype ? this.furnishedsubtype : ''));

      // console.log( this.furnishedsubtype)
      // return
      formData.append(
        "amentities",
        JSON.stringify(this.secondFormGroup.value.amentities ? this.secondFormGroup.value.amentities : '')
      );
      console.log(this.secondFormGroup.value.amentities)
      formData.append("parking", this.secondFormGroup.value.parking);
      formData.append(
        "pets",
        this.ontoggleChange(this.secondFormGroup.value.pets)
      );
      formData.append(
        "balcony",
        this.ontoggleChange(this.secondFormGroup.value.balcony)
      );
      formData.append(
        "smoking",
        this.ontoggleChange(this.secondFormGroup.value.smoking)
      );
      formData.append(
        "property_price",
        this.secondFormGroup.value.property_price
      );
      formData.append(
        "maintenance_fee",
        this.secondFormGroup.value.maintenance_fee
      );
      formData.append(
        "commission_offered",
        this.secondFormGroup.value.commission_offered
      );
      formData.append("deposite_amt", this.secondFormGroup.value.deposite_amt);
      formData.append(
        "available_from",
        this.transformDate(this.secondFormGroup.value.available_from)
      );
      formData.append(
        "available_to",
        this.transformDate(this.secondFormGroup.value.available_to)
      );
      formData.append("prop_owner", this.secondFormGroup.value.prop_owner);
      // formData.append("prop_tenant", this.secondFormGroup.value.prop_tenant);
      formData.append("prop_tenant",
        JSON.stringify(this.secondFormGroup.value.prop_tenant ? this.secondFormGroup.value.prop_tenant : '')
      );
      console.log(this.secondFormGroup.value.prop_tenant)
      let attachments = this.getAttachments();
      attachments.forEach(attachment => {
        formData.append("files", attachment.rawFile, attachment.name);
      });
      let Images = this.getImages();
      Images.forEach(Image => {
        formData.append("images", Image.rawFile, Image.name);
      });

      this.addpropertyservice.addProperty(formData).subscribe(
        data => {

          console.log(data)
          this.alert.success("Property Added Successfully");
          setTimeout(() => {
            // this.alert.removeAlert();
            // this.emitEventToChild()
            this.router.navigate(["/dashboard/listproperty"]);
          }, 4000);

          // this.displaymsg = JSON.stringify(data.msg);
        },
        error => {
          this.alert.error("Property Not Added please try again");
          // this.errormessage = "Please fill correct value";
          this.router.navigate(["/dashboard/add_property"]);
        }
      );
    }
  }
  // onKeyPress(type: any, event) {
  //   if (type == "Float") {
  //     let charCode = event.which ? event.which : event.keyCode;
  //     if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
  //       return false;
  //     return true;
  //   }
  //   if (type == "Number") {
  //     const charCode = event.which ? event.which : event.keyCode;
  //     if (charCode > 31 && (charCode < 48 || charCode > 57)) {
  //       return false;
  //     }
  //     return true;
  //   }
  //   if (type == "RemovingfirstSpace") {
  //     if (event.which === 32 &&  event.target.selectionStart === 0) {
  //       return false;
  //     }  
  //     return true;
  //   }
  // }

  getData() {
    this.urlId = this.route.snapshot.queryParamMap.get("data");

    this.viewProperty.getPropertyDetail(this.urlId).subscribe(
      data => {
        this.rowData = data;
        console.log("hi", this.rowData);


        this.imagesStored = data['images'];
        // (response: Blob) => saveAs(response, this.rowData.images.fileName + '.xlsx')
        console.log(this.imagesStored)
        this.filesStored = data['files'];

        // this.updateformData.append()
        this.apiurl = this.apiurl.replace("http://", "http://" + this.schemaname + ".").slice(0, -1);
        this.setFormValue();
      },
      error => { }
    );
  }
  // UpdateProperty
  updateProperty() {
    // return;
    this.submitted = true;
    if (this.firstFormGroup.invalid || this.secondFormGroup.invalid) {
      return;
    } else {
      const formData = new FormData();

      formData.append("property_name", this.firstFormGroup.value.property_name);
      formData.append("description", this.firstFormGroup.value.description);
      formData.append("prop_type", this.firstFormGroup.value.prop_type);
      // formData.append("rent_lease", this.firstFormGroup.value.rent_lease);
      formData.append(
        "land_size",
        this.firstFormGroup.value.land_size
          ? this.firstFormGroup.value.land_size
          : ""
      );
      formData.append("carpet_area", this.firstFormGroup.value.carpet_area ? this.firstFormGroup.value.carpet_area
        : "");
      formData.append("state", this.firstFormGroup.value.state);
      formData.append("address", this.firstFormGroup.value.address);
      formData.append("pincode", this.firstFormGroup.value.pincode);
      formData.append("bed", this.firstFormGroup.value.bed);
      formData.append("baths", this.firstFormGroup.value.baths);
      formData.append(
        "furnished_type",
        JSON.stringify(this.firstFormGroup.value.furnished_type ? this.firstFormGroup.value.furnished_type : '')
      );
      console.log(this.firstFormGroup.value.furnished_type)
      // formData.append("furnished", this.firstFormGroup.value.furnished);
      formData.append("propertytype", this.firstFormGroup.value.propertytype);
      formData.append("tenanttype", this.tenanttp);
      formData.append("no_of_tenants", this.tenantno);

      // formData.append("furnishedtypes", JSON.stringify(this.furnishedsubtype ? this.furnishedsubtype : ''));


      formData.append(
        "amentities",
        JSON.stringify(this.secondFormGroup.value.amentities ? this.secondFormGroup.value.amentities : '')
      );
      console.log(this.secondFormGroup.value.amentities)
      formData.append("parking", this.secondFormGroup.value.parking);
      formData.append(
        "pets",
        this.ontoggleChange(this.secondFormGroup.value.pets)
      );
      formData.append(
        "balcony",
        this.ontoggleChange(this.secondFormGroup.value.balcony)
      );
      formData.append(
        "smoking",
        this.ontoggleChange(this.secondFormGroup.value.smoking)
      );
      formData.append(
        "property_price",
        this.secondFormGroup.value.property_price
      );
      formData.append(
        "maintenance_fee",
        this.secondFormGroup.value.maintenance_fee
      );
      formData.append(
        "commission_offered",
        this.secondFormGroup.value.commission_offered
      );
      formData.append("deposite_amt", this.secondFormGroup.value.deposite_amt);
      formData.append(
        "available_from",
        this.transformDate(this.secondFormGroup.value.available_from)
      );
      formData.append(
        "available_to",
        this.transformDate(this.secondFormGroup.value.available_to)
      );
      formData.append(
        "prop_owner",
        this.secondFormGroup.value.prop_owner
          ? this.secondFormGroup.value.prop_owner
          : ""
      );
      console.log(this.secondFormGroup.value.prop_owner)
      // formData.append(
      //   "prop_tenant",
      //   this.secondFormGroup.value.prop_tenant
      //     ? this.secondFormGroup.value.prop_tenant
      //     : ""
      // );
      formData.append("prop_tenant",
        JSON.stringify(this.secondFormGroup.value.prop_tenant ? this.secondFormGroup.value.prop_tenant : '')
      );
      console.log(this.secondFormGroup.value.prop_tenant)
      let attachments = this.getAttachments();
      attachments.forEach(attachment => {
        formData.append("files", attachment.rawFile, attachment.name);
      });
      let Images = this.getImages();
      Images.forEach(Image => {
        formData.append("images", Image.rawFile, Image.name);
      });

      this.addpropertyservice
        .updateProperty(formData, this.firstFormGroup.value.id)
        .subscribe(
          data => {
            this.alert.success("Property Updated Successfully");
            setTimeout(() => {
              // this.alert.removeAlert();
              // this.emitEventToChild()
              this.router.navigate(["/dashboard/view_property"], {
                queryParams: { data: data.id }
              });
            }, 4000);


            // this.displaymsg = JSON.stringify(data.msg);
          },
          error => {
            this.alert.error("Property not updated please try again");
            // this.errormessage = "Please fill correct value";
            // this.router.navigate(['/dashboard/add_property']);
          }
        );
    }
  }
  deleteimage(index: number) {

    this.data.images.splice(index, 1);
    // this.data.videos.splice(index, 1);

  }
  deletefile(index: number) {

    this.data.files.splice(index, 1);

  }
  propertyEditSave() {
    if (this.id.value) {

      this.updateProperty();
    } else {
      this.addProperty();
    }
  }
  transformDate(date) {
    return this.datepipe.transform(date, "yyyy-MM-dd");
  }
  dateValidation() {
    const fromDate = this.secondFormGroup.get("available_from").value;
    const toDate = this.secondFormGroup.get("available_to").value;
    if (fromDate > toDate) {
      alert("To Date should be greater than from Date");
    }
  }
  getParkingValue(event) {
    this.parkingflag = event.checked;
    if (this.parkingflag == false) {
      this.parkingflag = false;
    } else {
      this.parkingflag == true;
    }

  }

  // validate(){
  //   var filed= this.secondFormGroup.value.files;
  //        var reg = /(.*?)\.(jpg|bmp|jpeg|png)$/;
  //        if(!filed.match(reg))
  //        {
  //          alert("Invalid File");
  //          return false;
  //        }
  //        }

  ontoggleChange(val) {
    if (val === true) {
      return (val = "true");
    } else {
      return (val = "false");
    }
  }
}
@Component({
  selector: "image_property-dialog",
  templateUrl: "image_property-dialog.html"
})
export class ImageAddPropDialog {
  schemaname = localStorage.getItem('currshema').replace(/['"]+/g, '');
  apiurl = environment.apiurl.replace("http://", "http://" + this.schemaname + ".").slice(0, -1)
  constructor(
    public dialogRef: MatDialogRef<ImageAddPropDialog>,
    @Inject(MAT_DIALOG_DATA) public data: attchment,
    private Router: ActivatedRoute
  ) { }
}
export interface attchment {
  url: string;
  path: string;
  attacpath;
}