
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ViewpropertyService } from 'src/app/_services/viewproperty.service';
import { ListallpropertiesService } from 'src/app/_services/listallproperties.service';
import { DataService } from 'src/app/_services/data.service';
import {TooltipPosition} from '@angular/material/tooltip';
import { FormControl } from '@angular/forms';
@Component({
  selector: 'app-list-all-property',
  templateUrl: './list-all-property.component.html',
  styleUrls: ['./list-all-property.component.css']
})
export class ListAllPropertyComponent implements OnInit {
  data: any;
  id: any;
  tenantcount: any;
  tenantcountstore: any;
  constructor(private dataService: DataService, public router: Router, private listproperties: ListallpropertiesService, private viewpropertyservice: ViewpropertyService) { }

  ngOnInit() {
    this.getProperties();
    this.searchData()
    
  }
  getProperties() {
    this.listproperties.getAllProperty()
      .subscribe(data => {
        console.log(data)
        // this.tenantcountstore = data;
        // for(var w=0; w<this.tenantcountstore.length;w++){
        //   this.tenantcount=data[w].tenant_name.tenant_count;
        
        // }
        // console.log(this.tenantcount)
        // for(var i=5;i<data.tenant_count;)
        // if(data.tenant_count<5){
        //   console.log("vacant")
        // }else{
        //   console.log("No Vacancy")
        // }
        this.data = data;
        // console.log(data)


      },
        error => {

          this.data = [];

        })

  }


  getId(propertyId: string) {

    this.router.navigate(['/dashboard/view_property'], { queryParams: { data: propertyId } })
  }

  searchData() {
    this.dataService.searchValue.subscribe(data => {

      // console.log(data)
      if (data.type == "property") {
        this.data = data.data
      }

    },
      error => {

        // console.log(error)
      })
  }

}

