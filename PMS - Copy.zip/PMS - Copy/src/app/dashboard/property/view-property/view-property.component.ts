import { environment } from 'src/environments/environment';
import { AddMaintenanceService } from "src/app/_services/add-maintenance.service";
import { Component, OnInit, Inject } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { ViewpropertyService } from "src/app/_services/viewproperty.service";

import { 
  ConfirmationDialogComponent,
  ConfirmDialogModel
} from "./../../../confirmation-dialog/confirmation-dialog.component";
import {
  MatDialog,
  MAT_DIALOG_DATA,
  MatDialogRef
} from "@angular/material/dialog";
import {
  GridComponent,
  ToolbarItems,
  EditService,
  PageService,
  CommandColumnService,
  CommandModel,
  PageSettingsModel,
  ColumnMenuService,
  RowSelectEventArgs, FilterSettingsModel

} from "@syncfusion/ej2-angular-grids";
export interface PeriodicElement {
  name: string;
  symbol: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { symbol: "address:", name: "Appartment" },
  { symbol: "type:", name: "Ready to move" },
  { symbol: "furnished:", name: "Fully-Furnished" },
  { symbol: "bed:", name: "02" },
  { symbol: "baths:", name: "01" },
  { symbol: "land_size:", name: "2000sq.ft" },
  { symbol: "parking:", name: "No" },
  { symbol: "pets:", name: "Yes" }
];
@Component({
  selector: "app-view-property",
  templateUrl: "./view-property.component.html",
  styleUrls: ["./view-property.component.css"]
})
export class ViewPropertyComponent implements OnInit {
  breakpoint: number;
  displayedColumns: string[] = ["symbol", "name"];
  result: string = "";
  imagesStored: any;
  filesStored: any;
  data: any;
  datas: any;
  dTdata:any;
  dttenant:any;
  parkingValue:any;
  petsValue: boolean;
  balconyValue: boolean;
  smokingValue: boolean;
  schemaname= localStorage.getItem('currshema').replace(/['"]+/g, '');
  apiurl = environment.apiurl;
  public pageOptions: Object;
  public filterSettings: FilterSettingsModel;
  public editSettings: Object;
  public toolbarOptions: ToolbarItems[] | object;
  public editparams: Object;
  public commands: CommandModel[];
  public initialPage: PageSettingsModel;
  tenantname: any;
  startdate: any;
  constructor(
    public router: Router,
    private viewpropertyservice: ViewpropertyService,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private getmaintenance: AddMaintenanceService
  ) {}

  ngOnInit() {
    console.log(this.apiurl)
    this.initialPage = { pageSizes: true, pageSize: 5 };

    this.filterSettings = { type: "Menu" };
    this.toolbarOptions = ["ExcelExport", "Search"];
    this.getPropertydetail(this.route.snapshot.queryParams["data"]);
    // console.log(this.route.snapshot.queryParams["data"]);
    this.breakpoint = window.innerWidth <= 800 ? 2 : 4;
  }

  getPropertydetail(id) {
    this.viewpropertyservice.getPropertyDetail(id).subscribe(
      data => {
        this.data = data;
        this.dTdata = data['maintenance_update'];
        this.tenantname = data['tenant_details'];
        this.startdate = data.start_date;
        this.dttenant = data['tenant_details'];
        this.imagesStored = data.images;
        this.filesStored = this.data.files;
        console.log(this.apiurl)
        this.apiurl= this.apiurl.replace("http://", "http://"+ this.schemaname+".").slice(0,-1);
        this.petsValue = data.pets;
        this.balconyValue = data.balcony;
        this.smokingValue = data.smoking;
        this.parkingValue = data.parking;
        if(this.parkingValue == 0){
this.data.parking ='2 wheeler'
        }else if (this.parkingValue == 1){
          this.data.parking ='4 wheeler'

        }
        else{
          this.data.parking ='Both'
        }
        if (this.petsValue == true) {
          this.data.pets = "yes"
        } else {
         this.data.pets = "No"
        }
        if(this.balconyValue==true){
          this.data.balcony= "yes";
        }
        else{
          this.data.balcony= "No";
        }
        if(this.smokingValue==true){
         
          this.data.smoking= "yes";
        }
        else{
          this.data.smoking= "No";
        }
        
      },
      error => {}
    );
  }

  openImageDialog(path) {
    const dialogRef = this.dialog.open(ImagePropertyDialog, {
      data: { attacpath: path }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log(`Dialog result: ${result}`);
    });
  }
  onResize(event) {
    this.breakpoint = event.target.innerWidth <= 800 ? 2 : 4;
  }
  editProperty(propertyId: string) {
    this.router.navigate(["/dashboard/add_property"], {
      queryParams: { data: propertyId }
    });
  }
  confirmDialog(id): void {
    const message = `Are you sure you want to delete?`;
    const dialogData = new ConfirmDialogModel(
      "Confirm Action",
      message,
      id,
      "property"
    );
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      maxWidth: "400px",
      data: dialogData
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      this.result = dialogResult;
    });
  }
}
@Component({
  selector: "image_property-dialog",
  templateUrl: "image_property-dialog.html"
})
export class ImagePropertyDialog {
  schemaname= localStorage.getItem('currshema').replace(/['"]+/g,'');
  apiurl =environment.apiurl.replace("http://", "http://"+this.schemaname+".").slice(0,-1)
  constructor(
    public dialogRef: MatDialogRef<ImagePropertyDialog>,
    @Inject(MAT_DIALOG_DATA) public data: attchment,
    private Router: ActivatedRoute
  ) {}
}
export interface attchment {
  url: string;
  path: string;
  attacpath;
}
