import { DataService } from "src/app/_services/data.service";
import { PmdashboardService } from "./../../_services/pmdashboard.service";
import { Router } from "@angular/router";
import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-pmhome",
  templateUrl: "./pmhome.component.html",
  styleUrls: ["./pmhome.component.css"]
})
export class PmhomeComponent implements OnInit {
  newRequest: any;
  data;
  searchedData: boolean = false;
  displayDashboard: boolean = true;
  role=localStorage.getItem('user_role')
  constructor(
    public router: Router,
    private getRequest: PmdashboardService,
    private dataservice: DataService
  ) {}

  ngOnInit() {
    this.getNewRequest();
  }
  getNewRequest() {
    this.getRequest.getNewMaintenaceRequest().subscribe(
      data => {
        this.newRequest = data;
        console.log(this.newRequest)
      },
      error => {
        this.newRequest = [];
      }
    );
  }
  searchData() {
    this.dataservice.searchValue.subscribe(
      data => {
        // console.log(data)
        if (data.type == "dashboard") {
          if (data.displayDashboard) {
            //show dashboard
            this.displayDashboard = true;
          } else {
            this.searchedData = true;
          }
        }
      },
      error => {
        // console.log(error)
      }
    );
  }
  navigateNewMaintaince(e){
    
    const requestType1 = document.getElementById('newRequest').innerText;
    const newMain=requestType1.includes('New');
    sessionStorage.setItem('NewMain',requestType1);
    this.router.navigate(["/dashboard/Maintenance"], {
      queryParams: { data: requestType1 }
    });
    if(newMain==true){
      this.router.navigate(["/dashboard/Maintenance"], {
        queryParams: { data: requestType1 }
      });
    }
  }
  navigateUpdateMaintaince(e){
    alert('ok')
    const requestType1 = document.getElementById('updateRequest').innerText;
    const newMain2=requestType1.includes('Updated');
    
    sessionStorage.setItem('UpdateMain',requestType1);
    alert(sessionStorage.UpdateMain)
    this.router.navigate(["/dashboard/Maintenance"], {
      queryParams: { data: requestType1 }
    });
       if(newMain2==true){
      this.router.navigate(["/dashboard/Maintenance"], {
        queryParams: { data: requestType1 }
      });
    }
  }
}
