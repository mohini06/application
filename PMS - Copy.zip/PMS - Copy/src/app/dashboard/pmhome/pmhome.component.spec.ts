import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PmhomeComponent } from './pmhome.component';

describe('PmhomeComponent', () => {
  let component: PmhomeComponent;
  let fixture: ComponentFixture<PmhomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PmhomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PmhomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
