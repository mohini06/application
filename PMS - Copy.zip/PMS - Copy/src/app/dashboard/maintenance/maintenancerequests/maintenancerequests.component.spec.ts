import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MaintenancerequestsComponent } from './maintenancerequests.component';

describe('MaintenancerequestsComponent', () => {
  let component: MaintenancerequestsComponent;
  let fixture: ComponentFixture<MaintenancerequestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MaintenancerequestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MaintenancerequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
