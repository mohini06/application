import { filter } from "rxjs/operators";
import { NavigationEnd } from "@angular/router";
import { Router, ActivatedRoute } from "@angular/router";
import { AddMaintenanceService } from "./../../../_services/add-maintenance.service";
import { Component, OnInit, ViewChild } from "@angular/core";
import { ClickEventArgs } from "@syncfusion/ej2-navigations";
import {
  GridComponent,
  ToolbarItems,
  EditService,
  PageService,
  CommandColumnService,
  CommandModel,
  PageSettingsModel,
  ColumnMenuService,
  RowSelectEventArgs,
  FilterSettingsModel
} from "@syncfusion/ej2-angular-grids";
import { DataStateChangeEventArgs } from "@syncfusion/ej2-grids";
import { Observable } from "rxjs";
import { DataService } from "src/app/_services/data.service";

@Component({
  selector: "app-maintenancerequests",
  templateUrl: "./maintenancerequests.component.html",
  styleUrls: ["./maintenancerequests.component.css"],
  providers: [EditService, PageService, CommandColumnService, ColumnMenuService]
})
export class MaintenancerequestsComponent implements OnInit {
  public pageOptions: Object;
  public filterSettings: FilterSettingsModel;
  public editSettings: Object;
  public toolbarOptions: ToolbarItems[] | object;
  public dTdata: any;
  public editparams: Object;
  public commands: CommandModel[];
  public initialPage: PageSettingsModel;
  // public viewData: Newitem;
  public formatOptions: any;
  @ViewChild("grid")
  public grid: GridComponent;
  url: any;

  public pageSizes: number[] = [10, 20, 100, 500, 1000];
  public pageSettings: Object;

  constructor(
    private dataService: DataService,
    public router: Router,
    private listAllMaintenance: AddMaintenanceService,
    private route: ActivatedRoute
  ) {}

  //  toolbarClick(args: ClickEventArgs): void {
  //   if (args.item.id === "Grid_excelexport") {
  //     // 'Grid_excelexport' -> Grid component id + _ + toolbar item name
  //     this.grid.excelExport();
  //   }
  // }
  ngOnInit() {
    this.searchData();
    this.initialPage = { pageSizes: true, pageSize: 10 };

    this.filterSettings = { type: "Menu" };
    this.toolbarOptions = ["ExcelExport", "Search"];
    this.getAllMaintenanceList();
  }
  getAllMaintenanceList() {
    this.listAllMaintenance.getlistAllMaintenance().subscribe(
      data => {
        this.dTdata = data;
        const a = sessionStorage.getItem("NewMain");
        const b = sessionStorage.getItem("UpdateMain");
        if (a) {
          this.dTdata = this.dTdata.filter(item => {
            sessionStorage.removeItem("NewMain");
            return item.status == "Open";
          });
        }
        if (b) {
          this.dTdata = this.dTdata.filter(item => {
            sessionStorage.removeItem("UpdateMain");
            return item.status != "Open";
          });
        }
      },
      error => {
        this.dTdata = [];
      }
    );
  }
  searchData() {
    this.dataService.searchValue.subscribe(
      data => {
        if (data.type == "maintenance") {
          this.dTdata = data.data;
        }
      },
      error => {
      }
    );
  }

  getId(maintananceId: string) {
    this.router.navigate(["/dashboard/view_maintanance"], {
      queryParams: { data: maintananceId }
    });
  }
}
