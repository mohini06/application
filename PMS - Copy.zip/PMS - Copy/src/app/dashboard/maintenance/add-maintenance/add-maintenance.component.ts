import { Component, OnInit, EventEmitter, Inject } from "@angular/core";
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators
} from "@angular/forms";
import { ListallpropertiesService } from "./../../../_services/listallproperties.service";
import { IssuetypesService } from "./../../../_services/issuetypes.service";
import { AddMaintenanceService } from "./../../../_services/add-maintenance.service";
import { Router, ActivatedRoute } from "@angular/router";
import { HttpClient } from "@angular/common/http";
import { MatDialog, MAT_DIALOG_DATA,MatDialogRef } from '@angular/material/dialog';
import { FileUploader, FileLikeObject } from "ng2-file-upload";
import { DatePipe } from "@angular/common";
import { AlertService } from './../../../_services/alert.service';
// import { ImageDialog, attchment } from '../view-maintenace/view-maintenace.component';
import { environment } from 'src/environments/environment';
// import { ConfirmationDialogComponent, ConfirmDialogModel } from 'src/app/confirmation-dialog/confirmation-dialog.component';


export interface attchment {
  url: string;
  path: string;
  attacpath;
}
@Component({
  selector: "app-add-maintenance",
  templateUrl: "./add-maintenance.component.html",
  styleUrls: ["./add-maintenance.component.css"]
})
export class AddMaintenanceComponent implements OnInit {
  public uploader: FileUploader = new FileUploader({
  });
  public uploadervid: FileUploader = new FileUploader({});
  public hasBaseDropZoneOver: boolean = false;
  // public issueotherdetails = false;
  // public subissueotherdetails = false;
  public divsubissue = false;
  addmaintenance: FormGroup;
  propertylist: any;
  issueLIst: any;
  submitted = false;
  subissue: any;
  selectedFile: File;
  urlId;
  rowData;
  selectedVideo: File;
  subissuetypes;
  errorimage = "";
  errorvideo = "";
  urls = [];
  maintenance_id: any;
  minDate: Date;
  dueDate: Date;
  imagesStored: any;
  videosStored: any;
  data: any;
  videoStored: any;
 
  breakpoint: number;
  result: any;
  // clicked = false;

  apiurl = environment.apiurl;
  schemaname = localStorage.getItem('currshema').replace(/['"]+/g, '');
  // isNameSelected: boolean;
  public isNameSelected = true;
  loading = false;
  // subissue: IssueSubType[]=[
  //   {value: '0', viewValue: 'Plumbing2', imgName:'plumbing3.png',issue_id:''},
  //   {value: '1', viewValue: 'Electrical3' ,imgName:'electrical.png',issue_id:''},
  //   {value: '2', viewValue: 'Interiors3' ,imgName:'interor.png',issue_id:''},
  //   {value: '3', viewValue: 'Exteriors3', imgName:'exterior.png',issue_id:''},
  //   {value: '4', viewValue: 'Appliance3s', imgName:'appliances2.png',issue_id:''}
  // ];
  constructor(public dialog: MatDialog,
    private datepipe: DatePipe,
    private router: Router,
    private route: ActivatedRoute,
    private addmaintenanceservice: AddMaintenanceService,
    private formBuilder: FormBuilder,
    private listproperties: ListallpropertiesService,
    private listIssue: IssuetypesService,
    private http: HttpClient,
    private alert: AlertService
  ) { }

  ngOnInit() {
    this.getIssueType();
    this.getData();
    this.getPropertyList(event);


    this.addmaintenance = this.formBuilder.group({
      issue_type: ["", Validators.required],
      subissue_type: [""],
      // otherdetails: [""],
      // extra_details: [""],
      extra_details: [""],
      priority: ["", Validators.required],
      propertyid: ["", Validators.required],
      requested_date: ["", Validators.required],
      work_start_date: [""],
      due_date: [""],
      video: [""],
      status: [""],
      last_update: [""],
      image: [""],
      id: [],


    });
    this.addmaintenance.valueChanges.subscribe(res => {
      this.minDate = new Date(res.requested_date);
      this.dueDate = new Date(res.work_start_date);
    });
    // this.getIssueSubType(this.id);
    // this.showOther(event);

  }
  get issue_type() {
    return this.addmaintenance.get("issue_type");
  }
  get subissue_type() {
    return this.addmaintenance.get("subissue_type");
  }
  // get otherdetails() {
  //   return this.addmaintenance.get("otherdetails");
  // }
  get extra_details() {
    return this.addmaintenance.get("extra_details");
  }
  get priority() {
    return this.addmaintenance.get("priority");
  }
  get propertyid() {
    return this.addmaintenance.get("propertyid");
  }
  get requested_date() {
    return this.addmaintenance.get("requested_date");
  }
  get work_start_date() {
    return this.addmaintenance.get("work_start_date");
  }
  get due_date() {
    return this.addmaintenance.get("due_date");
  }
  get status() {
    return this.addmaintenance.get("status");
  }
  get last_update() {
    return this.addmaintenance.get("last_update");
  }
  get video() {
    return this.addmaintenance.get("video");
  }
  get image() {
    return this.addmaintenance.get("image");
  }

  get id() {
    return this.addmaintenance.get("id");
  }
// Set the form data
  setFormValue() {
    this.issue_type.setValue(this.rowData.issue_type);
    this.getIssueSubType(this.issue_type.value);
    this.subissue_type.setValue(this.rowData.subissue_type);
    // this.otherdetails.setValue(this.rowData.otherdetails);
    this.extra_details.setValue(this.rowData.extra_details);
    this.priority.setValue(this.rowData.priority);
    this.propertyid.setValue(this.rowData.propertyid);
    this.requested_date.setValue(this.rowData.requested_date);
    this.work_start_date.setValue(this.rowData.work_start_date);
    this.due_date.setValue(this.rowData.due_date);
    this.status.setValue(this.rowData.status);
    this.last_update.setValue(this.rowData.last_update);
    this.image.setValue(this.rowData.image);
    this.video.setValue(this.rowData.video);
    this.id.setValue(this.rowData.id);
  }
  
  getData() {
    this.urlId = this.route.snapshot.queryParamMap.get("data");

    this.addmaintenanceservice.viewMaintenanceDetail(this.urlId).subscribe(
      data => {
        //     console.log(data.images_path[0])
        //     this.data=data; 
        //  this.videoStored=this.data.videos_path;
        //  this.imagesStored=data['images_path'];
        this.rowData = data;
        // console.log(data.images_path[0])
        this.data = data;
        //  this.videoStored=this.data.videos_path;
        this.videoStored = data['videos'];
        this.imagesStored = data['images'];
        // this.imagesStored=this.rowData.images;
        // // (response: Blob) => saveAs(response, this.rowData.images.fileName + '.xlsx')
        // console.log(this.imagesStored)
        //     this.videosStored=this.rowData.files;
        this.apiurl = this.apiurl.replace("http://", "http://" + this.schemaname + ".").slice(0, -1);
        this.setFormValue();
      },
      error => { }
    );
  }

  openImageDialog(path) {
    const dialogRef = this.dialog.open(ImageAddMaintDialog, {

      data: { attacpath: path }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log(`Dialog result: ${result}`);
    });
  }

  openVideoDialog(path) {

    const dialogRef = this.dialog.open(VideoAddMaintDialog, {

      data: { attacpath: path }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log(`Dialog result: ${result}`);
    });
  }


  ////////////////
  editSaveMaintenance() {
    if (this.id.value) {
      this.updateMaintenance();
    } else {
      this.addMaintenance();
    }
  }
  getIssueType() {
    this.listIssue.getIssue().subscribe(
      data => {
        this.issueLIst = data;

        console.log(this.issueLIst);
      },
      error => {
        this.issueLIst = [];
      }
    );
  }


  getIssueSubType(event) {
    console.log(event)
    // console.log(id.source.value)

    let issueid
    if (this.rowData) {
      issueid = event
    } else {
      issueid = event.value
      // this.subissue_type.setValue("");
      // issueid.setValue("");

    }
    console.log(issueid)
    if (this.issue_type.value == 6) {

      this.isNameSelected = false;

      this.subissue_type.clearValidators();
      this.subissue_type.updateValueAndValidity();
      this.subissue_type.setValue('');
      this.subissue_type.updateValueAndValidity();

      this.extra_details.setValidators([Validators.required]);
      this.extra_details.updateValueAndValidity();

    } else {
      this.isNameSelected = true;
      this.extra_details.clearValidators();
      this.extra_details.updateValueAndValidity();
      this.subissue_type.setValidators([Validators.required]);
      this.subissue_type.updateValueAndValidity();



      this.listIssue.getSubIssue(this.issue_type.value).subscribe(
        data => {
          console.log(issueid);
          // this.subissuetypes = data[0].name;
          this.subissue = data;
          console.log(data);
        },
        error => {
          this.subissue = [];
        }
      );
    }
  }
  showOther(event) {
    console.log(event);
    // this.issueotherdetails = true;
    let target = event.source.selected._element.nativeElement;
    let selectedData = {
      id: event.value,
      name: target.innerText.trim()
    };
    console.log(selectedData);
    if (selectedData.name == "others") {
      this.extra_details.setValidators([Validators.required]);
      this.extra_details.updateValueAndValidity();
      // this.issueotherdetails = true;
      // this.subissueotherdetails = true;
      // console.log(name);
      return;
    } else {
      this.extra_details.clearValidators();
      this.extra_details.updateValueAndValidity();
      // this.issueotherdetails = false;
      // this.subissueotherdetails = false;
      // console.log(name);
    }
  }


  //   onChanges() {
  //     this.addmaintenance.get('country').valueChanges
  //     .subscribe(selectedCountry => {
  //         if (selectedCountry != 'USA') {
  //             this.addmaintenance.get('state').reset();
  //             this.addmaintenance.get('state').disable();
  //         }
  //         else {
  //             this.addmaintenance.get('state').enable();
  //         }
  //     });
  // }
  // hideOther(){
  //   this.issueotherdetails=false;
  //       this.subissueotherdetails=false;
  // }
  getPropertyList(event: any) {
    this.listproperties.getAllProperty().subscribe(
      data => {
        this.propertylist = data;
        // console.log(this.propertylist);
      },
      error => {
        this.propertylist = [];
      }
    );
  }
  // onFileChange(event) {
  //   if (event.target.files.length > 0) {
  //     const file = event.target.files[0];
  //     this.addmaintenance.get('maintenance_images').setValue(file);
  //   }

  // }
  getImages(): FileLikeObject[] {
    return this.uploader.queue.map(fileItem => {
      return fileItem.file;
    });
  }
  getVideos(): FileLikeObject[] {
    return this.uploadervid.queue.map(fileItem => {
      return fileItem.file;
    });
  }
  // AddMaintenance
  addMaintenance() {
    console.log("add maintance")

    let selectedImages = this.getImages();
    let selectedvideos = this.getVideos();

    if (
      (selectedImages.length > 0 && selectedvideos.length > 0) ||
      (selectedImages.length == 0 && selectedvideos.length > 0) ||
      (selectedImages.length > 0 && selectedvideos.length == 0)
    ) {
      // console.log("test");

      if (selectedvideos.length > 0) {
        selectedvideos.forEach(selectedVideo => {
          let videoext: any = selectedVideo.name.split(".").pop();
          // console.log(videoext);
          if (videoext != "mp4") {
            console.log("not empty 2");
            this.errorvideo = "video should be mp4";
            return;
          } else if (selectedVideo.size > 41943040) {
            this.errorvideo = "video size should not exceed from 5 mb";
            return;
          } else {
            this.errorvideo = "";
            this.errorimage = "";
          }
        });
      }
      if (selectedImages.length > 0) {
        selectedImages.forEach(selectedFile => {
          let ext: any = selectedFile.name.split(".").pop();
          // console.log(ext);
          if (
            ext != "png" &&
            ext != "jpg" &&
            ext != "jpeg" &&
            ext != "PNG" &&
            ext != "JPG" &&
            ext != "JPEG"
          ) {
            // console.log('not valid')
            console.log("not empty 3");
            this.errorimage = "Image should be png,jpg,jpeg,PNG,JPG or JPEG";
            this.submitted = false;
            return;
          } else {
            this.errorimage = "";
            this.errorvideo = "";
            //  this.saveField_attachment()
          }
        });
      }

      this.saveField_attachment();
    } else {
      this.errorimage = "";
      this.errorvideo = "";
      this.saveFieldData();
    }
  }

  saveField_attachment() {
    console.log("savefield attachment")
    if (
      this.addmaintenance.invalid ||
      this.errorimage != "" ||
      this.errorvideo != ""
    ) {
      return;
    } else {
      console.log('not empty 5')
      let formData = new FormData();
      formData.append("issue_type", this.addmaintenance.value.issue_type);
      formData.append("subissue_type", this.addmaintenance.value.subissue_type);
      // formData.append("otherdetails", this.addmaintenance.value.otherdetails);
      formData.append("extra_details", this.addmaintenance.value.extra_details);
      formData.append("priority", this.addmaintenance.value.priority);
      formData.append("propertyid", this.addmaintenance.value.propertyid);
      formData.append(
        "requested_date",
        this.transformDate(
          this.addmaintenance.value.requested_date
            ? this.addmaintenance.value.requested_date
            : ""
        )
      );
      formData.append(
        "due_date",
        this.addmaintenance.value.due_date
          ? this.transformDate(this.addmaintenance.value.due_date)
          : ""
      );
      formData.append(
        "work_start_date",
        this.addmaintenance.value.work_start_date
          ? this.transformDate(this.addmaintenance.value.work_start_date)
          : ""
      );

      let attachments = this.getAttachments();
      attachments.forEach(attachment => {
        formData.append("videos", attachment.rawFile, attachment.name);
      });
      let Images = this.getImagess();
      Images.forEach(Image => {
        formData.append("images", Image.rawFile, Image.name);
      });


      // formData.append('id',this.addmaintenance.value.id);
      this.addmaintenanceservice.addMaintenance(formData).subscribe(
        data => {

          console.log("befor success")
          this.alert.success("Maintenance Added Successfully with images and videos");
          console.log("after success")
          setTimeout(() => {
            // this.alert.removeAlert();
            // this.emitEventToChild()
            this.router.navigate(["/dashboard/Maintenance"]);
          }, 4000);
          // console.log(data);

          // this.onUploadImage(data.maintenance_id);
          // this.onUploadVideo(data.maintenance_id);
          // this.router.navigate(["/dashboard/Maintenance"]);
          // this.maintenance_id=data.maintenance_id;
        },
        error => {
          this.alert.error("Maintenance not added with images and videos,Please try again");
          // this.errormessage="Please fill correct value" ;
          this.router.navigate(["/dashboard/add_Maintenance"]);
        }
      );
    }
  }
  saveFieldData() {
    console.log("savefield data")
    if (this.addmaintenance.invalid) {
      return;
    } else {
      let formData = new FormData();
      formData.append("issue_type", this.addmaintenance.value.issue_type);
      formData.append("subissue_type", this.addmaintenance.value.subissue_type);
      // formData.append("otherdetails", this.addmaintenance.value.otherdetails);
      formData.append("extra_details", this.addmaintenance.value.extra_details);
      formData.append("priority", this.addmaintenance.value.priority);
      formData.append("propertyid", this.addmaintenance.value.propertyid);
      formData.append(
        "requested_date",
        this.transformDate(
          this.addmaintenance.value.requested_date
            ? this.addmaintenance.value.requested_date
            : ""
        )
      );
      formData.append(
        "due_date",
        this.addmaintenance.value.due_date
          ? this.transformDate(this.addmaintenance.value.due_date)
          : ""
      );
      formData.append(
        "work_start_date",
        this.addmaintenance.value.work_start_date
          ? this.transformDate(this.addmaintenance.value.work_start_date)
          : ""
      );

      let attachments = this.getAttachments();
      attachments.forEach(attachment => {
        formData.append("videos", attachment.rawFile, attachment.name);
      });
      let Images = this.getImagess();
      Images.forEach(Image => {
        formData.append("images", Image.rawFile, Image.name);
      });
      // formData.append('id',this.addmaintenance.value.id);
      console.log("23", formData);
      this.addmaintenanceservice.addMaintenance(formData).subscribe(
        data => {
          console.log("befor success")
          this.alert.success("Maintenance Added Successfully");
          console.log("after success")
          setTimeout(() => {
            // this.alert.removeAlert();
            // this.emitEventToChild()
            this.router.navigate(["/dashboard/Maintenance"]);
          }, 4000);

          console.log(data);
          // this.getIssueSubType(this.id)
          console.log("")


        },

        error => {
          this.alert.error("Maintenance not added,Please try again");
          this.router.navigate(["/dashboard/add_Maintenance"]);
        }
      );
    }
  }

  getImagess(): FileLikeObject[] {
    return this.uploader.queue.map(fileItem => {
      return fileItem.file;
    });
  }
  getAttachments(): FileLikeObject[] {
    return this.uploadervid.queue.map(fileItem => {
      return fileItem.file;
    });
  }
  // UpdateMaintenance
  updateMaintenance() {
    this.submitted = true;
    if (this.addmaintenance.invalid) {
      return;
    } else {
      let formData = new FormData();
      formData.append("issue_type", this.addmaintenance.value.issue_type);
      formData.append("subissue_type", this.addmaintenance.value.subissue_type ? this.addmaintenance.value.subissue_type : '');
      // formData.append("otherdetails", this.addmaintenance.value.otherdetails);
      formData.append("extra_details", this.addmaintenance.value.extra_details);
      formData.append("priority", this.addmaintenance.value.priority);
      formData.append("status", this.addmaintenance.value.status);
      formData.append("last_update",this.addmaintenance.value.last_update);
      formData.append("propertyid", this.addmaintenance.value.propertyid);
      formData.append(
        "requested_date",
        this.transformDate(
          this.addmaintenance.value.requested_date
            ? this.addmaintenance.value.requested_date
            : ""
        )
      );
      formData.append(
        "due_date",
        this.addmaintenance.value.due_date
          ? this.transformDate(this.addmaintenance.value.due_date)
          : ""
      );
      formData.append(
        "work_start_date",
        this.addmaintenance.value.work_start_date
          ? this.transformDate(this.addmaintenance.value.work_start_date)
          : ""
      );

      let attachments = this.getAttachments();
      attachments.forEach(attachment => {
        formData.append("videos", attachment.rawFile, attachment.name);
      });
      let Images = this.getImagess();
      Images.forEach(Image => {
        formData.append("images", Image.rawFile, Image.name);
      });
      //  alert('SUCCESS!! :-)\n\n' +  JSON.stringify(Object.assign({}, this.firstFormGroup.value, this.secondFormGroup.value)  ));
      //  console.log('SUCCESS!! :-)\n\n' +  JSON.stringify(Object.assign({}, this.firstFormGroup.value, this.secondFormGroup.value)  ))
      this.addmaintenanceservice
        .updateMaintenance(formData, this.addmaintenance.value.id)
        .subscribe(
          data => {
            //     console.log(data.images_path[0])
            //     this.data=data; 
            //  this.videoStored=this.data.videos_path;
            //  this.imagesStored=data['images_path'];
            this.alert.success("Maintenance updated Successfully");
            setTimeout(() => {
              // this.alert.removeAlert();
              // this.emitEventToChild()
              this.router.navigate(["/dashboard/view_maintanance"], {
                queryParams: { data: data.id }
              });
            }, 4000);


          },
          error => {
            this.alert.error("Maintenance not updated,Please try again");
            //  this.errormessage="Please fill correct value" ;
          }
        );
    }
  }

  // openImageDialog(path){
  //     const dialogRef = this.dialog.open(ImageDialog, {

  //       data: {attacpath:path}
  //     });

  //     dialogRef.afterClosed().subscribe(result => {
  //       // console.log(`Dialog result: ${result}`);
  //     });
  //   }


  onFileChanged(event) {
    // this.ArrayOfSelectedFile= [];
    this.selectedFile = event.target.files[0];

  }
  onFileChangedVideo(event) {
    this.selectedVideo = event.target.files[0];
    // console.log(event);

  }
  
  save(): void {
    console.log(this.loading)
    this.loading = true;
    console.log(this.loading)
    this.editSaveMaintenance()
    // this.loading = false;
  }

  deleteimage(index: number) {

    this.data.images.splice(index, 1);
    // this.data.videos.splice(index, 1);

  }
  deletevideo(index: number) {

    this.data.videos.splice(index, 1);

  }
  // getImages(): FileLikeObject[] {
  //   return this.uploader.queue.map(fileItem => {
  //     return fileItem.file;
  //   });
  // }
  //   onUploadImage(id: any) {
  //     let files = this.getImages();
  //     // console.log(files);
  //     let requests = [];
  //     files.forEach(file => {
  //       let uploadData = new FormData();
  //       uploadData.append("images", file.rawFile, file.name);
  //       uploadData.append("maintenance_id", id);
  // this.addmaintenanceservice.addMaintenance(uploadData).subscribe(data => {
  // },
  // error =>{

  // })

  //     });
  //   }
  // getVideos(): FileLikeObject[] {
  //   return this.uploadervid.queue.map(fileItem => {
  //     return fileItem.file;
  //   });
  // }
  // onUploadVideo(id: any) {
  //   let videos = this.getVideos();
  //   // console.log(videos);
  //   let requests = [];
  //   videos.forEach(video => {
  //     let uploadData = new FormData();
  //     uploadData.append("videos", video.rawFile, video.name);
  //     uploadData.append("maintenance_id", id);
  //     this.addmaintenanceservice.addMaintenance(uploadData).subscribe(data => {
  //     },
  //     error =>{

  //     })

  //         });
  // }
  transformDate(date) {
    return this.datepipe.transform(date, "yyyy-MM-dd");

  }

}
@Component({
  selector: 'video_dialog',
  templateUrl: 'video_dialog.html',
})

export class VideoAddMaintDialog {
  schemaname = localStorage.getItem('currshema').replace(/['"]+/g, '');


  apiurl = environment.apiurl.replace("http://", "http://" + this.schemaname + ".").slice(0, -1);


  constructor(
    public dialogRef: MatDialogRef<VideoAddMaintDialog>,
    @Inject(MAT_DIALOG_DATA) public data: attchment, private Router: ActivatedRoute) { }


}

@Component({
  selector: 'image_dialog',
  templateUrl: 'image_dialog.html',
})

export class ImageAddMaintDialog {
  schemaname = localStorage.getItem('currshema').replace(/['"]+/g, '');


  apiurl = environment.apiurl.replace("http://", "http://" + this.schemaname + ".").slice(0, -1);
  constructor(
    public dialogRef: MatDialogRef<ImageAddMaintDialog>,
    @Inject(MAT_DIALOG_DATA) public data: attchment,private Router:ActivatedRoute) {
      console.log(data.attacpath)
    }
   
  
  }