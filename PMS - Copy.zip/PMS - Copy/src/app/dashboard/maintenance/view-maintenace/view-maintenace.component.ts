import { HttpClient } from '@angular/common/http';
import { environment } from './../../../../environments/environment';
import { Router, ActivatedRoute } from '@angular/router';
import { AddMaintenanceService } from './../../../_services/add-maintenance.service';
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ConfirmationDialogComponent, ConfirmDialogModel } from './../../../confirmation-dialog/confirmation-dialog.component';

export interface attchment {
  url: string;
  path: string;
  attacpath;
}

@Component({
  selector: 'app-view-maintenace',
  templateUrl: './view-maintenace.component.html',
  styleUrls: ['./view-maintenace.component.css']
})
export class ViewMaintenaceComponent implements OnInit {
  data: any;
  attacpath;
  breakpoint: number;
  result: string = '';
  imagesStored: any;
  videoStored: any;
  imagepath: any;
  images_path1 = [];
  apiurl = environment.apiurl;
  datam: any;
  dthistory: any;
  // viewMaintenanceHistory: any;
  constructor(public dialog: MatDialog, public router: Router, private http: HttpClient, private viewMaintenanceHistory: AddMaintenanceService, private viewMaintanance: AddMaintenanceService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.getMaintenanceDetail(this.route.snapshot.queryParams['data']);
    console.log(this.route.snapshot.queryParams['data'])
    this.getMaintenanceHistory(this.route.snapshot.queryParams['data'])
    // console.log(this.route.snapshot.queryParams['data'])
    this.breakpoint = (window.innerWidth <= 800) ? 2 : 2;

  }
  getMaintenanceDetail(id) {


    this.viewMaintanance.viewMaintenanceDetail(id)
      .subscribe(data => {
        console.log(data.images[0])
        this.data = data;
        // this.videoStored=this.data.videos_path;
        this.videoStored = data['videos'];
        this.imagesStored = data['images'];
        //   for(let i=0;i<data.images_path.length;i++){
        //  console.log(data['images_path'][i].image_path)
        //   }
        // this.data.array.forEach((item,index)=> {
        //   var obj;
        //   obj=[
        //   this.data.image_id=item.image_id,
        //     this.data.image_path=item.image_path,
        //   ]
        //   this.images_path1.push(obj)
        // });
        console.log(this.images_path1)

        this.apiurl = this.apiurl.slice(0, -1);

      },
        error => {



        })
  }


  getMaintenanceHistory(id) {


    this.viewMaintenanceHistory.viewMaintenanceHistory(id)
      .subscribe(datam => {

        this.datam = datam;
        console.log(this.datam)
        this.dthistory = datam['history']

        // this.apiurl= this.apiurl.slice(0,-1);

      },
        error => {



        })
  }

  openImageDialog(path) {
    console.log(path)
    const dialogRef = this.dialog.open(ImageDialog, {

      data: { attacpath: path }

    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }
  openDialog(path) {

    const dialogRef = this.dialog.open(VideoDialog, {

      data: { attacpath: path }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log(`Dialog result: ${result}`);
    });
  }
  editMaintenance(maintenanceId: string) {
    this.router.navigate(['/dashboard/add_Maintenance'], { queryParams: { data: maintenanceId } })
  }

  confirmDialog(id): void {
    const message = `Are you sure you want to delete?`;

    const dialogData = new ConfirmDialogModel("Confirm Action", message, id, "maintenance");

    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      maxWidth: "400px",
      data: dialogData
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      this.result = dialogResult;
    });
  }
  onResize(event) {
    this.breakpoint = event.target.innerWidth <= 800 ? 2 : 4;
  }
}
@Component({
  selector: 'video_dialog',
  templateUrl: 'video_dialog.html',
})

export class VideoDialog {
  apiurl = environment.apiurl.slice(0, -1);

  constructor(
    public dialogRef: MatDialogRef<VideoDialog>,
    @Inject(MAT_DIALOG_DATA) public data: attchment, private Router: ActivatedRoute) { }


}

@Component({
  selector: 'image_dialog',
  templateUrl: 'image_dialog.html',
})

export class ImageDialog {
  schemaname = localStorage.getItem('currshema').replace(/['"]+/g, '');


  apiurl = environment.apiurl.replace("http://", "http://" + this.schemaname + ".").slice(0, -1);

  constructor(
    public dialogRef: MatDialogRef<ImageDialog>,
    @Inject(MAT_DIALOG_DATA) public data: attchment, private Router: ActivatedRoute) {
    console.log(data.attacpath)
  }


}
export interface attchment {
  url: string;
  path: string;
  attacpath;
}