import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewMaintenaceComponent } from './view-maintenace.component';

describe('ViewMaintenaceComponent', () => {
  let component: ViewMaintenaceComponent;
  let fixture: ComponentFixture<ViewMaintenaceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewMaintenaceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewMaintenaceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
