import { SettingComponent } from './setting/setting.component';
import { ChangepwdComponent } from './changepwd/changepwd.component';
import { ThomeComponent } from './thome/thome.component';
import { OhomeComponent } from './ohome/ohome.component';
import { ViewMaintenaceComponent } from './maintenance/view-maintenace/view-maintenace.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PmhomeComponent } from './pmhome/pmhome.component';
import { ListAllPropertyComponent } from './property/list-all-property/list-all-property.component';
import { AddPropertyComponent } from './property/add-property/add-property.component';
import { ViewPropertyComponent } from './property/view-property/view-property.component';
import { ListownerComponent } from './owner/listowner/listowner.component';
import { AddOwnerComponent } from './owner/add-owner/add-owner.component';
import { ViewOwnerComponent } from './owner/view-owner/view-owner.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { AddTenantComponent } from './tenant/add-tenant/add-tenant.component';
import { ListAllTenantComponent } from './tenant/list-all-tenant/list-all-tenant.component';
import { MaintenancerequestsComponent } from './maintenance/maintenancerequests/maintenancerequests.component';
import { AuthGuard } from '../_guard/auth.guard';
import { PageNotFoundComponent } from '../page-not-found/page-not-found.component';
import { ViewtenantComponent } from './tenant/viewtenant/viewtenant.component';
import { AddMaintenanceComponent } from './maintenance/add-maintenance/add-maintenance.component';




const routes: Routes = [
  {
    path: 'dashboard',
    component: DashboardComponent, canActivate: [AuthGuard],
    children: [
      {
        path: '',
        component: DashboardComponent

      },
      {
        path: 'adminhome',
        component: AdminhomeComponent

      },
      {
        path: 'pmhome',
        component: PmhomeComponent
      },
      {
        path: 'ohome',
        component: OhomeComponent
      },
      {
        path: 'thome',
        component: ThomeComponent
      },
    
      {
        path: 'changepwd',
        component: ChangepwdComponent
      },
      {
        path: 'setting',
        component: SettingComponent
      },
      {
        path: 'listproperty',
        component: ListAllPropertyComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'add_property',
        component: AddPropertyComponent,
        canActivate: [AuthGuard]

      },
      {
        path: 'view_property',
        component: ViewPropertyComponent,
        canActivate: [AuthGuard]

      },
      {
        path: 'list_owner',
        component: ListownerComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'add_owner',
        component: AddOwnerComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'view_owner',
        component: ViewOwnerComponent,
        canActivate: [AuthGuard]
      },

      {
        path: 'list_all_tenant',
        component: ListAllTenantComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'add_tenant',
        component: AddTenantComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'view_tenant',
        component: ViewtenantComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'Maintenance',
        component: MaintenancerequestsComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'add_Maintenance',
        component: AddMaintenanceComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'view_maintanance',
        component: ViewMaintenaceComponent,
        canActivate: [AuthGuard]
      },

      { path: '**', component: PageNotFoundComponent }

    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes), RouterModule.forRoot(routes, {
    useHash: true
  })],
  exports: [RouterModule]
})
export class DashboardRoutingModule {



}
