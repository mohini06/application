import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-quicksidenav',
  templateUrl: './quicksidenav.component.html',
  styleUrls: ['./quicksidenav.component.css']
})
export class QuicksidenavComponent implements OnInit {

  @Output() quicknavOpen = new EventEmitter();
  quicknavopen = false;
 
  
  constructor(private router:Router) { 
  
  }
  ngOnInit() {
  }
  public onQuicknavClose = () => {
    this.quicknavOpen.emit();
    // this.sidenavopen=false;
    // this.quicknavopen=true;
  }
  logout()
  {
 
   localStorage.clear();
      this.router.navigate(['/']);
    
  }

}
