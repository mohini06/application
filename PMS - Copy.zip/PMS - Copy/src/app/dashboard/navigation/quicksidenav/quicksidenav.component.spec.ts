import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuicksidenavComponent } from './quicksidenav.component';

describe('QuicksidenavComponent', () => {
  let component: QuicksidenavComponent;
  let fixture: ComponentFixture<QuicksidenavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuicksidenavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuicksidenavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
