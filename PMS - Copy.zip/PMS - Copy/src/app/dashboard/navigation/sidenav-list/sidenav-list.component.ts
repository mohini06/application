
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-sidenav-list',
  templateUrl: './sidenav-list.component.html',
  styleUrls: ['./sidenav-list.component.css']
})
export class SidenavListComponent implements OnInit {
  @Output() sidenavClose = new EventEmitter();
  sidenavopen = true;
  quicknavopen = false;
  show: boolean = true;
  // active = true;
  // inactive:boolean = false;
  // isEnabled = true;
  role: string;
  public pmnav= false;
  public onav = false;
  user: any
  public tnav = false;
  public greyimg = false;
  public whiteimg = true;
 
  constructor(private router: Router) { }

  ngOnInit() {

   this.showNavlist();

  //  if(this.active=true){
  //    this.inactive =false;
  //    }

  }
showNavlist(){
  this.user = JSON.parse(localStorage.getItem("user_role"));
  console.log(this.user)
  if(this.user=="Property Manager") {
    console.log(this.user)
    this.pmnav = true;  
    this.onav = false;
    this.tnav= false;

  }
  else if(this.user=="Owner") 
  {
    console.log(this.user)
    this.onav = true;
    this.pmnav= false;
    this.tnav= false;
  }
   else if(this.user=="Tenant")
    {
      this.onav = false;
      this.pmnav= false;
      this.tnav= true;
    }
  else {
    this.onav = false;
    this.pmnav = false;
  }
}
  public onSidenavClose = () => {
    this.sidenavClose.emit();
    // localStorage.setItem('user_role', JSON.stringify(this.role));
    // this.user = JSON.parse(localStorage.getItem('this.role'));

  }
  logout() {

    localStorage.clear();
    this.router.navigate(['/']);

  }

  displayimg(){
   if(this.whiteimg==true){
    this.greyimg=false;
  }else{
    this.greyimg=true;
  }
}
}
