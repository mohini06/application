import { Component, OnInit, Output, EventEmitter } from "@angular/core";
import { AuthService } from "src/app/_services/auth.service";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { SearchService } from "src/app/_services/search.service";
import { Router, NavigationEnd } from "@angular/router";
import { DataService } from "src/app/_services/data.service";
import { ListallpropertiesService } from "src/app/_services/listallproperties.service";
import { ListallownerService } from "src/app/_services/listallowner.service";
import { ListalltenantService } from "src/app/_services/listalltenant.service";
import { AddMaintenanceService } from "src/app/_services/add-maintenance.service";
import { Observable } from "rxjs";
import { switchMap, debounceTime, tap, finalize } from "rxjs/operators";
import { outputs } from '@syncfusion/ej2-angular-grids/src/grid/grid.component';
@Component({
  selector: "app-header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.css"]
})
export class HeaderComponent implements OnInit {
  submitted = false;
  searchForm: FormGroup;
  globalSearchForm: FormGroup;
  data: any;
  urlData = "";
  filteredUsers: any = [];
  isLoading: boolean = false;
  options: string[];
  dashboard: boolean = false;
  dashboardSearch = false;
  userId: number;
  type: string;
  userName:string;
  role=JSON.parse(localStorage.getItem('user_role'))
  // username=JSON.parse(localStorage.getItem('currshema'))
  username=JSON.parse(localStorage.getItem('user_name'))
  displayFn;
  @Output() public sidenavToggle = new EventEmitter();
  @Output()  public quicknavTogle= new EventEmitter();
  filteredOptions: Observable<string[]>;
  error: string;
 
  constructor(
    private listAllMaintenance: AddMaintenanceService,
    private listtenants: ListalltenantService,
    private listowners: ListallownerService,
    private listproperties: ListallpropertiesService,
    private Dataservice: DataService,
    private authservice: AuthService,
    private searchservice: SearchService,
    private router: Router,
    private formBuilder: FormBuilder
  ) {
    router.events.subscribe((event: NavigationEnd) => {
      if (event.url) {
        this.urlData = event.url;

        if (this.urlData == "/dashboard/pmhome") {
          this.dashboard = false;
          this.dashboardSearch = true;
        } else {
                    
          if (this.urlData == "/dashboard/listproperty" || this.urlData == "/dashboard/list_owner" || this.urlData == "/dashboard/Maintenance" || this.urlData == "/dashboard/list_all_tenant" || this.urlData == "/dashboard/ohome") {
            this.dashboard = true;
            this.dashboardSearch = false;
          }
          else {
            this.dashboard = false;
            this.dashboardSearch = false;
          }

        }
   
      }
    });
  }

  ngOnInit() {
    this.searchForm = this.formBuilder.group({
      search_key: ["", [Validators.minLength(3), Validators.maxLength(32), Validators.pattern(".*\\S.*[a-zA-z0-9 ]")]]
    });
    this.globalSearchForm = this.formBuilder.group({
      userInput: ["",[Validators.minLength(3), Validators.maxLength(32),Validators.pattern(".*\\S.*[a-zA-z0-9 ]")]]
    });
  }

  searchKeyword(e) {
    if(e.target.value && e.target.value.length>1)
    {
 this.globalSearchForm
      .get("userInput")
      .valueChanges.pipe(
        // debounceTime(300),
        tap(() => (this.isLoading = true)),
        switchMap(() =>
          this.searchservice
            .search(this.userInput.value)
            .pipe(finalize(() => (
              this.isLoading = false
              )))
        )
      )
      .subscribe(data => (this.filteredUsers = data["search_details"]));
    
      // error => {
         
      //   this.success="Search data not found" ;
    
      // }
    }
    // if(this.filteredUsers == null || this.filteredUsers === 0 || this.filteredUsers.length === 0)
    if(this.filteredUsers.length === 0){

      console.log("Search data not found")
      this.error="Search data not found" ;
       }else{
         return
       }
  }

  get userInput() {
    return this.globalSearchForm.get("userInput");
  }

  getGloabalSearch(text) {
    this.searchservice.getSearchlistDashboard(text).subscribe(
      data => {
        this.filteredOptions = data;
        // console.log(this.amenitie);
      },
      error => {
        
      }
    );
  }
  public onToggleSidenav = () => {
    this.sidenavToggle.emit();
    
  };

  // public onToggleQuicknav = () => {
  //   this.quicknavTogle.emit();
    
  // };
  changepwd(){
    this.router.navigate(["/dashboard/changepwd"]);
  }
  logout() {
    localStorage.clear();
    
    this.router.navigate(["/"]);
  }

  search() {
    this.submitted = true;
    if (this.searchForm.invalid) {
      return;
    } else {
      // console.log("call")
      if (this.urlData == "/dashboard/pmhome") {
      }
      if (this.urlData == "/dashboard/listproperty") {
        this.search_property();
      }

      if (this.urlData == "/dashboard/list_owner") {
        this.search_owner();
      }
      if (this.urlData == "/dashboard/list_all_tenant") {
        this.search_tenant();
      }
      if (this.urlData == "/dashboard/Maintenance") {
        this.search_maintenance();
      }
    }
  }

  search_Dashboard() {
    this.submitted = true;
    if (this.searchForm.invalid) {
      return;
    } else {
      if (this.searchForm.get("search_key").value == "") {
        this.Dataservice.searchdata("", "dashboard", true);
      } else {
        // this.searchForm.value.minLength="3";
        this.searchservice
          .getSearchlistDashboard(this.searchForm.value)
          .subscribe(
            data => {
              this.Dataservice.searchdata(data, "dashboard", false);
            },
            error => {
              this.data = [];
            }
          );
      }
    }
  }

  search_property() {
    this.submitted = true;
    if (this.searchForm.invalid) {
      return;
    } else {
      if (this.searchForm.get("search_key").value == "") {
        this.listproperties.getAllProperty().subscribe(
          data => {
            this.Dataservice.searchdata(data, "property");
          },
          error => {
            this.data = [];
          }
        );
      } else {
        this.searchservice
          .getSearchlistProperty(this.searchForm.value)
          .subscribe(
            data => {
              this.Dataservice.searchdata(data, "property");
            },
            error => {
              this.data = [];
            }
          );
      }
    }
  }

  search_owner() {
    this.submitted = true;
    if (this.searchForm.invalid) {
      return;
    } else {
      if (this.searchForm.get("search_key").value == "") {
        this.listowners.getAllOwner().subscribe(
          data => {
            this.Dataservice.searchdata(data, "owner");
          },
          error => {
            this.data = [];
          }
        );
      } else {
        this.searchservice.getSearchlistOwner(this.searchForm.value).subscribe(
          data => {
            // console.log(data)
            // alert('added successfully')
            this.Dataservice.searchdata(data, "owner");
          },
          error => {
            // this.errormessage="Please fill correct value" ;
            this.data = [];
          }
        );
      }
    }
  }
  search_tenant() {
    this.submitted = true;
    if (this.searchForm.invalid) {
      return;
    } else {
      if (this.searchForm.get("search_key").value == "") {
        this.listtenants.getAllTenant().subscribe(
          data => {
            this.Dataservice.searchdata(data, "tenant");
          },
          error => {
            this.data = [];
          }
        );
      } else {
        this.searchservice.getSearchlistTenant(this.searchForm.value).subscribe(
          data => {
            this.Dataservice.searchdata(data, "tenant");
          },
          error => {
            this.data = [];
          }
        );
      }
    }
  }
  search_maintenance() {
    this.submitted = true;
    if (this.searchForm.invalid) {
      return;
    } else {
      if (this.searchForm.get("search_key").value == "") {
        this.listAllMaintenance.getlistAllMaintenance().subscribe(
          data => {
            this.Dataservice.searchdata(data, "maintenance");
          },
          error => {
            this.data = [];
          }
        );
      } else {
        this.searchservice
          .getSearchlistMaintenance(this.searchForm.value)
          .subscribe(
            data => {
              this.Dataservice.searchdata(data, "maintenance");
            },
            error => {
              this.data = [];
            }
          );
      }
    }
  }
  getSearchDetails(e) {}
  navigate(e) {
  
  }
  navigateToDifferent(e) {
    const id = this.globalSearchForm.value.userInput.id;
    const type = this.globalSearchForm.value.userInput.type;
    this.type = type;
    this.userId = id;
    this.userName=e.target.innerText;
    this.globalSearchForm.controls["userInput"].setValue(this.userName);

    if (this.type == "Owner") {
      this.router.navigate(["/dashboard/view_owner"], {
        queryParams: { data: this.userId }
      });
    }
    if (this.type == "Property") {
      this.router.navigate(["/dashboard/view_property"], {
        queryParams: { data: this.userId }
      });
    }

    if (this.type == "Tenant") {
      this.router.navigate(["/dashboard/view_tenant"], {
        queryParams: { data: this.userId }
      });
    }
    if (this.type == "Maintenance") {
      this.router.navigate(["/dashboard/view_maintanance"], {
        queryParams: { data: this.userId }
      });
    }
    this.globalSearchForm.controls["userInput"].setValue('');
  }
  
}
