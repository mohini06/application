import { from } from 'rxjs';

import { ConfirmationDialogComponent } from './../confirmation-dialog/confirmation-dialog.component';
import { MatPaginatorModule } from '@angular/material/paginator';

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import {MatTooltipModule} from '@angular/material/tooltip';
import { MatTabsModule, MatDatepickerModule, MatSlideToggleModule, MatButtonToggleModule, MatDividerModule, MatDialogModule, MatStepperModule, MatExpansionModule, MatListModule, MatBadgeModule, MatNativeDateModule, MatFormFieldModule, MatButtonModule, MatCheckboxModule,MatRadioModule, MatToolbarModule, MatInputModule, MatProgressSpinnerModule, MatCardModule, MatMenuModule, MatIconModule, MatSelectModule, MatSidenavModule, MatSliderModule, MatChipsModule, MatGridListModule, MatTableModule, MatAutocompleteModule } from '@angular/material';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { NgScrollbarModule } from 'ngx-scrollbar';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from '../app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SidenavListComponent } from './navigation/sidenav-list/sidenav-list.component';
import { HeaderComponent } from './navigation/header/header.component';
import { HomeComponent } from './home/home.component';
import { AddPropertyComponent, ImageAddPropDialog } from './property/add-property/add-property.component';
import { ListAllPropertyComponent } from './property/list-all-property/list-all-property.component';
import { ViewPropertyComponent, ImagePropertyDialog } from './property/view-property/view-property.component';
import { PmhomeComponent } from './pmhome/pmhome.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { AddOwnerComponent } from './owner/add-owner/add-owner.component';
import { ViewOwnerComponent, ImageOwnerDialog } from './owner/view-owner/view-owner.component';
import { ListownerComponent } from './owner/listowner/listowner.component';
import { DialogOverviewExampleDialog } from './property/add-property/dialog-overview-example-dialog';
import { DialogOverviewTenanttypDialog } from './property/add-property/dialog-overview-tenanttyp-dialog';
// import { DialogOverviewTenantnoDialog } from './property/add-property/dialog-overview-tenantno-dialog';
import { AddTenantComponent } from './tenant/add-tenant/add-tenant.component';
import { ListAllTenantComponent } from './tenant/list-all-tenant/list-all-tenant.component';
import { MaintenancerequestsComponent } from './maintenance/maintenancerequests/maintenancerequests.component';
import { AddMaintenanceComponent, ImageAddMaintDialog, VideoAddMaintDialog } from './maintenance/add-maintenance/add-maintenance.component';
import { ViewMaintenaceComponent, VideoDialog, ImageDialog } from './maintenance/view-maintenace/view-maintenace.component';
import { DatePipe } from '@angular/common';
import { ViewtenantComponent, ImageTenantDialog } from './tenant/viewtenant/viewtenant.component'; 
import {MatSort, MatSortModule} from '@angular/material/sort';
import { GridModule, ToolbarService, ExcelExportService, EditService } from '@syncfusion/ej2-angular-grids';
import { PageService, SortService, FilterService, GroupService } from '@syncfusion/ej2-angular-grids';
import { SearchpropertylistComponent } from './search/searchpropertylist/searchpropertylist.component';
import { LoaderService } from '../_services/loader.service';
import { DataService } from '../_services/data.service';
import { FileUploadModule } from 'ng2-file-upload';
import { AlertComponent } from '../shared/alert/alert.component';
import { AlertService } from '../_services/alert.service';
import { QuicksidenavComponent } from './navigation/quicksidenav/quicksidenav.component';
import { OhomeComponent } from './ohome/ohome.component';
import { ThomeComponent } from './thome/thome.component';
import { ChangepwdComponent } from './changepwd/changepwd.component';
import { SettingComponent } from './setting/setting.component';
import { LoaderComponent } from './loader/loader.component';
import { PermissionsDirective } from './permissions.directive';


@NgModule({
  declarations: [VideoAddMaintDialog,ImageAddMaintDialog,ImageAddPropDialog,ImageDialog,ImageTenantDialog,ImageOwnerDialog,ImagePropertyDialog,VideoDialog,DashboardComponent,SidenavListComponent,HeaderComponent,HomeComponent, MaintenancerequestsComponent, AddMaintenanceComponent, ViewMaintenaceComponent, AddPropertyComponent,ListAllPropertyComponent, ViewPropertyComponent, PmhomeComponent,  AdminhomeComponent,  ListownerComponent, AddOwnerComponent, ViewOwnerComponent,DialogOverviewExampleDialog,DialogOverviewTenanttypDialog,AddTenantComponent, ListAllTenantComponent, ViewtenantComponent, SearchpropertylistComponent,AlertComponent, QuicksidenavComponent, OhomeComponent, ThomeComponent, ChangepwdComponent, SettingComponent, LoaderComponent, PermissionsDirective, ],
  imports: [
    FileUploadModule,
    CommonModule,
    DashboardRoutingModule,
    MatProgressSpinnerModule,
    MatTabsModule,
    MatDatepickerModule,
    MatSlideToggleModule, MatButtonToggleModule, MatDividerModule,
    MatDialogModule,
    MatStepperModule,
    MatExpansionModule,
    NgMultiSelectDropDownModule,
    NgScrollbarModule,
    MatAutocompleteModule,
    MatListModule,
    MatBadgeModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    MatNativeDateModule,
    MatFormFieldModule,
    MatButtonModule,
    MatCheckboxModule,
    MatRadioModule,
    MatToolbarModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatCardModule,
    MatMenuModule,
    MatIconModule,
    MatSelectModule,
    MatMenuModule,
    MatSidenavModule,
    MatSliderModule,
    MatChipsModule,
    MatTooltipModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    MatGridListModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    GridModule,
    MatChipsModule,
  ],
  providers: [
    LoaderService,AlertService,DataService, DatePipe, PageService, SortService, FilterService, GroupService, ExcelExportService, ToolbarService,EditService,
  ],
entryComponents:[VideoAddMaintDialog,ImageAddMaintDialog,ImageAddPropDialog,ImageDialog,ImagePropertyDialog,VideoDialog,ConfirmationDialogComponent,ImageTenantDialog,ImageOwnerDialog],
  bootstrap: [DashboardComponent]
 })
export class DashboardModule { }
