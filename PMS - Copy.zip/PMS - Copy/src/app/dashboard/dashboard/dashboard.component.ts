import { Component, OnInit } from '@angular/core';
import { MediaObserver, MediaChange } from '@angular/flex-layout';
import { Subscription } from 'rxjs';
import { AuthService } from 'src/app/_services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  opened = true;
  closed=false;
  over = 'side';
  expandHeight = '42px';
  collapseHeight = '42px';
  displayMode = 'flat';
  watcher: Subscription;

  constructor(media: MediaObserver, private authservice: AuthService, private router: Router) {
    this.watcher = media.media$.subscribe((change: MediaChange) => {
      if (change.mqAlias === 'sm' || change.mqAlias === 'xs') {
        this.opened = false;
        // this.closed=true;
        this.over = 'over';
      } else {
        this.opened = true;
        // this.closed=false;
        this.over = 'side';
      }
    });
  }
//   this.watcher = media.subscribe((change: MediaChange) => {
//     if (change.mqAlias === 'sm' || change.mqAlias === 'xs') {
//       this.opened = false;
//       this.over = 'over';
//     } else {
//       this.opened = true;
//       this.over = 'side';
//     }
//   });
// }
  ngOnInit() {
  }

}
