import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ViewpropertyService } from 'src/app/_services/viewproperty.service';
import { ListallpropertiesService } from 'src/app/_services/listallproperties.service';
import { DataService } from 'src/app/_services/data.service';

@Component({
  selector: 'app-ohome',
  templateUrl: './ohome.component.html',
  styleUrls: ['./ohome.component.css']
})
export class OhomeComponent implements OnInit {
  displayedColumns = ['property', 'issue', 'status', 'opened'];
  dataSource = ELEMENT_DATA;
  data: any;
  id: any;
  tenantcount: any;
  tenantcountstore: any;

  constructor(private dataService: DataService, public router: Router, private listproperties: ListallpropertiesService, private viewpropertyservice: ViewpropertyService) { }

  ngOnInit() {
    // this.getProperties();
    this.searchData()

  }
  getProperties() {
    this.listproperties.getAllProperty()
      .subscribe(data => {
        console.log(data)

        this.data = data;



      },
        error => {

          this.data = [];

        })

  }


  getId(propertyId: string) {

    this.router.navigate(['/dashboard/view_property'], { queryParams: { data: propertyId } })
  }

  searchData() {
    this.dataService.searchValue.subscribe(data => {


      if (data.type == "property") {
        this.data = data.data
      }

    },
      error => {


      })
  }

}
export interface PeriodicElement {
  property: string;
  issue: string;
  status: string;
  opened: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { property: 'Test', issue: 'Plumbing', status: 'Open', opened: '2 days aho' },
  { property: 'Test', issue: 'Plumbing', status: 'Open', opened: '2 days aho' },
  { property: 'Test', issue: 'Plumbing', status: 'Open', opened: '2 days aho' },
  { property: 'Test', issue: 'Plumbing', status: 'Open', opened: '2 days aho' },



];