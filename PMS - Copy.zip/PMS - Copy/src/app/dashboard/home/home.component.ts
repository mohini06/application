import { PmdashboardService } from './../../_services/pmdashboard.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  newRequest;
  constructor(public router:Router,private getRequest:PmdashboardService) { }

  ngOnInit() {
    this.getNewRequest();
  }
getNewRequest(){
  this.getRequest.getNewMaintenaceRequest().subscribe(
    data=>{
    this.newRequest= data;
    console.log('request', this.newRequest)
  },
  error => {
    this.newRequest = [];
  }

  );
}
}


