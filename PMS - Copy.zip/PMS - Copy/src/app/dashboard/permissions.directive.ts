import { Directive, ElementRef, Input, OnInit, Renderer, } from '@angular/core';
import { AuthService } from '../_services/auth.service';

@Directive({
  selector: '[appPermissions]'
})
export class PermissionsDirective implements OnInit {
  @Input() name: string;
  @Input() action: string;
  @Input() type: string;
  Roledata: any;
  constructor(private auth: AuthService, private el: ElementRef, private render: Renderer,) { }
  ngOnInit() {

    console.log("Button disabled")
    console.log(this.auth.rolepermission)
    this.name = this.auth.rolepermission;
    console.log(this.name)
    if (this.name == "Owner") {
      if (this.action == "delete") {
        console.log(this.action)
        this.hide();

      } else {
        this.show();
      }
    }


    //   if (this.name == "Tenant") {
    //   if(this.action == "edit" || this.action == "delete"){
    //     console.log(this.action)
    //     this.hide();

    //   } else {
    //     this.show();
    //   }
    // }

    if (this.name == "Tenant") {
      if (this.action == "edit" || this.action == "delete") {
        console.log(this.action)
        this.hide();

      } else {
        this.show();
      }
    }

  }
  show() {
    this.el.nativeElement.style.display = 'block'
  }

  hide() {
    this.el.nativeElement.remove();
    // this.el.nativeElement.disabled = true;
  }


}
