import { PermissionsDirective } from './permissions.directive';

describe('PermissionsDirective', () => {
  it('should create an instance', () => {
    const directive = new PermissionsDirective();
    expect(directive).toBeTruthy();
  });
});
