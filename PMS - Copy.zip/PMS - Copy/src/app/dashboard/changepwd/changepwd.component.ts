import { PassMatch } from './../../signup/_helpers/must-match.validator';
import { AuthService } from './../../_services/auth.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertService } from 'src/app/_services/alert.service';




@Component({
  selector: 'app-changepwd',
  templateUrl: './changepwd.component.html',
  styleUrls: ['./changepwd.component.css']
})
export class ChangepwdComponent implements OnInit {
  changepwdform: FormGroup;
  // show: boolean =false;
  // buttonName: string;
  errormessage = "";
  hide: boolean = false;
  changepwdpg: boolean = true;
  user_id: any;
  constructor(private auth: AuthService, private router: Router, private formBuilder: FormBuilder, private alert: AlertService, ) { }

  ngOnInit() {
    this.changepwdform = this.formBuilder.group({
      current_password: ['', Validators.required],
      new_password: ['', [Validators.required, Validators.minLength(6)]],
      confirm_password: ['', Validators.required],
    },
      {
        validator: PassMatch.Match("new_password", "confirm_password")
      })
    this.user_id = JSON.parse(localStorage.getItem("user_id"));
  }


  get current_password() { return this.changepwdform.get('current_password'); }
  get new_password() { return this.changepwdform.get('new_password'); }
  get confirm_password() { return this.changepwdform.get('confirm_password'); }




  changePswd() {
    if (this.changepwdform.invalid) {
      return
    }
    else {
      this.auth.changePswd(this.current_password.value, this.new_password.value, this.confirm_password.value, this.user_id)
        .subscribe(data => {
          this.alert.success("Password Changed Successfully")
          // localStorage.clear();
          // this.router.navigate(['/']);
          setTimeout(() => {
            // this.alert.removeAlert();
            // this.emitEventToChild()
            localStorage.clear();
          this.router.navigate(['/']);
          }, 4000);
        },
          error => {
            this.alert.error(error.error.msg)

          })
    }
  }
  toggle() {
    // this.show = !this.show;

    // CHANGE THE NAME OF THE BUTTON.
    // if(this.show)  
    //   this.buttonName = "Hide";
    // else
    //   this.buttonName = "Show";
  }
  cancel() {
    // localStorage.clear();
    // this.router.navigate(['/']);
    this.router.navigate(["/dashboard/setting"]);
  }
}
