import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ViewpropertyService } from 'src/app/_services/viewproperty.service';
import { ListallownerService } from 'src/app/_services/listallowner.service';
import { DataService } from 'src/app/_services/data.service';

@Component({
  selector: 'app-listowner',
  templateUrl: './listowner.component.html',
  styleUrls: ['./listowner.component.css']
})
export class ListownerComponent implements OnInit {

  data: any;
  id: any;
  constructor(private dataService: DataService, public router: Router, private listowners: ListallownerService, private viewpropertyservice: ViewpropertyService) { }

  ngOnInit() {
    this.searchData()
    this.getProperties();
  }
  getProperties() {
    this.listowners.getAllOwner()
      .subscribe(data => {
        this.data = data;
        // console.log(data)


      },
        error => {

          this.data = [];

        })

  }
  searchData() {
    this.dataService.searchValue.subscribe(data => {

      // console.log(data)
      if (data.type == "owner") {
        // console.log(data)
        this.data = data.data
      }

    },
      error => {

        // console.log(error)
      })
  }

  getId(landlordId: string) {

    this.router.navigate(['/dashboard/view_owner'], { queryParams: { data: landlordId } })
  }
}
