import { environment } from './../../../../environments/environment';
import { ConfirmationDialogComponent, ConfirmDialogModel } from './../../../confirmation-dialog/confirmation-dialog.component';
import { Component, OnInit, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ViewownerService } from 'src/app/_services/viewowner.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
@Component({
  selector: 'app-view-owner',
  templateUrl: './view-owner.component.html',
  styleUrls: ['./view-owner.component.css']
})
export class ViewOwnerComponent implements OnInit {
  data: any;
  breakpoint: number;
  attacpath;
  id: any;
  result: string = '';
  public viewData;
  imagesStored: any;
  filesStored: any;
  schemaname = localStorage.getItem('currshema').replace(/['"]+/g, '');

  apiurl = environment.apiurl;

  constructor(public router: Router, private viewownerservice: ViewownerService, private route: ActivatedRoute, public dialog: MatDialog) { }
  confirmDialog(id): void {
    const message = `Are you sure you want to delete?`;

    const dialogData = new ConfirmDialogModel("Confirm Action", message, id, "owner");

    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      maxWidth: "400px",
      data: dialogData
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      this.result = dialogResult;
    });
  }

  ngOnInit() {
    console.log(this.apiurl)
    this.getOwnerdetail(this.route.snapshot.queryParams['data']);
    // console.log(this.route.snapshot.queryParams['data'])
    this.breakpoint = (window.innerWidth <= 800) ? 2 : 2;

  }
  getOwnerdetail(id) {


    this.viewownerservice.getOwnerDetail(id)
      .subscribe(data => {
        this.data = data;
        console.log(data)
        this.imagesStored = data['images'];
        this.filesStored = data['files'];

        this.apiurl = this.apiurl.replace("http://", "http://" + this.schemaname + ".").slice(0, -1);
        console.log(this.apiurl)
      },
        error => {



        })
  }
  onResize(event) {
    this.breakpoint = (event.target.innerWidth <= 800) ? 2 : 2;
  }
  editOwner(ownerid: string) {
    this.router.navigate(['/dashboard/add_owner'], { queryParams: { data: ownerid } })
  }
  openImageDialog(path) {
    const dialogRef = this.dialog.open(ImageOwnerDialog, {

      data: { attacpath: path }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log(`Dialog result: ${result}`);
    });
  }

}
@Component({
  selector: 'image_owner-dialog',
  templateUrl: 'image_owner-dialog.html',
})

export class ImageOwnerDialog {
  schemaname = localStorage.getItem('currshema').replace(/['"]+/g, '');


  apiurl = environment.apiurl.replace("http://", "http://" + this.schemaname + ".").slice(0, -1);

  constructor(
    public dialogRef: MatDialogRef<ImageOwnerDialog>,
    @Inject(MAT_DIALOG_DATA) public data: attchment, private Router: ActivatedRoute) { }


}
export interface attchment {
  url: string;
  path: string;
  attacpath;
}
