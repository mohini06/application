import { ListallownerService } from './../../../_services/listallowner.service';
import { ValidateEmailService } from "./../../../_services/validate-email.service";
import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators
} from "@angular/forms";
import { AddownerService } from "./../../../_services/addowner.service";
import {
  Router,
  NavigationEnd,
  ActivatedRoute,
  ActivatedRouteSnapshot,
  NavigationStart
} from "@angular/router";
import { Location } from "@angular/common";
import { ConditionalExpr } from "@angular/compiler";
import { ListallpropertiesService } from "./../../../_services/listallproperties.service";
import { filter } from "rxjs/operators";
import { DataService } from "./../../../_services/data.service";
import { ViewownerService } from "./../../../_services/viewowner.service";
import { FileUploader, FileLikeObject } from "ng2-file-upload";
import { AlertService } from './../../../_services/alert.service';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';



export interface Property {
  value: any;
  viewValue: any;
}
@Component({
  selector: "app-add-owner",
  templateUrl: "./add-owner.component.html",
  styleUrls: ["./add-owner.component.css"]
})
export class AddOwnerComponent implements OnInit {
  @Input() type: any;
  // @Input() parentData: any;
  rowData: any;
  public uploaderImg: FileUploader = new FileUploader({
    // allowedFileType: ['png', 'jpg','jpeg','PNG','JPG','JPEG']
  });
  public uploaderfile: FileUploader = new FileUploader({
    // allowedFileType: ['txt', 'pdf','doc']
  });
  addowner: FormGroup;
  submitted = false;
  ownervariable = "";
  errormessage2 = "";
  ownerpage = false;
  childData = "";
  formData: any;
  urlId;
  imagesStored: any;
  filesStored: any;
  schemaname = localStorage.getItem('currshema').replace(/['"]+/g, '');
  updateformData = new FormData;
  // @Input()  item: any;
  // @Output()  goback = new EventEmitter<string>();
  property: any = [];
  apiurl = environment.apiurl;
  data: any;
  isEnabled: boolean = false;
  iserrror: boolean = false;
  constructor(
    private viewownerservice: ViewownerService,
    private dataService: DataService,
    private listproperties: ListallpropertiesService,
    private validateemail: ValidateEmailService,
    private route: ActivatedRoute,
    private _location: Location,
    private formBuilder: FormBuilder,
    public addownerservice: AddownerService,
    private router: Router,
    private unselectedProperty: ListallownerService,
    private alert: AlertService,
    private http: HttpClient
  ) { }

  ngOnInit() {
    this.getPropertyList(event);
    this.getData();

    this.addowner = this.formBuilder.group(
      {
        first_name: ["", [Validators.required, Validators.maxLength(50), Validators.pattern('^[a-zA-Z \-\']+')]],
        additional_info: [""],
        // email: ["", [Validators.required, Validators.email,Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')]],
        email: ["", [Validators.required, Validators]],
        contact_no: ["", [Validators.required]],
        propertyid: [],
        image: [""],
        file: [""],
        id: []
      }
    );
  }

  get first_name() {
    return this.addowner.get("first_name");
  }
  get additional_info() {
    return this.addowner.get("additional_info");
  }
  get email() {
    return this.addowner.get("email");

  }
  get contact_no() {
    return this.addowner.get("contact_no");
  }
  get propertyid() {
    return this.addowner.get("propertyid");
  }
  get image() {
    return this.addowner.get("image");
  }
  get file() {
    return this.addowner.get("file");
  }
  get id() {
    return this.addowner.get("id");
  }

  getData() {
    this.urlId = this.route.snapshot.queryParamMap.get("data");
    // console.log(this.urlId)

    this.viewownerservice.getOwnerDetail(this.urlId).subscribe(
      data => {
        this.rowData = data;

        this.imagesStored = data['images'];
        // (response: Blob) => saveAs(response, this.rowData.images.fileName + '.xlsx')
        console.log(this.imagesStored)
        this.filesStored = data['files'];

        // this.updateformData.append()
        this.apiurl = this.apiurl.replace("http://", "http://" + this.schemaname + ".").slice(0, -1);


        // console.log(this.filesStored)
        // console.log('hi',this.rowData);
        this.setFormValue();
      },
      error => {
        // console.log(error);
      }
    );
  }
  // Set Form Data
  setFormValue() {

    // console.log(this.rowData.property_name.length)
    // console.log(this.rowData)
    for (let i = 0; i < this.rowData.property_name.length; i++) {
      this.property.push({ id: this.rowData.propertyid[i], property_name: this.rowData.property_name[i] })

    }

    // console.log(this.property)
    this.first_name.setValue(this.rowData.first_name);
    this.additional_info.setValue(this.rowData.additional_info);

    this.email.setValue(this.rowData.email);
    // this.email.disable();

    this.contact_no.setValue(this.rowData.contact_no);
    this.propertyid.setValue(this.rowData.propertyid);

    this.image.setValue(this.rowData.image)
    this.file.setValue(this.rowData.file)
    // console.log(this.rowData)
    this.id.setValue(this.rowData.id);
    // this.email.readonly();
    this.isEnabled = true;

  }
  // get email() { return this.addowner.get('email'); }

  getPropertyList(event: any) {
    this.unselectedProperty.getAllUnselectedProperty().subscribe(
      data => {
        this.property = data;
        //  console.log(this.property)
      },
      error => {
        this.property = [];
      }
    );
  }
  getImages(): FileLikeObject[] {
    return this.uploaderImg.queue.map(fileItem => {
      return fileItem.file;
    });
  }
  getAttachments(): FileLikeObject[] {
    return this.uploaderfile.queue.map(fileItem => {
      return fileItem.file;
    });
  }
  // Adding Owners
  addOwner() {
    this.submitted = true;

    if (this.addowner.invalid) {
      return;
    } else {

      let formData = new FormData();
      formData.append("first_name", this.addowner.value.first_name);
      formData.append("additional_info", this.addowner.value.additional_info);
      formData.append("email", this.addowner.value.email);
      formData.append("contact_no", this.addowner.value.contact_no);
      formData.append("propertyid", JSON.stringify(this.addowner.value.propertyid ? this.addowner.value.propertyid : []));
      // console.log( this.addowner.value.propertyid)
      // return
      // formData.append('id',this.addowner.value.id);
      let attachments = this.getAttachments();
      attachments.forEach(attachment => {
        formData.append("files", attachment.rawFile, attachment.name);
      });

      let Images = this.getImages();

      Images.forEach(Image => {
        formData.append("images", Image.rawFile, Image.name);
      });
      // console.log(this.addowner.value);
      this.addownerservice.sendDefaultPswd(this.email.value).subscribe
        (
          data => {
            if (this.errormessage2 == "") {
              this.addownerservice.addOwner(formData).subscribe(
                data => {

                  if (this.router.url == "/dashboard/add_owner") {

                    this.alert.success("Owner Added Successfully");
                    setTimeout(() => {
                      // this.alert.removeAlert();
                      // this.emitEventToChild()
                      this.router.navigate(["/dashboard/list_owner"]);
                    }, 4000);

                  } else {
                    this.alert.error("Owner not added please try again")
                    return;
                  }
                },
                error => {
                  this.alert.error("Owner not added please try again")
                  this.router.navigate(["/dashboard/add_owner"]);
                }
              );
            }
            else {
              this.alert.error("Owner not added please try again");
              return;
            }
          },
          error => {
            this.alert.error("Owner not added please try again")
            this.router.navigate(["/dashboard/add_owner"]);
          }

        )


    }
  }
  // updateOwner
  updateOwner() {
    this.submitted = true;

    if (this.addowner.invalid) {
      return;
    } else {
      // this.updateformData = new FormData();

      this.updateformData.append("first_name", this.addowner.value.first_name);
      this.updateformData.append("additional_info", this.addowner.value.additional_info);
      this.updateformData.append("email", this.addowner.value.email);
      this.updateformData.append("contact_no", this.addowner.value.contact_no);
      this.updateformData.append("propertyid", JSON.stringify(this.addowner.value.propertyid ? this.addowner.value.propertyid : []));
      this.updateformData.append("id", this.addowner.value.id);


      let attachments = this.getAttachments();
      // attachments.concat(this.filesStored);
      // for(let i=0;i<this.filesStored.length;i++)
      // {
      //   console.log(this.filesStored.length)
      //   attachments.concat(this.filesStored[i].files)

      // }
      //  console.log(attachments)
      attachments.forEach(attachment => {
        this.updateformData.append("files", attachment.rawFile, attachment.name)

      });
      let Images = this.getImages()
      // for(let i=0;i<this.imagesStored.length;i++)
      // {
      //   // this.updateformData.append("images", this.apiurl+this.imagesStored[i].files)
      // this.imagesStored=  this.http.get<any>(this.apiurl+this.imagesStored[i], { responseType: 'blob' as 'json' });
      //    Images =Images.concat(this.imagesStored)
      //    console.log(Images)

      // }
      console.log(Images)
      Images.forEach(Image => {
        this.updateformData.append("images", Image.rawFile, Image.name)
      }
      );


      // console.log(this.addowner.value.id);
      this.addownerservice
        .updateOwner(this.updateformData, this.addowner.value.id)
        .subscribe(
          data => {
            this.alert.success("Owner Updated Successfully");
            setTimeout(() => {
              // this.alert.removeAlert();
              // this.emitEventToChild()
              this.router.navigate(["/dashboard/view_owner/"], {
                queryParams: { data: data.id }
              });
            }, 4000);


          },
          error => {
            this.alert.error("Owner not updated please try again")
            //  this.errormessage="Please fill correct value" ;
            // this.router.navigate(['/dashboard/add_owner']);
          }
        );
    }
  }
  private newMethod(attachments: FileLikeObject[]) {
    console.log(attachments);
  }

  operationEditSave() {
    if (this.id.value) {
      this.updateOwner();
    } else {
      this.addOwner();
    }
  }
  deletefile(index: number) {

    this.data.file.splice(index, 1);

  }
  onKeyPress(type: any, event) {
    if (type == "Float") {
      let charCode = event.which ? event.which : event.keyCode;
      if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
      return true;
    }
    if (type == "Number") {
      const charCode = event.which ? event.which : event.keyCode;
      if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
      }
      return true;
    }
    if (type == "RemovingfirstSpace") {
      if (event.which === 32 && event.target.selectionStart === 0) {
        return false;
      }
      return true;
    }

  }


  emailExist() {
    this.validateemail.validateEmail(this.email.value).subscribe(
      data => {
        if (data.msg == "") {
          this.iserrror = false
          this.errormessage2 = "";
        } else {
          this.errormessage2 = data.msg;

        }
      },
      error => {
        this.errormessage2 = "Email-id Already Exists";
        this.iserrror = true;
        this.router.navigate(["/dashboard/add_owner"]);
      }
    );
  }

}
