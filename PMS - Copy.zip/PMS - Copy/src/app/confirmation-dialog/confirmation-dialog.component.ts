import { Router, ActivatedRoute } from '@angular/router';
import { DeleteService } from './../_services/delete.service';
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-confirmation-dialog',
  templateUrl: './confirmation-dialog.component.html',
  styleUrls: ['./confirmation-dialog.component.css']
})
export class ConfirmationDialogComponent implements OnInit {
  title: string;
  message: string;
  parentId = ""
  parentType = ""

  constructor(public dialogRef: MatDialogRef<ConfirmationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ConfirmDialogModel, private deleteSer: DeleteService,private router: Router) {
    // Update view with given values
    this.title = data.title;
    this.message = data.message;
  }

  ngOnInit() {
    // console.log(this.data)

    this.parentId = this.data.id
    this.parentType = this.data.type
  }

  onConfirm(): void {
    // Close the dialog, return true

    console.log(this.parentType)

    if (this.parentType == "owner") {
      // console.log(this.data.id)
      this.detleteOwner(this.parentId)
    }
    if (this.parentType == "property") {
      // console.log(this.data.id)
      this.deleteProperty(this.parentId)
    }
    if (this.parentType == "tenant") {
      // console.log(this.data.id)
      this.deleteTenant(this.parentId)
    }
    if (this.parentType == "maintenance") {
      // console.log(this.data.id)
      this.deleteMaintenance(this.parentId)
    }
    this.dialogRef.close(true);
  }

  onDismiss(): void {
    // Close the dialog, return false
    this.dialogRef.close(false);
    console.log("cancel")
  }

  detleteOwner(id) {
    this.deleteSer.deleteOwnerService(id).subscribe(data => {
      this.router.navigate(['/dashboard/list_owner']);

    },
    error => {
      this.router.navigate(['/dashboard/view_owner'],{ queryParams: {data: this.data.id }});

    })
  }
  deleteProperty(id) {
    this.deleteSer.deletePropertyService(id).subscribe(data => {
      this.router.navigate(['/dashboard/listproperty']);

    },error => {
      this.router.navigate(['/dashboard/view_property'],{ queryParams: {data: this.data.id }});

    })
    
  }
  deleteTenant(id) {
    this.deleteSer.deleteTenantService(id).subscribe(data => {
      this.router.navigate(['/dashboard/list_all_tenant']);

    },
    error => {
      this.router.navigate(['/dashboard/view_tenant'],{ queryParams: {data: this.data.id }});

    })
  }
  deleteMaintenance(id) {
    this.deleteSer.deletemaintenanceService(id).subscribe(data => {
      this.router.navigate(['/dashboard/Maintenance']);

    },
    error => {
      this.router.navigate(['/dashboard/view_maintanance'],{ queryParams: {data: this.data.id }});

    })
  }
}

/**
 * Class to represent confirm dialog model.
 *
 * It has been kept here to keep it as part of shared component.
 */
export class ConfirmDialogModel {

  constructor(public title: string, public message: string, public id, public type) {

  }
}

