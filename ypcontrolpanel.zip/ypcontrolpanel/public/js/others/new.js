 $(document).ready(function() {
	 
	
      $('#updatepayment').on('click',function(){
        //alert($('input[name=type]:checked').val());
        var selectedaPymentType=$('input[name=type]:checked').val();
        var SubTypes=["Свободно","Серебряный","Золото","премия"];
         console.log(selectedaPymentType);
        $("#paymenttype_id").val(selectedaPymentType);
         $("#paymenttype").text(SubTypes[selectedaPymentType]);
         $("#id02").hide();
        //setting type
      })
	  $('#updatepaymentadd').on('click',function(){
        //alert($('input[name=type]:checked').val());
        var selectedaPymentType=$('input[name=type]:checked').val();
        var SubTypes=["Свободно","премия"];
         console.log(selectedaPymentType);
        $("#paymenttype_id").val(selectedaPymentType);
         $("#paymenttype").text(SubTypes[selectedaPymentType]);
         $("#id02").hide();
        //setting type
      })

        $('#category').on('change', function() {
        var categoryID = $(this).val();

            if (categoryID) {
                $.ajax({
                    dataType: 'text',

                    type: 'POST',
                    url: '../resources/views/queryforsubcategory.php',
                    //url:'app/Http/Controllers/DynamicController@index2',
                    data: 'category_id=' + categoryID,

                    success: function(html) {
                        console.log(html);

                        $('#subcategory').html(html);
                    },
                    error: function(e) {
                        $('#subcategory').html(e);
                    }
                });
            }
        });

  
            $('#City').on('change', function() {
                var cityID = $(this).val();

                if (cityID) {
                    $.ajax({
                        dataType: 'text',

                        type: 'POST',
                        url: '../resources/views/queryforarea.php',
                        //url:'app/Http/Controllers/DynamicController@index2',
                        data: 'city_id=' + cityID,

                        success: function(html) {
                            console.log(html);

                            $('#Area').html(html);
                        },
                        error: function(e) {
                            $('#Area').html(e);
                        }
                    });
                }
            });

       
        $('#DescribeBusiness').keyup(function() {
                var max = 500;
                var len = $(this).val().length;
                if (len >= max) {
                    $('#charNum').text(' you have reached the limit');
                } else {
                    var char = max - len;
                    $('#charNum').text(char + ' characters left');
                }
            });

	
	jQuery.validator.addMethod("lettersonly", function(value, element) {
        return this.optional(element) || /^[a-zA-Zа-яА-ЯЁё\s]*$/.test(value);
    }, "Letters only please");
	
 jQuery.validator.addMethod("validecode", function(value, element) {
        return this.optional(element) || /^(\+7|)?[\s]?\(?[0-9]{3}\)?[\s]?[0-9]{3}[\s\-]?[0-9]{2}[\s\-]?[0-9]{2}$/.test(value);
    }, "Valid Country Code");


     $('.date_ru').bootstrapMaterialDatePicker
     ({
         format: 'DD-MM-YYYY',
         lang: 'ru',
         weekStart: 1,
         cancelText : 'ANNULER',
         okText : 'ХОРОШО',
         switchOnClick : true,
         time: false
     });
      $('.date_ru2').bootstrapMaterialDatePicker
     ({
         format: 'YYYY-MM-DD',
         lang: 'ru',
         weekStart: 1,
         cancelText : 'ANNULER',
         okText : 'ХОРОШО',
         switchOnClick : true,
         time: false
     });

     $('.datetime_ru').bootstrapMaterialDatePicker
     ({
         format: 'YYYY-MM-DD HH:mm:ss',
         lang: 'ru',
         weekStart: 1,
         cancelText : 'ANNULER',
         okText : 'ХОРОШО',
         switchOnClick : true
     });

     $(".announce_trash").click( function ()
     {
         var delete_path = $(this).parent().attr("data-delete");
         $(".announce .modal-footer .sure").attr("href",delete_path);
     });

     $(".approve_btn").click( function ()
     {
         var approve_path = $(this).attr("approve_url");
         $("#approveModal .modal-footer .sure").attr("href",approve_path);
     });

     $(".delete_btn").click( function ()
     {
         var delete_path = $(this).attr("delete_url");
         $("#deleteModal .modal-footer .sure").attr("href",delete_path);
     });

     $("#approve_ads").click( function ()
     {
         var approve_path = $(this).attr("approve_url");
         $("#approveAds .modal-footer .sure").attr("href",approve_path);
     });

     $("#delete_ads").click( function ()
     {
         var delete_path = $(this).attr("delete_url");

         $("#deleteAds .modal-footer .sure").attr("href",delete_path);
     });
	 
	 //validation for add announcements
	 $("#add_announcement_form").validate( {

			rules:     {
			   Description: {
                          required: true,
			           
                          } 
				
			           },

             messages: {
				  Description: {
                          required: "Пожалуйста, введите описание",
			           
                          } 
				
			            }
	 });

	$('.phonemask').mask('+0 (000) 0000000');
 });//end of documentready