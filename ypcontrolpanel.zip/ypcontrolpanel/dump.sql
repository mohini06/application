﻿USE `yellowpageskz`;

DELIMITER $$

DROP PROCEDURE IF EXISTS `yellowpageskz`.`Usp_GetCategorySubcategoryLeadReport_New`$$

CREATE DEFINER=`yellowpageskz`@`%` PROCEDURE `Usp_GetCategorySubcategoryLeadReport_New`(IN p_startDate DATETIME,
IN p_endDate DATETIME,
IN p_type VARCHAR(50),
IN p_category INT,
IN p_subcategory  INT
)
BEGIN 
IF(p_type='company')
then
IF(p_category<=0 and p_subcategory<=0)
Then
select distinct c.CompanyName AS Name ,count(A.ID) As Count,VisitingDate from analysistracking A inner join companyregistration c
on c.CompanyRegId=A.ID where DATE(VisitingDate) BETWEEN DATE(p_startDATE) AND DATE(p_endDATE)AND A.IPAddress NOT IN('213.180.203.60','178.154.171.84')
 group by id order by  Count desc limit 0,50;
else 
select distinct c.CompanyName AS Name ,CA.CategoryName,S.SubCategoryName ,c.CategoryCode,c.SubCategoryCode , count(A.ID) As Count,VisitingDate 
from analysistracking A inner join companyregistration c
on c.CompanyRegId=A.ID inner join subcategory S
on find_in_set(`s`.`SubCategoryId`, `c`.`SubCategoryCode`)  inner join category CA
on CA.CategoryId=c.CategoryCode
 where DATE(A.VisitingDate) BETWEEN DATE(p_startDate) AND DATE(p_endDate) AND find_in_set(p_subcategory,c.SubCategoryCode) > 0 AND c.CategoryCode=p_category
AND A.IPAddress NOT IN('213.180.203.60','178.154.171.84') 
group by id order by  Count desc limit 0,50;
END IF;
ELSE 
if(p_category<=0 and p_subcategory<=0)
then
select distinct c.ClassifiedTitle AS Name ,count(A.ID) As Count,VisitingDate from analysistracking A inner join classifiedregistration c
on c.ClassifiedRegId=A.ID where DATE(VisitingDate) BETWEEN DATE(p_startDATE) AND DATE(p_endDATE)
AND A.IPAddress NOT IN('213.180.203.60','178.154.171.84')
 group by id order by  Count desc limit 0,50;
else
select distinct c.ClassifiedTitle AS Name ,CA.CategoryName,S.SubCategoryName ,c.CategoryCode,c.SubCategoryCode , count(A.ID) As Count,VisitingDate 
from analysistracking A inner join classifiedregistration c
on c.ClassifiedRegId=A.ID inner join subcategory S
on find_in_set(`s`.`SubCategoryId`, `c`.`SubCategoryCode`) inner join category CA
on CA.CategoryId=c.CategoryCode
 where DATE(A.VisitingDate) BETWEEN DATE(p_startDate) AND DATE(p_endDate)
and FIND_IN_SET(p_subcategory, c.SubCategoryCode) > 0
AND c.CategoryCode=p_category
AND A.IPAddress NOT IN('213.180.203.60','178.154.171.84') 
group by id order by  Count desc limit 0,50;
END IF;
END IF;
END$$

DELIMITER ;
