<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('welcome');
//});
Route::get('login/','LoginController@login');
Route::get('/','LoginController@login');
 // Route::post('/login',array('uses'=>'LoginController@authenticate'));
Route::post('login/', 'Auth\LoginController@login')->name('login');
Route::post('logout', 'Auth\LoginController@logout')->name('logout');

//Registration Routes...
Route::get('register/', 'Auth\RegisterController@showRegistrationForm')->name('register');
Route::post('register/', 'Auth\RegisterController@register');

// Password Reset Routes...
Route::get('password/reset', 'Auth\ForgotPasswordController@showLinkRequestForm')->name('password.request');
Route::post('password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail');
Route::get('password/reset/{token}', 'Auth\ResetPasswordController@showResetForm')->name('password.reset');
Route::post('password/reset', 'Auth\ResetPasswordController@reset');


Route::group(['middleware'=>'auth'], function () {

Route::get('home', 'AdminController@index');
Route::get('approve', 'AdminController@approvelist');
Route::get('nonapprovesearch',array('uses'=>'AdminController@searchnonapprovelist'));
Route::get('/viewdetail/{CompanyRegId}','AdminController@viewdetail');
Route::get('/viewclassifieddetail/{ClassifiedRegId}','AdminController@viewclassifieddetail');
Route::get('/deletecompany/{CompanyRegId}','AdminController@deletecompany');
Route::get('/deleteadd/{ClassifiedRegId}','AdminController@deleteclassified');
Route::get('/approvead/{id}','AdminController@approvead');
Route::get('/approvecompany/{id}','AdminController@approvecompany');
Route::get('/report','AdminController@report');
Route::post('/visitors_report',array('uses'=>'AdminController@visitors_report'));
Route::get('/announcement','AdminController@announcement');
Route::post('/saveannouncements',array('uses'=>'AdminController@saveannouncements'));
Route::get('/deleteannouncement/{announcementid}','AdminController@deleteannouncement');
Route::get('show',array('uses'=>'AdminController@show'));
Route::get('/mailing','MailController@index');
Route::get('/search','MailController@search');
Route::post('/send_mail','MailController@sendmail');

Route::get('/editcompany/{companyregid}','AdminController@editcompanydetail');
Route::get('/editclassified/{classifiedregid}','AdminController@editclassifieddetail');

Route::get('/deletecompanydetail/{companyregid}','AdminController@deletecompanydetail');
Route::get('/deleteclassifieddetail/{classifiedregid}','AdminController@deleteclassifieddetail');

//Route::post('/updatepayment/{companyregid}',array('uses'=>'AdminController@updatepayment'));
Route::post('/setpayment_company',array('uses'=>'AdminController@updatepayment'));

Route::post('/setpayment_ad',array('uses'=>'AdminController@updatepaymentAdd'));

Route::post('/updatecompanydetail/{companyregid}',array('uses'=>'AdminController@updatecompanydetail'));
Route::post('/updateclassifieddetail/{classifiedregid}',array('uses'=>'AdminController@updateclassifieddetail'));
Route::post('/setranking_ad',array('uses'=>'AdminController@updateclassifiedRank'));
Route::post('/setranking_company',array('uses'=>'AdminController@updatecompanyRank'));

// Reports
Route::post('/report/weeklyreport','ReportController@weekly_report');
Route::post('/report/monthlyreport','ReportController@monthly_report');
Route::post('/report/categoryreport','ReportController@category_report');
Route::post('/report/leadreport','ReportController@lead_report');
Route::post('/report/revenuereport','ReportController@revenue_report');
Route::post('/report/subcategoryreport','ReportController@subcategory_report');
Route::post('/report/searchdownloadreport','ReportController@searchdownload_report');
});
// localization

Route::view('/test', 'testlocalization');
Route::get('locale', function () {
    return \App::getLocale();
});

Route::get('locale/{locale}', function ($locale) {
    \Session::put('locale', $locale);
    return redirect()->back();
});

    


// Auth::routes();







