<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Subcategory;

class Announcement extends Model
{
    protected $table='announcements';
    public $primarykey ='AnnouncementId';
    public $timestamps=false;
    //protected $fillable = ['country_id', 'created_at', 'updated_at', 'name', 'latitude', 'longitude'];
    

}