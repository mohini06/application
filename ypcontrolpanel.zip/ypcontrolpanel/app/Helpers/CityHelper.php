<?php
namespace App\Helpers;
use App\City;
use DB;

class CityHelper
{
    public function cityNames()
    {
        // $city=DB::table('city')
            // ->select('CityId','CityName')
// ->get();
        $city=DB::select('call usp_GetCityList()');
        return json_encode($city);
    }
    public static function instance()
    {
     return new CityHelper();
    }
}