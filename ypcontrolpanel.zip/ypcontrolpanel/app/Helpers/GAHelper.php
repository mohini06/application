<?php
namespace App\Helpers;
use Analytics;
use Spatie\Analytics\Period;
use Carbon\Carbon;

class GAHelper
{
	public function uniquePageviews()
	{
		$startDate=Carbon::parse('2017-03-30');
		$endDate=$endDate = Carbon::now();
		$period=Period::create($startDate, $endDate);
		$analyticsData = Analytics::performQuery(
		    $period,
		    'ga:sessions',
		    [
			'metrics' => 'ga:uniquePageviews'
		    ]
		);

		return $analyticsData['totalsForAllResults']['ga:uniquePageviews'];
	}

	public function googleAnalystics1()
	{
		$startDate=Carbon::parse('2017-01-01');
		$endDate=$endDate = Carbon::now();
		$period=Period::create($startDate, $endDate);
		$analyticsData = Analytics::performQuery(
			$period,
			'ga:sessions',
			[
				'metrics' => 'ga:users,ga:sessions,ga:bounceRate,ga:avgSessionDuration',
				'dimensions' => ''
			]
		);
		
		return json_encode($analyticsData['rows']);	
	}

	public function googleAnalystics2()
	{
		$period=Period::days(30);
		$analyticsData = Analytics::performQuery(
			$period,
			'ga:sessions',
			[
				'metrics' => 'ga:users,ga:sessions,ga:bounceRate,ga:avgSessionDuration',
				'dimensions' => '',
			]
		);
		
		return json_encode($analyticsData['totalsForAllResults']);	
	}

	public function googleAnalystics3()
	{
		$startDate=Carbon::parse('2017-01-01');
		$endDate=$endDate = Carbon::now();
		$period=Period::create($startDate, $endDate);
		$analyticsData = Analytics::performQuery(
			$period,
			'ga:sessions',
			[
				'metrics' => 'ga:users,ga:hits',
				'dimensions' => 'ga:country',
				'sort' => '-ga:users'
			]
		);
		
		return json_encode($analyticsData['rows']);	
	}

	public function googleAnalystics4()
	{
		$startDate=Carbon::parse('2017-01-01');
		$endDate=$endDate = Carbon::now();
		$period=Period::create($startDate, $endDate);
		$analyticsData = Analytics::performQuery(
			$period,
			'ga:sessions',
			[
				'metrics' => 'ga:users',
				'dimensions' => 'ga:operatingSystem',
				'sort' => '-ga:users'
			]
		);
		
		return json_encode($analyticsData['rows']);	
	}

	public static function instance()
	{
	 return new GAHelper();
	}
     
}

