<?php

namespace App;
use Krossroad\UnionPaginator\UnionPaginatorTrait;
use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
	 use UnionPaginatorTrait;
    protected $table='companyregistration';
    public $primarykey ='CompanyRegId';
    public $timestamps=false;
    public $fillable  = [
        'CompanyName','Address1','Address2','State','StateName','PostalCode','Country','FaxNo','CategoryCode','SubCategoryCode','Status','DateOfReg','WebsiteLink','DescribeBusiness','CityName','City','Area','DateOfPost','CategoryName','oldStatus','Ranking','IsApprove','ExpiryDate','IsProfileEnabled','ModifiedBy',
        'ModifiedDate','AdminModifiedDate'
    ];
}
