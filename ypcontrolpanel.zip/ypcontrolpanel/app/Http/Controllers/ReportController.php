<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Http\Request;


class ReportController extends Controller
{
    public function weekly_report(Request $request)
    {
        $year_id = $request->year_id;
        $startdate = $year_id . "-01-01";
        $enddate = $year_id . "-12-31";

        $sql = DB::select('call Usp_GetWeekWiseVisitorReport(?,?,?)', array($year_id, $startdate, $enddate));

        $returnHTML = view('weeklyreport')->with('report', $sql)->render();
        return response()->json(array('success' => true, 'html'=>$returnHTML));
    }

    public function monthly_report(Request $request)
    {
        
        $year_id = $request->year_id;

        $sql = DB::select('call Usp_GetMonthWiseVisitorReport(?)', array($year_id));

        $returnHTML = view('monthlyreport')->with('report', $sql)->render();
        return response()->json(array('success' => true, 'html'=>$returnHTML));
    }

    public function category_report(Request $request)
    {
        $year_id = $request->year_id;

        $sql = DB::select('call Usp_GetCategoryVisitorReport(?)', array($year_id));

        $returnHTML = view('categoryreport')->with('report', $sql)->render();
        return response()->json(array('success' => true, 'html'=>$returnHTML));
    }

    public function lead_report(Request $request)
    {
        $type = $request->data1;
        $categ=$request->data2;
        $subcateg=$request->data3;
        $from =  $request->data4;
        $to =  $request->data5;

        if($type == "")
        {
            $type = "company";
        }

        $sql = DB::select('call Usp_GetCategorySubcategoryLeadReport(?,?,?,?,?)', array($from,$to,$type,$categ,$subcateg));
        
        $returnHTML = view('leadreport')->with('report', $sql)->render();

        return response()->json(array('success' => true, 'html'=>$returnHTML));
    }

    public function revenue_report(Request $request)
    {
        $startdate=$request->data1;
        $enddate=$request->data2;

        $sql=DB::select('call Usp_GetRevenueReport(?,?)', array($startdate,$enddate));
          
        $returnHTML = view('revenuereport')->with('report', $sql)->render();
        return response()->json(array('success' => true, 'html'=>$returnHTML));

    }

    public function searchdownload_report(Request $request)
    {

        $downloadsDetails = DB::table('searchresult_downloads')
            ->leftjoin('userregistration', 'searchresult_downloads.UserId', '=', 'userregistration.UserRegId')
            ->select('searchresult_downloads.UserId','userregistration.Name','searchresult_downloads.IpAddress','searchresult_downloads.created_on')
            ->get();
        $returnHTML = view('searchdownloadsreport')->with('report', $downloadsDetails)->render();
        return response()->json(array('success' => true, 'html'=>$returnHTML));
    

    }
}
