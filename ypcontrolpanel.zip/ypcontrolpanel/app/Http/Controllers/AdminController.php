<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use DB;
use Mail;
use App\Classified;
use App\Company;
use App\Admin;
use App\User;
use App\City;
use App\Category;
use App\subcategory;
use App\Announcement;
use App\SubscriptionAudit;


class AdminController extends Controller
{
    public function index(){
        $citydetail= DB::table('city')->get();
        $categorydetail=DB::table('category')->get();
        $classifieddata= DB::table('classifiedregistration')->where('IsApprove','1')
            //->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
            //->leftjoin('city','city.CityId','=','classifiedregistration.City')
            //->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.ClassifiedRegId')
            ->get();
        $companydata= DB::table('companyregistration')->where('IsApprove','1')
            //->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
           // ->leftjoin('city','city.CityId','=','companyregistration.City')
           // ->leftjoin('area','area.AreaId','=','companyregistration.Area')
            //->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','companyregistration.CompanyRegId')

            ->get();
        $sitevisitor=DB::select(' select SiteCounterId  from sitecounter where   Date(TimeStamp) = curdate()');
		



         $type= 0;
        $keyword= '';
        $city=0;
        $category=0;
        $paymentType=0;
        $rank=0;
        $email= '';

      $page = Input::get('page',1);  
    $paginate = 10;  
      
    $data = DB::select('call Usp_GetAdminSearchResult(?,?,?,?,?,?,?)',array($type,$keyword,$city,$category,$paymentType,$rank,$email));
      
    $offSet = ($page * $paginate) - $paginate;  
    $itemsForCurrentPage = array_slice($data, $offSet, $paginate, true);  
    $data = new \Illuminate\Pagination\LengthAwarePaginator($itemsForCurrentPage, count($data), $paginate, $page);  
    $data->withPath('home/');
      
    // return view('companylist',compact('data'));  
     return view('companylist',compact('data'))->with(array('sitevisitor'=>$sitevisitor,'city'=>$city,'category'=>$category,'citydetail'=>$citydetail,'categorydetail'=>$categorydetail,'companydata'=>$companydata,'classifieddata'=>$classifieddata));      
       
    }
    public function show(Request $request)
    {
		$a=$request->getQueryString();
		 // return $a;
        $citydetail= DB::table('city')->get();
        $categorydetail=DB::table('category')->get(); 
        
		$sitevisitor=DB::select(' select count(SiteCounterId)  from sitecounter where   Date(TimeStamp) = curdate()');
		$type= (null !==$request->get('type'))? $request->get('type') : 0;
    
        $keyword=(null !==$request->get('keyword'))? $request->get('keyword') : '';
        $city=(null !==$request->get('city'))? $request->get('city') : 0;
        $category=(null !==$request->get('category'))? $request->get('category') : 0;
        $paymentType=(null !==$request->get('payment'))? $request->get('payment') : 0;
        $rank=(null !==$request->get('rate'))? $request->get('rate') : 0;
		$email=(null !== $request->get('email'))?$request->get('email'):'';
        $companydata= DB::table('companyregistration')->where('IsApprove','1')->get();
        $classifieddata= DB::table('classifiedregistration')->where('IsApprove','1')->get();
      
         $page = Input::get('page',1);  
		 $paginate = 10;  
		  
		 $data = DB::select('call Usp_GetAdminSearchResult(?,?,?,?,?,?,?)',array($type,$keyword,$city,$category,$paymentType,$rank,$email));
		
		 $offSet = ($page * $paginate) - $paginate;  
		 $itemsForCurrentPage = array_slice($data, $offSet, $paginate, true);  
		 $data = new \Illuminate\Pagination\LengthAwarePaginator($itemsForCurrentPage, count($data), $paginate, $page);  
		
	     $data->withPath('show/');
		 return view('companylist',compact('data'))->with(array('sitevisitor'=>$sitevisitor,'city'=>$city,'category'=>$category,'citydetail'=>$citydetail,'categorydetail'=>$categorydetail,'companydata'=>$companydata,'classifieddata'=>$classifieddata));        
       

    }
    public function editcompanydetail($companyregid)
    {
        $city= DB::table('city')->get();
        $category=DB::table('category')->get();
        $classified= DB::table('classifiedregistration')->where('IsApprove','1')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.ClassifiedRegId')
            ->get();
        $company= DB::table('companyregistration')->where('IsApprove','1')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('area','area.AreaId','=','companyregistration.Area')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','companyregistration.CompanyRegId')
            ->get();

        

        $companydata=DB::table('companyregistration')->where('CompanyRegId',$companyregid)
                        ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
                        ->leftjoin('city','city.CityId','=','companyregistration.City')
                        ->leftjoin('area','area.AreaId','=','companyregistration.Area')
                        ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
                        ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
                        ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','companyregistration.CompanyRegId')
                        ->first();
        $sub_categories = DB::table('subcategory')->where('CategoryId',$companydata->CategoryCode)->get();

       return  view('editCompany')->with(array('companydata'=>$companydata,'city'=>$city,'category'=>$category,'subcategories'=>$sub_categories,'classified'=>$classified,'company'=>$company));  
    }
    public function updatepayment(Request $request)
    {
       $paymentType=$request->input('type');
       $companyregisterid=$request->input('companyregid');
       $classifid=0;
    
        if($paymentType==0){
            $paymentname="Free";
        }
       elseif($paymentType==1)
       {
        $paymentname="Silver";
       }
       elseif ($paymentType==2)
       {
         $paymentname="Gold";
       }
       else {
         $paymentname="Premium";
       }
        // return $paymentname;
    $updatepayment=DB::select('call Usp_UpgradePayment(?,?,?,?,?)',array($companyregisterid,'Company',$paymentType,0,0));
 
      $SubscriptionAudit=DB::select('call Usp_SaveSubscriptionAudit(?,?,?)',array($paymentname,'Company',$companyregisterid));
  // return $paymentname;
   return redirect('/editcompany/'.$companyregisterid);
            
         
    }

    public function updatecompanyRank(Request $request)
    {
        $rank=$request->input('Ranking');
        $companyregisterid=$request->input('companyregid');
      $updateranking=DB::select('call Usp_SetRanking(?,?,?,?)',array($companyregisterid,$rank,$companyregisterid,'Company'));
   return redirect('/editcompany/'.$companyregisterid);
    }
    public function updatecompanydetail(Request $request,$companyregid)
    {
        
    $sub_categories = implode(',',$request->input('SubCategoryCode'));
    
    $user=DB::table('companyregistration')->where('CompanyRegId',$companyregid)->select('companyregistration.UserRegId')->first();
    

    $companyname=$request->input('CompanyName');
    $address1=$request->input('Address1');
    $address2=$request->input('Address2');
    $postalcode=$request->input('PostalCode');
    $faxno=$request->input('FaxNo');
    $name=$request->input('ContactName');
    $city=$request->input('City');
    // $citydata=DB::table('city')->where('CityId',$city)->select('city.CityName')->first();
    // $cityname=$citydata->CityName;

    
    $area=$request->input('Area');
    if($area!=""){
        $area=$request->input('Area') ;
    }
    else {
        $area=0 ;
    }
 
    $email=$request->input('Email');
    
    $phone=preg_replace('/[^\dxX]/', '', $request->input('Phone'));
    $mobile=preg_replace('/[^\dxX]/', '', $request->input('Mobile'));
    $category=$request->input('CategoryCode');
    $subcategory=$request->input('SubCategoryCode');
    $websitelink=$request->input('WebsiteLink');
    if($websitelink!="")
    {
      $websitelink=$request->input('WebsiteLink');
    }
    else {
      $websitelink="";
    }

    $description=$request->input('DescribeBusiness');
    $lookingfor=$request->input('lookingFor');
    $userid= $user->UserRegId;
    $claimflag=$request->input('ClaimFlag') ;
    if($claimflag!="")
    {
        $claimflag=$request->input('ClaimFlag') ;
    }
    else 
    {
        $claimflag=0 ;
    }
    $profilepic=$request->input('IsProfileEnabled');
    
    if($profilepic!="")
    {
        $profilepic=$request->input('IsProfileEnabled');
    }
    else 
    {
        $profilepic=0 ;
    }
    $isadmin=1;
    $expirydate=$request->input('ExpiryDate');
    $paymentType=$request->input('ActualRegType');
    $rank=$request->input('Ranking');
    $companyregisterid=$companyregid;
    $classifiedregid=0;
	$date=date('Y-m-d H:i:s');
    
	// return array($companyname,$address1,$address2,$postalcode,$faxno,$name,$city,$area,$email,$phone,$mobile,$category,$subcategory,$websitelink,$description,$userid,$claimflag,$profilepic,$isadmin,$expirydate,$companyregisterid);

    if($profilepic==1)
    {
     
     $profilepicenabled=DB::select('call Usp_SaveProfileEnabled(?,?,?,?)',array($profilepic,"Company",$companyregisterid,$expirydate));
     $SubscriptionAudit=DB::select('call Usp_SaveSubscriptionAudit(?,?,?)',array('Profile Photo','Company',$companyregisterid));
    }
    
   

      DB::table('userregistration')
            ->where('UserRegId', $userid)
            ->update(array('Name'=>$name,'Email'=>$email,'Phone'=>$phone,'Mobile'=>$mobile,'ClaimFlag'=>$claimflag));

        DB::table('companyregistration')
         ->where('UserRegId', $userid)->where('CompanyRegId',$companyregid)
             ->update(array('CompanyName'=>$companyname,'Address1'=>$address1,'Address2'=>$address2,'PostalCode'=>$postalcode,'FaxNo'=>$faxno,'CategoryCode'=>$category,'SubCategoryCode'=>$sub_categories,'WebsiteLink'=>$websitelink,'City'=>$city,'Area'=>$area,'DescribeBusiness'=>$description,'LookingFor'=>$lookingfor,'IsProfileEnabled'=>$profilepic,'AdminModifiedDate'=>$date,'ExpiryDate'=>$expirydate,'ModifiedBy'=>$isadmin,'ModifiedDate'=>$date));
      
    //$updatecompanydetail=DB::select('call usp_SaveEditDetailsLatest1(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',array($companyname,$address1,$address2,$postalcode,$faxno,$name,$city,$area,$email,$phone,$mobile,$category,$sub_categories,$websitelink,$description,$userid,$claimflag,$profilepic,$isadmin,$expirydate));
    

     return redirect('/editcompany/'.$companyregid);
    }

    public function editclassifieddetail($classifiedregid)
   {
        $city= DB::table('city')->get();
        $category=DB::table('category')->get();
        $classified= DB::table('classifiedregistration')->where('IsApprove','1')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.ClassifiedRegId')
            ->get();
        $company= DB::table('companyregistration')->where('IsApprove','1')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('area','area.AreaId','=','companyregistration.Area')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','companyregistration.CompanyRegId')
            ->get();

       $classifieddata=DB::table('classifiedregistration')->where('ClassifiedRegId',$classifiedregid)
         ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.ClassifiedRegId')
            ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
       ->first();

       $sub_categories = DB::table('subcategory')->where('CategoryId',$classifieddata->CategoryCode)->get();
      
      return  view('editClassified')->with(array('classifieddata'=> $classifieddata,'city'=>$city,'category'=>$category,'subcategories'=>$sub_categories,'classified'=>$classified,'company'=>$company));  
    }

    public function updateclassifiedRank(Request $request)
    {
        $rank=$request->input('Ranking');
        $classifiedregid=$request->input('classifiedregid');
      $updateranking=DB::select('call Usp_SetRanking(?,?,?,?)',array($classifiedregid,$rank,$classifiedregid,'Classified'));
       return redirect('/editclassified/'.$classifiedregid);
    }

    public function updatepaymentAdd(Request $request)
     {
         $paymentType=$request->input('ActualRegType');

         $classifiedregid=$request->input('classifiedregid');
         $companyid=0;
         $updatepayment=DB::select('call Usp_UpgradePayment(?,?,?,?,?)',array($classifiedregid,'Classified',$paymentType,$companyid,0));
           $SubscriptionAudit=DB::select('call Usp_SaveSubscriptionAudit(?,?,?)',array('Premium','Classified',$classifiedregid));
          return redirect('/editclassified/'.$classifiedregid);
    }
     public function updateclassifieddetail(Request $request,$classifiedregid)
    {
       
    $user=DB::table('classifiedregistration')->where('ClassifiedRegId',$classifiedregid)
         ->select('classifiedregistration.UserRegId')->first();
         
     $sub_categories = implode(',',$request->input('SubCategoryCode'));
     
    $id=$classifiedregid;
    $category=$request->input('CategoryCode');
    $subcategory=$request->input('SubCategoryCode');
    $city=$request->input('City');
    $citydata=DB::table('city')->where('CityId',$city)->select('city.CityName')->first();
    $cityname=$citydata->CityName;
    $classifiedtitle=$request->input('ClassifiedTitle');
    $classifiedcontent=$request->input('ClassifiedContent');        
    $weburl=$request->input('WebUrl'); 
    $name=$request->input('Name');
    $email=$request->input('Email');
    $phone=preg_replace('/[^\dxX]/', '', $request->input('Phone'));
    $mobile=preg_replace('/[^\dxX]/', '', $request->input('Mobile'));
    $purpose='';
    $flag=0;
    $claimflag=1;
    $isadmin=1;
    $profilepic=$request->input('IsProfileEnable') ;
    $expirydate=$request->input('ExpiryDate');
    $UserRegId=$user->UserRegId;  
    $rank=$request->input('Ranking');
    $paymentType=$request->input('ActualRegType');
    $companyregisterid=DB::table('companyregistration')->where('UserRegId',$UserRegId)->first();
    $companyid=0;
    $date=date('Y-m-d H:i:s');
   
    
    if($profilepic==1)
    {
     
     $profilepicenabled=DB::select('call Usp_SaveProfileEnabled(?,?,?,?)',array($profilepic,'Classified',$classifiedregid,$expirydate));
     $SubscriptionAudit=DB::select('call Usp_SaveSubscriptionAudit(?,?,?)',array('Profile Photo','Classified',$classifiedregid));
    }
    // elseif($paymentType>0)
    // {
    //        $updatepayment=DB::select('call Usp_UpgradePayment(?,?,?,?,?)',array($classifiedregid,'Classified',$paymentType,$companyid,$classifiedregid));
    //        $SubscriptionAudit=DB::select('call Usp_SaveSubscriptionAudit(?,?,?)',array('Premium','Classified',$classifiedregid));
    // }
    // else{

    //      }

   /* DB::table('userregistration')
        ->where('UserRegId', $userid)
        ->update(array('Name'=>$name,'Email'=>$email,'Phone'=>$phone,'Mobile'=>$mobile,'ClaimFlag'=>$claimflag));

    DB::table('companyregistration')
        ->where('UserRegId', $userid)->where('CompanyRegId',$companyregid)
        ->update(array('CompanyName'=>$companyname,'Address1'=>$address1,'Address2'=>$address2,'PostalCode'=>$postalcode,'FaxNo'=>$faxno,'CategoryCode'=>$category,'SubCategoryCode'=>$sub_categories,'WebsiteLink'=>$websitelink,'City'=>$city,'Area'=>$area,'DescribeBusiness'=>$description,'IsProfileEnabled'=>$profilepic,'AdminModifiedDate'=>$date,'ExpiryDate'=>$expirydate,'ModifiedBy'=>$isadmin,'ModifiedDate'=>$date));



     $updateclassifieddetail=DB::select('call Usp_SaveEditClassifiedById(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        array($id,$category,$subcategory,$city,$cityname,$classifiedtitle,$classifiedcontent,$weburl,$name,$email,$phone,$mobile,$purpose,$flag,$claimflag,$isadmin,$profilepic,$expirydate));
      */ 
      DB::table('userregistration')
        ->where('UserRegId', $UserRegId)
        ->update(array('Name'=>$name,'Email'=>$email,'Phone'=>$phone,'Mobile'=>$mobile,'ClaimFlag'=>$claimflag));
       
    DB::table('classifiedregistration')
        ->where('UserRegId', $UserRegId)
        ->where('ClassifiedRegId',$classifiedregid)
		->update(array('ClassifiedTitle'=>$classifiedtitle,'CategoryCode'=>$category,'SubCategoryCode'=>$sub_categories,'WebUrl'=>$weburl,'City'=>$city,'IsProfileEnabled'=>$profilepic,'Purpose'=>$purpose,'AdminModifiedDate'=>$date,'ExpiryDate'=>$expirydate,'ModifiedBy'=>$isadmin,'ModifiedDate'=>$date));
        
        
    return redirect('/editclassified/'.$classifiedregid);
    }
    public function viewdetail($CompanyRegId)
    {
        $user=DB::table('companyregistration')->where('CompanyRegId',$CompanyRegId)
               ->leftjoin('userregistration' ,'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
               ->leftjoin('city','city.CityId','=','companyregistration.City')
               ->leftjoin('area','area.AreaId','=','companyregistration.Area')
               ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','companyregistration.CompanyRegId')
               ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
               ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
               ->first();
        return view('userdetail')->with('user',$user);
        
    }
    public function viewclassifieddetail($classifiedregid){
        $user=DB::table('classifiedregistration')->where('ClassifiedRegId',$classifiedregid)
         ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.ClassifiedRegId')
            ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
            ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
       ->first();
   return view('classifieddetail')->with('user',$user);

    }

    public function deletecompany($companyregid)
    {
        $user=DB::table('companyregistration')->where('CompanyRegId',$companyregid)
        ->join('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
        ->delete();
        $classified= DB::table('classifiedregistration')->where('IsApprove',0)
            ->join('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.ClassifiedRegId')
            ->select('classifiedregistration.*', 'userregistration.*')
            ->get();

        $company= DB::table('companyregistration')->where('IsApprove',0)
            ->join('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')


            ->select('companyregistration.*', 'userregistration.*')
            ->get();
        return redirect('approve')->with(array('classified'=>$classified,'company'=>$company));
    }
	public function deleteclassified($classifiedregid)
    {
        $user=DB::table('classifiedregistration')->where('ClassifiedRegId',$classifiedregid)
        ->join('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
        ->delete();
        $classified= DB::table('classifiedregistration')->where('IsApprove',0)
            ->join('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.ClassifiedRegId')
            ->select('classifiedregistration.*', 'userregistration.*')
            ->get();

        $company= DB::table('companyregistration')->where('IsApprove',0)
            ->join('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')


            ->select('companyregistration.*', 'userregistration.*')
            ->get();
        return redirect('approve')->with(array('classified'=>$classified,'company'=>$company));
    }
    public function approvelist(){
     
        $classified= Classified::where('IsApprove','0')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.ClassifiedRegId')
            ->select(DB::raw('ClassifiedRegId,ClassifiedTitle,""as AreaName,city.CityName,Name,Email,Phone,"Classified" as type,PostedDate,ActualRegType,Ranking')) ;
           
        $company= Company::where('IsApprove','0')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('area','area.AreaId','=','companyregistration.Area')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','companyregistration.CompanyRegId')
            ->select(DB::raw('CompanyRegId,CompanyName,area.AreaName,city.CityName,Name,Email,Phone,"Company" as type,DateOfReg,ActualRegType,Ranking'))
           ->union($classified)
           ->unionPaginate(10,'*',$pageName = 'page',null);

        
        return view('approvelist')->with(array('company'=>$company));
    }
    public function searchnonapprovelist(Request $request)
    {
        $type=$request->get('type');
        $keyword=$request->get('searchtext');

        if(($type==0)&&($keyword==''))
        {
            $classified= Classified::where('IsApprove','0')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.ClassifiedRegId')
            ->select(DB::raw('ClassifiedRegId,ClassifiedTitle,""as AreaName,city.CityName,Name,Email,Phone,"Classified" as type,PostedDate,ActualRegType,Ranking')) ;
           
        $company= Company::where('IsApprove','0')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('area','area.AreaId','=','companyregistration.Area')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','companyregistration.CompanyRegId')
            ->select(DB::raw('CompanyRegId,CompanyName,area.AreaName,city.CityName,Name,Email,Phone,"Company" as type,DateOfReg,ActualRegType,Ranking'))
           ->union($classified)
		   ->orderBy('CompanyRegId','desc')
           ->unionPaginate(10,'*',$pageName = 'page',null);
        }
        elseif(($type==1)&&($keyword==''))
        {

            $company= Company::where('IsApprove','0')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('area','area.AreaId','=','companyregistration.Area')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','companyregistration.CompanyRegId')
            ->select(DB::raw('CompanyRegId,CompanyName,area.AreaName,city.CityName,Name,Email,Phone,"Company" as type,DateOfReg,ActualRegType,Ranking'))
           
           ->unionPaginate(10,'*',$pageName = 'page',null);
        }
        elseif(($type==2)&&($keyword=='')){
          $company= Classified::where('IsApprove','0')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.ClassifiedRegId')
            ->select(DB::raw('ClassifiedRegId,ClassifiedTitle,""as AreaName,city.CityName,Name,Email,Phone,"Classified" as type,PostedDate,ActualRegType,Ranking'))->unionPaginate(10,'*',$pageName = 'page',null); 
        }
        elseif(($type==0)&&($keyword!=''))
        {
            $classified= Classified::where('IsApprove','0')->where('ClassifiedTitle','like', '%' .$keyword.'%')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.ClassifiedRegId')
            ->select(DB::raw('ClassifiedRegId,ClassifiedTitle,""as AreaName,city.CityName,Name,Email,Phone,"Classified" as type,PostedDate,ActualRegType,Ranking')) ;
           
        $company= Company::where('IsApprove','0')->where('CompanyName','like', '%' .$keyword.'%')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('area','area.AreaId','=','companyregistration.Area')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','companyregistration.CompanyRegId')
            ->select(DB::raw('CompanyRegId,CompanyName,area.AreaName,city.CityName,Name,Email,Phone,"Company" as type,DateOfReg,ActualRegType,Ranking'))
           ->union($classified)
		    ->orderBy('CompanyRegId','desc')
           ->unionPaginate(10,'*',$pageName = 'page',null);
        }
        elseif(($type==1)&&($keyword!=''))
        {

            $company= Company::where('IsApprove','0')->where('CompanyName','like', '%' .$keyword.'%')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('area','area.AreaId','=','companyregistration.Area')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','companyregistration.CompanyRegId')
            ->select(DB::raw('CompanyRegId,CompanyName,area.AreaName,city.CityName,Name,Email,Phone,"Company" as type,DateOfReg,ActualRegType,Ranking'))
           
           ->unionPaginate(10,'*',$pageName = 'page',null);
        }
        elseif(($type==2)&&($keyword!='')){
          $company= Classified::where('IsApprove','0')->where('ClassifiedTitle','like', '%' .$keyword.'%')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.ClassifiedRegId')
            ->select(DB::raw('ClassifiedRegId,ClassifiedTitle,""as AreaName,city.CityName,Name,Email,Phone,"Classified" as type,PostedDate,ActualRegType,Ranking'))->unionPaginate(10,'*',$pageName = 'page',null);
        }
        else {
            $classified= Classified::where('IsApprove','0')->where('ClassifiedTitle','like', '%' .$keyword.'%')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','classifiedregistration.City')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','classifiedregistration.ClassifiedRegId')
            ->select(DB::raw('ClassifiedRegId,ClassifiedTitle,""as AreaName,city.CityName,Name,Email,Phone,"Classified" as type,PostedDate,ActualRegType,Ranking')) ;
           
        $company= Company::where('IsApprove','0')->where('CompanyName','like', '%' .$keyword.'%')
            ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
            ->leftjoin('city','city.CityId','=','companyregistration.City')
            ->leftjoin('area','area.AreaId','=','companyregistration.Area')
            ->leftjoin('subscriptionaudit','subscriptionaudit.Id','=','companyregistration.CompanyRegId')
            ->select(DB::raw('CompanyRegId,CompanyName,area.AreaName,city.CityName,Name,Email,Phone,"Company" as type,DateOfReg,ActualRegType,Ranking'))
           ->union($classified)
           ->unionPaginate(10,'*',$pageName = 'page',null); 
        }

        return view('approvelist')->with(array('company'=>$company,'type'=>$type));
    }
    public function approvead($id){
     
          
    
      DB::select('call Usp_ApproveRegistration(?,?,?,?)',array($id,1,'Classified',$id));
          
        return redirect('/approve');

    }
    public function approvecompany($id)
    {

        DB::select('call Usp_ApproveRegistration(?,?,?,?)',array($id,1,'Company',$id));

        return redirect('/approve');

    }
    public function report()
    {

      $category=DB::table('category')->get();  
      $company=DB::table('companyregistration')->get();
        return view ('reportpage')->with(array('category'=>$category,'company'=>$company));
    }
    public function visitors_report(Request $request)
    { 
      $year=$request->input('year');

      $monthwise= DB::select('call Usp_GetMonthWiseVisitorReport(?)',array($year));

     return $monthwise;
      $startdate=$year."-01-01 00:00:00";
      $enddate=$year."-12-31 00:00:00";
      $weekwise=DB::select('call Usp_GetWeekWiseVisitorReport(?,?,?)',array($year,$startdate,$enddate));
      return $weekwise;
        return view ('reportpage')->with(array('monthwise'=>$monthwise,'weekwise'=>$weekwise));
     
    }
    public function companyreport(){
       

    }
    public function  announcement()
    {
        $announcements=DB::table('announcements')->get();
        return view('announcements')->with('announcements',$announcements);
    }
    public function saveannouncements(Request $request)
    {
         $announcement=new Announcement;
           
            $announcement->Description=$request->input('Description');
            $announcement->NavigateUrl=$request->input('NavigateUrl');
            $announcement->CreatedDate=now();
            $announcement->save();
       $announcements=DB::table('announcements')->get();
        return redirect('/announcement')->with('announcements',$announcements);

    }
    public function deleteannouncement($announcementid)
    {
            $announcements_del=DB::table('announcements')->where('AnnouncementId',$announcementid)->delete();
            $announcements=DB::table('announcements')->get();
        return redirect('/announcement')->with('announcements',$announcements);
    }

    public function deletecompanydetail($companyid)
    {
        $company_del=DB::table('companyregistration')->where('CompanyRegId',$companyid)->delete();
        return redirect('/home');
    }
    public function deleteclassifieddetail($classifiedid)
    {
        $company_del=DB::table('classifiedregistration')->where('ClassifiedRegId',$classifiedid)->delete();
        return redirect('/home');
    }

}
