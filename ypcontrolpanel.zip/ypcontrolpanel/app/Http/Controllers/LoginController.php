<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use DB;
use Mail;
use app\Classified;
use app\Company;
use app\Admin;
use app\City;
use Auth;

class LoginController extends Controller
{
   public function login(){
	   if(Auth::user())
	   {
		    return redirect ('/home');
	   }
       return view ('login');
   }
    public function authenticate(Request $request){
      // return $request;

        $username=$request->input('UserName');
        $password=$request->input('Password');
        $admin=DB::select('select * from admin where  Password=? and UserName=?',[$password,$username]);
        if($admin!=null){

            return redirect ('/home');

//            return View('dashboard')->with('classified',$classified);
        }
        else{
          return  redirect ('/');
        }
    }
      public function  dologin(Request $request){

    }
 }
