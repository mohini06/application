<?php

namespace App\Http\Controllers;

use DB;
use Auth;
use App\User;
use App\city;
use App\Company;
use App\Category;
use App\Classified;
use App\Mail\Email;
use Mail;
use App\SubCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;


class MailController extends Controller
{
    public function index()
    {
        $category=DB::table('category')->get();
        $subcategory=DB::table('subcategory')->get();
        return view('mailing')->with(array('subcategory'=>$subcategory,'category'=>$category));
    }
    public function search(Request $request)
    {
        $cityname = $request->get('city');
        $search_item = $request->get('search_item');
        $selectedoption = $request->get('selectedoption');

        $category=DB::table('category')->get();
        $subcategory=DB::table('subcategory')->get();

        $cat_subcat=DB::table('subcategory')
            ->where ('SubCategoryName', $selectedoption)
            ->leftjoin('category', 'category.CategoryId', '=', 'subcategory.CategoryId')
            ->first();

            if(($search_item!="")&&($cityname=="")&&($selectedoption==""))
            {
                $classifieddata=DB::table('classifiedregistration')
                    ->where('IsApprove',1)
                    ->whereRaw("(`ClassifiedTitle` like '%".$search_item."%' or `ClassifiedContent` like '%".$search_item."%') and ExpiryDate > now()")
                    ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
                    ->leftjoin('city','city.CityId','=','classifiedregistration.City')
                    ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
                    ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
                    ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
                    ->orderBy('ActualRegType','desc')
                    ->select(DB::raw('Email,ActualRegType,ClassifiedRegId,ClassifiedTitle,city.CityName,WebUrl,ClassifiedContent,classifiedimage.ImageUrl,Phone,"classified" as type'));
                
                $companydata=Company::where('CompanyName','like', '%' .$search_item.'%')
                    ->where('IsApprove',1)
                    ->orWhere('DescribeBusiness','like', '%' .$search_item.'%')
                    ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
                    ->leftjoin('city','city.CityId','=','companyregistration.City')
                    ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
                    ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
                    ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
                    ->select(DB::raw('Email,ActualRegType,CompanyRegId,CompanyName,city.CityName,WebsiteLink,DescribeBusiness,companyimage.ImageUrl,Phone,"Company" as type'))
                    ->union($classifieddata)
                    ->orderBy('ActualRegType','desc')
                    ->get();
                    //->unionPaginate(10,'*',$pageName = 'page',null);	
            }
            elseif (($search_item!="")&&($cityname!="")&&($selectedoption=="")) 
            {
                $classifieddata=DB::table('classifiedregistration')
                    ->where([
                        ['City', $request->input('city') ],
                        ['ClassifiedTitle','like', '%' .$search_item.'%']
                     ])
                    ->where('IsApprove',1)
                    ->whereRaw(' ExpiryDate > now()')
                    ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
                    ->leftjoin('city','city.CityId','=','classifiedregistration.City')
                    ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
                    ->leftjoin('category','category.CategoryId','=','classifiedregistration.CategoryCode')
                    ->leftjoin('subcategory','subcategory.SubCategoryId','=','classifiedregistration.SubCategoryCode')
                    ->orderBy('ActualRegType','desc')
                    ->select(DB::raw('Email,ActualRegType,ClassifiedRegId,ClassifiedTitle,city.CityName,WebUrl,ClassifiedContent,Phone,classifiedimage.ImageUrl,"classified" as type'));
                 
                $companydata=Company::where([
                        ['City', $request->input('city') ],
                        ['CompanyName','like', '%' .$search_item.'%']
                    ])
                    ->where('IsApprove',1)
                    ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
                    ->leftjoin('city','city.CityId','=','companyregistration.City')
                    ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
                    ->leftjoin('category','category.CategoryId','=','companyregistration.CategoryCode')
                    ->leftjoin('subcategory','subcategory.SubCategoryId','=','companyregistration.SubCategoryCode')
                    ->select(DB::raw('Email,ActualRegType,CompanyRegId,CompanyName,city.CityName,WebsiteLink,DescribeBusiness,Phone,companyimage.ImageUrl,"Company" as type'))
                    ->union($classifieddata)
                    ->orderBy('ActualRegType','desc')
                    ->get();
                    //->unionPaginate(10,'*',$pageName = 'page',null);
            }
            elseif(($search_item=="")&&($cityname!="")&&($selectedoption!=""))
            {
                $classifieddata=DB::table('classifiedregistration')->where([
                        ['City', $request->input('city') ],
                        ['SubCategoryName',$selectedoption],
                        ['IsApprove',1]
                    ])
                    ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
                    ->leftjoin('city','classifiedregistration.City','=','city.CityId')
                    ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
                    ->leftjoin('subcategory',function($query) { $query->whereRaw("find_in_set(subcategory.SubCategoryId, classifiedregistration.SubCategoryCode)"); })
                    ->orderBy('ActualRegType','desc')
                    ->whereRaw(' ExpiryDate > now()')
                    ->select(DB::raw('Email,ActualRegType,ClassifiedRegId,ClassifiedTitle,SubCategoryName,city.CityName,WebUrl,ClassifiedContent,Phone,classifiedimage.ImageUrl,"classified" as type'));  
        
                $companydata=Company::where([
                        ['City', $request->input('city') ],
                        ['SubCategoryName',$selectedoption],
                        ['IsApprove',1]
                    ])
                    ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
                    ->leftjoin('city','companyregistration.City','=','city.CityId')
                    ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
                    ->leftJoin('subcategory', function($query) { $query->whereRaw("find_in_set(subcategory.SubCategoryId, companyregistration.SubCategoryCode)"); })
                    ->select(DB::raw('Email,ActualRegType,CompanyRegId,CompanyName,SubCategoryName,city.CityName,WebsiteLink,DescribeBusiness,Phone,companyimage.ImageUrl,"Company" as type'))
                    ->union($classifieddata)
                    ->orderBy('ActualRegType','desc')
                    ->get();
                    //->unionPaginate(10,'*',$pageName = 'page',null);
            }
            elseif (($search_item=="")&&($cityname=="")&&($selectedoption!=""))
            {
                $classifieddata=DB::table('classifiedregistration')->where([
                        ['SubCategoryName',$selectedoption],
                        ['IsApprove',1]
                    ])
                    ->leftjoin('classifiedimage','classifiedimage.ClassifiedId','=','classifiedregistration.ClassifiedRegId')
                    ->leftjoin('city','classifiedregistration.City','=','city.CityId')
                    ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'classifiedregistration.UserRegId')
                    ->leftjoin('subcategory',function($query) { $query->whereRaw("find_in_set(subcategory.SubCategoryId, classifiedregistration.SubCategoryCode)"); })
                    ->orderBy('ActualRegType','desc')
                    ->orderBy('Ranking','asc')
                    ->whereRaw(' ExpiryDate > now()')                        
                    ->select(DB::raw('Email,Ranking,ActualRegType,ClassifiedRegId,ClassifiedTitle,SubCategoryName,city.CityName,WebUrl,ClassifiedContent,Phone,classifiedimage.ImageUrl,"classified" as type'));  
    
                $companydata=Company::where([
                        ['SubCategoryName',$selectedoption],
                        ['IsApprove',1]
                    ])
                    ->leftjoin('companyimage','companyimage.CompanyId','=','companyregistration.CompanyRegId')
                    ->leftjoin('city','companyregistration.City','=','city.CityId')
                    ->leftjoin('userregistration', 'userregistration.UserRegId', '=', 'companyregistration.UserRegId')
                    ->leftJoin('subcategory', function($query) { $query->whereRaw("find_in_set(subcategory.SubCategoryId, companyregistration.SubCategoryCode)"); })
                    ->select(DB::raw('Email,Ranking,ActualRegType,CompanyRegId,CompanyName,SubCategoryName,city.CityName,WebsiteLink,DescribeBusiness,Phone,companyimage.ImageUrl,"Company" as type'))
                    ->union($classifieddata)
                    ->orderBy('ActualRegType','desc')
                    ->orderBy('Ranking','asc')
                    ->get();
                    //->unionPaginate(10,'*',$pageName = 'page',null);
            }  
            else
            {
                $companydata=[];
            }
        return view('mailsearch')->with(array('companydata'=>$companydata,'subcategory'=>$subcategory,'category'=>$category)); 
    }

    public function sendmail(Request $request)
    {
        $to_address = $request->get('to');
        $subject_data = trim($request->get('subject'));
        $message_data = trim($request->get('message'));
        $files = $request->file('files');

        $address_array=explode(',',$to_address);
        
        $template_path = 'mail_companies';
     
        foreach($address_array as $email_id)
        {
            $data = array('email'=>$email_id,'subject'=>$subject_data,'messagerec'=>$message_data);
            Mail::send('mail_companies',$data,function($message) use ($data, $files) {
                $message->to($data['email'])->subject($data['subject']);
                $message->cc("sales@ypk.kz");
                if(count($files)>0)
                {
                    foreach($files as $file) {
                        $message->attach($file->getRealPath(), array(
                            'as' => $file->getClientOriginalName(),      
                            'mime' => $file->getMimeType())
                        );
                    }
                }
           });
        }
        $category=DB::table('category')->get();
        $subcategory=DB::table('subcategory')->get();
        return redirect('mailing')->with(array('subcategory'=>$subcategory,'category'=>$category));        
    }
} 