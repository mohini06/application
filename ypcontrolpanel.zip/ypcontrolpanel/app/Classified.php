<?php

namespace App;
use Krossroad\UnionPaginator\UnionPaginatorTrait;
use Illuminate\Database\Eloquent\Model;

class Classified extends Model
{
    use UnionPaginatorTrait;
    protected $table='classifiedregistration';
    public $primarykey ='ClassifiedRegId';
    public $timestamps=false;
    public $fillable  = [
        'ClassifiedTitle','CategoryCode','SubCategoryCode','email','name','city','mobile','phone','ClassifiedContent','url','UserRegId'
    ];

    public function user()
    {
        return $this->belongsTo(User::class,'UserRegId','UserRegId');
    }
}
