<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubscriptionAudit extends Model
{
    protected $table='subscriptionaudit';
    public $primarykey ='SubscriptionAuditId';

    public $timestamps=true;
    // protected $dateFormat = 'U';
    const CREATED_AT = 'CreatedDate';
    const UPDATED_AT = 'UpgradeDate';
    


    protected $fillable = ['SubscriptionType', 'Type', 'Id','CreatedDate', 'UpgradeDate','CancelDate'];

    
}
