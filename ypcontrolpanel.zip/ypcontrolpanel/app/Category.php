<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Subcategory;

class Category extends Model
{
    protected $table='category';
    public $primarykey ='CategoryId';
    public $timestamps=false;
    //protected $fillable = ['country_id', 'created_at', 'updated_at', 'name', 'latitude', 'longitude'];
    public function subcategory()
    {
        return $this->hasMany('App\SubCategory');
    }

}
