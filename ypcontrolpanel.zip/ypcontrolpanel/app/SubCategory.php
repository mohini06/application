<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Category;

class SubCategory extends Model
{
    protected $table='subcategory';
    public $primarykey ='SubCategoryId';

    public $timestamps=false;
    protected $fillable = ['country_id', 'created_at', 'updated_at', 'name', 'latitude', 'longitude'];

    public function category()
    {
        return $this->belongsTo('App\Category');
    }
}
