<?php
//Database credentials
$dbHost     = '127.0.0.1';
$dbUsername = 'ypksite';
$dbPassword = 'l&&ph]7C$=5u;{W';
$dbName     = 'yellowpageskz';

//Connect and select the database
//$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
$db = new PDO('mysql:charset=utf8mb4; host=localhost; dbname=yellowpageskz', "ypksite", "l&&ph]7C$=5u;{W");
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
?>