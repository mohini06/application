
    <h4>{{__('message.Visitors_report_Monthly')}}</h4>
    <table id="monthly">
        <thead>
            <tr>
                <th>{{__('message.Month')}}</th>
                <th>{{__('message.Visitors_Count')}}</th>
            </tr>
        </thead>
        <tbody>
            @foreach($report as $data)
                @if($data->Count==null)

                    <tr><td>{{$data->Month}}</td><td>0</td></tr>
                    @else
                    <tr><td>{{$data->Month}}</td><td>{{$data->Count}}</td></tr>
                    @endif
            @endforeach
        </tbody>
    </table>