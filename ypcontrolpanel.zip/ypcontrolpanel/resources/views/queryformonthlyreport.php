<?php
include "db2.php";
$year_id = $_REQUEST['year_id'];
 $sql="call Usp_GetMonthWiseVisitorReport($year_id)";
$result=$db->query($sql);
$output=array();
echo ' <h4>'.'Visitors report Monthly'.'</h4>';
 echo '<table id="monthly">'.'<tr>'.'<th>'.'Month'.'</th>'.'<th>'.'Visitors Count'.'</th>'.'</tr>' ;

    while($row = mysqli_fetch_array($result)){
       if($row['Count']==null)
       {
       	echo '<tr>'.'<td>'.$row['Month'].'</td>'.'<td>'.'0'.'</td>'.'</tr>';
       }
      else {
      	echo '<tr>'.'<td>'.$row['Month'].'</td>'.'<td>'.$row['Count'].'</td>'.'</tr>';
      }  

    }
 echo '</table>';
?>