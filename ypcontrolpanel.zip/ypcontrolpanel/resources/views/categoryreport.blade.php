
    <h4>{{__('message.Report_Category')}}</h4>
    <table id="categorywise">
        <thead>
            <tr>
                <th>{{__('message.Category_Name')}}</th>
                <th>{{__('message.Visitors_Count')}}</th>
            </tr>
        </thead>
        <tbody>
            @foreach($report as $data)
                @if($data->Count==null)
                    <tr><td>{{$data->Name}}</td><td>0</td></tr>
                    @else
                    <tr><td>{{$data->Name}}</td><td>{{$data->Count}}</td></tr>
                    @endif
            @endforeach
        </tbody>
    </table>