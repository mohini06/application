
<div id="data">
   <p>
  {{ __('message.para') }}
  tfdgh rffqjwuebfc
   </p>
</div>
