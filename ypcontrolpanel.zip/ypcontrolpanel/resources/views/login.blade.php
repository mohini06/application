<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
<title>{{ __('message.YPK') }}</title>
<link rel="icon" href="{{asset('/public/Images/favicon.png')}}">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <!-- Styles -->

</head><!-- app/views/login.blade.php -->

<body style="background-color:white; margin: 50px;">

<div class="container">
	<div class="row">
		<div class="col-md-12">
			<p class="text-center">
				<a  style="margin:0px; padding:0px;" href="{{url('/')}}"><img src="{{asset('/public/Images/ypk_ru.png')}}" alt="" class="logo-img-width"></a>
			</p>
		</div>
	</div>
    <div class="row" style="margin-top:60px;">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">{{ __('message.Admin_Login') }}</div>

                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="{{ route('login') }}">
                        {{ csrf_field() }}

                        <div class="form-group">
                            <label for="UserName" class="col-md-4 control-label">{{ __('message.Username') }}</label>

                            <div class="col-md-6">
                                <input id="UserName" type="text" class="form-control" name="UserName" value="{{ old('UserName') }}" required>

                                @if ($errors->has('UserName'))
                                    <!--<span class="help-block">
                                        <strong>{{ __('message.credentials_mismatch') }}</strong>
                                    </span>-->
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label">{{ __('message.Password') }}</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required autofocus>

                                @if ($errors->has('password') || $errors->has('UserName'))
                                    <span class="help-block">
                                        <!--<strong>{{ $errors->first('password') }}</strong>-->
                                        <strong class="text-danger">{{ __('message.credentials_mismatch') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}> {{ __('message.Remember_Me') }}
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('message.Login') }}
                                </button>

                               
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
