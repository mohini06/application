@extends('layouts.app')
@section('content')
<div class="row">
	<div class="col-md-12">
		<h3 class="heading">{{ __('message.SEARCH_ANNONCEMENTS') }}</h3>
	</div>
</div>
@php 
			     $searchtext= isset($_GET['searchtext'])?$_GET['searchtext']:"";
				 $type         =isset($_GET['type'])?$_GET['type']:0;
				 
			  @endphp
 <form method="get" action="{{url('/nonapprovesearch')}}" id="nonapprovesearch" role="form">
  <input type="hidden" name="_token" value="{{ csrf_token()}}">
<div class="row" >
  

<div class="col-sm-4">
  <div class="form-group">
  <select class="form-control" name="type" id="type">
     
    <option value="0"  <?php  echo $type==0 ? "SELECTED":""; ?>>{{ __('message.All') }}</option>
	
    <option value="1" <?php  echo ($type==1) ? "SELECTED":"";?>>{{ __('message.Company') }}</option>
	
    <option value="2" <?php  echo ($type==2) ? "SELECTED":""; ?>>{{ __('message.ad') }}</option>
  </select>
  </div>
  </div>
  <div class="col-sm-6">
    <div class="form-group">
      <input type="text" name="searchtext" value="@php echo $searchtext;  @endphp" id="searchtext" class="form-control" />
	</div>
  </div>
<div class="col-sm-2">
	<div>
		<input type="submit" class="btn btn-md" style="margin:0px;"  value="{{ __('message.Search') }}" />
	</div>
</div>

</div>
</form>
<table class="table table-bordered">
<thead>
	<tr>
		 <th>{{ __('message.Name') }}</th>
		 <th>{{ __('message.Region') }}</th>
		 <th>{{ __('message.City') }}</th>
		 <th>{{ __('message.The_Contact_Person') }}</th>
		 <th>{{ __('message.Email_Address') }}</th>
		 <th>{{ __('message.Phone_No') }}</th>
		 <th>{{ __('message.A_Type') }}</th>
		 <th>{{ __('message.Date_Of_Registration') }}</th>
		 <th>{{ __('message.Payment_Type') }}</th>
		 <th>{{ __('message.Rank') }}</th>
		 <th>{{ __('message.Action') }}</th>
	</tr>
 </thead>
 <tbody>





  @foreach($company as $companies)
   @php 
 
 if((($type==0)||($type==1))&&($companies->type=='Company'))
 {

              $actualregtype=$companies->ActualRegType;
               if($actualregtype>2)
               {
                $paymenttype="Premium";
               }
               elseif($actualregtype>1)
               {
                $paymenttype="Gold";
               }
                elseif($actualregtype>0)
               {
                $paymenttype="Silver";
               }
                else
               {
                $paymenttype="Free";
               }
              $url=url('/viewdetail'); @endphp
             <tr>
              <td>{{$companies->CompanyName}}</td>
              <td>{{$companies->AreaName}}</td>
              <td>{{$companies->CityName}}</td>
              <td>{{$companies->Name}}</td>
              <td>{{$companies->Email}}</td>
              <td>{{$companies->Phone}}</td>

              <td>{{$companies->type}}</td>
              
             <td>@php echo DATE($companies->DateOfReg); @endphp </td>

            <td>{{$paymenttype}}</td>

            <td>{{$companies->Ranking}}</td>


            <td><a href="{{$url}}/{{$companies->CompanyRegId}}">{{ __('message.View_Detail') }}</a></td>
             
              </tr>
@php }

elseif((($type==0)||($type==1))&&($companies->type=='Classified'))
{

    $actualregtype=$companies->ActualRegType;
              if($actualregtype>0)
               {
                $paymenttype="Premium";
               }
                else
               {
                $paymenttype="Free";
               }
              $url=url('/viewclassifieddetail'); 
    @endphp
             <tr>
              <td>{{$companies->CompanyName}}</td>
              <td>{{$companies->AreaName}}</td>
              <td>{{$companies->CityName}}</td>
              <td>{{$companies->Name}}</td>
              <td>{{$companies->Email}}</td>
              <td>{{$companies->Phone}}</td>

              <td>{{$companies->type}}</td>
              
             <td>@php echo DATE($companies->DateOfReg); @endphp </td>

            <td>{{$paymenttype}}</td>

            <td>{{$companies->Ranking}}</td>


            <td><a href="{{$url}}/{{$companies->CompanyRegId}}">{{ __('message.View_Detail') }}</a></td>
             
              </tr>

@php  
}
 else{

 $actualregtype=$companies->ActualRegType;
 if($actualregtype>0)
   {
    $paymenttype="Premium";
   }
    else
   {
    $paymenttype="Free";
   }
 $url=url('/viewclassifieddetail'); @endphp
  <tr>
  <td>{{$companies->ClassifiedTitle}}</td>
  <td>{{$companies->AreaName}}</td>
  <td>{{$companies->CityName}}</td>
  <td>{{$companies->Name}}</td>
  <td>{{$companies->Email}}</td>
  <td>{{$companies->Phone}}</td>

  <td>{{$companies->type}}</td>
  
 <td>@php echo DATE($companies->PostedDate); @endphp </td>

<td>{{$paymenttype}}</td>

<td>{{$companies->Ranking}}</td>


<td><a href="{{$url}}/{{$companies->ClassifiedRegId}}">{{ __('message.View_Detail') }}</a></td>
 
  </tr>
@php
}
 @endphp
 
 
  @endforeach
 
</tbody>
</table>
{{ $company->appends(request()->query())->links() }}
@endsection