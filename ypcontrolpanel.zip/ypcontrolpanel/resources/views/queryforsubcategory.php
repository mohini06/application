<?php
include "db.php";
$category_id = $_REQUEST['category_id'];
$sql="SELECT * FROM subcategory where CategoryId=$category_id";
$result=$db->query($sql);

if(isset($result)){
    while($row = $result->fetch(PDO::FETCH_ASSOC))
    {
        echo '<input type="checkbox" name="subcategory[]" value="'.$row['SubCategoryId'].'"> '.$row['SubCategoryName'].'<br>';
    }
}else
{
    echo "No Data Available";
}
  
?>