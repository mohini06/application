<?php
//Database credentials
//$dbHost     = 'mysql:charset=utf8mb4;host=localhost;dbname=yellowpages_php';
//$dbUsername = 'root';
//$dbPassword = '';
//$dbName     = 'yellowpages_php';

//Connect and select the database
//$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);


$db = new PDO('mysql:charset=utf8mb4; host=localhost; dbname=yellowpageskz', "ypksite", "l&&ph]7C$=5u;{W");
?>