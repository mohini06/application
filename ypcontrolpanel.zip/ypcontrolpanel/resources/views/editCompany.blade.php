@extends('layouts.app')
@section('content')
<div class="row ">
	 <div class="panel">
	 	  <div class="panel-heading">
	 	  	   <h3>{{ __('message.EDIT_COMPANY') }}</h3>
           <hr>
	 	  </div>
	 	  <div class="panel-body" >
	 	  	<form method="post" action="{{url('updatecompanydetail')}}/{{$companydata->CompanyRegId}}" id="editCompanyForm" role="form">
         <input type="hidden" name="_token" value="{{ csrf_token()}}">
	 	  	  <div class="row">
                  <div class="col-sm-4">
                  	  <label>{{ __('message.Company_Name') }}</label><span style="color:red;">*</span>
                  	  <input type="text" name="CompanyName" value="{{$companydata->CompanyName}}" class="form-control">
                  </div>
                   <div class="col-sm-4">
                  	   <label>{{ __('message.Contact_Name') }}</label><span style="color:red;">*</span>
                  	  <input type="text" name="ContactName" value="{{$companydata->Name}}"class="form-control">
                  </div>
                   <div class="col-sm-4">
                  	   <label>{{ __('message.Email_Address') }}</label><span style="color:red;">*</span>
                  	  <input type="text" name="Email" value="{{$companydata->Email}}"class="form-control">
                  </div>
                
              </div>
              <br>
              <div class="row">
	 	  	  	
                  <div class="col-sm-4">
                  	  <label>{{ __('message.Street_Address') }}</label><span style="color:red;">*</span>
                  	  <input type="text" name="Address1" value="{{$companydata->Address1}}"class="form-control">
                  	  <span>{{ __('message.ABAY') }}</span>
                  </div>
                   <div class="col-sm-4">
                  	   <label>{{ __('message.Building/Office') }}</label><span style="color:red;">*</span>
                  	  <input type="text" name="Address2" value="{{$companydata->Address2}}" class="form-control">
                  	  <span>{{ __('message.office') }}</span>
                  </div>
                   <div class="col-sm-4">
                  	   <label>{{ __('message.Postal_Code') }}</label><span style="color:red;">*</span>
                  	  <input type="text" name="PostalCode"value="{{$companydata->PostalCode}}" class="form-control">
                  </div>
                
              </div>
              <br>
              <div class="row">
	 	  	  	
                  <div class="col-sm-4">
                  	  <label>{{ __('message.City') }}</label><span style="color:red;">*</span>
                  	   <select name="City" class="form-control" id="City">
                            @foreach($city as $cities)
                            @if($companydata->City == $cities->CityId)
                                <!--<option value="{{$companydata->CityId}}" selected>{{$companydata->CityName}}</option>-->
                                <option value="{{$cities->CityId}}" selected>{{$cities->CityName}}</option>
                            @else
                                <option value="{{$cities->CityId}}">{{$cities->CityName}}</option>
                            @endif
                       @endforeach

                       </select>
                  </div>
                   <div class="col-sm-4">
                  	   <label>{{ __('message.Area') }}</label>
                  	    <select class="form-control" name="Area" id="Area">
                          <option value="{{$companydata->AreaId}}">{{$companydata->AreaName}}</option>
                        </select>
                  </div>
                   <div class="col-sm-4">
                  	   <label>{{ __('message.Phone_No') }}</label><span style="color:red;">*</span>
                  	  <input type="text" name="Phone" value="{{$companydata->Phone}}" class="form-control phonemask">
                  </div>                
              </div>
              <br>
              <div class="row">
	 	  	  	
                  <div class="col-sm-4">
                  	  <label>{{ __('message.Mobile') }}</label>
                  	  <input type="text" name="Mobile" value="{{$companydata->Mobile}}" class="form-control phonemask">
                  </div>
                   <div class="col-sm-4">
                  	   <label>{{ __('message.Category') }}</label><span style="color:red;">*</span>
                  	   <select class="form-control" id="category" name="CategoryCode">

                          @foreach($category as $categories)
                              @if($companydata->CategoryCode == $categories->CategoryId)
                                <option value="{{$companydata->CategoryCode}}" selected>{{$companydata->CategoryName}}</option>
                              @else
                                <option value="{{$categories->CategoryId}}">{{$categories->CategoryName}}</option>
                              @endif
                          @endforeach
                       </select>
                  </div>
                   <div class="col-sm-4">
                         <label>{{ __('message.Subcategory') }}</label><span style="color:red;">*</span><br/>
                         
                  	  <!-- <select class="form-control" id="subcategory" name="SubCategoryCode[]" multiple>
                         @foreach($subcategories as $subcategory)
                              @if(in_array($subcategory->SubCategoryId,explode(',',$companydata->SubCategoryCode)))
                                <option value="{{$subcategory->SubCategoryId}}" selected>{{$subcategory->SubCategoryName}}</option>
                              @else
                                <option value="{{$subcategory->SubCategoryId}}">{{$subcategory->SubCategoryName}}</option>
                              @endif
                          @endforeach


                          <option value="{{$companydata->SubCategoryId}}">{{$companydata->SubCategoryName}}</option> 
                       </select>-->
                       <label id="select_all"><input type="checkbox" class="select_all_checkbox"  /> {{__('message.Select_all')}}</label>
                            <div id="subcategory" class="subcategory_checkbox">
                                @foreach($subcategories as $subcategory)
                                @if(in_array($subcategory->SubCategoryId,explode(',',$companydata->SubCategoryCode)))
                                        <!--<option value="{{$subcategory->SubCategoryId}}" selected>{{$subcategory->SubCategoryName}}</option>-->
                                        <input type="checkbox" name="SubCategoryCode[]" value="{{$subcategory->SubCategoryId}}" checked /> {{$subcategory->SubCategoryName}}<br/>
                                    @else
                                        <!--<option value="{{$subcategory->SubCategoryId}}">{{$subcategory->SubCategoryName}}</option>-->
                                        <input type="checkbox" name="SubCategoryCode[]" value="{{$subcategory->SubCategoryId}}" /> {{$subcategory->SubCategoryName}}<br/>
                                    @endif
                                @endforeach
                            </div>


                  </div>
                
              </div>
              <br>
               <div class="row">
	 	  	  	
                  <div class="col-sm-4">
                  	  <label>{{ __('message.Fax_No') }}</label>
                  	  <input type="text" name="FaxNo" value="{{$companydata->FaxNo}}"class="form-control">
                  </div>
                   <div class="col-sm-4">
                  	   <label>{{ __('message.Link') }}</label>
                  	  <input type="text" name="WebsiteLink" value="{{$companydata->WebsiteLink}}" class="form-control">
                  </div>
                   <div class="col-sm-4">
                   	  <div class="paymentbox">
                   	  	
                        <?php $paymenttype=(int)$companydata->ActualRegType;
                        $SubTypes[0]="Free";
                         $SubTypes[1]="Silver";
                          $SubTypes[2]="Gold";
                           $SubTypes[3]="Premium";
                       
                        ?>
                        
                       <label>{{ __('message.Payment_Category') }} : </label>
                      <label id="paymenttype" style=""><?php echo  $SubTypes[$paymenttype];?></label>
                   	  <input type="hidden" id="paymenttype_id" name="ActualRegType" value="<?php echo $paymenttype;?>" />	
                         <a class="btn btn-md" style="display:block" href="#" onclick="document.getElementById('id02').style.display='block'" style="text-align: right; margin-left: 70%;">{{ __('message.Change') }}</a>
                  	   
                   	  </div>
                      
                   </div>
                
              </div>
              <br>
               <div class="row">
	 	  	  	
                  <div class="col-sm-4">
                  	  <label>{{ __('message.Describe_Business') }}</label>
                  	  <textarea style="position:relative; top:-30px;" class="form-control" id="DescribeBusiness"name="DescribeBusiness">{{$companydata->DescribeBusiness}}</textarea>
                  </div>
                   <div class="col-sm-4">
                   	<div class="paymentbox">
                  	  <label>{{ __('message.Ranking') }} : </label><label>{{$companydata->Ranking}}</label>
                          <a class="btn btn-md" style="display:block;" href="#" onclick="document.getElementById('id01').style.display='block'" style="text-align: right; margin-left: 70%;">{{ __('message.Rank') }}</a>
                  	</div>
                  </div>
                  <div class="col-sm-4">
                  	  <label>{{__('message.what_r_u_looking_for')}}</label>
                  	  <textarea style="position:relative; top:-30px;" class="form-control" id="lookingFor"name="lookingFor">{{$companydata->LookingFor}}</textarea>
                  </div>
                  
                
              </div>
              
               <div class="row">
                   <div class="col-sm-4">
                  	   <label>{{ __('message.Expiration_Date') }}</label>
                  	  <input type="text" name="ExpiryDate" value="{{$companydata->ExpiryDate}}" class="form-control datetime_ru">
                      <b>{{ __('message.Modified_Admin') }} </b>@php echo DATE($companydata->AdminModifiedDate);@endphp
                  </div>
                  <div class="col-sm-4">
                      <label>{{ __('message.Expiration') }}</label><br>
                      <label style="display:none;" id="expirationdate" >@php echo DATE($companydata->ExpiryDate);@endphp</label>
					  <input type="text" class="form-control" readonly value="@php echo DATE($companydata->ExpiryDate);@endphp" />
                  </div>
                  <div class="col-sm-2">
						@php $isclaimenable=$companydata->ClaimFlag;@endphp
						
						@if ($isclaimenable>0)
							<p style="font-size: 12px; font-weight: bold;"><input type="checkbox" value="0" name="ClaimFlag"> {{ __('message.Include_Claim') }}</p>
						@else
							<p style="font-size: 12px; font-weight: bold;"><input type="checkbox" value="1" name="ClaimFlag" checked disabled> {{ __('message.Include_Claim') }}</p>
						@endif	
					</div>
					<div class="col-sm-2">
                      @php $isprofileenable=$companydata->IsProfileEnabled;@endphp
                  	 @if (($paymenttype>0)||($isprofileenable>0))
                  	  <p style="font-size: 12px; font-weight: bold;"><input type="checkbox" value="1" name="IsProfileEnabled" checked disabled> {{ __('message.Profile_Photo') }}</p>
                      @else 
                       <p style="font-size: 12px; font-weight: bold;"><input type="checkbox" value="1" name="IsProfileEnabled"> {{ __('message.Profile_Photo') }}</p>
                       @endif
                  </div>
                
              </div>
              <br>
               <div class="row">
	 	  	  	
                  <div class="col-sm-4">
                  	   <label> <input type="checkbox" id="myCheck" name ="myCheck">
                        <span class="headline hd2"> <b>{{ __('message.terms_conditions') }}</b></span>
                   </label>
                  </div>
                   <div class="col-sm-4">
                  	   
                  </div>
                   <div class="col-sm-4 text-right">
                  	  <input type="submit"  value="{{ __('message.Refresh') }}" class="btn btn-md">
                  	  <input type="reset"  value="{{ __('message.Cancel') }}" class="btn btn-md" >
                  </div>
                
              </div>
              <br>
            </form>
	 	  </div>
	 </div>

</div>
<div id="id01" class="modal overflow-modal">
        <!--rami-->
       <form method="post"class="modal-content download-body" action="{{url('/setranking_company')}}" role="form">
         <input type="hidden" name="_token" value="{{ csrf_token()}}">
           <div class="title-head-modal" style="background-color:#ffce00;height:50px;">
                        <span onclick="document.getElementById('id01').style.display='none'" class="download-close" title="Close Modal">&times;</span>
                        <h4 class="modal-title" style="padding:15px;text-align: center;">{{ __('message.Set_Rank') }}</h4>
           </div>
            
              <input type="hidden" name="companyregid" value="{{$companydata->CompanyRegId}}">
                  <br>
                  <form>
                     <div class="row" style="padding-left:30px;" >
                       <div class="col-sm-3" style="padding-top:6px;">
                         <label>{{ __('message.Rank_Value') }}</label>
                       </div>
                       
                        <div class="col-sm-8">
                          <select name="Ranking" class="form-control">
                            <option value="0">{{ __('message.Choose_Rating') }}</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>

                        </select>
                        </div>
                        
                     </div>
					<div class="row">
						<div class="col-md-12">
							<input type="submit" Value="{{ __('message.Refresh') }}" class="btn btn-md" style="margin-left:40%; margin-top:10px">
						</div>
					</div>
                
                  </form>
            

        </form>
    </div>
 <div id="id02" class="modal overflow-modal">
        <!--rami-->
		<form  method="post"class="modal-content download-body" action="{{url('/setpayment_company')}}" role="form">
			<input type="hidden" name="_token" value="{{ csrf_token()}}">
			<div class="title-head-modal" style="background-color:#ffce00;height:50px;">
				<span onclick="document.getElementById('id02').style.display='none'" class="download-close" title="Close Modal">&times;</span>
				<h4 class="modal-title" style="padding:15px;text-align: center;">{{ __('message.Change_payment') }}</h4>
			</div>

		<div class="row" style="padding:20px;">
			<div class="col-md-12">
				<h6>{{ __('message.Confirmation') }}</h6>
			</div>
		</div>
		 <input type="hidden" name="companyregid" value="{{$companydata->CompanyRegId}}">
		<div class="row" style="padding:20px;">
			<div class="col-sm-3">
				<input type="radio" value="3" name ="type" <?php echo ((int)$companydata->ActualRegType==3)?"CHECKED":"";?> >
				<label>{{ __('message.Premium') }}</label><br>
				<img src="{{asset('public/Images/premium-yellowpages.png')}}" >
			</div>
			<div class="col-sm-3">
				<input type="radio" value="2" name ="type" <?php echo ((int)$companydata->ActualRegType==2)?"CHECKED":"";?>>
				<label>{{ __('message.Gold') }}</label><br>
				<img src="{{asset('public/Images/gold-yellowpages.png')}}" >
			</div>
			<div class="col-sm-3">
				<input type="radio" value="1" name ="type" <?php echo ((int)$companydata->ActualRegType==1)?"CHECKED":"";?>>
				<label>{{ __('message.Silver') }}</label><br>
				<img src="{{asset('public/Images/silver-yellowpages.png')}}" >
			</div>
			<div class="col-sm-3">
				<input type="radio" value="0" name ="type" <?php echo ((int)$companydata->ActualRegType==0)?"CHECKED":"";?>>
				<label>{{ __('message.Free') }}</label><br>
				<img src="{{asset('public/Images/free-yellowpages.png')}}" >
			</div>
			
		</div>
		
		<div class="row">
			<div class="col-md-12">
			
				<p class="text-right">
					<input type="submit" id="updatepayment" Value="{{ __('message.Update') }}" class="btn btn-md" >
					<input type="button" id="cancelupdatepayment" Value="{{ __('message.Cancel') }}" class="btn btn-md" onclick="document.getElementById('id02').style.display='none'" >
				</p>
			</div>	
		</div>
		</form>
    </div>
    <script type="text/javascript">
 

    $(document).ready(function() {


         $(".select_all_checkbox").click(function () {
             
            $("#subcategory input[type='checkbox']").prop('checked', $(this).prop('checked'));
        });
    
        $("#subcategory input[type='checkbox']").change(function(){
            if (!$(this).prop("checked"))
            {
                $(".selectall_checkbox").prop("checked",false);
            }
        });
            $("#editCompanyForm").validate({

        rules: {
            CompanyName: {
                required: true,
               
            },
            ContactName: {
                required: true,
                lettersonly: true
            },
            Email: {
                required: true,
                email: true,
                email_exists: false

            },
            UserName: {
                required: true,
                minlength: 6,
              
            },
            PostalCode: {
                required: true,
                number: true
            },
            password: {
                required: true,
                 minlength: 5,
                maxlength: 20

            },
            Confirmpassword: {
                required: true,
                equalTo: "#Password"
            },
            Phone: {
                required: true,
                validecode: true, 
            },
            Mobile:{
                validecode: true, 
            },

            Address1: {
                required: true
            },

            Address2: {
                required: true
            },

            City: {
                required: true
            },
            
            category: {
                required: true

            },
            subcategory: {
                required: true

            },
             DescribeBusiness: {
                required: true,
                minlength: 30,
                maxlength: 1000
            },
            dateofincorporation: {
                required : true
            },
            myCheck:{
                required:true
            },

        },
        messages: {
            CompanyName: {
                required: "{{__('message.Please Enter your company name')}}",
              

            },
            ContactName: {
                required: "{{__('message.Please Enter your name')}}",
                lettersonly: "{{__('message.Please Enter only character') }}"

            },
            Email: {
                required: "{{__('message.Please Enter your email aadress')}}",
                email: "{{__('message.Please Enter valid email')}}",
                email_exists: "{{__('message.Email already exist')}}"

            },

            UserName: {
                required: "{{__('message.Please Enter Unique User name')}}",
                minlength: "{{__('message.Please Enter Atleast 6 Characters')}}"
                
            },
            PostalCode: {
                required: "{{__('message.Please Enter postalcode')}}",
                number: "{{__('message.Please Enter digits')}}"
            },
            password: {
                required: "{{__('message.Please enter password')}}",
                 minlength: "Minimum 5 ",
                maxlength: "Maximum 20"
            },

            Confirmpassword: {
                required: "{{__('message.Please enter password again')}}",
                equalTo: "{{__('message.Password should match with confirm password')}}"
            },
            Phone: {
                required: "{{__('message.please enter mobile number')}}",
                number: "{{__('message.please enter only numbers')}}",
                minlength: "{{__('message.minimum 10 numbers required')}}",
                maxlength: "{{__('message.maximum 10 numbers only')}}",
                    validecode: "{{__('message.country code should be valid')}}"
            },
            Mobile:{
                
                   number: "{{__('message.please enter only numbers')}}",
                   minlength: "{{__('message.minimum 10 numbers required')}}",
                    maxlength: "{{__('message.maximum 10 numbers only')}}",
                    validecode: "{{__('message.country code should be valid')}}"
            },

            Address1: {
                required: "{{__('message.Please enter address')}}"
            },

            Address2: {
                required: "{{__('message.Please enter address')}}"
            },

            City: {
                required: "{{__('message.Please select one city')}}"
            },
           
            category: {
                required: "{{__('message.Please select one category')}}"

            },
            subcategory: {
                required: "{{__('message.please select one subcategory after category')}}"

            },
            DescribeBusiness: {
                 required: "{{__('message.Write Something')}}",
                minlength: "{{__('message.Minimum 30 characters required')}}",
                maxlength: "{{__('message.Maximum 1000 characters')}}"
            },
            dateofincorporation: {
                required : "{{__('message.Pleaseselectdateofincorporation')}}"
            },
            myCheck:{
                required:"{{__('message.Tickthebox')}}",
            },

            
        }
    });
        });
       
</script>

@endsection