@extends('layouts.app')
@section('content')
@include('adminsearchform')

<div class="row">

<table id="myTable" class=" table table-bordered">
   <thead>
        <tr>
         <th>Name</th>
         <th>City</th>
         <th>The Contact Person</th>
         <th>EI address</th>
         <th>Phone No</th>
         <th>A Type</th>
         <th>Date Of Registration</th>
         <th>Payment Type</th>
         <th>Rank</th>
         <th></th>
       </tr>
    </thead>
    <tbody>
    @foreach($companydata as $companies)
          <tr>
              <td>{{$companies->CompanyName}}</td>
              <td>{{$companies->CityName}}</td>
              <td>{{$companies->Name}}</td>
              <td>{{$companies->Email}}</td>
              <td>{{$companies->Phone}}</td>
              <td>Company</td>
              <td></td>
                <?php $paymenttype=$companies->SubscriptionType;
                        ?>
                          @if (!empty($paymenttype))
                          
                          <?php $paymenttype="$companies->SubscriptionType";?>
                          
                          @else
                         <?php  $paymenttype="free"; ?>
                          @endif
              <td><?php echo $paymenttype; ?></td>
              <td></td>
              <td>
                <a href="{{url('editcompany')}}/{{$companies->CompanyRegId}}">Edit</a>
              </td>
          </tr>
      @endforeach
      @foreach($classifieddata as $classifieds)
            <tr>
                <td>{{$classifieds->ClassifiedTitle}}</td>
                <td></td>
                <td>{{$classifieds->CityName}}</td>

                <td>{{$classifieds->Name}}</td>
                <td>{{$classifieds->Email}}</td>
                <td>{{$classifieds->Phone}}</td>

                <td style="font-size: 10px;">{{$classifieds->Type}}</td>

                <td></td>
                <td>{{$classifieds->SubscriptionType}}</td>
                <td></td>
                <td>
                    <a href="{{url('editclassified')}}/{{$classifieds->ClassifiedRegId}}">Edit</a>
                </td>
            </tr>
        @endforeach
    </tbody>
  

</table>

</div>
{{--</div--}}
<script>
$(document).ready(function(){
    $('#myTable').dataTable();
});
</script>
 <script>
    function showhide(id) {
        var e = document.getElementById(id);
        e.style.display = (e.style.display == 'block') ? 'none' : 'block';
    }
    $(document).ready(function() {

        $('#category').on('click', function() {
        var categoryID = $(type).val();


            if (categoryID) {
                $.ajax({
                    dataType: 'text',

                    type: 'POST',
                    url: 'resources/views/queryforsubcategory.php',
                    //url:'app/Http/Controllers/DynamicController@index2',
                    data: 'category_id=' + categoryID,

                    success: function(html) {
                        console.log(html);

                        $('#subcategory').html(html);
                    },
                    error: function(e) {
                        $('#subcategory').html(e);
                    }
                });
            }
        });

    });
</script>

@endsection