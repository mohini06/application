<?php
include "db.php";

$startdate=$_REQUEST['data1'];
$enddate=$_REQUEST['data2'];

$sql="call Usp_GetRevenueReport('$startdate','$enddate')";

$result=$db->query($sql) ;

echo '<h4>'.'Revenue Report'.'</h4>';
 echo '<table id="income">'.'<tr>'.'<th>'.'Title'.'</th>'.'<th>'.'Type'.'</th>'.'<th>'.'Payment Type'.'</th>'.'<th>'.'Update Date'.'</th>'.'<th>'.'Cancel Date'.'</th>'.'</tr>' ;
 if ($result) {
  while($row=$result->fetch(PDO::FETCH_ASSOC))
    {
   		
 
       echo  '<tr>'.'<td>'.$row['Company_Classified_Name'].'</td>'.'<td>'.$row['Type'].'</td>'.'<td>'.$row['RegstrationType'].'</td>'.'<td>'.$row['DateOfReg'].'</td>'.'<td>'.$row['ExpiryDate'].'</td>'.'</tr>';
      
      }
     	
  } 
else {
  echo  '<tr >'.'<td>'.'No Record Found'.'</td>'.'</tr>';
  }
 
 echo '</table>';
// $array = mysqli_fetch_all($result, MYSQLI_ASSOC);

?>