@extends('layouts.app')
@section('content')
     <div class="row" >
	 <div class="panel">
	 	  <div class="panel-heading">
	 	  	   <h3>{{ __('message.EDIT_CLASSIFIED') }}</h3>
           <hr>
	 	  </div>
	 	  <div class="panel-body">
	 	  	<form method="post" action="{{url('updateclassifieddetail')}}\{{$classifieddata->ClassifiedRegId}}" id="editclassifiedForm" role="form">
           <input type="hidden" name="_token" value="{{ csrf_token()}}">
	 	  	  <div class="row">
	 	  	  	
                  <div class="col-sm-4">
                  	  <label>{{ __('message.Ad_Title') }}</label><span style="color:red;">*</span>
                  	  <input type="text" name="ClassifiedTitle" value="{{$classifieddata->ClassifiedTitle}}" class="form-control">
                  </div>
                   <div class="col-sm-4">
                  	   <label>{{ __('message.Select_Category') }}</label><span style="color:red;">*</span>
                  	   <select class="form-control" id="category"name="CategoryCode">
                  	   	 <!--<option value="{{$classifieddata->CategoryCode}}">{{$classifieddata->CategoryName}}</option>-->
                          @foreach($category as $categories)
                            @if($classifieddata->CategoryCode == $categories->CategoryId)
                                <option selected value="{{$categories->CategoryId}}">{{$categories->CategoryName}}</option>
                            @else
                                <option value="{{$categories->CategoryId}}">{{$categories->CategoryName}}</option>
                            @endif



                          @endforeach
                  	   </select>
                  </div>
                   <div class="col-sm-4">
                  	   <label>{{ __('message.Select_Subcategory') }}</label><span style="color:red;">*</span><br/>
                  	   <!-- <select class="form-control"  id="subcategory" name="SubCategoryCode[]" multiple>
                            @foreach($subcategories as $subcategory)
                              @if(in_array($subcategory->SubCategoryId,explode(',',$classifieddata->SubCategoryCode)))
                                <option value="{{$subcategory->SubCategoryId}}" selected>{{$subcategory->SubCategoryName}}</option>
                              @else
                                <option value="{{$subcategory->SubCategoryId}}">{{$subcategory->SubCategoryName}}</option>
                              @endif
                          @endforeach
                  	   </select>-->

                         <label id="select_all"><input type="checkbox" class="select_all_checkbox"  /> {{__('message.Select_all')}}</label>
                            <div id="subcategory" class="subcategory_checkbox">
                                @foreach($subcategories as $subcategory)
                                    @if(in_array($subcategory->SubCategoryId,explode(',',$classifieddata->SubCategoryCode)))
                                        <!--<option value="{{$subcategory->SubCategoryId}}" selected>{{$subcategory->SubCategoryName}}</option>-->
                                        <input type="checkbox" name="SubCategoryCode[]" value="{{$subcategory->SubCategoryId}}" checked /> {{$subcategory->SubCategoryName}}<br/>
                                    @else
                                        <!--<option value="{{$subcategory->SubCategoryId}}">{{$subcategory->SubCategoryName}}</option>-->
                                        <input type="checkbox" name="SubCategoryCode[]" value="{{$subcategory->SubCategoryId}}" /> {{$subcategory->SubCategoryName}}<br/>
                                    @endif
                                @endforeach
                            </div>
                  </div>
                
              </div>
              <br>
              <div class="row">
	 	  	  	
                  <div class="col-sm-4">
                  	  <label>{{ __('message.Email_Address') }}</label><span style="color:red;">*</span>
                  	  <input type="text" name="Email" value="{{$classifieddata->Email}}" class="form-control">
                  	 
                  </div>
                   <div class="col-sm-4">
                  	   <label>{{ __('message.Your_Name') }}</label><span style="color:red;">*</span>
                  	  <input type="text" name="Name"  value="{{$classifieddata->Name}}" class="form-control">
                  	 
                  </div>
                   <div class="col-sm-4">
                  	   <label>{{ __('message.City') }}</label><span style="color:red;">*</span>
                  	   <select class="form-control" name="City">
                        <!--<option value="{{$classifieddata->CityId}}">{{$classifieddata->CityName}}</option>-->
                  	   	@foreach($city as $citiies)
                  	   	    @if($citiies->CityId == $classifieddata->City)
                      	   	    <option selected value="{{$citiies->CityId}}">{{$citiies->CityName}}</option>
                  	   	    @else
                      	   	    <option value="{{$citiies->CityId}}">{{$citiies->CityName}}</option>
                  	   	    @endif

                  	    <option value="{{$citiies->CityId}}">{{$citiies->CityName}}</option>
                  	    @endforeach
                  	   </select>
                  	  
                  </div>
                
              </div>
              <br>
              <div class="row">
	 	  	  	
                  <div class="col-sm-4">
                  	  <label>{{ __('message.Mobile') }}</label>
                  	   <input type="text" name="Mobile" value="{{$classifieddata->Mobile}}" class="form-control">
                  </div>
                   <div class="col-sm-4">
                  	   <label>{{ __('message.Phone_No') }}</label><span style="color:red;">*</span>
                  	  <input type="text" name="Phone"value="{{$classifieddata->Phone}}" class="form-control">
                  </div>
                   <div class="col-sm-4">
                  	   <label>{{ __('message.Link') }}</label><span style="color:red;">*</span>
                  	  <input type="url" name="WebUrl" value="{{$classifieddata->WebUrl}}"  class="form-control">
                  </div>                
              </div>
                        
              <br>
               <div class="row">
	 	  	  	
                  <div class="col-sm-4">
                  	  <label>{{ __('message.Describe_Business') }}</label>
					  <textarea style="position:relative; top:-30px;" value="" name="ClassifiedContent" class="form-control">{{$classifieddata->ClassifiedContent}}</textarea>
                  </div>
                   <div class="col-sm-4">
                  <div class="paymentbox">
                        
                        <?php $paymenttype=(int)$classifieddata->ActualRegType;
                        $SubTypes[0]="Свободно";
                        $SubTypes[1]="премия";
                       
                        ?>
                        
                       <label>{{ __('message.Payment_Category') }} : </label>
					   
                      <label id="paymenttype" style=""><?php echo  $SubTypes[$paymenttype];?></label>
                      
                      <input type="hidden" id="paymenttype_id" name="ActualRegType" value="<?php echo $paymenttype;?>" /> 
                         <a class="btn btn-md"  style="display:block;" href="#" onclick="document.getElementById('id02').style.display='block'">{{ __('message.Change') }}</a>
                       
                      </div>
                  </div>
                     <div class="col-sm-4">
                    <div class="paymentbox">
                       <label>{{ __('message.Ranking') }} : </label><label>{{$classifieddata->Ranking}}</label>
                          <a class="btn btn-md" style="display:block;" href="#" onclick="document.getElementById('id01').style.display='block'" >{{ __('message.Rank') }}</a>

                    </div>
                  </div>
              </div>
              
               <div class="row">
                   <div class="col-sm-4">
                  	   <label>{{ __('message.Expiration_Date') }}</label>
                  	  <input type="text" name="ExpiryDate" value="{{$classifieddata->ExpiryDate}}" class="form-control datetime_ru">
                      <b>{{ __('message.Modified_Admin') }} </b>{{$classifieddata->AdminModifiedDate}}
                  </div>
                  <div class="col-sm-4">
                      <label>{{ __('message.Expiration') }}</label><br>
                      <label style="display:none" id="expirationdate">{{$classifieddata->ExpiryDate}}</label>
					  <input type="text" readonly value="{{$classifieddata->ExpiryDate}}" class="form-control" />
                  </div>
                   <div class="col-sm-2">
                      <p style="font-size: 12px; font-weight: bold; padding-top:30px;">
						<input type="checkbox" value="claim" /> {{ __('message.Include_Claim') }}
					  </p>
                   </div>
					<div class="col-sm-2">
                      <p style="font-size: 12px; font-weight: bold; padding-top:30px;">
                        @php $paymenttype=$classifieddata->ActualRegType;
                             $isprofileenable=$classifieddata->IsProfileEnabled;
                        @endphp
                        @if(($paymenttype>0)||($isprofileenable>0))
                        <input type="checkbox" name="IsProfileEnable" value="1" checked disabled>
                        @else
                         <input type="checkbox" name="IsProfileEnable" value="1">
                         @endif
					{{ __('message.Profile_Photo') }}</p>
                  </div>
                
              </div>
              <br>
               <div class="row">
	 	  	  	
                  <div class="col-sm-4">
                  	   <label> <input type="checkbox" id="myCheck" name="myCheck">
                    <b>{{ __('message.terms_conditions') }}</b></label>
                  </div>
                   <div class="col-sm-4">
                  	   
                  </div>
                   <div class="col-sm-4 text-right">
                  	  <input type="submit"  value="{{ __('message.Refresh') }}" class="btn btn-md">
                  	  <input type="reset" value="{{ __('message.Cancel') }}" class="btn btn-md">
                  </div>
                
              </div>
              <br>
            </form>
	 	  </div>
	 </div>

</div>
<div id="id01" class="modal overflow-modal">
		<!--rami-->
       <form method="post"class="modal-content download-body" action="{{url('/setranking_ad')}}" role="form">
         <input type="hidden" name="_token" value="{{ csrf_token()}}">
           <div class="modal-dialogtitle-head-modal" style="background-color:#ffce00;height:50px;">
                        <span onclick="document.getElementById('id01').style.display='none'" class="download-close" title="Close Modal">&times;</span>
                        <h4 class="modal-title" style="padding:15px;text-align: center;">{{ __('message.Set_Rank') }}</h4>
           </div>
            
              <input type="hidden" name="classifiedregid" value="{{$classifieddata->ClassifiedRegId}}">
                  <br>
                  <form>
				  
                     <div class="row" style="padding-left:30px;" >
                       <div class="col-sm-3" style="padding-top:6px;">
                         <label class="text-center">{{ __('message.Rank_Value') }}</label>
                       </div>
					
						<div class="col-sm-8 text-center" >
							<select name="Ranking" class="form-control">
								<option value="0">{{ __('message.Choose_Rating') }}</option>
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
							</select>
                        </div>
                     </div>
					 <div class="row">
						<div class="col-md-12">
							<input type="submit" Value="{{ __('message.Refresh') }}" class="btn btn-md" style="margin-left:40%; margin-top:10px;" />
						</div>
					 </div>
					 
						
						
					
                                      </form>
           

        </form>
    </div>
	
	




    <div id="id02" class="modal overflow-modal">
        <!--rami-->


          <form method="post"class="modal-content download-body" action="{{url('/setpayment_ad')}}" role="form">
                  <input type="hidden" name="_token" value="{{ csrf_token()}}">
           <div class="title-head-modal" style="background-color:#ffce00;height:50px;">
                        <span onclick="document.getElementById('id02').style.display='none'" class="download-close" title="Close Modal">&times;</span>
                        <h4 class="modal-title" style="padding:15px;text-align: center;">{{ __('message.Change_payment') }}</h4>
           </div>
            <input type="hidden" name="classifiedregid" value="{{$classifieddata->ClassifiedRegId}}">
            <div class="row" style="padding:20px;">
                  <div class="col-md-12">
                      <h6>{{ __('message.Confirmation') }}</h6>
                  </div>
                 </div>
                    <div class="row" style="padding:20px;">
                        <div class="col-sm-3">
                          <input type="radio" value="1" name ="ActualRegType" <?php echo ((int)$classifieddata->ActualRegType==3)?"CHECKED":"";?> >
                          <label>{{ __('message.Premium') }}</label><br>
                          <img src="{{asset('public/Images/premium-yellowpages.png')}}" >
                        </div>
                        
                        <div class="col-sm-3">
                          <input type="radio" value="0" name ="ActualRegType" <?php echo ((int)$classifieddata->ActualRegType==0)?"CHECKED":"";?>>
                          <label>{{ __('message.Free') }}</label><br>
                           <img src="{{asset('public/Images/free-yellowpages.png')}}" >
                        </div>
                    </div>
					<div class="row">
						<div class="col-md-12">
							<p class="text-right">
								<input type="submit" id="updatepaymentadd" Value="{{ __('message.Update') }}" class="btn btn-md" >
								<input type="button" id="cancelupdatepayment" Value="{{ __('message.Cancel') }}" class="btn btn-md" onclick="document.getElementById('id02').style.display='none'">
							</p>		
						</div>
					</div>
                    
                
            

        </form>
    </div>
      <script type="text/javascript">

         $(".select_all_checkbox").click(function () {
            
            $("#subcategory input[type='checkbox']").prop('checked', $(this).prop('checked'));
        });
    
        $("#subcategory input[type='checkbox']").change(function(){
            if (!$(this).prop("checked"))
            {
                $(".selectall_checkbox").prop("checked",false);
            }
        });


       $("#editclassifiedForm").validate( {

    rules: {
        ClassifiedTitle: {
                  required: true,
                  
        } ,
         email: {
                  required:true,
                  email:true
            }    , 
        name: {
                required: true,
                lettersonly: true
                }
                , mobile: {
                   
          number: true, 
          minlength: 10,
          maxlength: 10,
          validecode: true,
          
                },
        phone:{
			 required: true, 
          number: true, 
          minlength: 10,
          maxlength: 10,
          validecode: true, 
        },
         category: {
                    required: true
                }
                , 
        subcategory: {
                    required: true
                }, 

                city: {
                 
                    required: true
                },
        dateofincorporation: {
        required : true
          },
        ClassifiedContent:{
          required: true,
                minlength: 30,
                maxlength: 500
        },

            myCheck:{
                required:true
            },
            },

             messages: {
                ClassifiedTitle: {
                    required: "{{__('message.Please Enter the classified title')}} ",
					
                }
                , category: {
					required: "{{__('message.Please select one category')}}"
                }
                
                , email: {
                    required: "{{__('message.Please Enter your email aadress')}}",
					email: "{{__('message.Please Enter valid email')}}",
                }
                , name: {
                    required: "{{__('message.Please Enter your name')}}",
					lettersonly: "{{__('message.Please Enter only character') }}"
                }
                , mobile: {
                   
					number: "{{__('message.please enter only numbers')}}",
					minlength: "{{__('message.minimum 10 numbers required')}}",
					maxlength: "{{__('message.maximum 10 numbers only')}}",
					validecode: "{{__('message.country code should be valid')}}"
                },
		  phone:{
			        required: "{{__('message.please enter mobile number')}}",
					number: "{{__('message.please enter only numbers')}}",
					minlength: "{{__('message.minimum 10 numbers required')}}",
					maxlength: "{{__('message.maximum 10 numbers only')}}",
					validecode: "{{__('message.country code should be valid')}}"
				}

                , category: {
                    required: "{{__('message.Please select one category')}}"
                }
                , subcategory: {
                    required: "{{__('message.please select one subcategory after category')}}"
                }
                , city: {
                    required: "{{__('message.Please select one city')}}"
                },
        dateofincorporation: {
        required : "{{__('message.Pleaseselectdateofincorporation')}}"
          },
        ClassifiedContent:{
          required: "{{__('message.Write Something')}}",
                minlength: "{{__('message.Minimum 30 characters required')}}",
                maxlength: "{{__('message.Maximum 500 characters')}}"
        },
            myCheck:{
                required:"{{__('message.Tickthebox')}}"
            },

        }
   });
    </script>
@endsection