
    <table id="search_report">
        <thead>
            <tr>
                <th>{{__('message.Name')}}</th>
                <th>{{__('message.Ip_Address')}}</th>
                <th>{{__('message.created_on')}}</th>
            </tr>
        </thead>
        <tbody>
            @if($report)
                @foreach($report as $data)
                   <tr>
                        <td>{{$data->Name}}</td>
                        <td>{{$data->IpAddress}}</td>
                        <td>{{$data->created_on}}</td>
                   </tr>
                @endforeach
            @else
                <tr><td>No Record Found</td></tr>
            @endif
        </tbody>
    </table>