
    <h4>{{__('message.LEADING_VISIT_report')}}</h4>
    <table id="leadtable">
        <thead>
            <tr>
                <th>{{__('message.Name')}}</th>
                <th>{{__('message.Visitors_Count')}}</th>
            </tr>
        </thead>
        <tbody>
            @if($report)
                @foreach($report as $data)
                   <tr><td>{{$data->Name}}</td><td>{{$data->Count}}</td></tr>
                @endforeach
            @else
                <tr><td>No Record Found</td></tr>
            @endif
        </tbody>
    </table>
