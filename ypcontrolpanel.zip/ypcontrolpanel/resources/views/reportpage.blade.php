@extends('layouts.app')
@section('content')

<div class="tab">
  <button class="tablinks" onclick="openCity(event, 'London')" id="defaultOpen">{{ __('message.Visitor_Report') }}</button>
  <button class="tablinks" onclick="openCity(event, 'Paris')">{{ __('message.Report_Category') }}</button>
<button class="tablinks" onclick="openCity(event, 'Tokyo')">{{ __('message.Report_Category/Subcategory') }}</button>
 <!--   <button class="tablinks" onclick="openCity(event, 'Tokyo2')">Visitors Payment Status Report </button> -->
  <button class="tablinks" onclick="openCity(event, 'Tokyo3')">{{ __('message.Income_Statement') }}</button>
  <button class="tablinks search_down" onclick="openCity(event, 'search_down')">{{ __('message.Search_Downloads') }}</button>
</div>

<div id="search_down" class="tabcontent">
    <h3>{{ __('message.Search_Result_Downloads') }}</h3>
    <div class="row">
        <div class="col-md-6">
            <div class="entire_report pt-3" id="entire_report">
                
            </div>
        </div>
    </div>
</div>


<div id="London" class="tabcontent">
  <!--<span onclick="this.parentElement.style.display='none'" class="topright">&times</span>-->
  <h3>{{ __('message.Visitor_Report') }}</h3>

  <div class="row" style="margin:20px;">
    <div class="col-sm-4">
          <?php $curYear = date('Y');
         $total_counter=0;
          ?>
    <select class="form-control" id="year"name="year" >
	   <option value="">{{ __('message.Select_One') }}</option>
      @for($i=$curYear;$i>=2017;$i--)
        
        <option value="{{$i}}">{{$i}}</option>
      
      @endfor
    </select>
     
     <input style="margin-left:-3px;" type="submit" name="Look" value="{{ __('message.Look') }}" class="btn btn-md report1" onclick="javascript:showhide('monthlyreport');showhide('weeklyreport')">
     <input type="button" id="btnExport" onclick="fnExcelReport();" value="{{ __('message.Export') }}" class="btn btn-md" style="display:inline">
    </div>
     </div>

    <div class="row" style="margin:30px;">
     <div class="col-sm-6">
        
         <div id="monthlyreport">

        </div>

     </div>
     <div class="col-sm-6">
       <div id="weeklyreport" style="display: inline;">

        </div>
     </div>
    </div>
 <iframe id="txtArea1" style="display:none"></iframe>
</div>

<div id="Paris" class="tabcontent">
  <!--<span onclick="this.parentElement.style.display='none'" class="topright">&times</span>-->
  <h3>{{ __('message.Report_Category') }}</h3>

  <div class="row" style="margin:20px; ">
    <div class="col-sm-4">
          <?php $curYear = date('Y');
         $total_counter=0;
          ?>
    <select class="form-control" id="year2"name="year2" >
	<option value="">{{ __('message.Select_One') }}</option>
      @for($i=2017;$i<=$curYear;$i++)
      
        <option value="{{$i}}">{{$i}}</option>
      
      @endfor
    </select>
     
     <input style="margin-left:-3px;" type="submit" name="category2" value="{{ __('message.Look') }}" class="btn btn-md" onclick="javascript:showhide('categorywisereport')">
     <input type="button" id="btnExport1" onclick="fnCatWiseExcelReport();" value="{{ __('message.Export') }}" class="btn btn-md" style="display:inline">
    </div>
     </div> 
    <div class="row" style="margin:30px;">
     <div class="col-sm-6">
        
      <div id="categorywisereport" style="display: none;">
         

      </div>

     
     </div>
    
    </div>
 <iframe id="txtArea2" style="display:none"></iframe>
 
</div>



<div id="Tokyo" class="tabcontent">
 <!-- <span onclick="this.parentElement.style.display='none'" class="topright">&times</span>-->
  <h3>{{ __('message.Report_Category/Subcategory') }}</h3>
  <div class="row" style="margin-left:22px; margin-bottom:10px; margin-top:20px;">
     <div class="col-sm-4">
       <label>{{ __('message.Select_Type') }}</label>
       <select class="form-control" id="type"name="type" >
        <option value="">{{ __('message.Select_Type') }}</option>
        <option value="company">{{ __('message.Company') }}</option>
        <option value="Add">{{ __('message.Announcements') }}</option>
       </select>
     </div>
	 
     <div class="col-sm-4">
       <label>{{ __('message.Select_Category') }}</label>
       <select id="category_id" class="form-control">
          <option selected value="-1">{{ __('message.Everything') }}</option>
         @foreach($category as $categories)
           <option value="{{$categories->CategoryId}}">{{$categories->CategoryName}}</option>
         @endforeach
       </select>
     </div>
	 
     <div class="col-sm-4">
       <label>{{ __('message.Select_Subcategory') }}</label>
       <!--<div id="subcategory" name="subcategory" class="subcategory_checkbox" style="background-color:white; padding-left:5px;">
        
       </div>-->
       <select id="subcategory" class="form-control" name="subcategory">
            <option selected value="-1">{{ __('message.Everything') }}</option>
       </select>
     </div>
  </div>
  
  <div class="row" style="margin-left:19px;">
   <div class="col-sm-4">
     <label>{{ __('message.Period_From') }}</label>
    <!-- <input type="date" data-date="" data-date-format="YYYY MM DD" id="datefrom" name="datefrom" placeholder="From" class="form-control" />-->
	 <input type="text" id="datefrom" name="datefrom" placeholder="{{ __('message.From') }}" class="form-control date_ru2" />
   </div>
   <div class="col-sm-4">
     <label>{{ __('message.Period_To') }}</label>
    <!--<input type="date" data-date="" data-date-format="YYYY MM DD" id="dateto" name="dateto" placeholder="To" class="form-control" />-->
	<input type="text"  id="dateto" name="dateto" placeholder="{{ __('message.To') }}" class="form-control date_ru2" />
   </div>
  </div>
  <div class="row" style="margin-left:30px;">
    <div class="col-sm-4">
       <input style="margin-left:-3px;" type="button" name="lead" id="lead" value="{{ __('message.Look') }}" class="btn btn-md">
     <input type="button" id="btnExport2" onclick="fnleadExcelReport();" value="{{ __('message.Export') }}" class="btn btn-md" style="display:inline">
    </div>
  </div>
  <div class="row" style="margin:30px;">
    <div id="leadreport" style="display: none;">
      
    </div>
    
  </div>
   <iframe id="txtArea3" style="display:none"></iframe>
</div>

<!-- <div id="Tokyo2" class="tabcontent">
  <span onclick="this.parentElement.style.display='none'" class="topright">&times</span>
  <h3>Company/Classified Payment Status</h3>
 
   <iframe id="txtArea4" style="display:none"></iframe>
</div> -->


<div id="Tokyo3" class="tabcontent">
  <!--<span onclick="this.parentElement.style.display='none'" class="topright">&times</span>-->
  <h3>{{ __('message.Income_Statement') }}</h3>
  <div class="row" style="margin-left: 20px; margin-bottom:10px; margin-top:20px;">
   <div class="col-sm-4">
     <label>{{ __('message.Period_From') }}</label>
     <!--<input type="date"  data-date="" data-date-format="YYYY MM DD" id="startdate" name="startdate" class="form-control">-->
	 <input type="text"  id="startdate" name="startdate" placeholder="{{ __('message.From') }}" class="form-control date_ru2" />
   </div>
   <div class="col-sm-4">
     <label>{{ __('message.Period_To') }}</label>
   <!-- <input type="date"  data-date="" data-date-format="YYYY MM DD" id="enddate" name="enddate" class="form-control">-->
	<input type="text"  id="enddate" name="enddate" placeholder="{{ __('message.To') }}" class="form-control date_ru2" />
   </div>
  </div>
  <div class="row" style="margin-left:30px;">

   <input type="button" name="revenue" id="revenue" value="{{ __('message.Look') }}" class="btn btn-md" onclick="javascript:showhide('revenuereport')">
     <input type="button" id="btnExport3" onclick="fnrevenueExcelReport();" value="{{ __('message.Export') }}" class="btn btn-md" style="display:inline">
  </div>
  <div class="row" style="margin: 30px;">
     <div id="revenuereport" style="display: none;">

     </div>
  </div>
   <iframe id="txtArea5" style="display:none"></iframe>
</div>
<script>
    function showhide(id) {
        var e = document.getElementById(id);
        e.style.display = (e.style.display == 'block') ? 'none' : 'block';
    }
</script>
<script>
function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();

 $(document).ready(function() {
    
        $('#search_report').DataTable();
        $('.report1').on('click', function() {
        $('#monthlyreport').html("<img src=\"{{url('/public/ajax-loader.gif')}}\"><span> Loading.....</span>");
        $('#categorywisereport').html("<img src=\"{{url('/public/ajax-loader.gif')}}\"><span> Loading.....</span>");
        $('#leadreport').html("<img src=\"{{url('/public/ajax-loader.gif')}}\"><span> Loading.....</span>");
        $('#revenuereport').html("<img src=\"{{url('/public/ajax-loader.gif')}}\"><span> Loading.....</span>");
        $('#entire_report').html("<img src=\"{{url('/public/ajax-loader.gif')}}\"><span> Loading.....</span>");

        var yearID = $('#year').val();

            if (yearID) {
                $.ajax({
                    dataType: 'json',
                    type: 'post',
                    url: '{{url('/report/monthlyreport')}}',
                    //url:'app/Http/Controllers/DynamicController@index2',
                    data: 'year_id=' + yearID,

                    success: function(res)
                    {
                        $('#monthlyreport').html(res['html']);
                    },
                    error: function(e) {
                        $('#monthlyreport').html(e);
                    }
                });
                $.ajax({
                    dataType: 'json',
                    type: 'post',
                    url: '{{url('/report/weeklyreport')}}',
                    //url:'app/Http/Controllers/DynamicController@index2',
                    data: 'year_id=' + yearID,

                    success: function(res)
                    {
                        $('#weeklyreport').html(res['html']);
                    },
                    error: function(e) {
                        $('#weeklyreport').html(e);
                    }
                });
               
            }
        });



        $('#year2').on('change', function() {
        
        var yearID = $(this).val();


            if (yearID) {

           $.ajax({
                    dataType: 'json',

                    type: 'POST',
                    url: '{{url('/report/categoryreport')}}',
                    //url:'app/Http/Controllers/DynamicController@index2',
                    data: 'year_id=' + yearID,

                    success: function(res) {
                        $('#categorywisereport').html(res['html']);
                    },
                    error: function(e) {
                        $('#categorywisereport').html(e);
                    }
                });
               
            }
        });

   

        $('#lead').on('click', function() {
            $('#leadreport').show();
            $('#leadreport').html("<img src=\"{{url('/public/ajax-loader.gif')}}\"><span> Loading.....</span>");
        var type=$('#type').val();
        var categoryID = $('#category_id').val();
        var subcategoryId = $('#subcategory').val();
        /*var subcategoryIds = new Array();
        $('#subcategory input:checked').each(function() {
            subcategoryIds.push(this.value);
        });*/
//
        var from=$('#datefrom').val();
        var to=$('#dateto').val();
               $.ajax({
                    dataType: 'json',
                  
                    type: 'POST',
                    url: '{{url('/report/leadreport')}}',
                    data: {'data1':type, 'data2': categoryID, 'data3':subcategoryId,'data4':from,'data5':to},

                    success: function(res) {

                        $('#leadreport').html(res['html']);
                    },
                    error: function(e) {
                        $('#leadreport').html(e);
                    }
                });
               
               
            
        });

  

        $('#revenue').on('click', function() {
        var fromdate= $('#startdate').val();
        var todate= $('#enddate').val();
        
               $.ajax({
                    dataType: 'json',
                  
                    type: 'POST',
                    url: '{{url('/report/revenuereport')}}',
                    //url:'app/Http/Controllers/DynamicController@index2',
                    data: {'data1':fromdate,'data2':todate},

                     success: function(res) {
                        $('#revenuereport').html(res['html']);
                      
                    },
                    error: function(e) {
                        $('#revenuereport').html(e);
                    }
                });

        });

   
        $('#category_id').on('change', function() {
        var categoryID = $(this).val();
            if (categoryID) {
                $.ajax({
                    dataType: 'text',

                    type: 'POST',
                    url: 'resources/views/queryforsubcategory_list.php',
                    //url:'app/Http/Controllers/DynamicController@index2',
                    data: 'category_id=' + categoryID,

                    success: function(html) {
                        console.log(html);

                        $('#subcategory').html(html);
                    },
                    error: function(e) {
                        $('#subcategory').html(e);
                    }
                });
            }
        });
        $(".search_down").click( function () 
        {
            $('#entire_report').html("<img src=\"{{url('/public/ajax-loader.gif')}}\"><span> Loading.....</span>");
            $.ajax({
                type: 'POST',
                url: '/report/searchdownloadreport',
                success: function(html) {
                    $('.entire_report').html(html['html']);
                },
                error: function(e) {
                    $('.entire_report').html(e);
                }
            });
        });

       
    });

 function fnExcelReport()
{
    var tab_text="monthlyreport"+"<table border='2px'><tr bgcolor='#87AFC6'>";
    var textRange; var j=0;
    tab = document.getElementById('monthly'); // id of table

    for(j = 0 ; j < tab.rows.length ; j++) 
    {     
        tab_text=tab_text+tab.rows[j].innerHTML+"</tr>";
        //tab_text=tab_text+"</tr>";
    }
    tab_text=tab_text+"</table>"+"weeklyreport"+"<table border='2px'><tr bgcolor='#87AFC6'>";
    var textRange; var j=0;
    tab = document.getElementById('weekly'); // id of table

    for(k = 0 ; k < tab.rows.length ; k++) 
    {     
        tab_text=tab_text+tab.rows[k].innerHTML+"</tr>";
        //tab_text=tab_text+"</tr>";
    }
    tab_text=tab_text+"</table>";
    tab_text= tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
    tab_text= tab_text.replace(/<img[^>]*>/gi,""); // remove if u want images in your table
    tab_text= tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE "); 

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
    {
        txtArea1.document.open("txt/html","replace");
        txtArea1.document.write(tab_text);
        txtArea1.document.close();
        txtArea1.focus(); 
        sa=txtArea1.document.execCommand("SaveAs",true,"Say Thanks to Sumit.xls");
    }  
    else                 //other browser not tested on IE 11
        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));  

    return (sa);
}
function fnCatWiseExcelReport()
{
    var tab_text="CategoryWisereport"+"<table border='2px'><tr bgcolor='#87AFC6'>";
    var textRange; var j=0;
    tab = document.getElementById('categorywise'); // id of table

    for(j = 0 ; j < tab.rows.length ; j++) 
    {     
        tab_text=tab_text+tab.rows[j].innerHTML+"</tr>";
        //tab_text=tab_text+"</tr>";
    }
   
    tab_text=tab_text+"</table>";
    tab_text= tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
    tab_text= tab_text.replace(/<img[^>]*>/gi,""); // remove if u want images in your table
    tab_text= tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE "); 

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
    {
        txtArea2.document.open("txt/html","replace");
        txtArea2.document.write(tab_text);
        txtArea2.document.close();
        txtArea2.focus(); 
        sa=txtArea2.document.execCommand("SaveAs",true,"Say Thanks to Sumit.xls");
    }  
    else                 //other browser not tested on IE 11
        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));  

    return (sa);
}

function fnleadExcelReport()
{
    var tab_text="leadreport"+"<table border='2px'><tr bgcolor='#87AFC6'>";
    var textRange; var j=0;
    tab = document.getElementById('leadtable'); // id of table

    for(j = 0 ; j < tab.rows.length ; j++) 
    {     
        tab_text=tab_text+tab.rows[j].innerHTML+"</tr>";
        //tab_text=tab_text+"</tr>";
    }
   
    tab_text=tab_text+"</table>";
    tab_text= tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
    tab_text= tab_text.replace(/<img[^>]*>/gi,""); // remove if u want images in your table
    tab_text= tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE "); 

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
    {
        txtArea3.document.open("txt/html","replace");
        txtArea3.document.write(tab_text);
        txtArea3.document.close();
        txtArea3.focus(); 
        sa=txtArea3.document.execCommand("SaveAs",true,"Say Thanks to Sumit.xls");
    }  
    else                 //other browser not tested on IE 11
        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));  

    return (sa);
}

function fnrevenueExcelReport()
{
    var tab_text="revenuereport"+"<table border='2px'><tr bgcolor='#87AFC6'>";
    var textRange; var j=0;
    tab = document.getElementById('income'); // id of table

    for(j = 0 ; j < tab.rows.length ; j++) 
    {     
        tab_text=tab_text+tab.rows[j].innerHTML+"</tr>";
        //tab_text=tab_text+"</tr>";
    }
   
    tab_text=tab_text+"</table>";
    tab_text= tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
    tab_text= tab_text.replace(/<img[^>]*>/gi,""); // remove if u want images in your table
    tab_text= tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE "); 

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
    {
        txtArea5.document.open("txt/html","replace");
        txtArea5.document.write(tab_text);
        txtArea5.document.close();
        txtArea5.focus(); 
        sa=txtArea5.document.execCommand("SaveAs",true,"Say Thanks to Sumit.xls");
    }  
    else                 //other browser not tested on IE 11
        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));  

    return (sa);
}


</script>

@endsection