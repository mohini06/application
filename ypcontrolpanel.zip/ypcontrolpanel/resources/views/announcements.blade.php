@extends('layouts.app')
@section('content')
  <div class="row" >
   <h3>{{ __('message.Announcements') }}</h3>
</div>
<div class="row" >
	<div class="col-sm-6">
<form  method="POST" action="{{url('saveannouncements')}}" id="add_announcement_form" role="form">
<input type="hidden" name="_token" value="{{ csrf_token()}}">
	<br>
	<div class="row">
	 <div class="col-sm-10">
		<p class="headline" style="margin-left: 4px; position: absolute;">{{ __('message.Description') }}<span style="color:red;">*</span></p>
       <textarea placeholder="{{ __('message.comment_box') }}" name="Description" id="announcement" cols="40" class="bg-danger ui-autocomplete-input form-control" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true"></textarea>
      </div>
	</div>
	<br>
	<div class="row mb-1">
		<div class="col-sm-10">
		  <p class="headline" style="margin-left: 4px;">{{ __('message.Link_site') }}<span style="color:red;"></span></p>
          <input type="url" name="NavigateUrl" id="NavigateUrl" class="form-control" />
      </div>
	</div>

	 <div class="row">
		<div class="col-sm-10">
			<input style="margin-left:-1px; margin-top: 12px;" type="submit" name="" class="btn btn-md" id="save" value="{{ __('message.Send') }}">
		</div>	
	</div>
 </form>
 </div>
</div>
<div class="row" style="margin-top: 20px;">
<div class="col-sm-12">
	<table class="table">
			<thead>
			<tr style="background-color: #ffc107;">
                <th style="width:50%">{{ __('message.Description') }}</th>
                <th>{{ __('message.Link') }}</th>
                <th>{{ __('message.Date_of_creation') }}</th>
                <th></th>
		     </tr>
			</thead>
			<tbody>
			@if(count($announcements)>0)
                @foreach($announcements as $announcement)
                <tr>
                    <td>{{$announcement->Description}}</td>
                    <td>{{$announcement->NavigateUrl}}</td>
                    <td>{{$announcement->CreatedDate}}</td>
                    <!--<td><a href="{{url('/deleteannouncement')}}/{{$announcement->AnnouncementId}}">{{ __('message.Delete') }}</a></td>-->
                    <td data-delete="{{url('deleteannouncement').'/'.$announcement->AnnouncementId}}" ><a href="#" class="announce_trash" data-toggle="modal" data-target="#myModal">{{ __('message.Delete') }}</a></td>

                </tr>
                @endforeach
             @else
             <tr><td colspan="4" class="text-center">{{__('message.Record_Found')}}</td></tr>
            @endif
		</tbody>
	</table>
	</div>
</div>

<!-- Modal -->
<div id="myModal" style="" class="modal fade announce" role="dialog">
  <div class="modal-dialog modal-lg" >
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">{{__('message.Confirm')}}</h4>
      </div>
      <div class="modal-body">
        <p>{{__('message.Confirm_delete')}}?</p>
      </div>
      <div class="modal-footer">
        <a href="" data-dismiss="modal" class="btn">{{__('message.Cancel')}}</a>
        <a href="" class="btn sure">{{__('message.Sure')}}</a>
      </div>
    </div>

  </div>
</div>

@endsection