@extends('layouts.app')
@section('content')

<div class="panel" style="padding:20px;">
 <div class="">
   <h3>{{ __('message.Classified_detail') }}</h3>
   <hr color="red"/>
  </div>
 	<div class="row">
 	   <div class="col-sm-5">
 	      <label class="detail-font">{{ __('message.Classified_Title') }}</label>
       </div>
 	   <div class="col-sm-7">
 		<p class="data-font">{{$user->ClassifiedTitle}}</p>
 	   </div>
    </div>
    <div class="row">
 	   <div class="col-sm-5">
 	      <label class="detail-font">{{ __('message.Description') }}</label>
       </div>
 	   <div class="col-sm-7">
 		<p class="data-font">{{$user->ClassifiedContent}}</p>
 	   </div>
    </div>
     <div class="row">
 	   <div class="col-sm-5">
 	      <label class="detail-font">{{ __('message.Category/Subcategory') }}</label>
       </div>
 	   <div class="col-sm-7">
 		<p class="data-font">{{$user->CategoryName}} &nbsp; &nbsp;/&nbsp; &nbsp;{{$user->SubCategoryName}}</p>
 	   </div>
    </div>
    <div class="row">
 	   <div class="col-sm-5">
 	      <label class="detail-font">{{ __('message.Address') }}</label>
       </div>
 	   <div class="col-sm-7">
 	    <p class="data-font">{{$user->Name}}</p>
 		<p class="data-font">{{$user->CityName}}</p>
 		<p class="data-font">{{$user->Phone}}</p>
 		<p class="data-font">{{$user->Email}}</p>
 		
 	   </div>
    </div>
    <div class="row">
 	   <div class="col-sm-5">
 	      <label class="detail-font">{{ __('message.Date_Of_Incorporation') }}</label>
       </div>
 	   <div class="col-sm-7">
 	    <p class="data-font">{{$user->dateofincorporation}}</p>
 		
 		
 	   </div>
    </div>

    <div class="row">
     <div class="col-sm-5">
        <label class="detail-font">{{ __('message.email_verify') }}</label>
       </div>
     <div class="col-sm-7">
      
       @php
        $content = ($user->verified!=1)?'<p class="data-font" style="color: #ff0000">Verification Pending</p>':'<p class="data-font" style="color: #00FF00">Verified</p>';
        echo $content;
       @endphp
    
    
     </div>
    </div>

     <div class="row">
     	  <div class="col-sm-12">
     	  	 <!-- <td><a class="btn btn-md" href="{{url('/approvead')}}/{{$user->ClassifiedRegId}}" style="color:black; font-weight:normal;">{{ __('message.Approve') }}</a></td>
     	  	  <button class="btn btn-md"><a href="{{url('/deleteadd')}}/{{$user->ClassifiedRegId}}" style="color:black; font-weight:normal;">{{ __('message.Delete') }}</a></button>-->
     	      <button class="btn btn-md"><a data-toggle="modal" data-target="#approveAds" href="#" id="approve_ads" approve_url="{{url('/approvead')}}/{{$user->ClassifiedRegId}}" style="color:black; font-weight:normal;">{{ __('message.Approve') }}</a></button>
              <button class="btn btn-md"><a data-toggle="modal" data-target="#deleteAds" href="#" id="delete_ads" delete_url="{{url('/deleteadd')}}/{{$user->ClassifiedRegId}}" style="color:black; font-weight:normal;">{{ __('message.Delete') }}</a></button>
     	  </div>
     </div>
 </div>

 <!-- Modal -->
  <div id="approveAds" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">{{__('message.Confirm')}}</h4>
        </div>
        <div class="modal-body">
          <p>{{__('message.Confirm_approve')}} ?</p>
        </div>
        <div class="modal-footer">
          <a href="" data-dismiss="modal" class="btn">{{__('message.Cancel')}}</a>
          <a href="" class="btn sure">{{__('message.Sure')}}</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal -->
  <div id="deleteAds" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">{{__('message.Confirm')}}</h4>
        </div>
        <div class="modal-body">
          <p>{{__('message.Confirm_delete')}} ?</p>
        </div>
        <div class="modal-footer">
          <a href="" data-dismiss="modal" class="btn">{{__('message.Cancel')}}</a>
          <a href="" class="btn sure">{{__('message.Sure')}}</a>
        </div>
      </div>
    </div>
  </div>
@endsection