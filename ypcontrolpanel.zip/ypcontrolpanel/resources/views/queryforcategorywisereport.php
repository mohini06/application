<?php
include "db.php";
$year_id = $_REQUEST['year_id'];

$sql="call Usp_GetCategoryVisitorReport($year_id)";
$result=$db->query($sql) ;

echo '<h4>'.'Visitors report by Category'.'</h4>';
 echo '<table id="categorywise">'.'<tr>'.'<th>'.'Category Name'.'</th>'.'<th>'.'Visitors Count'.'</th>'.'</tr>' ;
  while($row = $result->fetch(PDO::FETCH_ASSOC))
    {
     	echo '<tr>'.'<td>'.$row['Name'].'</td>'.'<td>'.$row['Count'].'</td>'.'</tr>';
    }
 echo '</table>';
?>