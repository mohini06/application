<div class="row">

<div class="col-sm-6">
<form method="GET" action="{{url('/show')}}" role="form">
<input type="hidden" name="_token" value="{{ csrf_token()}}">

    <div class="row mb-3" >
		<div class="col-md-12">
			<h3 class="heading">{{ __('message.COMPANY_ANNOUNCEMENTS') }}</h3>
		</div>
    </div>
    <div class="row">
        <div class="col-sm-4 form-group">
             <select class="form-control"  name="type" >
                 <option class="form-control" value="0">{{ __('message.All') }}</option>
                 <option value="1">{{ __('message.Company') }}</option>
                 <option value="2">{{ __('message.ad') }}</option>
             </select>
       </div>
       <div class="col-sm-4 form-group">
         <input type="text" name="keyword" class="form-control">

       </div>
       <div class="col-sm-4" style="padding-top:7px;">
       <a href="javascript:showhide('advance')" style="font-size: 15px; color:blue; ">{{ __('message.Advance_Search') }}</a>
       </div>

    </div>
    <div id="advance" style="background-color:darkgrey; padding: 20px; display:none;">
        <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                 <label style="font-size: 15px;">{{ __('message.City') }}</label>
                 <select name="city" class="form-control">
                  <option value="0">{{ __('message.Select_City') }}</option>
                   @foreach($citydetail as $cities)
                   <option value="{{$cities->CityId}}">{{$cities->CityName}}</option>
                   @endforeach
                 </select>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group">
                 <label style="font-size: 15px;">{{ __('message.Category') }}</label>
                 <select name="category" class="form-control">
                  <option value="0">{{ __('message.Select_Category') }}</option>
                   @foreach($categorydetail as $categories)
                   <option value="{{$categories->CategoryId}}">{{$categories->CategoryName}}</option>
                   @endforeach
                 </select>
              </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                 <label style="font-size: 15px;">{{ __('message.Payment') }}</label>
                 <select name="payment" class="form-control">
                  
                   <option value="0">{{ __('message.Select_Payment') }}</option>
                   <option value="3">{{ __('message.Premium') }}</option>
                   <option value="2">{{ __('message.Gold') }}</option>
                   <option value="1">{{ __('message.Silver') }}</option>
                   <option value="0">{{ __('message.Free') }}</option>

                 </select>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group">
                 <label style="font-size: 15px;">{{ __('message.Ranking') }}</label>
             
                  <select name="rate" class="form-control">
                    <option value="0">{{ __('message.Choose_Rating') }}</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>

                  </select>
              </div>
            </div>

            
        </div>
        <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                <label style="font-size: 15px;">{{ __('message.Email') }}</label>
                <input type="text" name="email" class="form-control"> 
              </div>
            </div>
            </div>
    </div>

    

    <div class="row">
		<div class="col-sm-12">
			<input type="submit" class="btn btn-md" value={{ __('message.Search') }} style=" background-color: #ffce00; color:#ffffff; margin-left:0px; margin-bottom:30px; ">
		</div>
	</div>
 </form>
</div>
<div class="col-sm-6 text-right">
<?php
  $company_count=(count($companydata));
  $classified_count=(count($classifieddata));
  $sitevisitor_count=(count($sitevisitor));
  ?>
    <p>Всего <?php echo $company_count; ?> Компания</p>
    <p>Всего <?php echo $classified_count;?> объявление</p>
    <p>Количество посетителей за сутки  #<?php echo $sitevisitor_count;?> </p>
</div>
</div>