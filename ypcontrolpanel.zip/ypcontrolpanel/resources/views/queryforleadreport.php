<?php
include "db.php";
$type = $_REQUEST['data1'];
$categ=$_REQUEST['data2'];
$subcateg=$_REQUEST['data3'];
$from = $_REQUEST['data4'];
$to = $_REQUEST['data5'];

// $sql="call Usp_GetCategorySubcategoryLeadReport(%s,%s,%s,%s,%s)",$from,$to,$type,$categ,$subcateg;
$sql="call Usp_GetCategorySubcategoryLeadReport('$from','$to','$type',$categ,$subcateg)";


$result=$db->query($sql);

echo ' <h4>'.'THE REPORT ON THE LEADING BY VISIT'.'</h4>';
 echo '<table id="lead">';
 echo '<tr>'.'<th>'.'Name'.'</th>'.'<th>'.'No of Visitors'.'</th>'.'</tr>';
 if ($result) {
  while($row =$result->fetch(PDO::FETCH_ASSOC))
    {
    	
    echo '<tr>'.'<td>'.$row['Name'].'</td>'.'<td>'.$row['Count'].'</td>'.'</tr>';
    
     	
    }
  }
  else {
  echo  '<tr>'.'<td>'.'No Record Found'.'</td>'.'</tr>';
  }
 
 echo '</table>';
?>
