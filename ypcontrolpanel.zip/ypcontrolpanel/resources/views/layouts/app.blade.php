<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	  
	<!-- Favicon -->
    <link rel="icon" href="{{asset('/public/Images/favicon.png')}}">
      
	<!-- Title -->
    <title>{{ __('message.YPK') }}</title>
	  
	<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">-->
    <link rel="stylesheet" href="{{asset('/public/css/bootstrap/bootstrap.css')}}" />
	<!-- Data Tables -->
	<!--<link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"> @sharu-->
	<link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="{{asset('/public/css/bootstrap-material-datetimepicker.css')}}" />
	
	<!-- Font Awesome -->
	<link rel="stylesheet" href="{{asset('/public/css/others/font-awesome.min.css')}}" />
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,500' rel='stylesheet' type='text/css'>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	 
	<!-- Customised -->
	<link rel="stylesheet" href="{{asset('/public/css/new-style.css')}}" />

    <!-- Core Stylesheet -->
    <link href="{{asset('/public/css/others/style.css')}}" rel="stylesheet">
  

	<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>-->
    <!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>-->
	  
    <link rel="stylesheet" href="{{asset('/public/css/others/pe-icon-7-stroke.css')}}" />
    <!--datepickr-->
      
      
    <script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
   <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="http://momentjs.com/downloads/moment-with-locales.min.js"></script>
    <script type="text/javascript" src="{{asset('/public/js/bootstrap-material-datetimepicker.js')}}"></script>

    <!--/datepickr-->
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	
  </head>
    <!-- Styles -->

<style>
   table 
  {
    table-border: 1px solid black;   
  }
 table tr td
 { word-wrap:break-word;
 font-size: 15px; width:10%;
  }
 #dorneMenu{
   margin-left: 20px;
  }
  .menudist
  {
	font-size: 15px;
	
   }
   .icon-bar {border:1px white solid !important;}
   #scrollUp{border-radius:10px !important; padding:0px !important;}
   #scrollUp i{ padding-top:0px !important; line-height:13px;  position: absolute;
    left: 23%; top:30%;}
   .footer_sticky {  
	  position:relative;
	  left: 0;
	  bottom: 0;
	  width: 100%;
	  background-color:black;
	  color: white;
	  text-align: center;
	  padding: 10px 5px;
	  margin-top:10px;
	  }
 .content-holder{margin-top:100px; min-height:477px;}
 .navbar-nav .nav-link{color:black;}
 .navbar-nav .nav-link:hover{ color:white; background-color: #ffce00;}
 .heading{font-size: 22px; padding-bottom:10px ;}
 .paymentbox{padding:10px; border-radius:2%;}
   </style>
</head>

<body style="background-color: #fced9f;">
  <div class="container">
    <div id="preloader">
        <div class="ypk-load"></div>
    </div>
    <div class="row">
		<header class="header_area" id="header">
			<div class="container-fluid h-100">
				<div class="row h-100">
					<div class="col-12 h-100">
						<nav class="navbar p-5" style="background-color: #ffce00;">
							<div class="container-fluid">
								<div class="navbar-header">
									<a class="navbar-brand" style="margin:0px; padding:0px;" href="{{url('/')}}"><img src="{{asset('/public/Images/ypk_ru.png')}}" alt="" class="logo-img-width"></a>

									<button type="button" class="navbar-toggle" data-target="#myNavbar" data-toggle="collapse">
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span> 
									</button>
								</div>

								<ul class="nav navbar-nav navbar-right" style="margin-top:5px;" id="myNavbar">
									<li class="nav-item menudist"><a class="nav-link" href="{{url('/home')}}">{{ __('message.Search') }}</a></li>
									<li class="nav-item menudist"><a class="nav-link" href="{{url('/approve')}}">{{ __('message.Approve') }}</a></li>
									<li class="nav-item menudist"><a  class="nav-link" href="{{url('/report')}}">{{ __('message.Report') }}</a></li>
									<li class="nav-item menudist"><a  class="nav-link" href="{{url('/announcement')}}">{{ __('message.Announcements') }}</a></li>
									<li class="nav-item menudist"><a  class="nav-link" href="{{url('/mailing')}}">{{ __('message.mailer') }}</a></li>
									<li class="nav-item menudist">
										@guest
										@else
									<a  class="nav-link" href="{{ route('logout') }}" onclick="event.preventDefault();
									document.getElementById('logout-form').submit();">
										{{ __('message.Logout') }}
									</a>
									<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
										{{ csrf_field() }}
									</form>
										@endguest
									</li>  
								</ul>
							</div>
						</nav>
					</div>
				</div>
			</div>
		</header>
	</div>

	<div class="row content-holder">
		<div class="col-md-12">
			@yield('content')
		</div>
	</div>
	</div>
	
	<footer class="footer_sticky">
		<div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-9" style="padding-top:14px;">
				<p>{{ __('message.Copyright') }}{{date("Y") }},{{ __('message.rights_reserved') }}</p>
			</div>
			<div class="col-md-2">
				<span style="color: white; font-size:8px;">{{ __('message.Developed') }} </span><img src="{{asset('/public/Images/dt_logo.png')}}" alt="error" style=" height:50px; width:64px;" />
				<!--<img src="{{asset('public/ProductImages/IMG270218031227.jpg')}}" style=" height:30px; width:40px;margin-top:-25px;"> -->
			</div>
		</div>
		</div>
	</footer>
	

     
    <script src="{{asset('public/js/bootstrap/popper.min.js')}}"></script>
    <!-- Bootstrap-4 js -->
    <!--<script src="{{asset('public/js/bootstrap/bootstrap.min.js')}}"></script>-->

    <!-- All Plugins js -->
    <script src="{{asset('public/js/others/plugins.js')}}"></script>
    <!-- Active JS -->
	<script src="{{asset('public/js/active.js')}}"></script>
	<script src="{{asset('public/js/jquery.mask.js')}}"></script>
	<script src="{{asset('public/js/others/new.js')}}"></script>
</body>
</html>
