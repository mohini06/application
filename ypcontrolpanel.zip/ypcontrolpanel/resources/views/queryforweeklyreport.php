<?php
include "db2.php";
$year_id =$_REQUEST['year_id'];
$startdate=$year_id."-01-01";
$enddate=$year_id."-12-31";
$sql="call Usp_GetWeekWiseVisitorReport($year_id,$startdate,$enddate)";
$result=$db->query($sql) ;
$output=array();
echo '<h4>'.'{{ __('message.Visitors_report_Weekly') }}'.'</h4>';
echo '<table id="weekly">';
 echo '<tr>'.'<th>'.'{{ __('message.Week') }}'.'</th>'.'<th>'.'{{ __('message.Visitors_Count') }}'.'</th>'.'</tr>' ;
  while($row = mysqli_fetch_array($result))
    {
    	if($row['Count']==null)
       {
       	echo '<tr>'.'<td>'.$row['Week'].'</td>'.'<td>'.'0'.'</td>'.'</tr>';
       }
      else {
      	echo '<tr>'.'<td>'.$row['Week'].'</td>'.'<td>'.$row['Count'].'</td>'.'</tr>';
      }  

     	
    }
 echo '</table>';
?>