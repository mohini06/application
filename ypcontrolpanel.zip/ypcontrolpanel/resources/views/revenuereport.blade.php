<h4>{{__('message.Revenue_Report')}}</h4>
   <table id="income">
       <thead>
           <tr>
               <th>{{__('message.Title')}}</th>
               <th>{{__('message.Type')}}</th>
               <th>{{__('message.Payment_Type')}}</th>
               <th>{{__('message.Update_Date')}}</th>
               <th>{{__('message.Cancel_Date')}}</th>
           </tr>
       </thead>
       <tbody>
           @if($report)
               @foreach($report as $data)
                  <tr>
                       <td>{{$data->Company_Classified_Name}}</td>
                       <td>{{$data->Type}}</td>
                       <td>{{$data->RegstrationType}}</td>
                       <td>{{$data->DateOfReg}}</td>
                       <td>{{$data->ExpiryDate}}</td>
                  </tr>
               @endforeach
           @else
               <tr><td>No Record Found</td></tr>
           @endif

       </tbody>
   </table>