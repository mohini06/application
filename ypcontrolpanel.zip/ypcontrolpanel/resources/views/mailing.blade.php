@extends('layouts.app')
@section('content')
    <div class="row">
        <div class="col-md-12">
            <h3 class="heading"><!--{{ __('message.SEARCH_ANNONCEMENTS') }}-->Customize Mail System</h3>
        </div>
    </div>
    @php 
	    $search_item = isset($_GET['search_item'])?$_GET['search_item']:"";
		$cityid = isset($_GET['city'])?$_GET['city']:"";
		$selected_categ = isset($_GET['selectedoption'])?$_GET['selectedoption']:"";
	@endphp
    <div class="row">
        <div class="col-md-12">
            <form style="margin-top:30px;" action="{{url('/search')}}" onsubmit="return SearchValidate()"  id="search_validation" method="GET" role="form">
                <input type="hidden" name="_token" value="{{csrf_token()}}">
                <div class="rq-search-container container">
                    <div class="rq-search-single">
                        <div class="rq-search-content">
                            <span class="rq-search-heading">{{ __('message.keywords') }}</span>
                            <input type="text" id="search_item" value="@php $search_item;  @endphp"  name="search_item" class="rq-form-element" placeholder="{{ __('message.what_r_u_looking_for') }}" autocomplete="off" style="width:100%;"/>
						</div>
                    </div>
                    <div class="rq-search-single">
                        <div class="rq-search-content">
                            <span class="rq-search-heading">{{ __('message.location') }}</span>
							<select name="city" id="citylist" class="category-option">
                                <option value="">{{ __('message.pick_a_location') }}</option>
                                @foreach(json_decode(\App\Helpers\CityHelper::instance()->cityNames()) as $city)
                                    @php $selected=($city->CityId==$cityid )? "SELECTED":"";@endphp
                                    <option value="{{$city->CityId}}" {{$selected}}>{{$city->CityName}}</option>
                                @endforeach
                            </select>
							<p id="searchalert"  class="search_eror_msg"></p>
                        </div>
                    </div>
                    <div class="rq-search-single">
                        <div class="rq-search-content last-child">
                            <span class="rq-search-heading">{{ __('message.categories') }}</span>
                            <a class="nav-link" href="#" onclick="document.getElementById('id04').style.display='block'" style="width:auto;">
                                <input type="text" id="selectedoption" value="@php echo $selected_categ  @endphp" name="selectedoption"class="rq-form-element" placeholder="{{ __('message.categories') }}/{{__('message.subcategory')}}"  autocomplete="off" readonly/>
                            </a>
                        </div>
                    </div>
                    <div class="rq-search-single search-btn">
                        <div class="rq-search-content serch-background">
                            <input type="submit" value="{{ __('message.search') }}" onclick="SearchValidate()" class="rq-btn rq-btn-primary fluid-btn"><i class="arrow_right"></i>
                        </div>
                    </div>
                </div>   
            </form>
            <div id="id04" class="modal overflow-modal">
                <!--rami-->
                <form class="modal-content download-body choose-category-modal" action="/action_page.php">
                    <div class="title-head-modal" style="background-color:#ffce00;height:50px;">
                        <span onclick="document.getElementById('id04').style.display='none'" class="download-close" title="Close Modal">&times;</span>
                        <h4 class="modal-title" style="padding:15px;text-align: center;">{{__('message.CHOOSE CATEGORY AND SUBCATEGORY')}}</h4>
                    </div>
                    <div class="container-fluid">
                        <div class="categories-popup">
                        <div>
                        <br>
                        <div class="category-lists">
                            <?php
                                $row_count=(count($category)/3);
                                if((count($category)%3)>0)
                                {
                                    $row_count=(count($category)/3);
                                }
                                $total_counter=1;
                            ?>
                            @for ($i = 0; $i < 3; $i++)
                                <?php 
                                    $counter=0;
                                ?>
                                <div class="col-md-4" style="border-right: 1px solid rgba(255, 255, 255, 0.4);">
                                    @for($j=$counter;$j<$row_count;$j++)
                                        <table  cellspacing="0" style="/* border-collapse:collapse; */">
                                            <tbody>
                                                @foreach($category->where('CategoryId','=',$total_counter) as $categories)
                                                    <tr>
                                                        <td>
                                                            <?php
                                                                $totalcounter=0;
                                                            ?>
                                                            <a  href="javascript:showhide('uniquename<?php echo $total_counter;?>')" class="btnCategory" style="cursor:pointer;font-size:13px;" aria-hidden="true" >
                                                                <span  class="fa fa-plus-circle" style="cursor:pointer;font-size:13px;"></span>
                                                                {{$categories->CategoryName}}
                                                            </a>
                                                            <div  class="sub-category" id="uniquename<?php echo $total_counter;?>" >
                                                                @foreach($subcategory->where('CategoryId','=',$categories->CategoryId) as $subcategories)
                                                                    <table  cellspacing="0" style="border-collapse:collapse;">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td  class="subcateg" onclick="document.getElementById('selectedoption').value='{{$subcategories->SubCategoryName}}'; document.getElementById('id04').style.display='none'">
                                                                                    {{$subcategories->SubCategoryName}}
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                @endforeach
                                                            </div>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>    
                                        <?php 
                                            $counter++;
                                            $total_counter++;
                                        ?>
                                    @endfor
                                </div>
                            @endfor
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12 pt-3">
        @yield('search_result')               
    </div>
</div>
    <script>
        // Get the modal
        var modal = document.getElementById('id04');

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event)     
        {
            if (event.target == modal) 
            {
                modal.style.display = "none";
            }
        }

        // Get the modal
        var modal = document.getElementById('id02');

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) 
        {
            if (event.target == modal) 
            {
                modal.style.display = "none";
            }
        }

        // Get the modal
        var modal = document.getElementById('id04');

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) 
        {
            if (event.target == modal) 
            {
                modal.style.display = "none";
            }
        }

        function showhide(id) 
        {
            $(".sub-category").not("#"+id).hide();
            var e = document.getElementById(id);
            e.style.display = (e.style.display == 'block') ? 'none' : 'block';
        }
    </script>            
@endsection