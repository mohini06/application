@extends('mailing')
@section('search_result')

    @if(count($companydata)>=1)
        @foreach($companydata as $companydetail)
            <div class="row mt-4">
                <div class="job-list" style="width:100%;">
                    <div class="row">
                        <div class="col-md-12 ipad-responsive">
                            <!-- rami-->
                            <label class="checker">{{$companydetail->CompanyName}} 
                                <input type="checkbox" value="{{$companydetail->Email}}" name="email" companyId="{{$companydetail->CompanyRegId}}">
                                <span class="checkmark"></span>
                            </label>
                            <span class="describe-business-details" style=" font-size:14px; font-weight:normal">{{$companydetail->Email}} - {{$companydetail->CityName}}</span>
                        </div>
                    </div>
                </div>    
            </div>
        @endforeach
    @else 
        <p style="font-size:20px;"> {{__('message.No Data found')}}</p>
    @endif
    <p class="addtocompose btn btn-warning" style="float:right;" data-toggle="modal" data-target="#mailpopup">Add to mail</p>
    <div id="mailpopup" class="modal fade" role="dialog">
        <div class="modal-dialog modal-lg">
            <!-- Modal content-->
            <form action="/send_mail" method="post" enctype="multipart/form-data">
                <input type="hidden" name="_token" value="{{ csrf_token()}}">
                <div class="modal-content" style="width:100%;">
                    <div class="modal-header ">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Compose Mail</h4>
                    </div>
                    <div class="modal-body">
                        <input type="text" name="to" class="form-control to_address" />
                        <input type="text" name="subject" class="form-control subject" placeholder="Subject" style="margin-top:10px; margin-bottom:30px" />
                        <textarea id="summernote" name="message" class="form-control" placeholder="Write message here..." rows="5" style="width: 100%; max-width: 100%;"></textarea>
                        <input type="file" name="files[]" multiple>
                    </div>
                    <div class="modal-footer">
                        <input type="submit" value="Send" class="btn btn-md" />
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready( function () {

            $('#summernote').summernote();
            $(".addtocompose").click( function () {
                var emails = [];
                $.each($("input[name='email']:checked"), function(){            
                    emails.push($(this).val());
                });
                $("#mailpopup .to_address").val(emails);
            });
            
           $("input[type='checkbox']").click(function () 
           {
               $total_count = $('input:checkbox:checked').length;
                if($total_count>=21)
                {
                    $('input:checkbox:not(":checked")').next(".checkmark").hide();
                }
                else
                {
                    $('input:checkbox:not(":checked")').next(".checkmark").show();
                }
            });
    
        $("#subcategory input[type='checkbox']").change(function(){
            if (!$(this).prop("checked"))
            {
                $(".selectall_checkbox").prop("checked",false);
            }
        });

        });
    </script>
    
    <link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote.css" rel="stylesheet">
  <script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote.js"></script>
@endsection