@extends('layouts.app')
@section('content')
@include('adminsearchform')



<div class="row">

<table id="myTable">
<thead>
        <tr>
         <th>{{ __('message.Name') }}</th>
         <th>{{ __('message.City') }}</th>
         <th>{{ __('message.The_Contact_Person') }}</th>
         <th>{{ __('message.Email_Address') }}</th>
         <th style="width:100px;">{{ __('message.Phone_No') }}</th>
         <th>{{ __('message.A_Type') }}</th>
         <th>{{ __('message.Date_Of_Registration') }}</th>
         <th>{{ __('message.Payment_Type') }}</th>
         <th>{{ __('message.Rank') }}</th>
         <th></th>
       </tr>
</thead>
<tbody>


    @foreach($data as $companies)
          <tr>
              <td style="font-size: 14px;">{{$companies->CompanyName}}</td>
              <td style="font-size: 14px;">{{$companies->CityName}}</td>
              <td style="font-size: 14px;">{{$companies->ContactName}}</td>
              <td style="font-size: 14px;">{{$companies->EmailAddress}}</td>
              <td style="font-size: 14px;">{{$companies->Phone}}</td>
              <td style="font-size: 14px;">{{$companies->Type}}</td>
              <td style="font-size: 14px;">{{$companies->DateOfReg}}</td>
			     @php
                  $type=$companies->Type;
				  $actualregtype=$companies->ActualRegType;
				  if($type=="Company")
				  {
					if($actualregtype==0)
					{
						$paymenttype="Free";
					}
					elseif($actualregtype==1)
					{
						$paymenttype="Silver";
					}
					elseif($actualregtype==2)
					{
						$paymenttype="Gold";
					}
					elseif($actualregtype==3)
					{
						$paymenttype="Premium";
					}
					else{
						$paymenttype="Free";
					}
					
				  }
				  else {
					  if($actualregtype==0)
					{
						$paymenttype="Free";
					}
					elseif($actualregtype==3)
					{
						$paymenttype="Premium";
					}
					else{
						$paymenttype="Free";
					}
				  }
                @endphp 
			  <td style="font-size: 14px;">{{$paymenttype}}</td>
              <td style="font-size: 14px;">{{$companies->Ranking}}</td>
               
                @if($type=="Company")
              <td style="font-size: 14px;"><a  href="{{url('editcompany')}}/{{$companies->CompanyRegId}}">{{ __('message.Edit') }}</a> / 
			  <a class="delete_company" data-toggle="modal" data-target="#myModal" href="#" url="{{url('deletecompanydetail')}}/{{$companies->CompanyRegId}}">{{ __('message.Delete') }}</a></td>
			  @else
              <td style="font-size: 14px;"><a  href="{{url('editclassified')}}/{{$companies->CompanyRegId}}">{{ __('message.Edit') }}</a> / 
			  <a data-toggle="modal" data-target="#myModal" class="delete_classified" href="#" url="{{url('deleteclassifieddetail')}}/{{$companies->CompanyRegId}}">{{ __('message.Delete') }}</a></td>
              @endif
          </tr>
      @endforeach
	
</tbody>
</table>
  {{$data->appends(request()->query())->links()}}
</div>

<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Confirmation</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        Are you sure ?
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		<a href="" class="btn btn-danger delete_button">Sure</a>
      </div>

    </div>
  </div>
</div>



{{--</div>--}}
<script>
$(document).ready(function(){
    $('#myTable1').dataTable();
	$(".delete_company").click( function () {
		var url = $(this).attr('url');
		$(".delete_button").attr("href",url);
	});
	$(".delete_classified").click( function () {
		var url = $(this).attr('url');
		$(".delete_button").attr("href",url);
	});
});
</script>
 <script>
    function showhide(id) {
        var e = document.getElementById(id);
        e.style.display = (e.style.display == 'block') ? 'none' : 'block';
    }
</script>
@endsection