@extends('layouts.app')
@section('content')
<div class="row">
   <h4>COMPANY SEARCH/ANNONCEMENTS</h4>
</div>
 <form method="GET" action="{{url('/nonapprovesearch')}}" id="nonapprovesearch" role="form">
  <input type="hidden" name="_token" value="{{ csrf_token()}}">
<div class="row" >
  

<div class="col-sm-4">
  <div class="form-group">
  <select class="form-control" name="type" id="type">
    <option value="0">All</option>
    <option value="1">Company</option>
    <option value="2">ad</option>
  </select>
  </div>
  </div>
  <div class="col-sm-6">
    <div class="form-group">
      <input type="text" name="searchtext" id="searchtext"class="form-control">
      </div>
  </div>
<div class="col-sm-2">
   <input type="submit" class="btn btn-primary" value="Search">
</div>

</div>
</form>
<table class="table table-bordered">
<tr>


 <th>Name</th>
 <th>Region</th>
 <th>City</th>
 <th>The Contact Person</th>
 <th>EI address</th>
 <th>Phone No</th>
 <th>A Type</th>
 <th>Date Of Registration</th>
 <th>Payment Type</th>
 <th>Rank</th>
 <th>Action</th>




</tr>

@php 
   $companycount=count($company);
@endphp
@if($companycount>0)
  @foreach($company as $companies)
   @php 
 $type=$companies->type;
 if($type=="Company")
 {
  $actualregtype=$companies->ActualRegType;
   if($actualregtype>2)
   {
    $paymenttype="Premium";
   }
   elseif($actualregtype>1)
   {
    $paymenttype="Gold";
   }
    elseif($actualregtype>0)
   {
    $paymenttype="Silver";
   }
    else
   {
    $paymenttype="Free";
   }
  $url=url('/viewdetail');
 }
 else{
 $actualregtype=$companies->ActualRegType;
 if($actualregtype>0)
   {
    $paymenttype="Premium";
   }
    else
   {
    $paymenttype="Free";
   }
 $url=url('/viewclassifieddetail');
}
 @endphp
  <tr>
  <td>{{$companies->CompanyName}}</td>
  <td>{{$companies->AreaName}}</td>
  <td>{{$companies->CityName}}</td>
  <td>{{$companies->Name}}</td>
  <td>{{$companies->Email}}</td>
  <td>{{$companies->Phone}}</td>

  <td>{{$companies->type}}</td>
  
 <td>{{$companies->DateOfReg}}</td>

<td>{{$paymenttype}}</td>

<td>{{$companies->Ranking}}</td>


<td><a href="{{$url}}/{{$companies->CompanyRegId}}">View Detail</a></td>
 
  </tr>
  @endforeach

@else
<tr><td colspan="11">No Data Found</td></tr>
@endif
</table>
{{ $company->appends(request()->query())->links() }} 
@endsection