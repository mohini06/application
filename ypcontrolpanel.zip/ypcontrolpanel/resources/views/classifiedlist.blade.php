@extends('layouts.app')
@section('content')
<div class="row" style="margin-top: 150px;">

<div class="col-sm-6">
<form method="POST" action="{{url('/show')}}" role="form">
<input type="hidden" name="_token" value="{{ csrf_token()}}">

    <div class="row">

        <span class="text-right"style="font-size: 22px;margin-left:13px;color: #ffce00;">{{ __('message.COMPANY_ANNOUNCEMENTS') }}</span>


    </div>
    <div class="row">

        <div class="col-sm-4 form-group">

             <select class="form-control"  name="type" >
                 <option class="form-control" value="0">{{ __('message.All') }}</option>
                 <option value="1">{{ __('message.Company') }}</option>
                 <option value="2">{{ __('message.ad') }}</option>
             </select>
       </div>
       <div class="col-sm-4 form-group">
         <input type="text" name="keyword"class="form-control">

       </div>
       <div class="col-sm-4">
       <a href="javascript:showhide('advance')" style="font-size: 15px; color:blue; ">{{ __('message.Advance_Search') }}</a>
       </div>

    </div>
    <div id="advance" style="background-color:lightgray; padding: 20px;">
        <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                 <label style="font-size: 15px;">{{ __('message.City') }}</label>
                 <select name="city" class="form-control">
                   @foreach($city as $cities)
                   <option value="{{$cities->CityId}}">{{$cities->CityName}}</option>
                   @endforeach
                 </select>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group">
                 <label style="font-size: 15px;">{{ __('message.Category') }}</label>
                 <select name="category" class="form-control">
                   @foreach($category as $categories)
                   <option value="{{$categories->CategoryId}}">{{$categories->CategoryName}}</option>
                   @endforeach
                 </select>
              </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                 <label style="font-size: 15px;">{{ __('message.Payment') }}</label>
                 <select name="payment" class="form-control">
                   @foreach($city as $cities)
                   <option value="{{$cities->CityId}}">{{$cities->CityName}}</option>
                   @endforeach
                 </select>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group">
                 <label style="font-size: 15px;">{{ __('message.Rating') }}</label>
                 <select name="rate" class="form-control">
                   @foreach($category as $categories)
                   <option value="{{$categories->CategoryId}}">{{$categories->CategoryName}}</option>
                   @endforeach
                 </select>
              </div>
            </div>
        </div>
    </div>
    <div class="row">
     <input type="submit" class="btn btn-lg" value="Search{{ __('message.Search') }}" style="height:30px; width:100px; background-color: #ffce00; color:#ffffff; font-size: 15px; ">
    </div>
 </form>
</div>
<div class="col-sm-6 text-right">
<?php
  $company_count=(count($company));
  $classified_count=(count($classified));
  ?>
    <p>Всего <?php echo $company_count; ?> Компания</p>
    <p>Всего <?php echo $classified_count;?> объявление</p>
    <p>Количество посетителей за сутки #1</p>
</div>
</div>



<div class="row">

<table id="myTable">
<thead>
        <tr>
         <th>{{ __('message.Name') }}</th>
         <th>{{ __('message.Region') }}</th>
         <th>{{ __('message.City') }}</th>
         <th>{{ __('message.The_Contact_Person') }}</th>
         <th>{{ __('message.Email_Address') }}</th>
         <th>{{ __('message.Phone_No') }}</th>
         <th>{{ __('message.A_Type') }}</th>
         <th>{{ __('message.Date_Of_Registration') }}</th>
         <th>{{ __('message.Payment_Type') }}</th>
         <th>{{ __('message.Rank') }}</th>
         <th></th>
       </tr>
</thead>
<tbody>

      @foreach($classified as $classifieds)
            <tr>
                <td>{{$classifieds->ClassifiedTitle}}</td>
                <td></td>
                <td>{{$classifieds->CityName}}</td>

                <td>{{$classifieds->Name}}</td>
                <td>{{$classifieds->Email}}</td>
                <td>{{$classifieds->Phone}}</td>

                <td>Classified</td>

                <td></td>
                <?php $paymenttype=$classifieds->SubscriptionType;
                        ?>
                          @if (!empty($paymenttype))
                          
                          <?php $paymenttype="$classifieds->SubscriptionType";?>
                          
                          @else
                         <?php  $paymenttype="free"; ?>
                          @endif
                <td><?php echo $paymenttype;?></td>
                <td></td>
                <td><a href="{{url('editclassified')}}/{{$classifieds->ClassifiedRegId}}">Edit{{ __('message.Rank') }}</a></td>
            </tr>
        @endforeach

  {{--@foreach($classified as $classifieds)--}}
      {{--<tr>--}}
          {{--<td>{{$classifieds->ClassifiedTitle}}</td>--}}
          {{--<td></td>--}}
          {{--<td>{{$classifieds->City}}</td>--}}

          {{--<td>{{$classifieds->Name}}</td>--}}
          {{--<td>{{$classifieds->Email}}</td>--}}
          {{--<td>{{$classifieds->Phone}}</td>--}}

          {{--<td>Classified</td>--}}

          {{--<td></td>--}}
          {{--<td>free</td>--}}
          {{--<td></td>--}}
          {{--<td><a href="">Edit</a></td>--}}
      {{--</tr>--}}
  {{--@endforeach--}}
</tbody>
</table>

</div>
{{--</div--}}
<script>
$(document).ready(function(){
    $('#myTable').dataTable();
});
</script>
 <script>
                function showhide(id) {
                    var e = document.getElementById(id);
                    e.style.display = (e.style.display == 'block') ? 'none' : 'block';
                }
            </script>
@endsection