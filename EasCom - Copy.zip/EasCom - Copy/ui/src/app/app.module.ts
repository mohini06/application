import { MatOptionModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule, Routes } from '@angular/router';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { TranslateModule } from '@ngx-translate/core';
import 'hammerjs';

import { FuseModule } from '@fuse/fuse.module';
import { FuseSharedModule } from '@fuse/shared.module';
import { FuseProgressBarModule, FuseSidebarModule, FuseThemeOptionsModule } from '@fuse/components';
import { fuseConfig } from 'app/fuse-config';
import { FakeDbService } from 'app/fake-db/fake-db.service';
import { AppComponent } from 'app/app.component';
import { AppStoreModule } from 'app/store/store.module';
import { LayoutModule } from 'app/layout/layout.module';
import { MenuComponent } from './main/pages/menu/menu.component';
import { MenuModule } from './main/pages/menu/menu.module';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { MasterModule } from './main/master/master.module';
import { JwtHttpInterceptor } from './_helpers/jwt-interceptor';
import { DatePipe, HashLocationStrategy, LocationStrategy, APP_BASE_HREF } from '@angular/common';

const appRoutes: Routes = [
    {
        path        : 'apps',
        loadChildren: './main/apps/apps.module#AppsModule'
    },
    {
        path        : 'pages',
        loadChildren: './main/pages/pages.module#PagesModule'
    },
    {
        path      : 'master',
        loadChildren: './main/master/master.module#MasterModule'
    },
  
    {
        path      : '**',
        redirectTo: 'pages/auth/login-2'
    }
];

@NgModule({
    declarations: [
        AppComponent,
        MenuComponent,
        ],
    imports     : [
        BrowserModule,
        BrowserAnimationsModule,
        HttpClientModule,
        RouterModule.forRoot(appRoutes),

        TranslateModule.forRoot(),
        InMemoryWebApiModule.forRoot(FakeDbService, {
            delay             : 0,
            passThruUnknownUrl: true
        }),
        // Material moment date module
        MatMomentDateModule,
        // Material
        MatButtonModule,
        MatIconModule,
        MatSelectModule,
        MatOptionModule,
        // Fuse modules
        FuseModule.forRoot(fuseConfig),
        FuseProgressBarModule,
        FuseSharedModule,
        FuseSidebarModule,
        FuseThemeOptionsModule,
        // App modules
        LayoutModule,
        AppStoreModule,
        MenuModule,
        NgxDatatableModule,
        //Master module
        MasterModule,
    ],
    bootstrap   : [
        AppComponent
    ],
    providers: [
       
        DatePipe,
        {
          provide: HTTP_INTERCEPTORS,
          useClass: JwtHttpInterceptor,
          multi: true
        },
        
        { provide: APP_BASE_HREF, useValue: '', },
        { provide: LocationStrategy, useClass: HashLocationStrategy }
      ],
})
export class AppModule
{
    
}
