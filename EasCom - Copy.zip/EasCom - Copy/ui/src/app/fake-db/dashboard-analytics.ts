export class AnalyticsDashboardDb {
    public static widgets = {
        widget1: {
            chartType: 'line',
            datasets: {
                '2016': [
                    {
                        label: 'Sales',
                        data: [1.9, 3, 3.4, 2.2, 2.9, 3.9, 2.5, 3.8, 4.1, 3.8, 3.2, 2.9],
                        fill: 'start'

                    }
                ],
                '2017': [
                    {
                        label: 'Sales',
                        data: [2.2, 2.9, 3.9, 2.5, 3.8, 3.2, 2.9, 1.9, 3, 3.4, 4.1, 3.8],
                        fill: 'start'

                    }
                ],
                '2018': [
                    {
                        label: 'Sales',
                        data: [3.9, 2.5, 3.8, 4.1, 1.9, 3, 3.8, 3.2, 2.9, 3.4, 2.2, 2.9],
                        fill: 'start'

                    }
                ]

            },
            labels: ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'],
            colors: [
                {
                    borderColor: '#42a5f5',
                    backgroundColor: '#42a5f5',
                    pointBackgroundColor: '#1e88e5',
                    pointHoverBackgroundColor: '#1e88e5',
                    pointBorderColor: '#ffffff',
                    pointHoverBorderColor: '#ffffff'
                }
            ],
            options: {
                spanGaps: false,
                legend: {
                    display: false
                },
                maintainAspectRatio: false,
                layout: {
                    padding: {
                        top: 32,
                        left: 32,
                        right: 32
                    }
                },
                elements: {
                    point: {
                        radius: 4,
                        borderWidth: 2,
                        hoverRadius: 4,
                        hoverBorderWidth: 2
                    },
                    line: {
                        tension: 0
                    }
                },
                scales: {
                    xAxes: [
                        {
                            gridLines: {
                                display: false,
                                drawBorder: false,
                                tickMarkLength: 18
                            },
                            ticks: {
                                fontColor: '#ffffff'
                            }
                        }
                    ],
                    yAxes: [
                        {
                            display: false,
                            ticks: {
                                min: 1.5,
                                max: 5,
                                stepSize: 0.5
                            }
                        }
                    ]
                },
                plugins: {
                    filler: {
                        propagate: false
                    },
                    xLabelsOnTop: {
                        active: true
                    }
                }
            }
        },
        widget2: {
            conversion: {
                value: 492,
                ofTarget: 13
            },
            chartType: 'line',
            datasets: {
                '2016': [
                    {
                        label: 'Expiry Count',
                        data: [1, 1, 2, 2, 3, 5,1, 1, 2, 2, 3, 5, 3, 4, 2, 2, 3, 2, 2, 3,2, 2, 3, 2, 2, 3, 4, 2, 2, 3, 2, 2, 3,4, 2, 3, 2, 2],
                        fill: 'start'

                    }
                ],
                '2017': [
                    {
                        label: 'Expiry Count',
                        data: [2, 3, 5, 3, 4, 1, 2, 1, 2, 3, 5, 3, 4, 1, 2, 1],
                        fill: 'start'

                    }
                ],
                '2018': [
                    {
                        label: 'Expiry Count',
                        data: [2, 3, 5, 3, 4, 1, 2, 1, 3, 5, 3, 4, 1, 2, 1, 2],
                        fill: 'start'

                    }
                ]

            },
            labels: ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30'],
            colors: [
                {
                    borderColor: 'rgba(200, 99, 132, .7)',
                    backgroundColor: 'lightblue',

                    // borderWidth: 2,
                }
                //   {

                //     backgroundColor:' linear-gradient(pink, yellow)',
                //     borderColor: 'rgba(200, 99, 132, .7)',
                //     // borderWidth: 2,
                //   },
            ],
            options: {
                responsive: true,
                spanGaps: false,
                legend: {
                    display: false
                },
                maintainAspectRatio: false,
                elements: {
                    point: {
                        radius: 2,
                        borderWidth: 1,
                        hoverRadius: 2,
                        hoverBorderWidth: 1
                    },
                    line: {
                        tension: 0.3
                    }
                },
                // tooltips           : {
                //     position : 'nearest',
                //     mode     : 'index',
                //     intersect: false
                // },
                layout: {
                    padding: {
                        top: 2,
                        left: 10,
                        right: 10,
                        bottom: 6
                    }
                },
                scales: {
                    xAxes: [
                        {
                            display: false
                        }
                    ],
                    yAxes: [
                        {
                            display: false,
                            ticks: {
                                // min: 100,
                                // max: 500
                                // stepSize: 0.9
                            }
                        }
                    ]
                },
                plugins: {
                    filler: {
                        propagate: false
                    }
                }
            }
        },
        widget3: {
            conversion: {
                value: 492,
                ofTarget: 13
            },
            chartType: 'line',
            datasets: {
                '2016': [
                    {
                        label: 'Expiry Count',
                        data: [1, 1, 2,1, 1, 2, 2, 3, 5, 3, 4, 2, 2, 3, 2, 2, 3,2, 2, 3, 2, 2, 2, 3, 5, 3, 4, 2, 2, 3, 2, 2, 3, 6, 2, 3, 2, 2],
                        fill: 'start'

                    }
                ],
                '2017': [
                    {
                        label: 'Expiry Count',
                        data: [2, 3, 5, 3, 4, 1, 2, 1, 2, 3, 5, 3, 4, 1, 2, 1],
                        fill: 'start'

                    }
                ],
                '2018': [
                    {
                        label: 'Expiry Count',
                        data: [2, 3, 5, 3, 4, 1, 2, 1, 3, 5, 3, 4, 1, 2, 1, 2],
                        fill: 'start'

                    }
                ]

            },
            labels: ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30'],
                 colors: [
                {
                    borderColor: 'rgba(200, 99, 132, .7)',
                    backgroundColor: 'lightblue',

                    // borderWidth: 2,
                }
                //   {

                //     backgroundColor:' linear-gradient(pink, yellow)',
                //     borderColor: 'rgba(200, 99, 132, .7)',
                //     // borderWidth: 2,
                //   },
            ],
            options: {
                responsive: true,
                spanGaps: false,
                legend: {
                    display: false
                },
                maintainAspectRatio: false,
                elements: {
                    point: {
                        radius: 2,
                        borderWidth: 1,
                        hoverRadius: 2,
                        hoverBorderWidth: 1
                    },
                    line: {
                        tension: 0.3
                    }
                },
                // tooltips           : {
                //     position : 'nearest',
                //     mode     : 'index',
                //     intersect: false
                // },
                layout: {
                    padding: {
                        top: 2,
                        left: 10,
                        right: 10,
                        bottom: 6
                    }
                },
                scales: {
                    xAxes: [
                        {
                            display: false
                        }
                    ],
                    yAxes: [
                        {
                            display: false,
                            ticks: {
                                // min: 100,
                                // max: 500
                                // stepSize: 0.9
                            }
                        }
                    ]
                },
                plugins: {
                    filler: {
                        propagate: false
                    }
                }
            }
        },
        widget4: {
            conversion: {
                value: 492,
                ofTarget: 13
            },
            chartType: 'line',
            datasets: {
                '2016': [
                    {
                        label: 'Expiry Count',
                        data: [1, 1, 2, 2, 3, 5, 3, 4, 2, 2, 3, 2, 2, 1, 1, 2, 2, 3, 5, 3, 4, 2, 2, 3, 2, 2, 3,2, 2, 3, 2, 2,3, 0, 2, 3, 2, 2],
                        fill: 'start'

                    }
                ],
                '2017': [
                    {
                        label: 'Expiry Count',
                        data: [2, 3, 5, 3, 4, 1, 2, 1, 2, 3, 5, 3, 4, 1, 2, 1,1, 1, 2, 2, 3, 5, 3, 4, 2, 2, 3, 2, 2, 3,2, 2, 3, 2, 2],
                        fill: 'start'

                    }
                ],
                '2018': [
                    {
                        label: 'Expiry Count',
                        data: [2, 3, 5, 3, 4, 1, 2, 1, 3, 5, 3, 4, 1, 2, 1, 2,1, 1, 2, 2, 3, 5, 3, 4, 2, 2, 3, 2, 2, 3,2, 2, 3, 2, 2],
                        fill: 'start'

                    }
                ]

            },
            labels: ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30'],
                        colors: [
                {
                    borderColor: 'rgba(200, 99, 132, .7)',
                    backgroundColor: 'lightblue',

                    // borderWidth: 2,
                }
                //   {

                //     backgroundColor:' linear-gradient(pink, yellow)',
                //     borderColor: 'rgba(200, 99, 132, .7)',
                //     // borderWidth: 2,
                //   },
            ],
            options: {
                responsive: true,
                spanGaps: false,
                legend: {
                    display: false
                },
                maintainAspectRatio: false,
                elements: {
                    point: {
                        radius: 2,
                        borderWidth: 1,
                        hoverRadius: 2,
                        hoverBorderWidth: 1
                    },
                    line: {
                        tension: 0.3
                    }
                },
                // tooltips           : {
                //     position : 'nearest',
                //     mode     : 'index',
                //     intersect: false
                // },
                layout: {
                    padding: {
                        top: 2,
                        left: 10,
                        right: 10,
                        bottom: 6
                    }
                },
                scales: {
                    xAxes: [
                        {
                            display: false
                        }
                    ],
                    yAxes: [
                        {
                            display: false,
                            ticks: {
                                // min: 100,
                                // max: 500
                                // stepSize: 0.9
                            }
                        }
                    ]
                },
                plugins: {
                    filler: {
                        propagate: false
                    }
                }
            }
        },

        widget15: {
            conversion: {
                value: 492,
                ofTarget: 13
            },
            chartType: 'line',
            datasets: {
                '2016': [
                    {
                        label: 'Expiry Count',
                        data: [1, 1, 2, 2, 3, 5, 3, 4, 2, 2, 3, 2, 2, 3,2, 2, 3, 2, 2,1, 1, 2, 2, 3, 5, 3, 4, 2, 2, 3, 2, 2, 3,2, 2, 3, 2, 2],
                        fill: 'start'

                    }
                ],
                '2017': [
                    {
                        label: 'Expiry Count',
                        data: [2, 3, 5, 3, 4, 1, 2, 1, 2, 3, 5, 3, 4, 1, 2, 1],
                        fill: 'start'

                    }
                ],
                '2018': [
                    {
                        label: 'Expiry Count',
                        data: [2, 3, 5, 3, 4, 1, 2, 1, 3, 5, 3, 4, 1, 2, 1, 2],
                        fill: 'start'

                    }
                ]

            },
            labels: ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30'],
                        colors: [
                {
                    borderColor: 'rgba(200, 99, 132, .7)',
                    backgroundColor: 'lightblue',

                    // borderWidth: 2,
                }
                //   {

                //     backgroundColor:' linear-gradient(pink, yellow)',
                //     borderColor: 'rgba(200, 99, 132, .7)',
                //     // borderWidth: 2,
                //   },
            ],
            options: {
                responsive: true,
                spanGaps: false,
                legend: {
                    display: false
                },
                maintainAspectRatio: false,
                elements: {
                    point: {
                        radius: 2,
                        borderWidth: 1,
                        hoverRadius: 2,
                        hoverBorderWidth: 1
                    },
                    line: {
                        tension: 0.3
                    }
                },
                // tooltips           : {
                //     position : 'nearest',
                //     mode     : 'index',
                //     intersect: false
                // },
                layout: {
                    padding: {
                        top: 2,
                        left: 10,
                        right: 10,
                        bottom: 6
                    }
                },
                scales: {
                    xAxes: [
                        {
                            display: false
                        }
                    ],
                    yAxes: [
                        {
                            display: false,
                            ticks: {
                                // min: 100,
                                // max: 500
                                // stepSize: 0.9
                            }
                        }
                    ]
                },
                plugins: {
                    filler: {
                        propagate: false
                    }
                }
            }
        },
        widget5: {
            chartType: 'horizontalBar',
            datasets: {
                'yesterday': [
                    {
                        label: 'Vendors',
                        data: [6,150,190, 300, 340, 220, 290, 390, 250, 380, 410, 380, 320, 290],
                        fill: 'start'

                    }
                   
                ],
                'today': [
                    {
                        label: 'Vendors',
                        data: [5,150,410, 380, 320, 290, 190, 390, 250, 380, 300, 340, 220, 290],
                        fill: 'start'
                    }
                 
                ]
            },
            labels: ['New Mexico-nm','Kuntucky-ky','Delaware-DE','Kentucky - KY','New Mexico - NM'],
            colors: [
             
                {
                    borderColor: '#008cef',
                    backgroundColor: '#008cef',
                    pointBackgroundColor: 'rgba(30, 136, 229, 0.87)',
                    pointHoverBackgroundColor: 'rgba(30, 136, 229, 0.87)',
                    pointBorderColor: '#ffffff',
                    pointHoverBorderColor: '#ffffff'
                }
            ],
            options: {
                spanGaps: false,
                legend: {
                    display: false
                },
                maintainAspectRatio: false,
                tooltips: {
                    position: 'nearest',
                    mode: 'index',
                    intersect: false
                },
                layout: {
                    padding: {
                        left: 24,
                        right: 32
                    }
                },
                elements: {
                    point: {
                        radius: 4,
                        borderWidth: 2,
                        hoverRadius: 4,
                        hoverBorderWidth: 2
                    }
                },
                scales: {
                    xAxes: [
                        {
                            gridLines: {
                                display: false
                            },
                            ticks: {
                                stepSize: 1
                                // fontColor: 'rgba(0,0,0,0.54)'
                            }
                        }
                    ],
                    yAxes: [
                        {
                            gridLines: {
                                // tickMarkLength: 16
                                display: false
                            },
                            ticks: {
                                // stepSize: 1
                            }
                        }
                    ]
                },
                plugins: {
                    filler: {
                        propagate: false
                    }
                }
            }
        },
        widget6: {
            markers: [
                {
                    lat: 52,
                    lng: -73,
                    label: '120'
                },
                {
                    lat: 37,
                    lng: -104,
                    label: '498'
                },
                {
                    lat: 21,
                    lng: -7,
                    label: '443'
                },
                {
                    lat: 55,
                    lng: 75,
                    label: '332'
                },
                {
                    lat: 51,
                    lng: 7,
                    label: '50'
                },
                {
                    lat: 31,
                    lng: 12,
                    label: '221'
                },
                {
                    lat: 45,
                    lng: 44,
                    label: '455'
                },
                {
                    lat: -26,
                    lng: 134,
                    label: '231'
                },
                {
                    lat: -9,
                    lng: -60,
                    label: '67'
                },
                {
                    lat: 33,
                    lng: 104,
                    label: '665'
                }
            ],
            styles: [
                {
                    'featureType': 'administrative',
                    'elementType': 'labels.text.fill',
                    'stylers': [
                        {
                            'color': '#444444'
                        }
                    ]
                },
                {
                    'featureType': 'landscape',
                    'elementType': 'all',
                    'stylers': [
                        {
                            'color': '#f2f2f2'
                        }
                    ]
                },
                {
                    'featureType': 'poi',
                    'elementType': 'all',
                    'stylers': [
                        {
                            'visibility': 'off'
                        }
                    ]
                },
                {
                    'featureType': 'road',
                    'elementType': 'all',
                    'stylers': [
                        {
                            'saturation': -100
                        },
                        {
                            'lightness': 45
                        }
                    ]
                },
                {
                    'featureType': 'road.highway',
                    'elementType': 'all',
                    'stylers': [
                        {
                            'visibility': 'simplified'
                        }
                    ]
                },
                {
                    'featureType': 'road.arterial',
                    'elementType': 'labels.icon',
                    'stylers': [
                        {
                            'visibility': 'off'
                        }
                    ]
                },
                {
                    'featureType': 'transit',
                    'elementType': 'all',
                    'stylers': [
                        {
                            'visibility': 'off'
                        }
                    ]
                },
                {
                    'featureType': 'water',
                    'elementType': 'all',
                    'stylers': [
                        {
                            'color': '#039be5'
                        },
                        {
                            'visibility': 'on'
                        }
                    ]
                }
            ]
        },
        widget7: {
            scheme: {
                domain: ['#73d8ff', '#fb9e00', '#f44e3b']
            },
            devices: [
                {
                    name: 'Desktop',
                    value: 92.8,
                    change: -0.6
                },
                {
                    name: 'Mouse',
                    value: 56.8,
                    change: 0.6
                },
                {
                    name: 'Keypad',
                    value: 23.8,
                    change: -0.6
                },
                {
                    name: 'Mobile',
                    value: 36.1,
                    change: 0.7
                },
                {
                    name: 'Tablet',
                    value: 1.1,
                    change: 0.1
                }
            ]
        },
        'widget8': {
            'title': 'Budget Distribution',
            'mainChart': [
                {
                    'name': 'Wireframing',
                    'value': 12
                },
                {
                    'name': 'Design',
                    'value': 17
                },
                {
                    'name': 'Coding',
                    'value': 28
                },
                {
                    'name': 'Marketing',
                    'value': 25
                },
                {
                    'name': 'Extra',
                    'value': 15
                }
            ]
        },
        widget9: {
            rows: [
                {
                    title: 'Vendor 1',
                    clicks: 5,
                    conversion: 10
                },
                {
                    title: 'Vendor 2',
                    clicks: 5,
                    conversion: 9
                },
                {
                    title: 'Vendor 3',
                    clicks: 15,
                    conversion: 7
                },
                {
                    title: 'Vendor 4',
                    clicks: 15,
                    conversion: 7
                },
                {
                    title: 'Vendor 5',
                    clicks: 15,
                    conversion: 25
                },
                {
                    title: 'Vendor 6',
                    clicks: 15,
                    conversion: 9
                },
                {
                    title: 'Vendor 7',
                    clicks: 15,
                    conversion: 8
                }
            ]
        }
    };
}
