import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { MatRippleModule } from '@angular/material/core';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { AgmCoreModule } from '@agm/core';

import { FuseSharedModule } from '@fuse/shared.module';
import { FuseWidgetModule } from '@fuse/components/widget/widget.module';

// import { EcommerceProductsComponent } from 'app/main/apps/e-commerce/products/products.component';
// import { EcommerceProductsService } from 'app/main/apps/e-commerce/products/products.service';
// import { EcommerceProductComponent } from 'app/main/apps/e-commerce/product/product.component';
// import { EcommerceProductService } from 'app/main/apps/e-commerce/product/product.service';
// import { EcommerceOrdersComponent } from 'app/main/apps/e-commerce/orders/orders.component';
// import { EcommerceOrdersService } from 'app/main/apps/e-commerce/orders/orders.service';
// import { EcommerceOrderComponent } from 'app/main/apps/e-commerce/order/order.component';
// import { EcommerceOrderService } from 'app/main/apps/e-commerce/order/order.service';
// import { MenuComponent } from 'app/main/apps/e-commerce/menu/menu.component';
import { FuseConfirmDialogModule, FuseSidebarModule } from '@fuse/components';
import { ContactModule } from 'app/main/vendorsview_component/contact/contact.module';
import { ContactComponent } from 'app/main/vendorsview_component/contact/contact.component';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ContractsComponent } from 'app/main/vendorsview_component/contracts/contracts.component';
import { FinancialsComponent } from 'app/main/vendorsview_component/Financials/financials.component';
import { IncidentComponent } from 'app/main/vendorsview_component/Incidents/incident.component';
import { InsuranceComponent } from 'app/main/vendorsview_component/insurances/insurance.component';
import { InvoiceComponent } from 'app/main/vendorsview_component/Invoices/invoice.component';
import { PandpComponent } from 'app/main/vendorsview_component/pandp/pandp.component';
import { QuestionnairesComponent } from 'app/main/vendorsview_component/Questionnaires/questionnaires.component';
import { ContractsModule } from 'app/main/vendorsview_component/contracts/contracts.module';
import { InvoiceModule } from 'app/main/vendorsview_component/Invoices/invoice.module';
import { FinancialsModule } from 'app/main/vendorsview_component/Financials/financials.module';
import { IncidentModule } from 'app/main/vendorsview_component/Incidents/incident.module';
import { InsuranceModule } from 'app/main/vendorsview_component/insurances/insurance.module';
import { PandpModule } from 'app/main/vendorsview_component/pandp/pandp.module';
import { QuestionnairesModule } from 'app/main/vendorsview_component/Questionnaires/questionnaires.module';




const routes: Routes = [
 
//     {
//         path     : 'products/:id',
//         component: EcommerceProductComponent,
//         resolve  : {
//             data: EcommerceProductService
//         }
//     },
//     {
//         path     : 'products/:id/:handle',
//         component: EcommerceProductComponent,
//         resolve  : {
//             data: EcommerceProductService
//         }
//     },
//     {
//         path     : 'orders',
//         component: EcommerceOrdersComponent,
//         resolve  : {
//             data: EcommerceOrdersService
//         }
//     },
    
//     {
//         path     : 'orders/:id',
//         component: EcommerceOrderComponent,
//         resolve  : {
//             data: EcommerceOrderService
//         }
//     },
//     {
//         path     : 'menu',
//         component: MenuComponent,
       
//     }
  
    
//     // {
//     //     path     : 'products/:id/:handle',
//     //     component: VendorTemplateComponent,
//     //     resolve  : {
//     //         data: ECommerceVendorService
//     //     }
//     // }
];

@NgModule({
    declarations: [
        // EcommerceProductsComponent,
        // EcommerceProductComponent,
        // EcommerceOrdersComponent,
        // EcommerceOrderComponent,
        // MenuComponent,
        // ContactComponent,
        // ContractsComponent,
        // FinancialsComponent,
        // IncidentComponent,
        // InsuranceComponent,
        // InvoiceComponent,
        // PandpComponent,
        // QuestionnairesComponent


    ],
    imports     : [
        RouterModule.forChild(routes),

        MatButtonModule,
        MatChipsModule,
        MatExpansionModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatPaginatorModule,
        MatRippleModule,
        MatSelectModule,
        MatSortModule,
        MatSnackBarModule,
        MatTableModule,
        MatTabsModule,

        FuseConfirmDialogModule,
        
        NgxChartsModule,
        AgmCoreModule.forRoot({
            apiKey: 'AIzaSyD81ecsCj4yYpcXSLFcYU97PvRsE_X8Bx8'
        }),

        FuseSharedModule,
        FuseWidgetModule,
        FuseSidebarModule,
       
        NgxDatatableModule,

        //vendorsmenumodule
        ContactModule,
        ContractsModule,
        InvoiceModule,
        FinancialsModule,
        IncidentModule,
        InsuranceModule,
        PandpModule,
        QuestionnairesModule




    ],
    providers   : [
        // EcommerceProductsService,
        // EcommerceProductService,
        // EcommerceOrdersService,
        // EcommerceOrderService,
        
    ],
    entryComponents: [
       
    ]
})
export class EcommerceModule
{
    
}
