import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { DataSource } from '@angular/cdk/collections';
import { BehaviorSubject, fromEvent, merge, Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';

import { fuseAnimations } from '@fuse/animations';
import { FuseUtils } from '@fuse/utils';

import { EcommerceProductsService } from 'app/main/apps/e-commerce/products/products.service';
import { takeUntil } from 'rxjs/internal/operators';
import { MatDialog } from '@angular/material/dialog';
// import { VendorComponent } from '../vendor/vendor.component';
import { FormGroup } from '@angular/forms';

import { ColumnMode } from '@swimlane/ngx-datatable';

@Component({
    selector     : 'e-commerce-products',
    templateUrl  : './products.component.html',
    styleUrls    : ['./products.component.scss'],
    animations   : fuseAnimations,
    encapsulation: ViewEncapsulation.None
})
export class EcommerceProductsComponent implements OnInit
{

    rows = [
        {
          name: 'Neal',
          account: 'vh464',
          status: 'Active',
          state:'Karnataka',
          city:'Bangalore',
          zip:'4554',
          phone:'123456789',
          fax:'333',
          createdon:'june 26 2020',
          view : '',
          edit :'',
         },
         {
            name: ' Aqa',
            account: 'vh464',
            status: 'Active',
            state:'Karnataka',
            city:'Bangalore',
            zip:'4554',
            phone:'567676788',
            fax:'333',
            createdon:'june 26 2020',
            view : '',
            edit :'',
           },
           {
            name: 'John',
            account: 'H464',
            status: 'Active',
            state:'Karnataka',
            city:'Bangalore',
            zip:'4554',
            phone:'567676788',
            fax:'333',
            createdon:'june 26 2020',
            view : '',
            edit :'',
           },
           {
            name: 'Adom',
            account: 'H464',
            status: 'Active',
            state:'Karnataka',
            city:'Bangalore',
            zip:'4554',
            phone:'567676788',
            fax:'333',
            createdon:'june 26 2020',
            view : '',
            edit :'',
           },
           {
            name: 'Eve',
            account: 'H464',
            status: 'Active',
            state:'Karnataka',
            city:'Bangalore',
            zip:'4554',
            phone:'567676788',
            fax:'333',
            createdon:'june 26 2020',
            view : '',
            edit :'',
           },
           {
            name: 'Evening',
            account: 'H464',
            status: 'Active',
            state:'Karnataka',
            city:'Bangalore',
            zip:'4554',
            phone:'567676788',
            fax:'333',
            createdon:'june 26 2020',
            view : '',
            edit :'',
           },
       
      ];

      columns = [
        { name: 'Name', prop: 'name'},
        { name: 'Account',prop: 'account' }, 
        { name: 'Status',prop: 'status'  },
        { name: 'State', prop: 'state' },
        { name: 'City', prop: 'city' },
        { name: 'Zip',prop: 'zip' },
        { name: 'Phone',prop: 'phone' },
        { name: 'Fax' , prop: 'fax'},
        { name: 'Createdon' ,prop: 'createdon'},
       
      ];
    
    //   rows = [
    //     {name: "A", gender: "male", company: "abc"},
    //     {name: "B", gender: "female", company: "abc"},
    //     {name: "C", gender: "male", company: "abc"}
    //   ];
    
      columnWidths = [
          { column: 'name', width: 80 }, 
          { column: 'account', width: 130}, 
          { column: 'status', width: 80 },
          { column: 'state', width: 100 },
          { column: 'city', width: 110 },
          { column: 'zip', width: 80 },
          { column: 'phone', width: 115 },
          { column: 'fax' , width: 70},
          { column: 'createdon' , width: 110},
      ]

    //   columns = [
    //       { name: 'Name', width: 22 }, 
    //       { name: 'Accountnumber', width: 22}, 
    //       { name: 'Status', width: 22 },
    //       { name: 'State', width: 22 },
    //       { name: 'City', width: 22 },
    //       { name: 'Zipcode', width: 22 },
    //       { name: 'Phonenumber', width: 22 },
    //       { name: 'Fax' , width: 22},
    //       { name: 'Createdon' , width: 22},
    //     //   { name: '', width: 80 },    
    //     //   { name: '' , width: 80},
    //     ];
    
    //   allColumns = [
    //     { name: 'Name', width: 22 }, 
    //       { name: 'Accountnumber', width: 22}, 
    //       { name: 'Status', width: 22 },
    //       { name: 'State', width: 22 },
    //       { name: 'City', width: 22 },
    //       { name: 'Zipcode', width: 22 },
    //       { name: 'Phonenumber', width: 22 },
    //       { name: 'Fax' , width: 22},
    //       { name: 'Createdon' , width: 22},
    //     //   { name: '' }, 
    //     //   { name: '' },
    //     ];
    
    //   ColumnMode = ColumnMode;

    public view=false;
    public list=true;
    dataSource: FilesDataSource | null;
    //  displayedColumns = ['id', 'image', 'name', 'category', 'price', 'quantity', 'active'];
    //displayedColumns = ['id', 'vendorname', 'accountnumber', 'state', 'city', 'phonenumber', 'status','createdBy','zipcode','fax'];
    displayedColumns = [ 'name', 'category', 'price', 'a','b','c','d','e','f','quantity','id'];

    @ViewChild(MatPaginator, {static: true})
    paginator: MatPaginator;

    @ViewChild(MatSort, {static: true})
    sort: MatSort;

    @ViewChild('filter', {static: true})
    filter: ElementRef;

    // Private
    private _unsubscribeAll: Subject<any>;

    dialogRef: any;
    constructor(
        private _ecommerceProductsService: EcommerceProductsService,
        private _matDialog: MatDialog

    )
    {
        // Set the private defaults
        this._unsubscribeAll = new Subject();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void
    {
        this.dataSource = new FilesDataSource(this._ecommerceProductsService, this.paginator, this.sort);
        // this.viewVendorInfo();

        fromEvent(this.filter.nativeElement, 'keyup')
            .pipe(
                takeUntil(this._unsubscribeAll),
                debounceTime(150),
                distinctUntilChanged()
            )
            .subscribe(() => {
                if ( !this.dataSource )
                {
                    return;
                }

                this.dataSource.filter = this.filter.nativeElement.value;
            });

            // added ngx code
            this.columns.forEach((col: any) => {
                const colWidth = this.columnWidths.find(colWidth => colWidth.column === col.prop);
                if (colWidth) {
                  col.width = colWidth.width;
                }
              });
         
    }

    // newVendor(): void
    // {
    //     this.dialogRef = this._matDialog.open(VendorTemplateComponent, {
    //         // height: "400px",

    //         panelClass: 'add-vendor',
    //         data      : {
    //             action: 'new'
    //         }
    //     });

    //     this.dialogRef.afterClosed()
    //         .subscribe((response: FormGroup) => {
    //             if ( !response )
    //             {
    //                 return;
    //             }

    //             //this._contactsService.updateContact(response.getRawValue());
    //         });
    // }
  
    // columnDefinitions = [
    //     { def: 'name', hide: true},
    //     { def: 'category', hide: false},
    //     {def: 'price',  hide: false},
    //     {def: 'a', hide: false},
    //     {def: 'b',  hide: false},
    //     {def: 'c', hide: false},
    //     {def: 'd',  hide: false},
    //     {def: 'e', hide: false},
    //     {def: 'f',  hide: false},
    //     {def: 'quantity',  hide: false},
    //     {def: 'id',  hide: false},
        
    //   ]
      viewVendorInfo() {
        //  this.list=false;
        this.columns=[{ name: 'Name', prop: 'name'}]
        document.getElementById('vendorlist').style.width="15%";
        document.getElementById('vendorlist').style.marginRight="10px";
        this.view=true;
        let pgContainer = document.getElementById('prodPg')
        // pgContainer.getElementsByClassName("mat-paginator-range-actions")[0].style.display="none";
       
    }
}

export class FilesDataSource extends DataSource<any>
{
    private _filterChange = new BehaviorSubject('');
    private _filteredDataChange = new BehaviorSubject('');

    /**
     * Constructor
     *
     * @param {EcommerceProductsService} _ecommerceProductsService
     * @param {MatPaginator} _matPaginator
     * @param {MatSort} _matSort
     */
    constructor(
        private _ecommerceProductsService: EcommerceProductsService,
        private _matPaginator: MatPaginator,
        private _matSort: MatSort
    )
    {
        super();

        this.filteredData = this._ecommerceProductsService.products;
    }

    /**
     * Connect function called by the table to retrieve one stream containing the data to render.
     *
     * @returns {Observable<any[]>}
     */
    connect(): Observable<any[]>
    {
        const displayDataChanges = [
            this._ecommerceProductsService.onProductsChanged,
            this._matPaginator.page,
            this._filterChange,
            this._matSort.sortChange
        ];

        return merge(...displayDataChanges)
            .pipe(
                map(() => {
                        let data = this._ecommerceProductsService.products.slice();

                        data = this.filterData(data);

                        this.filteredData = [...data];

                        data = this.sortData(data);

                        // Grab the page's slice of data.
                        const startIndex = this._matPaginator.pageIndex * this._matPaginator.pageSize;
                        return data.splice(startIndex, this._matPaginator.pageSize);
                    }
                ));
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------

    // Filtered data
    get filteredData(): any
    {
        return this._filteredDataChange.value;
    }

    set filteredData(value: any)
    {
        this._filteredDataChange.next(value);
    }

    // Filter
    get filter(): string
    {
        return this._filterChange.value;
    }

    set filter(filter: string)
    {
        this._filterChange.next(filter);
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Filter data
     *
     * @param data
     * @returns {any}
     */
    filterData(data): any
    {
        if ( !this.filter )
        {
            return data;
        }
        return FuseUtils.filterArrayByString(data, this.filter);
    }

    /**
     * Sort data
     *
     * @param data
     * @returns {any[]}
     */
    sortData(data): any[]
    {
        if ( !this._matSort.active || this._matSort.direction === '' )
        {
            return data;
        }

        return data.sort((a, b) => {
            let propertyA: number | string = '';
            let propertyB: number | string = '';

            switch ( this._matSort.active )
            {
                case 'id':
                    [propertyA, propertyB] = [a.id, b.id];
                    break;
                case 'name':
                    [propertyA, propertyB] = [a.name, b.name];
                    break;
                case 'categories':
                    [propertyA, propertyB] = [a.categories[0], b.categories[0]];
                    break;
                case 'price':
                    [propertyA, propertyB] = [a.priceTaxIncl, b.priceTaxIncl];
                    break;
                case 'quantity':
                    [propertyA, propertyB] = [a.quantity, b.quantity];
                    break;
                case 'active':
                    [propertyA, propertyB] = [a.active, b.active];
                    break;
            }

            const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
            const valueB = isNaN(+propertyB) ? propertyB : +propertyB;

            return (valueA < valueB ? -1 : 1) * (this._matSort.direction === 'asc' ? 1 : -1);
        });
    }

    /**
     * Disconnect
     */
    disconnect(): void
    {
    }
}
