import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { MatRippleModule } from '@angular/material/core';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { AgmCoreModule } from '@agm/core';

import { FuseSharedModule } from '@fuse/shared.module';
import { FuseWidgetModule } from '@fuse/components/widget/widget.module';

import { QuestionnaireTemplatesComponent } from 'app/main/apps/questionnaire/templates/templates.component';
import { QuestionnaireTemplatesService } from 'app/main/apps/questionnaire/templates/templates.service';
import { QuestionnaireQuestionListComponent } from 'app/main/apps/questionnaire/questionlist/questionlist.component';
import { QuestionnaireTemplateService } from 'app/main/apps/questionnaire/template/template.service';
import { QuestionnaireTemplateComponent } from 'app/main/apps/questionnaire/template/template.component';
import { QuestionnaireQuestionComponent } from 'app/main/apps/questionnaire/question/question.component';
import { MatCheckboxModule } from '@angular/material/checkbox';

import { MatToolbarModule } from '@angular/material/toolbar';
import { FuseConfirmDialogModule } from '@fuse/components';
import { QuestionnaireQuestionService } from 'app/main/apps/questionnaire/question/question.service';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { QuestionnaireQuestionListService } from './questionlist/questionlist.service';
import { AuthGuard } from 'app/_guard/auth.guard';
import { Login2Module } from 'app/main/pages/authentication/login-2/login-2.module';
import { Login2Component } from 'app/main/pages/authentication/login-2/login-2.component';

const routes: Routes = [
    {
        path: 'templates',
        component: QuestionnaireTemplatesComponent, canActivate: [AuthGuard],
        resolve: {
            data: QuestionnaireTemplatesService
        }
    },
    {
        path: 'templates/:id',
        component: QuestionnaireQuestionListComponent, canActivate: [AuthGuard],

    },
    {
        path: '',
        component: Login2Component,
    }
];

@NgModule({
    declarations: [
        QuestionnaireTemplatesComponent,
        QuestionnaireQuestionListComponent,
        QuestionnaireTemplateComponent,
        QuestionnaireQuestionComponent
    ],
    imports: [
        RouterModule.forChild(routes),
        Login2Module,
        MatButtonModule,
        MatChipsModule,
        MatExpansionModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatPaginatorModule,
        MatRippleModule,
        MatSelectModule,
        MatSortModule,
        MatSnackBarModule,
        MatTableModule,
        MatTabsModule,
        MatCheckboxModule,
        MatToolbarModule,
        NgxDatatableModule,
        FuseConfirmDialogModule,
        NgxChartsModule,
        AgmCoreModule.forRoot({
            apiKey: 'AIzaSyD81ecsCj4yYpcXSLFcYU97PvRsE_X8Bx8'
        }),

        FuseSharedModule,
        FuseWidgetModule
    ],
    providers: [
        QuestionnaireTemplatesService,
        QuestionnaireTemplateService,
        QuestionnaireQuestionService,
        QuestionnaireQuestionListService
    ],
    entryComponents: [
        QuestionnaireTemplateComponent,
        QuestionnaireQuestionComponent
    ]
})
export class QuestionnaireModule {
}
