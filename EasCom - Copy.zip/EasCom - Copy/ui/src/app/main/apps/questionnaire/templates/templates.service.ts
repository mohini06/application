import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from 'environments/environment';

@Injectable()
export class QuestionnaireTemplatesService implements Resolve<any>
{
    private pathUrl = environment.urlPath;
    products: any[];
    onProductsChanged: BehaviorSubject<any>;

    /**
     * Constructor
     *
     * @param {HttpClient} _httpClient
     */
    constructor(
        private _httpClient: HttpClient
    )
    {
        // Set the defaults
        this.onProductsChanged = new BehaviorSubject({});
    }

    /**
     * Resolver
     *
     * @param {ActivatedRouteSnapshot} route
     * @param {RouterStateSnapshot} state
     * @returns {Observable<any> | Promise<any> | any}
     */
    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> | Promise<any> | any
    {
        return new Promise((resolve, reject) => {

            Promise.all([
                this.getProducts()
            ]).then(
                () => {
                    resolve();
                },
                reject
            );
        });
    }

    /**
     * Get products
     *
     * @returns {Promise<any>}
     */
    getProducts(): Promise<any>
    {
        return new Promise((resolve, reject) => {
            this._httpClient.get('api/e-commerce-products')
                .subscribe((response: any) => {
                    this.products = response;
                    this.onProductsChanged.next(this.products);
                    resolve(response);
                }, reject);
        });
    }

    getTemplatesList(pagelimit: any, pageoffset: any, pageorderby: any, pageorderdir: any) {
        return this._httpClient.post<any>(this.pathUrl + "/template/templates", {
            "per": pagelimit,
            "page": pageoffset + 1,
            "orderby": pageorderby + " " + pageorderdir,
            "vendorid": 0
        })
            .pipe(map(getTemplateList => {
                return getTemplateList;
            }));
    }

    getTemplates(){
        return this._httpClient.get<any>(this.pathUrl + "/template/templatelist")
    }

    getTemplateName(tId: any){
        return this._httpClient.get<any>(this.pathUrl + "/template/template/"+tId)
      }
      SearchTemplatesList(pagelimit: any, pageoffset: any, pageorderby: any, pageorderdir: any,searchKey:any){
        return this._httpClient.post<any>(this.pathUrl + "/template/templates", {
            "per": pagelimit,
            "page": pageoffset + 1,
            "orderby": pageorderby + " " + pageorderdir,
            "vendorid": 0,
            "commonsearch":[
                {
                   "value":searchKey
                }]
        })
            .pipe(map(SearchTemplatesList => {
                return SearchTemplatesList;
            }));
      }
}
