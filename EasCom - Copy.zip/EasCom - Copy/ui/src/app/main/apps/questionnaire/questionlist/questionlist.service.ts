import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from 'environments/environment';
import { map } from 'rxjs/operators';

@Injectable()
export class QuestionnaireQuestionListService implements Resolve<any>
{
    private pathUrl=environment.urlPath;
    routeParams: any;
    products: any[];
    onProductsChanged: BehaviorSubject<any>;

    /**
     * Constructor
     *
     * @param {HttpClient} _httpClient
     */
    constructor(
        private _httpClient: HttpClient
    )
    {
        // Set the defaults
        this.onProductsChanged = new BehaviorSubject({});
    }

    /**
     * Resolver
     *
     * @param {ActivatedRouteSnapshot} route
     * @param {RouterStateSnapshot} state
     * @returns {Observable<any> | Promise<any> | any}
     */
    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> | Promise<any> | any
    {
        this.routeParams = route.params;

        return new Promise((resolve, reject) => {

            Promise.all([
            //this.getProduct()
            ]).then(
                () => {
                    resolve();
                },
                reject
            );
        });
    }

    /**
     * Get product
     *
     * @returns {Promise<any>}
     */
    
    /**
     * Save product
     *
     * @param product
     * @returns {Promise<any>}
     */
    saveProduct(product): Promise<any>
    {
        return new Promise((resolve, reject) => {
            this._httpClient.post('api/e-commerce-products/' + product.id, product)
            .subscribe((response: any) => {
                resolve(response);
            }, reject);
        });
    }

    /**
     * Add product
     *
     * @param product
     * @returns {Promise<any>}
     */

    addProduct(product): Promise<any>
    {
        return new Promise((resolve, reject) => {
            this._httpClient.post('api/e-commerce-products/', product)
                .subscribe((response: any) => {
                    resolve(response);
                }, reject);
        });
    }

getQuestionList(pagelimit:any,pageoffset:any,pageorderby:any,pageorderdir:any,templateid:any)
{
  return this._httpClient.post<any>(this.pathUrl+"/questionnaire/questionnaires",{
    "per": pagelimit,
        "page": pageoffset+1,
         "orderby": pageorderby+" "+pageorderdir,
         "templateid" : templateid
  })
      .pipe(map(getQuestionList => {
        return getQuestionList;
    }));
}

searchQuestionList(pagelimit:any,pageoffset:any,pageorderby:any,pageorderdir:any,templateid:any,searchKey:any)
{
  return this._httpClient.post<any>(this.pathUrl+"/questionnaire/questionnaires",{
    "per": pagelimit,
        "page": pageoffset+1,
        "orderby": pageorderby+" "+pageorderdir,
        "templateid" : templateid,
        "commonsearch":[
        {
            "value":searchKey
        }]
    })
    .pipe(map(searchQuestionList => {
    return searchQuestionList;
    }));
  }
}