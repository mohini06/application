import { Component, OnDestroy, OnInit, ViewEncapsulation, Inject } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Location } from '@angular/common';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, MatSnackBarConfig, } from '@angular/material/snack-bar';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { fuseAnimations } from '@fuse/animations';
import { FuseUtils } from '@fuse/utils';

import { Question } from 'app/main/apps/questionnaire/question/question.model';
import { QuestionnaireQuestionService } from 'app/main/apps/questionnaire/question/question.service';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MasterService } from 'app/_sharedService/master.service';


enum CheckBoxType { YES, NO, NONE };

export interface Questionnaire {

  id?: number;
  label?: string;
  type?: string;
  options?: string;
  required?: boolean;
  templateId?: number;
  userId?: string;
  vid?: number;
  typeId?: number;

}
export interface StateOrLegalentityOrStatusOrOfficetype {
  id: string;

}

@Component({
  selector: 'questionnaire-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations
})
export class QuestionnaireQuestionComponent implements OnInit {
  
  pageType: string;
  QuestioneriesForm: FormGroup;
  check_box_type = CheckBoxType;
  currentlyChecked: CheckBoxType;
  unamePattern = "/^[a-zA-Z\s-, ]+$/";
  isSubmitted: any = false;
  message: any;
  disablefield: Boolean = false;
  read: Boolean = false;
  questionnaire: Questionnaire = {};
  selectedTemplate: any;
  tempid: number;
  typeData: any;
  templateTypeData: any;

  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  constructor(
    public matDialogRef: MatDialogRef<QuestionnaireQuestionComponent>,
    private _formBuilder: FormBuilder,
    private _location: Location,
    private _matSnackBar: MatSnackBar,
    private masterService: MasterService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private questionnaireService: QuestionnaireQuestionService,
    private _snackBar: MatSnackBar,
  ) {
  }

  ngOnInit(): void {
    console.log(this.data.tname)
    this.pageType = this.data.action;
    this.QuestioneriesForm = this._formBuilder.group({
      templateType: ['', [Validators.required]],
      label: ['', [Validators.required,
      Validators.pattern('^[a-zA-Z \-\']+')]],
      options: [''],
      requiredyes: [''],
      requiredno: [''],
      type: ['', [Validators.required]],
      id: [''],
    })
    
    this.QuestioneriesForm.get('type').valueChanges
      .subscribe(value => {

      if ((value == "select") || (value == "radio") || (value == "checkbox")) {
        this.QuestioneriesForm.get('options').setValidators([Validators.required])
      }
      else {
        this.QuestioneriesForm.get('options').setValidators([])
      }
      this.QuestioneriesForm.get('options').updateValueAndValidity();
      this.isSubmitted = true;
    });
    this.getTemplates();

    this.getTypedata();
    this.tempid = this.data.tid;
    this.selectedTemplate = { id: Number(this.tempid), name: this.data.tname }
    console.log(this.selectedTemplate)
    this.setFormValue()
  }

  getTemplates() {
    this.questionnaireService.getTemplates().subscribe(data => {
      if (data) {
        this.templateTypeData = data;
        for (let i = 0; i < this.templateTypeData.length; i++) {
          if (this.templateTypeData[i].id == this.data.tid) {
            this.selectedTemplate = this.templateTypeData[i]
          }
        }
        console.log(this.templateTypeData)
      }
    });

  }
  getTypedata() {
    return this.typeData = [
      { name: "TextBox", value: "textBox" },
      { name: "ComboBox", value: "select" },
      { name: "Radio", value: "radio" },
      { name: "Checkbox", value: "checkbox" },
      { name: "Number", value: "number" },
      { name: "Upload Document", value: "uploaddocument" }
    ];
  }

  getTypedatavalue(event) {
    console.log(event)
  }
  get templateType() { return this.QuestioneriesForm.get('templateType') };
  get label() { return this.QuestioneriesForm.get('label') };
  get options() { return this.QuestioneriesForm.get('options') };
  get type() {
    console.log(this.QuestioneriesForm.get('type'))
    return this.QuestioneriesForm.get('type')
  };
  get id() { return this.QuestioneriesForm.get('id') };

  getType(event: any) {
    console.log(event.value)
    if ((event.value == "number") || (event.value == "textBox")) {
      this.disablefield = true;
    }
    else {
      this.disablefield = false;
    }
  }

  selectCheckBox(targetType: CheckBoxType) {
    // If the checkbox was already checked, clear the currentlyChecked variable
    if (this.currentlyChecked === targetType) {
      this.currentlyChecked = CheckBoxType.NONE;
      return;
    }
    this.currentlyChecked = targetType;

  }
  setFormValue() {
    console.log(this.pageType)
    if (this.data.action == "edit") {
      console.log(this.data.row.templateid)
      console.log(this.data.row.templateid.id)
      this.id.setValue(this.data.row.id);
      this.label.setValue(this.data.row.label);
      this.options.setValue(this.data.row.options);
      this.type.setValue(this.data.row.type);
      this.templateType.setValue(this.data.row.templateid.id)
      if (this.data.row.required) {
        this.currentlyChecked = CheckBoxType.YES
      }
      if (this.data.row.required == false) {
        this.currentlyChecked = CheckBoxType.NO
      }
      this.read = true;

    }
    else if (this.data.action == "new") {
      console.log(this.data.tid)

      this.templateType.setValue(this.selectedTemplate.id)
      this.read = true;

    }
    else {

    }

  }
  saveQuestion() {
    if (this.QuestioneriesForm.invalid) {
      return;
    }
    else {
      
      this.isSubmitted = true;

      this.questionnaire.id = this.id.value
      this.questionnaire.label = this.label.value
      this.questionnaire.options = this.options.value
      this.questionnaire.type = this.QuestioneriesForm.value.type
      this.questionnaire.templateId = this.templateType.value
      this.questionnaire.userId = localStorage.getItem('user')
      if (this.currentlyChecked === 0) {
        this.questionnaire.required = true
      } else if (this.currentlyChecked === 1) {
        this.questionnaire.required = false
      } else {
        this.questionnaire.required = false
      }
      console.log(this.questionnaire)

      this.questionnaireService.saveQuestions(this.questionnaire)
        .subscribe(data => {
          this.openSnackBar()
          this.closeModal({ save: true });

        },
          error => {
            if (error.status == 401) {
              alert('Contact Name already exist..!')
            }
            alert('Something went wrong please try again')
            this.isSubmitted = false;
          });
    }
  }

  openSnackBar() {
    let config = new MatSnackBarConfig();
    config.panelClass = 'center';
    this._snackBar.open('Data saved successfully..!', 'X', {
      duration: 2000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
    });
  }

  /**
   * On destroy
   */

  closeModal(data) {
    this.matDialogRef.close(data);
  }

}