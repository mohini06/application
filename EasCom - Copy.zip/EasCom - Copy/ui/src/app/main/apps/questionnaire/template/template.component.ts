import { Component, OnDestroy, OnInit, ViewEncapsulation, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Location } from '@angular/common';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, MatSnackBarConfig,} from '@angular/material/snack-bar';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { fuseAnimations } from '@fuse/animations';
import { FuseUtils } from '@fuse/utils';

//import { Template } from 'app/main/apps/questionnaire/template/template.model';
import { QuestionnaireTemplateService } from 'app/main/apps/questionnaire/template/template.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

export interface Temp {
    id ?: number;
    name ?: string;
    userId?: string;
  }

  @Component({
    selector     : 'questionnaire-template',
    templateUrl  : './template.component.html',
    styleUrls    : ['./template.component.scss'],
    encapsulation: ViewEncapsulation.None,
    animations   : fuseAnimations
})
export class QuestionnaireTemplateComponent implements OnInit, OnDestroy
{
    //template: Template;
    pageType: string;
    templateForm: FormGroup;
    template: Temp = {};
    isSubmitted: any = false;
    edit:boolean=false;
    message: any;
    // Private
    private _unsubscribeAll: Subject<any>;

    /**
     * Constructor
     *
     * @param {QuestionnaireProductService} _ecommerceProductService
     * @param {FormBuilder} _formBuilder
     * @param {Location} _location
     * @param {MatSnackBar} _matSnackBar
     */

    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';

    constructor(
        public matDialogRef: MatDialogRef<QuestionnaireTemplateComponent>,
        private _questionnaireTemplateService: QuestionnaireTemplateService,
        private _formBuilder: FormBuilder,
        private _location: Location,
        private _matSnackBar: MatSnackBar,
        private _snackBar: MatSnackBar,
        @Inject(MAT_DIALOG_DATA) public data: any
    )
    {
      this._unsubscribeAll = new Subject();
    }


    /**
     * On init
     */
    ngOnInit(): void
    {
      this.templateForm = this._formBuilder.group({
          name: ['',
              [Validators.required, Validators.minLength(4)]],
          id:['']   
      });
        
      if (this.data.action == 'edit') {
          this.edit=true
          this.setFormValue()
        }
        else{
          this.edit=false
        }
    }

    public hasError = (controlName: string, errorName: string) =>{
        return this.templateForm.controls[controlName].hasError(errorName);
      }

    get id() { return this.templateForm.get('id') };
    get name() { return this.templateForm.get('name') };

    setFormValue(){
      if (this.data.row != null) {
        this.id.setValue(this.data.row.id);
        this.name.setValue(this.data.row.name);
      }
    }

    checkName(){
        this._questionnaireTemplateService.checkName(this.templateForm.value)
        .subscribe(data => {
          this.message = "";
        },
        error => {
          this.message = "Template already exists";
          console.log(error.error);
        });
    }

    clearMessage(){
      this.message="";
    }

    saveTemplate() {
        this.isSubmitted = true;
        this.template.id = this.id.value
        this.template.name = this.name.value
        this.template.userId = localStorage.getItem('user')
        if (!this.templateForm.valid) {
          return;
        }
        else {
          this._questionnaireTemplateService.saveTemplate(this.template)
            .subscribe(data => {console.log(data)
              this.openSnackBar()
              this.closeModal({save:true});
    
            },
            error => {
              if (error.status == 403) {
                // this.alertService.error("Contact Name already exist..!");
                this.message="Template already exist"
              }
              // this.alertService.error("Something went wrong please try again");
              this.isSubmitted = false;
            });
        }
      }

      openSnackBar() {
        let config = new MatSnackBarConfig();
        config.panelClass = 'center';
        this._snackBar.open('Data saved successfully..!', 'X', {
          duration: 2000,
         horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
        });
      }

    /**
     * On destroy
     */

    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

    /**
     * Create product form
     *
     * @returns {FormGroup}
     */

  closeModal(data){
      this.matDialogRef.close(data);
  }

}
