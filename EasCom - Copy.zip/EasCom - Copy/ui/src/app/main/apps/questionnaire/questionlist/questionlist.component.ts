import { Component, OnDestroy, OnInit, ViewEncapsulation, ViewChild, ElementRef, Input } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Location } from '@angular/common';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { DataSource } from '@angular/cdk/collections';
import { fuseAnimations } from '@fuse/animations';
import { FuseUtils } from '@fuse/utils';

import { QuestionnaireQuestionListService } from 'app/main/apps/questionnaire/questionlist/questionlist.service';
import { MatDialog } from '@angular/material/dialog';

import { QuestionnaireQuestionComponent } from 'app/main/apps/questionnaire/question/question.component';
import { Router } from '@angular/router';
import { QuestionnaireTemplatesService } from '../templates/templates.service';

import { fromEvent, BehaviorSubject, Observable, merge, Subject } from 'rxjs';
import { takeUntil, debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
import { DataserviceService } from 'app/_sharedService/dataservice.service';
import { SelectionType, ColumnMode } from '@swimlane/ngx-datatable';

@Component({
    selector: 'questionnaire-questionlist',
    templateUrl: './questionlist.component.html',
    styleUrls: ['./questionlist.component.scss'],
    encapsulation: ViewEncapsulation.None,
    animations: fuseAnimations
})
export class QuestionnaireQuestionListComponent implements OnInit {
    public parent: any = "";
    public for: any;
    templatename: any;
    index: any;
    page = {
        limit: 6,
        count: 0,
        offset: 0,
        orderBy: 'createdOn',
        orderDir: 'desc'
    };
    dataSource: FilesDataSource | null;
    SelectionType = SelectionType;
    ColumnMode = ColumnMode;
    selected = [];
    @ViewChild(MatPaginator, { static: true })
    paginator: MatPaginator;

    @ViewChild(MatSort, { static: true })
    sort: MatSort;

    @ViewChild('filter', { static: true })
    filter: ElementRef;
    rows: any;
    trows: any;
    tid: any;
    data: any;
    dialogRef: any;
    pageType: string;
    productForm: FormGroup;
    private _unsubscribeAll: Subject<any>;
    /**
     * Constructor
     * @param {FormBuilder} _formBuilder
     * @param {Location} _location
     * @param {MatSnackBar} _matSnackBar
     */
    constructor(
        private _formBuilder: FormBuilder,
        private _location: Location,
        private _matSnackBar: MatSnackBar,
        private _matDialog: MatDialog,
        private QuestionnaireProductService: QuestionnaireQuestionListService,
        private _questionnaireTemplatesService: QuestionnaireTemplatesService,
        private router: Router,
        private Dataservice: DataserviceService,
    ) {
        this._unsubscribeAll = new Subject();
    }

    ngOnInit(): void {

        this.tid = this.router.url.split("/")[4];
        this.pageCallback({ offset: 0 });
        this.dataSource = new FilesDataSource(this.QuestionnaireProductService, this.paginator, this.sort);

        fromEvent(this.filter.nativeElement, 'keyup')
            .pipe(
                takeUntil(this._unsubscribeAll),
                debounceTime(150),
                distinctUntilChanged()
            )
            .subscribe(() => {
                if (!this.dataSource) {
                    return;
                }

                this.dataSource.filter = this.filter.nativeElement.value;
            });
        document.getElementById('vendorlist').style.width = "15%";
        document.getElementById('vendorlist').style.marginRight = "10px";
        this.reloadTemplateTable();
        this.getTemplatename();

    }

    redirectQList(value) {
        this.tid = value.id;
        this.templatename = value.name;
        this.pageCallback({ offset: 0 });
    }

    pageCallback(pageInfo: { count?: number, pageSize?: number, limit?: number, offset?: number }) {
        this.page.offset = pageInfo.offset;
        this.reloadTable();
    }

    sortCallback(sortInfo: { sorts: { dir: string, prop: string }[], column: {}, prevValue: string, newValue: string }) {
        // there will always be one "sort" object if "sortType" is set to "single"
        this.page.orderDir = sortInfo.sorts[0].dir;
        this.page.orderBy = sortInfo.sorts[0].prop;
        this.reloadTable();
    }
    reloadTable() {
        this.QuestionnaireProductService.getQuestionList(this.page.limit,
            this.page.offset,
            this.page.orderBy,
            this.page.orderDir, this.tid)
        .subscribe(data => {
            this.page.count = data === null ? 0 : data[0].total;
            if (data == null) {
                this.rows = []
            }
            else {
                this.rows = data;
            }
        })
    }

    reloadTemplateTable() {
        this._questionnaireTemplatesService.getTemplates()
            .subscribe(data => {
                if (this.tid) {
                    let notSeletedTemplate
                    notSeletedTemplate = data.filter(template => template.id != this.tid);
                    var templateOnTop = data.filter(template => template.id == this.tid);
                    this.trows = notSeletedTemplate
                    this.trows.unshift(templateOnTop[0])
                }
                for (let i = 0; i < this.trows.length; i++) {
                    if (this.trows[i].id == this.tid) {
                        this.index = i;
                    }
                }
                this.selected = [this.trows[this.index]]
            })
    }

    addQuestion(event, type): void {

        console.log(event)
        if (type == "add") {
            this.dialogRef = this._matDialog.open(QuestionnaireQuestionComponent, {
                panelClass: 'questionnaire-question',
                data: {
                    tid: this.tid,
                    action: 'new',
                    tname: this.templatename
                }
            });

            this.dialogRef.afterClosed()
                .subscribe(response => {
                    console.log(response)
                    if (!response.save) {
                    return;
                }
                this.reloadTable()
            });
        }
        else if (type == "edit") {
            this.dialogRef = this._matDialog.open(QuestionnaireQuestionComponent, {
            data: {
                row: event,
                action: 'edit', tid: this.tid,
            },

            panelClass: 'questionnaire-question',
            });

            this.dialogRef.afterClosed()
            .subscribe(response => {
                console.log(response)
                if (!response.save) {
                    return;
                }
                this.reloadTable()
            });
        }
    }
    getTemplatename() {
        this._questionnaireTemplatesService.getTemplateName(this.tid)
            .subscribe(data => {
            this.templatename = data.name;
        })
    }

    updateFilter(event) {
        this.for = "questions"
        console.log(this.for)
        console.log(event)
        const val = event.target.value.toLowerCase();
        console.log(val)
        if (this.for == "questions") {
            this.QuestionnaireProductService.searchQuestionList(this.page.limit,
                this.page.offset,
                this.page.orderBy,
                this.page.orderDir, this.tid, val)
                .subscribe(data => {
                    console.log(data)
                    this.page.count = data === null ? 0 : data[0].total;
                    if (data == null) {
                        this.rows = []
                    }
                    else {
                        this.rows = data;
                    }
                    //this.Dataservice.searchdata(data, "questions");
                },
                    error => {
                        this.data = [];
                    })
        }
    }

}
export class FilesDataSource extends DataSource<any>
{
    private _filterChange = new BehaviorSubject('');
    private _filteredDataChange = new BehaviorSubject('');

    /**
     * Constructor
     *
     * @param {QuestionnaireQuestionsService} _ecommerceProductsService
     * @param {MatPaginator} _matPaginator
     * @param {MatSort} _matSort
     */
    constructor(
        private _ecommerceProductsService: QuestionnaireQuestionListService,
        private _matPaginator: MatPaginator,
        private _matSort: MatSort
    ) {
        super();

        this.filteredData = this._ecommerceProductsService.products;
    }

    /**
     * Connect function called by the table to retrieve one stream containing the data to render.
     *
     * @returns {Observable<any[]>}
     */
    connect(): Observable<any[]> {
        const displayDataChanges = [
            this._ecommerceProductsService.onProductsChanged,
            this._matPaginator.page,
            this._filterChange,
            this._matSort.sortChange
        ];

        return merge(...displayDataChanges)
            .pipe(
                map(() => {
                    let data = this._ecommerceProductsService.products.slice();

                    data = this.filterData(data);

                    this.filteredData = [...data];

                    data = this.sortData(data);

                    // Grab the page's slice of data.
                    const startIndex = this._matPaginator.pageIndex * this._matPaginator.pageSize;
                    return data.splice(startIndex, this._matPaginator.pageSize);
                }
                ));
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------

    // Filtered data
    get filteredData(): any {
        return this._filteredDataChange.value;
    }

    set filteredData(value: any) {
        this._filteredDataChange.next(value);
    }

    // Filter
    get filter(): string {
        return this._filterChange.value;
    }

    set filter(filter: string) {
        this._filterChange.next(filter);
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Filter data
     *
     * @param data
     * @returns {any}
     */
    filterData(data): any {
        if (!this.filter) {
            return data;
        }
        return FuseUtils.filterArrayByString(data, this.filter);
    }

    /**
     * Sort data
     *
     * @param data
     * @returns {any[]}
     */
    sortData(data): any[] {
        if (!this._matSort.active || this._matSort.direction === '') {
            return data;
        }

        return data.sort((a, b) => {
            let propertyA: number | string = '';
            let propertyB: number | string = '';

            switch (this._matSort.active) {
                case 'id':
                    [propertyA, propertyB] = [a.id, b.id];
                    break;
                case 'name':
                    [propertyA, propertyB] = [a.name, b.name];
                    break;
                case 'categories':
                    [propertyA, propertyB] = [a.categories[0], b.categories[0]];
                    break;
                case 'price':
                    [propertyA, propertyB] = [a.priceTaxIncl, b.priceTaxIncl];
                    break;
                case 'quantity':
                    [propertyA, propertyB] = [a.quantity, b.quantity];
                    break;
                case 'active':
                    [propertyA, propertyB] = [a.active, b.active];
                    break;
            }

            const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
            const valueB = isNaN(+propertyB) ? propertyB : +propertyB;

            return (valueA < valueB ? -1 : 1) * (this._matSort.direction === 'asc' ? 1 : -1);
        });
    }

    /**
     * Disconnect
     */
    disconnect(): void {
    }
}
