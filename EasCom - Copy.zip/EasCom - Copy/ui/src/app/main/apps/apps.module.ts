import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { FuseSharedModule } from '@fuse/shared.module';
import { Login2Component } from '../pages/authentication/login-2/login-2.component';
import { Login2Module } from '../pages/authentication/login-2/login-2.module';

const routes = [
    {
        path        : 'dashboards/analytics',
        loadChildren: './dashboards/analytics/analytics.module#AnalyticsDashboardModule'
    },
    {
        path        : 'dashboards/project',
        loadChildren: './dashboards/project/project.module#ProjectDashboardModule'
    },
    {
        path        : 'e-commerce',
        loadChildren: './e-commerce/e-commerce.module#EcommerceModule'
    },
    {
        path        : 'questionnaire',
        loadChildren: './questionnaire/questionnaire.module#QuestionnaireModule'
    },
      {
        path      : '**',
        component : Login2Component
    }
   
];

@NgModule({
    imports     : [
        RouterModule.forChild(routes),
        FuseSharedModule,
        Login2Module
        
    ]
})
export class AppsModule
{
}
