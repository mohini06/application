import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { Subject } from 'rxjs';
import { fuseAnimations } from '@fuse/animations';
import { FuseUtils } from '@fuse/utils';
import { MatDialog, MatDialogRef } from "@angular/material";
import { ColumnMode, SelectionType } from '@swimlane/ngx-datatable';
import { VendorTemplateComponent } from '../add-edit-vendor/vendor.component';
import { VendorviewService } from './vendorview.service';
import { Router } from '@angular/router';
import { VendotlistService } from '../vendorlist/vendotlist.service';
import { ContactService } from 'app/main/vendorsview_component/contact/contact.service';
import { DataserviceService } from 'app/_sharedService/dataservice.service';
import { ContractsService } from 'app/main/vendorsview_component/contracts/contracts.service';
import { FinancialsService } from 'app/main/vendorsview_component/Financials/financials.service';
import { IncidentsService } from 'app/main/vendorsview_component/Incidents/incidents.service';
import { InsurancesService } from 'app/main/vendorsview_component/insurances/insurances.service';
import { InvoicesService } from 'app/main/vendorsview_component/Invoices/invoices.service';
import { PandPService } from 'app/main/vendorsview_component/pandp/pandp.service';

@Component({
    selector: 'app-vendorview',
    templateUrl: './vendorview.component.html',
    styleUrls: ['./vendorview.component.scss'],
    animations: fuseAnimations,
    encapsulation: ViewEncapsulation.None
})
export class VendorviewComponent implements OnInit {
    dialogRef: MatDialogRef<VendorTemplateComponent>;
    rowData: any
    public parent: any = "";
    public for: any;
    Questionlist:any;
    temp = [];
    data: any;
    index:any;
    selectedVendor:any;
    page = {
        limit: 6,
        count: 0,
        offset: 0,
        orderBy: 'createdOn',
        orderDir: 'desc'
    };
    rows = [];
    contactrows = [];
    selected = [];
    selectedrow:any;
    SelectionType = SelectionType;
    ColumnMode = ColumnMode;
    vendorName: any;
    public tabIndex: any;
    public list = true;

    public viewData;
    public vendor_id: any;

    private _unsubscribeAll: Subject<any>;
    name = 'angular material tabs';
    column: { name: string; prop: string; }[];

    constructor(
        private router: Router,
        private _matDialog: MatDialog,
        private vendorviewServics: VendorviewService,
        private contactService: ContactService,
        private Dataservice:DataserviceService,
        private contractsService:ContractsService,
        private financialsService: FinancialsService,
        private incidentsService:IncidentsService,
        private insurancesService:InsurancesService,
        private invoicesService:InvoicesService,
        private panpService:PandPService
    ) {

    }

    ngOnInit(): void {
        this.vendor_id = this.router.url.split("/")[3];
        document.getElementById('vendorlist').style.width = "15%";
        document.getElementById('vendorlist').style.marginRight = "10px";
        //this.pageCallback({ offset: 0 });
        this.reloadTable();
        this.getVendorname();
        document.getElementById('tableV').scrollTop=10;
                // {vendorid: 27, vendorname: "RK constructions"}
     
    }
    getChildHeading(event) {
        // console.log(event);
        this.for = event;
    }
    getQuestionAns(event){
       
        this.Questionlist = event;
    }
    pageCallback(pageInfo: { count?: number, pageSize?: number, limit?: number, offset?: number }) {
        this.page.offset = pageInfo.offset;
        this.reloadTable();
    }

    sortCallback(sortInfo: { sorts: { dir: string, prop: string }[], column: {}, prevValue: string, newValue: string }) {
        // there will always be one "sort" object if "sortType" is set to "single"
        this.page.orderDir = sortInfo.sorts[0].dir;
        this.page.orderBy = sortInfo.sorts[0].prop;
        this.reloadTable();
    }
    reloadTable() {
        this.vendorviewServics.getList()
            .subscribe(data => {
                
                if(this.vendor_id)
                {
                let notSeletedVendor
                notSeletedVendor =data.filter(vendor => vendor.vendorid != this.vendor_id);
                var vendorOnTop =data.filter(vendor => vendor.vendorid == this.vendor_id);
                this.rows=notSeletedVendor
                this.rows.unshift(vendorOnTop[0])
                }
               for(let i=0;i<this.rows.length;i++)
               {
                   if(this.rows[i].vendorid==this.vendor_id){
                    this.index =i;
                   }
               }
            
                this.selected=[this.rows[this.index]]
                
            })

    }

    getVendorname() {
        this.vendorviewServics.getVendorName(this.vendor_id)
            .subscribe(data => {
                console.log(data)
                this.onSelectView({ vendorid: data.vendorid, vendorname: data.vendorname })  
                this.vendorName = data.vendorname;
            })
          
           
    }
    
    onSelectView(row) {
    
    this.vendorName = row.vendorname;
    this.vendor_id = row.vendorid
    console.log(row)
    this.rowData = row;
    this.viewVendorInfo(this.rowData.vendorid);
    this.selectedrow=document.getElementById('tableV').attributes;
    }

    getRowData(data) {
        console.log(data)
        this.vendor_id == data.vendorid

    }

    newVendor(event, type): void {

        if (type == "add") {
            this.dialogRef = this._matDialog.open(VendorTemplateComponent, {

                panelClass: 'add-vendor',
                data: {
                    action: 'new',

                }
            });

            this.dialogRef.afterClosed()
                .subscribe(response => {
                    console.log(response)
                    if (!response.save) {
                        return;
                    }
                    this.reloadTable()
                });
        }
        else if (type == "edit") {
            this.dialogRef = this._matDialog.open(VendorTemplateComponent, {
                data: { row: this.rowData, action: 'edit' },

                panelClass: 'add-vendor',
            });
            this.dialogRef.afterClosed()
            .subscribe(response => {
                console.log(response)
                if (!response.save) {
                    return;
                }
                this.reloadTable()
            });
        }
    }

    viewChild(event) {
        this.tabIndex = event.index;
        if(event.index==0)
        {
            this.for="contacts";
        }
    }

    viewVendorInfo(id) {
        this.vendor_id = id;
        console.log(this.vendor_id)
        this.column = [{ name: 'Vendor Name', prop: 'vendorname' }]
        
    }
    updateFilter(event) {

        console.log(this.vendor_id)
        console.log(this.for)
        console.log(event)
        const val = event.target.value.toLowerCase();
        console.log(val)

        if (this.for == "contacts") {
            console.log(this.for)
            this.contactService.getSearchContactList(this.page.limit,
                this.page.offset,
                this.page.orderBy,
                this.page.orderDir, this.vendor_id, val
            )
            .subscribe(data => {
                this.page.count = data === null ? 0 : data[0].total;
                // this.rows = data;
                console.log(data)   
                this.Dataservice.searchdata(data, "contacts");
            },
            error => {
                this.data = [];
            }
        )
    }
     else if(this.for== "contracts") {

        console.log(this.for)
        this.contractsService.getSearchContractList( this.page.limit,
            this.page.offset,
            this.page.orderBy,
            this.page.orderDir,this.vendor_id,val)
        .subscribe(data => {
            this.page.count = data === null ? 0 : data[0].total;
            this.Dataservice.searchdata(data, "contracts");
        },
        error => {
            this.data = [];
        }
        )
}  
     else if (this.for == "Financials") {
        this.financialsService.getSearchFinancialList(this.page.limit,
            this.page.offset,
            this.page.orderBy,
            this.page.orderDir, this.vendor_id,val)
            .subscribe(data => {
                this.page.count = data === null ? 0 : data[0].total;
                this.Dataservice.searchdata(data, "Financials");
        },
        error => {
            this.data = [];
        }
        )
}
else if (this.for == "Incidents") {
    this.incidentsService.getSearchIncidentList( this.page.limit,
        this.page.offset,
        this.page.orderBy,
        this.page.orderDir,this.vendor_id,val)
    .subscribe(data => {
        this.page.count = data === null ? 0 : data[0].total;
        this.Dataservice.searchdata(data, "Incidents");
        },
        error => {
            this.data = [];
        }
        )
}
else if (this.for == "Insurances") {
    this.insurancesService.getSearchInsuranceList( this.page.limit,
        this.page.offset,
        this.page.orderBy,
        this.page.orderDir,this.vendor_id,val)
    .subscribe(data => {
        this.page.count = data === null ? 0 : data[0].total;
        this.Dataservice.searchdata(data, "Insurances");
        },
        error => {
            this.data = [];
        }
        )
}
else if (this.for == "Invoices") {
    this.invoicesService.getSearchInvoiceList( this.page.limit,
        this.page.offset,
        this.page.orderBy,
        this.page.orderDir,this.vendor_id,val)
    .subscribe(data => {
        this.page.count = data === null ? 0 : data[0].total;
        this.Dataservice.searchdata(data, "Invoices");
        },
        error => {
            this.data = [];
        }
        )
}
else if (this.for == "pandp") {
    this.panpService.getSearchPandPList( this.page.limit,
        this.page.offset,
        this.page.orderBy,
        this.page.orderDir,this.vendor_id,val)
    .subscribe(data => {
        this.page.count = data === null ? 0 : data[0].total;
        this.Dataservice.searchdata(data, "pandp");
        },
        error => {
            this.data = [];
        }
        )
}
else if (this.for == "questionlist")
{

 console.log(this.Questionlist);
    const keys = Object.keys(this.Questionlist[0]);
      this.temp = this.Questionlist.filter(item => {
        for (let i = 0; i < 4; i++) {
          if (
            (item[keys[i]] &&
              item[keys[i]]
                .toString()
                .toLowerCase()
                .indexOf(val) !== -1) ||
            !val
          ) {
            return true;
          }
        }
      });
    console.log(this.temp)

    this.Dataservice.searchdata(this.temp, "questionlist");
    
     }
  }
}