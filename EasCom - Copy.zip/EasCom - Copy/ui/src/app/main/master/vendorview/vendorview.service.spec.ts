import { TestBed } from '@angular/core/testing';

import { VendorviewService } from './vendorview.service';

describe('VendorviewService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: VendorviewService = TestBed.get(VendorviewService);
    expect(service).toBeTruthy();
  });
});
