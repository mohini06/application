import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';

import { environment } from 'environments/environment';

@Injectable({
  providedIn: 'root'
})
export class VendorviewService  {
  private pathUrl=environment.urlPath;

  constructor(private http: HttpClient) {
    
   }


getVendorName(vendorId: any){
  return this.http.get<any>(this.pathUrl + "/vendor/vendor/"+vendorId)
}

getVendorList(pagelimit:any,pageoffset:any,pageorderby:any,pageorderdir:any)
{
  return this.http.post<any>(this.pathUrl+"/vendor/vendors",{
    "per": 20,
        "page": pageoffset+1,
         "orderby": pageorderby+" "+pageorderdir,
         "vendorid" : 0
  })
      .pipe(map(getVendorList => {
        return getVendorList;
    }));
}
getList(){
  return this.http.get<any>(this.pathUrl + "/vendor/vendorlist");
}
  
  saveVendor(vendor:any)
  {
      return this.http.post<any>(this.pathUrl+"/vendor/save",vendor)
      .pipe(map( saveVendor => {
        return saveVendor;
    }));
  }

    
  validateVendor(vendor)
  {
 
      return this.http.post<any>(this.pathUrl+"/vendor/validatevendor",{"vendorname":vendor})
      .pipe(map(validateVendor => {
        return validateVendor;
    }));
  }

}