
import { VendorlistComponent } from './vendorlist/vendorlist.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { MatRippleModule } from '@angular/material/core';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { AgmCoreModule } from '@agm/core';

import { FuseSharedModule } from '@fuse/shared.module';
import { FuseWidgetModule } from '@fuse/components/widget/widget.module';

import { EcommerceProductsComponent } from 'app/main/apps/e-commerce/products/products.component';
import { EcommerceProductComponent } from 'app/main/apps/e-commerce/product/product.component';
import { EcommerceProductService } from 'app/main/apps/e-commerce/product/product.service';
// import { EcommerceOrdersComponent } from 'app/main/apps/e-commerce/orders/orders.component';
// import { EcommerceOrdersService } from 'app/main/apps/e-commerce/orders/orders.service';
// import { EcommerceOrderComponent } from 'app/main/apps/e-commerce/order/order.component';
// import { EcommerceOrderService } from 'app/main/apps/e-commerce/order/order.service';
// import { MenuComponent } from 'app/main/apps/e-commerce/menu/menu.component';
import { FuseConfirmDialogModule, FuseSidebarModule } from '@fuse/components';
import { ContactModule } from 'app/main/vendorsview_component/contact/contact.module';
import { ContactComponent } from 'app/main/vendorsview_component/contact/contact.component';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ContractsComponent } from 'app/main/vendorsview_component/contracts/contracts.component';
import { FinancialsComponent } from 'app/main/vendorsview_component/Financials/financials.component';
import { IncidentComponent } from 'app/main/vendorsview_component/Incidents/incident.component';
import { InsuranceComponent } from 'app/main/vendorsview_component/insurances/insurance.component';
import { InvoiceComponent } from 'app/main/vendorsview_component/Invoices/invoice.component';
import { PandpComponent } from 'app/main/vendorsview_component/pandp/pandp.component';
import { QuestionnairesComponent } from 'app/main/vendorsview_component/Questionnaires/questionnaires.component';
import { ContractsModule } from 'app/main/vendorsview_component/contracts/contracts.module';
import { InvoiceModule } from 'app/main/vendorsview_component/Invoices/invoice.module';
import { FinancialsModule } from 'app/main/vendorsview_component/Financials/financials.module';
import { IncidentModule } from 'app/main/vendorsview_component/Incidents/incident.module';
import { InsuranceModule } from 'app/main/vendorsview_component/insurances/insurance.module';
import { PandpModule } from 'app/main/vendorsview_component/pandp/pandp.module';
import { QuestionnairesModule } from 'app/main/vendorsview_component/Questionnaires/questionnaires.module';
import { EcommerceProductsService } from '../apps/e-commerce/products/products.service';
import { VendorTemplateComponent } from './add-edit-vendor/vendor.component';
import { ECommerceVendorService } from './add-edit-vendor/vendor.service';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { VendorviewComponent } from './vendorview/vendorview.component';
import { QuestionnairelistComponent } from '../vendorsview_component/questionnairelist/questionnairelist.component';
import { FileUploadModule } from 'ng2-file-upload';
import { AuthGuard } from 'app/_guard/auth.guard';
import { Login2Component } from '../pages/authentication/login-2/login-2.component';
import { Login2Module } from '../pages/authentication/login-2/login-2.module';

const routes: Routes = [
    {
        path     : 'Vendors',
        component: VendorlistComponent,canActivate: [AuthGuard],
        resolve  : {
            data: EcommerceProductsService
        }
    },
    {
        path     : 'Vendors/:id',
        component: VendorviewComponent,canActivate: [AuthGuard],
        
    },
    {
            path      : '',
            component:Login2Component,
           }
    
];
// const masterRoutes: Routes = [
//     {
//     path      : '**',
//     redirectTo:'pages/auth/login-2'
//    }
// ];

@NgModule({
    declarations: [        
      VendorlistComponent,
        EcommerceProductsComponent,
        EcommerceProductComponent,
        VendorTemplateComponent,
        ContactComponent,
        ContractsComponent,
        FinancialsComponent,
        IncidentComponent,
        InsuranceComponent,
        InvoiceComponent,
        PandpComponent,
        QuestionnairesComponent,
        VendorviewComponent,
        QuestionnairelistComponent

    ],
    imports     : [
        RouterModule.forChild(routes),
        Login2Module,
        MatButtonModule,
        MatChipsModule,
        MatExpansionModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatPaginatorModule,
        MatRippleModule,
        MatSelectModule,
        MatSortModule,
        MatSnackBarModule,
        MatTableModule,
        MatTabsModule,
        ScrollingModule,
        FuseConfirmDialogModule,
        NgxChartsModule,
        AgmCoreModule.forRoot({
            apiKey: 'AIzaSyD81ecsCj4yYpcXSLFcYU97PvRsE_X8Bx8'
        }),
        FuseSharedModule,
        FuseWidgetModule,
        FuseSidebarModule,
        NgxDatatableModule,
        ContactModule,
        ContractsModule,
        InvoiceModule,
        FinancialsModule,
        IncidentModule,
        InsuranceModule,
        PandpModule,
        QuestionnairesModule,
        
        FileUploadModule
   ],
    providers   : [
        EcommerceProductsService,
        EcommerceProductService,
        ECommerceVendorService
    ],
    entryComponents: [
        VendorTemplateComponent,QuestionnairesComponent
    ]
})
export class MasterModule
{
}
