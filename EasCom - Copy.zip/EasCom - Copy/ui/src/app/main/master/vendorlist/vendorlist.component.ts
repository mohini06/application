
import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation,Output, Input, EventEmitter } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { DataSource } from '@angular/cdk/collections';
import { BehaviorSubject, fromEvent, merge, Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';

import { fuseAnimations } from '@fuse/animations';
import { FuseUtils } from '@fuse/utils';

import { EcommerceProductsService } from 'app/main/apps/e-commerce/products/products.service';
import { takeUntil } from 'rxjs/internal/operators';
import { MatDialog, MatDialogRef } from "@angular/material";
import { FormGroup } from '@angular/forms';
import { ColumnMode, SelectionType, DatatableComponent } from '@swimlane/ngx-datatable';
import { HttpClient } from '@angular/common/http';
import { VendorTemplateComponent } from '../add-edit-vendor/vendor.component';
import { VendotlistService } from './vendotlist.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-vendorlist',
    templateUrl: './vendorlist.component.html',
    styleUrls: ['./vendorlist.component.scss'],
    animations: fuseAnimations,
    encapsulation: ViewEncapsulation.None
})
export class VendorlistComponent implements OnInit
{
    //temp = [];
    temp:any;
    public parent:any;
    public for: any;
    dialogRef: MatDialogRef<VendorTemplateComponent>;
    rowData: any
    
    isAlreadyloaded: boolean = false;
    page = {
        limit: 6,
        count: 0,
        offset: 0,
        orderBy: 'createdOn',
        orderDir: 'desc'
    };

    //rows:any;
    rows = [];
    arr = [];
    selected = [];


    SelectionType = SelectionType;

    ColumnMode = ColumnMode;
    //columns=[];
    columns = [
        { name: 'Vendorname', prop: 'vendorname' },
        { name: 'Accountnumber', prop: 'accountnumber' },
        { name: 'statusId', prop: 'statusId' },
        { name: 'stateId', prop: 'stateId' },
        { name: 'City', prop: 'city' },
        { name: 'Zipcode', prop: 'zipcode' },
        { name: 'Phone', prop: 'phone' },
        { name: 'Fax', prop: 'fax' },
        { name: 'createdon', prop: 'createdOn' },

    ];

    @ViewChild("DatatableComponent", { static: false }) vendorlistTable: DatatableComponent;
    public view = false;
    public list = true;
    dataSource: FilesDataSource | null;
    @ViewChild("grid", { static: false })
    public viewData;
    public vendor_id: any;

    @ViewChild(MatPaginator, { static: true })
    paginator: MatPaginator;

    @ViewChild(MatSort, { static: true })
    sort: MatSort;

    @ViewChild('filter', { static: true })
    filter: ElementRef;

    // Private
    private _unsubscribeAll: Subject<any>;
    name = 'angular material tabs';
    column: { name: string; prop: string; }[];
    // dialogRef: any;
    constructor(
        private _ecommerceProductsService: EcommerceProductsService,
        private _matDialog: MatDialog,
        private vendorlistServics: VendotlistService,
        private router: Router
    ) {
        // Set the private defaults
        this._unsubscribeAll = new Subject();
    }

    /**
     * On init
     */
    ngOnInit(): void {
        this.for="vendors";
        this.pageCallback({ offset: 0 });
        this.dataSource = new FilesDataSource(this._ecommerceProductsService, this.paginator, this.sort);
        // this.viewVendorInfo();

        fromEvent(this.filter.nativeElement, 'keyup')
            .pipe(
                takeUntil(this._unsubscribeAll),
                debounceTime(150),
                distinctUntilChanged()
            )
            .subscribe(() => {
                if (!this.dataSource) {
                    return;
                }

                this.dataSource.filter = this.filter.nativeElement.value;
            });
    }

    pageCallback(pageInfo: { count?: number, pageSize?: number, limit?: number, offset?: number }) {
        this.page.offset = pageInfo.offset;
        this.reloadTable();
    }

    sortCallback(sortInfo: { sorts: { dir: string, prop: string }[], column: {}, prevValue: string, newValue: string }) {
        // there will always be one "sort" object if "sortType" is set to "single"
        this.page.orderDir = sortInfo.sorts[0].dir;
        this.page.orderBy = sortInfo.sorts[0].prop;
        this.reloadTable();
    }
    reloadTable() {
        // let arr=[];
        this.vendorlistServics.getVendorList(this.page.limit,
            this.page.offset,
            this.page.orderBy,
            this.page.orderDir)
        .subscribe(data => {
            this.page.count = data === null ? 0 : data[0].total;
                this.rows= data;
                this.temp = [...data];
        })
        
      }
      onEdit(row) {
        //console.log(row);
        this.rowData = row;
        // document.getElementById('edit').style.backgroundColor="#008cef";
        // document.getElementById('edit').style.color="white";
        this.newVendor(this.rowData, 'edit');

    }
    onSelectView(row) {
        this.rowData = row;
        console.log(this.rowData)
        //   document.getElementById('view').style.backgroundColor="#008cef";
        //   document.getElementById('view').style.color="white";
        this.vendor_id = row.vendorid
        this.viewVendorInfo(this.rowData.vendorid);
    }

    onSelect(event) {
        console.log('Event: select', event, this.selected);
        console.log('Activate Event', event);
        console.log(event.event.target.textContent)
        if ((event.type == 'click') && (event.cellIndex == 0)) {

            this.rowData = event.row;
            console.log(this.rowData)
            this.viewVendorInfo(this.rowData.vendorid);
            return {
                'row-color': true
            };
        }
    }

    getRowData(data) {
        console.log(data)
        this.vendor_id == data.vendorid

    }
    newVendor(event, type): void {

        if (type == "add") {
            this.dialogRef = this._matDialog.open(VendorTemplateComponent, {
                panelClass: 'add-vendor',
                data: {
                    action: 'new',

                }
            });

            this.dialogRef.afterClosed()
                .subscribe(response => {
                    console.log(response)
                    if (!response.save) {
                        return;
                    }
                    this.reloadTable()
                    //this._contactsService.updateContact(response.getRawValue());
                });
        }
        else if (type == "edit") {
            //    alert(this.rowData)
            this.dialogRef = this._matDialog.open(VendorTemplateComponent, {
                // height: "400px",
                data: { row: this.rowData, action: 'edit' },

                panelClass: 'add-vendor',
            });
            this.dialogRef.afterClosed()
                .subscribe(response => {
                    console.log(response)
                    if (!response.save) {
                        return;
                    }
                    this.reloadTable()
                    //this._contactsService.updateContact(response.getRawValue());
                });
        }
    }

    redirectViewList(value) {
        this.router.navigate(['/master/Vendors/' + value.vendorid]);
    }

    viewVendorInfo(id) {
        //  this.list=false;
        console.log(id)
        this.vendor_id = id;
        console.log(this.vendor_id)
        this.column = [{ name: 'Vendor Name', prop: 'vendorname' }]
        document.getElementById('vendorlist').style.width = "15%";
        document.getElementById('vendorlist').style.marginRight = "10px";
        this.view = true;
        document.getElementsByClassName('mat-tab-header-pagination-before')[0].remove();
        document.getElementsByClassName('mat-tab-header-pagination-after')[0].remove();
        let pgContainer = document.getElementById('prodPg')
        // pgContainer.getElementsByClassName("mat-paginator-range-actions")[0].style.display="none";

    }
    updateFilter(event) {
        console.log(this.for)
        this.for="vendors";
        console.log(event)
        const val = event.target.value.toLowerCase();
        console.log(val)
        console.log(this.temp)
       
        const count = this.columns.length;
        console.log(count)
  
        if(this.for=="vendors")
      {
        this.vendorlistServics.getVendorList(100,
            this.page.offset,
            this.page.orderBy,
            this.page.orderDir)
            .subscribe(data => {
                if (data) {
                    this.temp = data;
                     
                    console.log(this.temp[0]);
                    const keys = Object.keys(this.temp[0]);
                    console.log(keys)
                    this.rows = this.temp.filter(item => {
                       
                        for (let i = 0; i < 35; i++) {
                        if (
                                (item[keys[i]] &&
                                    item[keys[i]]
                                        .toString()
                                        .toLowerCase()
                                        .indexOf(val) !== -1) ||
                                !val
                            ) {

                                return true;

                            }
                            this.page.offset = 0;
                        }

                       
                    });
                   
                }

            })


        this.page.offset = 0;
    }
     else if(this.for=="contacts"){
      console.log(this.for)
     }
     else if(this.for=="contracts"){
         
     }  
     else if(this.for=="Financials"){
         
    } 
    else if(this.for=="Incidents"){
         
    }
    else if(this.for=="Insurances"){
         
    }
    else if(this.for=="Invoices"){
         
    }
    else if(this.for=="pandp"){
         
    }
    else {

    }
    // Whenever the filter changes, always go back to the first page

    }

   

}

export class FilesDataSource extends DataSource<any>
{
    private _filterChange = new BehaviorSubject('');
    private _filteredDataChange = new BehaviorSubject('');

    /**
     * Constructor
     *
     * @param {EcommerceProductsService} _ecommerceProductsService
     * @param {MatPaginator} _matPaginator
     * @param {MatSort} _matSort
     */
    constructor(
        private _ecommerceProductsService: EcommerceProductsService,
        private _matPaginator: MatPaginator,
        private _matSort: MatSort
    ) {
        super();

        this.filteredData = this._ecommerceProductsService.products;
    }

    /**
     * Connect function called by the table to retrieve one stream containing the data to render.
     *
     * @returns {Observable<any[]>}
     */
    connect(): Observable<any[]> {
        const displayDataChanges = [
            this._ecommerceProductsService.onProductsChanged,
            this._matPaginator.page,
            this._filterChange,
            this._matSort.sortChange
        ];

        return merge(...displayDataChanges)
            .pipe(
                map(() => {
                    let data = this._ecommerceProductsService.products.slice();

                    data = this.filterData(data);

                    this.filteredData = [...data];

                    data = this.sortData(data);

                    // Grab the page's slice of data.
                    const startIndex = this._matPaginator.pageIndex * this._matPaginator.pageSize;
                    return data.splice(startIndex, this._matPaginator.pageSize);
                }
                ));
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------

    // Filtered data
    get filteredData(): any {
        return this._filteredDataChange.value;
    }

    set filteredData(value: any) {
        this._filteredDataChange.next(value);
    }

    // Filter
    get filter(): string {
        return this._filterChange.value;
    }

    set filter(filter: string) {
        this._filterChange.next(filter);
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Filter data
     *
     * @param data
     * @returns {any}
     */
    filterData(data): any {
        if (!this.filter) {
            return data;
        }
        return FuseUtils.filterArrayByString(data, this.filter);
    }

    /**
     * Sort data
     *
     * @param data
     * @returns {any[]}
     */
    sortData(data): any[] {
        if (!this._matSort.active || this._matSort.direction === '') {
            return data;
        }

        return data.sort((a, b) => {
            let propertyA: number | string = '';
            let propertyB: number | string = '';

            switch (this._matSort.active) {
                case 'id':
                    [propertyA, propertyB] = [a.id, b.id];
                    break;
                case 'name':
                    [propertyA, propertyB] = [a.name, b.name];
                    break;
                case 'categories':
                    [propertyA, propertyB] = [a.categories[0], b.categories[0]];
                    break;
                case 'price':
                    [propertyA, propertyB] = [a.priceTaxIncl, b.priceTaxIncl];
                    break;
                case 'quantity':
                    [propertyA, propertyB] = [a.quantity, b.quantity];
                    break;
                case 'active':
                    [propertyA, propertyB] = [a.active, b.active];
                    break;
            }

            const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
            const valueB = isNaN(+propertyB) ? propertyB : +propertyB;

            return (valueA < valueB ? -1 : 1) * (this._matSort.direction === 'asc' ? 1 : -1);
        });
    }

    /**
     * Disconnect
     */
    disconnect(): void {
    }
}
