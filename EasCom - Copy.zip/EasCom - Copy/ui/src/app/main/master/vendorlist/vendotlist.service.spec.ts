import { TestBed } from '@angular/core/testing';

import { VendotlistService } from './vendotlist.service';

describe('VendotlistService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: VendotlistService = TestBed.get(VendotlistService);
    expect(service).toBeTruthy();
  });
});
