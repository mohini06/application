import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { environment } from 'environments/environment';

@Injectable({
  providedIn: 'root'
})
export class VendotlistService {
  private pathUrl = environment.urlPath;


  startwith = []
  endswith = []
  contains = []
  equal = []
  notequal = []
  greaterthan = []
  greaterthanorequal = []
  lessthanorequal = []
  lessthan = []
  dateequal = []
  datenotequal = []
  commonsearch = []
  sideBarState$
  user$;
  constructor(private http: HttpClient) {
    // super();
  }

  getVendorListAtonce() {
    return this.http.post<any>(this.pathUrl + "/vendor/vendors",{"vendorid": 0}).pipe(map(getVendorListAtonce => {
      return getVendorListAtonce;
    }));
  }
  getVendorList(pagelimit: any, pageoffset: any, pageorderby: any, pageorderdir: any) {
    return this.http.post<any>(this.pathUrl + "/vendor/vendors", {
      "per": pagelimit,
      "page": pageoffset + 1,
      "orderby": pageorderby + " " + pageorderdir,
      "vendorid": 0
    })
      .pipe(map(getVendorList => {
        return getVendorList;
      }));
  }

  saveVendor(vendor: any) {
    return this.http.post<any>(this.pathUrl + "/vendor/save", vendor)
      .pipe(map(saveVendor => {
        return saveVendor;
      }));
  }


  validateVendor(vendor) {

    return this.http.post<any>(this.pathUrl + "/vendor/validatevendor", { "vendorname": vendor })
      .pipe(map(validateVendor => {
        return validateVendor;
      }));
  }

}