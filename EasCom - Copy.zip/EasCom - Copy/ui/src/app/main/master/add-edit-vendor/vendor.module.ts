import { MatChipInputEvent } from '@angular/material/chips';
import { FuseUtils } from '@fuse/utils';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatInputModule } from '@angular/material/input';
import { FuseSharedModule } from '@fuse/shared.module';
import { FuseCountdownModule, FuseWidgetModule, FuseConfirmDialogModule } from '@fuse/components';
import { MatMenuModule } from '@angular/material/menu';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';
import { AgmCoreModule } from '@agm/core';
import { ChartsModule } from 'ng2-charts';
import { NgxChartsModule } from '@swimlane/ngx-charts';

import { MenuComponent } from 'app/main/pages/menu/menu.component';
import { EcommerceProductsComponent } from 'app/main/apps/e-commerce/products/products.component';
import { EcommerceProductsService } from 'app/main/apps/e-commerce/products/products.service';
import { EcommerceProductComponent } from 'app/main/apps/e-commerce/product/product.component';
import { EcommerceProductService } from 'app/main/apps/e-commerce/product/product.service';
import { VendorTemplateComponent } from './vendor.component';
import { AuthGuard } from 'app/_guard/auth.guard';


const routes = [
    {
        path: 'products',
        component: EcommerceProductsComponent, canActivate: [AuthGuard],
        resolve: {
            data: EcommerceProductsService
        }
    },
    {
        path: 'products/:id',
        component: EcommerceProductComponent, canActivate: [AuthGuard],
        resolve: {
            data: EcommerceProductService
        }
    },
    {
        path: 'products/:id/:handle',
        component: EcommerceProductComponent, canActivate: [AuthGuard],
        resolve: {
            data: EcommerceProductService
        }
    },
    {
        path: 'menu',
        component: MenuComponent,

    },
];
@NgModule({
    declarations: [
        
    ],
    imports: [
        RouterModule.forChild(routes),
        MatButtonModule,
        MatFormFieldModule,
        MatIconModule,
        MatMenuModule,
        MatSelectModule,
        MatTabsModule,
        MatChipsModule,
        FuseConfirmDialogModule,
        AgmCoreModule.forRoot({
            apiKey: 'AIzaSyD81ecsCj4yYpcXSLFcYU97PvRsE_X8Bx8'
        }),
        ChartsModule,
        NgxChartsModule,
        FuseSharedModule,
        FuseWidgetModule
    ],
    providers: [
        EcommerceProductsService,
        EcommerceProductService,
    ],
    entryComponents: [
        VendorTemplateComponent
    ]
})

export class Vendor { }



