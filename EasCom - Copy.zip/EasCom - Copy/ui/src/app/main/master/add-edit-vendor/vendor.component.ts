// import { Component, OnInit } from '@angular/core';
import { Component, OnDestroy, OnInit, ViewEncapsulation, Inject } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';
import { Location } from '@angular/common';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, MatSnackBarConfig, } from '@angular/material/snack-bar';
import { Subject } from 'rxjs';

import { fuseAnimations } from '@fuse/animations';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { ECommerceVendorService } from './vendor.service';
import { MasterService } from 'app/_sharedService/master.service';
import { QuestionnairesService } from 'app/main/vendorsview_component/Questionnaires/questionnaires.service';
// import { MyMaskUtil } from './my-mask.util';

export interface Vendor {
  vendorid?: number;
  vendorname?: string;
  accountnumber?: string;
  streetaddress1?: string;
  streetaddress2?: string;
  state?: any;
  stateId?: number;
  city?: string;
  email?: string;
  fax?: string;
  zipcode?: number;
  phone?: string;
  website?: string;
  legalentity?: string;
  status?: string;
  statusId?: number;
  officeId?: number;
  officetype?: string;
  risk?: string;
  riskId?: string;
  industry?: string;
  industryId?: string;
  templateId?: string;
  legalentityId?: string;
  userId?: string;
}
export interface StateOrLegalentityOrStatusOrOfficetype {
  id: string;

}

@Component({
  selector: 'app-vendor',
  templateUrl: './vendor.component.html',
  styleUrls: ['./vendor.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations
})
export class VendorTemplateComponent implements OnInit, OnDestroy {

  isSubmitted: any = false;
  states: any;
  statetypeData: any;
  legalentityData: any;
  vendor: Vendor = {};
  statustypeData: any;
  officetypeData: any;
  risktypeData: any;
  industryData: any;
  templateData: any;
  unamePattern = "([a-zA-Z ]*)+([0-9]*)+([a-zA-Z ]*)+([$&+,:;=?@#|'<>.-^*()%!-_`~]*)+([a-zA-Z ]*)+([0-9]*)+([$&+,:;=?@#|'<>.-^*()%!-_`~]*)";
  mobNumberPattern = "^((\\+91-?)|0)?[0-9]{10}$";
  numPattern = "[0-9]*";
  accnumPattern = "([a-zA-Z ]*)+([0-9]*)+([0-9]*)+([a-zA-Z ]*)";

  pageType: string;
  isEnabled: boolean = false;
  read: boolean = false;
  edit: boolean = false;
  hidden: boolean = true;
  vendorForm: FormGroup;
  hideRequiredControl = new FormControl(false);
  floatLabelControl = new FormControl('auto');
  
  // Private
  private _unsubscribeAll: Subject<any>;
  productForm: FormGroup;

  /**
   * Constructor
   *
   * @param {FormBuilder} _formBuilder
   * @param {Location} _location
   * @param {MatSnackBar} _matSnackBar
   */

  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(
    public matDialogRef: MatDialogRef<VendorTemplateComponent>,
    private _formBuilder: FormBuilder,
    private _location: Location,
    private _matSnackBar: MatSnackBar,
    private masterService: MasterService,
    private vendorService: ECommerceVendorService,
    private questionnaireService: QuestionnairesService,
    private _snackBar: MatSnackBar,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {

  }


  ngOnInit(): void {
    this.vendorForm = this._formBuilder.group({
      accountNumber: ['', [Validators.required, Validators.pattern(this.accnumPattern)]],
      zipCode: ['', [Validators.required, Validators.pattern(this.numPattern)]],
      streetAddress1: [''],
      streetAddress2: [''],
      phoneNumber: ['', [Validators.pattern(/^\(\d{3}\)\s\d{3}-\d{4}$/)]],
      state: ['', [Validators.required]],
      riskCategory: ['', [Validators.required]],
      industry: ['', [Validators.required]],
      office: ['', [Validators.required]],
      legalentity: ['', [Validators.required]],
      faxNumber: ['', [Validators.pattern(/^\(\d{3}\)\s\d{3}-\d{4}$/)]],
      city: ['', [Validators.required]],
      vendorName: ['', [Validators.required,
      Validators.pattern(this.unamePattern), Validators.maxLength(32), Validators.minLength(4)]],
      status: ['', [Validators.required]],
      template: [''],
      website: [''],
      vendorid: ['']
    });


    this.getStates('state');
    this.getStatus('status');
    this.getOffice('office');
    this.getRisk('riskcategory');
    this.getIndustry('vendorindustry');
    this.getLegalentity('legalentity');
    this.getTemplates();

    if (this.data.action == 'edit') {
      this.edit = true
      this.setFormValue()
    }
    else {
      this.edit = false
    }
    this.phoneValidate();
    this.faxsValidate();
  }

  public hasError = (controlName: string, errorName: string) => {
    return this.vendorForm.controls[controlName].hasError(errorName);
  }

  getStates(type: string) {
    this.masterService.getComboList(type).subscribe(data => {
      this.statetypeData = data;
    });

  }

  getStatus(type: string) {
    this.masterService.getComboList(type).subscribe(data => {
      this.statustypeData = data;
    });

  }

  getOffice(type: string) {
    this.masterService.getComboList(type).subscribe(data => {
      this.officetypeData = data;
    });

  }

  getRisk(type: string) {
    this.masterService.getComboList(type).subscribe(data => {
      this.risktypeData = data;
    });

  }

  getIndustry(type: string) {
    this.masterService.getComboList(type).subscribe(data => {
      this.industryData = data;
    });
  }

  getTemplates() {
    this.questionnaireService.getTemplates().subscribe(data => {
      this.templateData = data;
    });
  }

  getLegalentity(type: string) {
    this.masterService.getComboList(type).subscribe(data => {
      this.legalentityData = data;
    });
  }

  get vendorid() { return this.vendorForm.get('vendorid') };
  get vendorname() { return this.vendorForm.get('vendorName') };
  get statetype() { return this.vendorForm.get('state'); }
  get accountnumber() { return this.vendorForm.get('accountNumber') };
  get zipcode() { return this.vendorForm.get('zipCode') };
  get streetaddress1() { return this.vendorForm.get('streetAddress1') };
  get streetaddress2() { return this.vendorForm.get('streetAddress2') };
  get phonenumber() { return this.vendorForm.get('phoneNumber') };
  get fax() { return this.vendorForm.get('faxNumber') };
  get city() { return this.vendorForm.get('city') };
  get statustype() { return this.vendorForm.get('status') };
  get officetype() { return this.vendorForm.get('office') };
  get risktype() { return this.vendorForm.get('riskCategory') };
  get industry() { return this.vendorForm.get('industry') };
  get template() { return this.vendorForm.get('template') };
  get website() { return this.vendorForm.get('website') };
  get legalentity() { return this.vendorForm.get('legalentity') };

  saveVendor() {

    this.isSubmitted = true;
    this.vendor.vendorname = this.vendorname.value;
    this.vendor.accountnumber = this.accountnumber.value;
    this.vendor.stateId = this.statetype.value;
    this.vendor.zipcode = this.zipcode.value;
    this.vendor.streetaddress1 = this.streetaddress1.value;
    this.vendor.streetaddress2 = this.streetaddress2.value;
    this.vendor.phone = this.phonenumber.value;
    this.vendor.fax = this.fax.value;
    this.vendor.city = this.city.value;
    this.vendor.statusId = this.statustype.value;
    this.vendor.vendorid = this.vendorid.value;
    this.vendor.officeId = this.officetype.value;
    this.vendor.riskId = this.risktype.value;
    this.vendor.industryId = this.industry.value;
    this.vendor.templateId = this.template.value;;
    this.vendor.legalentityId = this.legalentity.value;
    this.vendor.website = this.website.value;
    this.vendor.userId = localStorage.getItem('user')

    if (!this.vendorForm.valid) {
      return;
    }
    else {
      this.vendorService.saveVendor(this.vendor)
        .subscribe(data => {
          this.openSnackBar()
          this.closeModal({ save: true });
        },
          error => {
            if (error.status == 401) {
              alert("please try again")
            }
            this.isSubmitted = false;
          });
    }
  }

  openSnackBar() {
    let config = new MatSnackBarConfig();
    config.panelClass = 'center';
    this._snackBar.open('Data saved successfully..!', 'X', {
      duration: 2000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
    });
  }

  setFormValue() {
    if (this.data.row != null) {
      this.vendorid.setValue(this.data.row.vendorid);
      this.vendorname.setValue(this.data.row.vendorname)
      this.accountnumber.setValue(this.data.row.accountnumber);
      this.zipcode.setValue(this.data.row.zipcode);
      this.streetaddress1.setValue(this.data.row.streetaddress1);
      this.streetaddress2.setValue(this.data.row.streetaddress2);
      this.phonenumber.setValue(this.data.row.phone);
      this.statetype.setValue(this.data.row.state.id);
      this.fax.setValue(this.data.row.fax);
      this.website.setValue(this.data.row.website);
      this.statustype.setValue(this.data.row.status.id);
      this.officetype.setValue(this.data.row.officetype.id);
      this.risktype.setValue(null != this.data.row.riskcategory ? this.data.row.riskcategory.id : null);
      this.industry.setValue(null != this.data.row.industry ? this.data.row.industry.id : null);
      this.legalentity.setValue(null != this.data.row.legalentity ? this.data.row.legalentity.id : null);
      this.city.setValue(this.data.row.city);
      this.template.setValue(null != this.data.row.template ? this.data.row.template.id : '');
      if (this.data.row.template.id) {
        this.read = true;
      }
      this.vendorname.disable();
      this.isEnabled = true;
    }
  }
  /**
   * On destroy
   */
  ngOnDestroy(): void {

  }

  closeModal(data) {
    this.matDialogRef.close(data);
  }

  phoneValidate() {
    const phoneControl: AbstractControl = this.vendorForm.controls['phoneNumber'];

    phoneControl.valueChanges.subscribe(data => {
      let preInputValue: string = this.vendorForm.value.phoneNumber;
      let lastChar: string = preInputValue.substr(preInputValue.length - 1);

      var newVal = data.replace(/\D/g, '');
      //when removed value from input
      if (data.length < preInputValue.length) {

        if (lastChar == ')') {
          newVal = newVal.substr(0, newVal.length - 1);
        }
        if (newVal.length == 0) {
          newVal = '';
        }
        else if (newVal.length <= 3) {
          newVal = newVal.replace(/^(\d{0,3})/, '($1');
        } else if (newVal.length <= 6) {
          newVal = newVal.replace(/^(\d{0,3})(\d{0,3})/, '($1) $2');
        } else {
          newVal = newVal.replace(/^(\d{0,3})(\d{0,3})(.*)/, '($1) $2-$3');
        }
        //when typed value in input
      } else {


        if (newVal.length == 0) {
          newVal = '';
        }
        else if (newVal.length <= 3) {
          newVal = newVal.replace(/^(\d{0,3})/, '($1)');
        } else if (newVal.length <= 6) {
          newVal = newVal.replace(/^(\d{0,3})(\d{0,3})/, '($1) $2');
        } else {
          newVal = newVal.replace(/^(\d{0,3})(\d{0,3})(.*)/, '($1) $2-$3');
        }

      }
      this.vendorForm.controls['phoneNumber'].setValue(newVal, { emitEvent: false });
    });
  }

  faxsValidate() {
    const faxControl: AbstractControl = this.vendorForm.controls['faxNumber'];

    faxControl.valueChanges.subscribe(data => {
      let preInputValue: string = this.vendorForm.value.faxNumber;
      let lastChar: string = preInputValue.substr(preInputValue.length - 1);

      var newVal = data.replace(/\D/g, '');
      //when removed value from input
      if (data.length < preInputValue.length) {
        if (lastChar == ')') {
          newVal = newVal.substr(0, newVal.length - 1);
        }
        if (newVal.length == 0) {
          newVal = '';
        }
        else if (newVal.length <= 3) {
          newVal = newVal.replace(/^(\d{0,3})/, '($1');
        } else if (newVal.length <= 6) {
          newVal = newVal.replace(/^(\d{0,3})(\d{0,3})/, '($1) $2');
        } else {
          newVal = newVal.replace(/^(\d{0,3})(\d{0,3})(.*)/, '($1) $2-$3');
        }
        //when typed value in input
      } else {

        if (newVal.length == 0) {
          newVal = '';
        }
        else if (newVal.length <= 3) {
          newVal = newVal.replace(/^(\d{0,3})/, '($1)');
        } else if (newVal.length <= 6) {
          newVal = newVal.replace(/^(\d{0,3})(\d{0,3})/, '($1) $2');
        } else {
          newVal = newVal.replace(/^(\d{0,3})(\d{0,3})(.*)/, '($1) $2-$3');
        }
      }
      this.vendorForm.controls['faxNumber'].setValue(newVal, { emitEvent: false });
    });
  }

}

