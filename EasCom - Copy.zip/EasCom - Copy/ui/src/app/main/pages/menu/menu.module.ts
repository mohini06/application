import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { FuseSharedModule } from '@fuse/shared.module';
import { MenuComponent } from 'app/main/pages/menu/menu.component';
import { HomeDashboardService } from '../homecontent/analytics.service';

const routes = [
    {
        path     : 'menu',
        component: MenuComponent,
        resolve  : {
            data: HomeDashboardService
        }
    }
];

@NgModule({
    declarations: [
        
    ],
    imports     : [
        RouterModule.forChild(routes),

        FuseSharedModule
    ]
})
export class MenuModule
{
}
