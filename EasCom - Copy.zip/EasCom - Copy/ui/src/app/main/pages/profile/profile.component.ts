import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators, FormControl } from '@angular/forms';
import { Subject } from 'rxjs';

import { ProfileService } from './profile.service';
import { MasterService } from 'app/_sharedService/master.service';
import { RegisterService } from '../authentication/register-2/register.service';
import { MatSnackBarConfig, MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, MatDialogRef, MatDialog } from '@angular/material';
import { FileUploader, FileLikeObject } from 'ng2-file-upload';
import { UpdatepswdComponent } from './updatepswd/updatepswd.component';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit, OnDestroy {
  dialogRef: MatDialogRef<UpdatepswdComponent>;
  statusTypeData: any;
  name: string;
  registerForm: FormGroup;
  userTypeData: any;

  // Private
  private _unsubscribeAll: Subject<any>;
  isSubmitted: boolean;
  url: string | ArrayBuffer;

  public uploaderfile: FileUploader = new FileUploader({
    //allowedFileType: ['txt', 'pdf','doc']
  });

  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  constructor(
    private registerService: RegisterService,
    private _formBuilder: FormBuilder,
    private profileService: ProfileService,
    private masterService: MasterService,
    private _snackBar: MatSnackBar,
    private _matDialog: MatDialog,
  ) {

    // Set the private defaults
    this._unsubscribeAll = new Subject();
  }

  /**
   * On init
   */

  ngOnInit(): void {
    this.url = "assets/images/avatars/profile.png";
    this.registerForm = this._formBuilder.group({
      files: [null],
      username: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      title: [''],
      firstname: ['', Validators.required],
      lastname: ['', Validators.required],
      address: [''],
      phonenumber: ['', [Validators.pattern(/^\(\d{3}\)\s\d{3}-\d{4}$/)]],
      fax: ['', [Validators.pattern(/^\(\d{3}\)\s\d{3}-\d{4}$/)]],
      usertype: ["", Validators.required],
      status: ["", Validators.required],
      userid: ['']
    });

    this.profileData();
    this.registerForm.disable();
    this.getStatus('status')
    this.getuserType();
    this.phonesValidate();
    this.faxValidate();
   
  }

  public hasError = (controlName: string, errorName: string) => {
    return this.registerForm.controls[controlName].hasError(errorName);
  }
  submit() {

    if (!this.registerForm.valid) {
      return;
    }
    console.log(this.registerForm.value);
    this.updateData()

  }

  get fax() { return this.registerForm.get('fax') };
  get files() {
    return this.registerForm.get("files");
  }

  getAttachments(): FileLikeObject[] {
    return this.uploaderfile.queue.map(fileItem => {
      return fileItem.file;
    });
  }
 
  updateData() {
    console.log(this.registerForm.value.userid)
    const formData = new FormData();
    formData.append("userid", this.registerForm.value.userid)
    formData.append("title", this.registerForm.value.title);
    formData.append("firstname", this.registerForm.value.firstname);
    formData.append("lastname", this.registerForm.value.lastname);
    formData.append("username", this.registerForm.value.username);
    formData.append("email", this.registerForm.value.email);
    formData.append(
      "statusId",
      JSON.stringify(this.registerForm.value.status ? this.registerForm.value.status : '')
    );
    formData.append("address", this.registerForm.value.address);
    formData.append("phone", this.registerForm.value.phonenumber);
    formData.append("fax", this.registerForm.value.fax);
    formData.append(
      "userTypeId",
      JSON.stringify(this.registerForm.value.usertype ? this.registerForm.value.usertype : '')
    );
    formData.append('password', this.registerForm.value.password)
    let attachments = this.getAttachments();
    attachments.forEach(attachment => {
      formData.append("files", attachment.rawFile, attachment.name);
    });
    this.profileService.updateProfile(formData)
      .subscribe(data => {
        this.openSnackBar();
        this.profileData();
      },
      error => {
        if (error.status == 401) {
          alert('Contact Name already exist..!')
        }
        alert('Something went wrong please try again..')
        this.isSubmitted = false;
      });
    this.registerForm.disable();
  }

  openSnackBar() {
    let config = new MatSnackBarConfig();
    config.panelClass = 'center';
    this._snackBar.open('Data saved successfully...!', 'X', {
      duration: 1000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,

    });
  }

  onSelectFile(event: any) {
    console.log(event)
    if (event.target.files && event.target.files[0]) {

      const reader = new FileReader();
      reader.onload = (event: Event) => {
        this.url = reader.result;
      };
      reader.readAsDataURL(event.target.files[0]);
    }
  }

  profileData() {
    this.profileService.getProfile(localStorage.getItem("user")).subscribe(data => {
      this.registerForm.get("title").setValue(data.title);
      this.name = data.firstname + "  " + data.lastname;
      this.registerForm.get("firstname").setValue(data.firstname);
      this.registerForm.get("lastname").setValue(data.lastname);
      this.registerForm.get("username").setValue(data.username);
      this.registerForm.get("password").setValue("12345678");
      this.registerForm.get("email").setValue(data.email);
      this.registerForm.get("phonenumber").setValue(data.phone);
      this.registerForm.get("address").setValue(data.address);
      this.registerForm.get("fax").setValue(data.fax);
      this.registerForm.get("status").setValue(data.status.id);
      this.registerForm.get("usertype").setValue(data.roles[0].id);
      this.registerForm.get("userid").setValue(data.userid);
      // this.url=data.profilepic;
      // this.url="/vvDocs/user_docs/17/3.jpg";
      // this.registerForm.get("files").setValue(data.files);
    });
  }

  Editform() {
    this.registerForm.enable();
  }

  getStatus(type: string) {
    this.masterService.getComboList(type).subscribe(data => {
      this.statusTypeData = data;
    });
  }

  getuserType() {
    this.registerService.getRoles().subscribe(data => {
      this.userTypeData = data;
    });
  }

  /**
   * On destroy
   */
  newContact(event, type): void {

    this.dialogRef = this._matDialog.open(UpdatepswdComponent, {
      panelClass: 'app-createcontact',
      data: {
        action: 'new'
      }
    });

  this.dialogRef.afterClosed()
    .subscribe(response => {
      console.log(response)
      if (!response.save) {
        return;
      }
    });

  }
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next();
    this._unsubscribeAll.complete();
  }

  phonesValidate() {
    const phoneControl: AbstractControl = this.registerForm.controls['phonenumber'];

    phoneControl.valueChanges.subscribe(data => {
      /**the most of code from @Günter Zöchbauer's answer.*/

      /**we remove from input but: 
         @preInputValue still keep the previous value because of not setting.
      */
      let preInputValue: string = this.registerForm.value.phonenumber;
      let lastChar: string = preInputValue.substr(preInputValue.length - 1);

      var newVal = data.replace(/\D/g, '');
      //when removed value from input
      if (data.length < preInputValue.length) {

        /**while removing if we encounter ) character,
           then remove the last digit too.*/
        if (lastChar == ')') {
          newVal = newVal.substr(0, newVal.length - 1);
        }
        if (newVal.length == 0) {
          newVal = '';
        }
        else if (newVal.length <= 3) {
          /**when removing, we change pattern match.
          "otherwise deleting of non-numeric characters is not recognized"*/
          newVal = newVal.replace(/^(\d{0,3})/, '($1');
        } else if (newVal.length <= 6) {
          newVal = newVal.replace(/^(\d{0,3})(\d{0,3})/, '($1) $2');
        } else {
          newVal = newVal.replace(/^(\d{0,3})(\d{0,3})(.*)/, '($1) $2-$3');
        }
        //when typed value in input
      } else {

        if (newVal.length == 0) {
          newVal = '';
        }
        else if (newVal.length <= 3) {
          newVal = newVal.replace(/^(\d{0,3})/, '($1)');
        } else if (newVal.length <= 6) {
          newVal = newVal.replace(/^(\d{0,3})(\d{0,3})/, '($1) $2');
        } else {
          newVal = newVal.replace(/^(\d{0,3})(\d{0,3})(.*)/, '($1) $2-$3');
        }

      }
      this.registerForm.controls['phonenumber'].setValue(newVal, { emitEvent: false });
    });
  }

  faxValidate() {

    const faxControl: AbstractControl = this.registerForm.controls['fax'];

    faxControl.valueChanges.subscribe(data => {

      /**the most of code from @Günter Zöchbauer's answer.*/
      /**we remove from input but: 
         @preInputValue still keep the previous value because of not setting.
      */
      let preInputValue: string = this.registerForm.value.fax; //
      let lastChar: string = preInputValue.substr(preInputValue.length - 1);

      var newVal = data.replace(/\D/g, '');
      //when removed value from input
      if (data.length < preInputValue.length) {

        /**while removing if we encounter ) character,
           then remove the last digit too.*/
        if (lastChar == ')') {
          newVal = newVal.substr(0, newVal.length - 1);
        }
        if (newVal.length == 0) {
          newVal = '';
        }
        else if (newVal.length <= 3) {
          /**when removing, we change pattern match.
          "otherwise deleting of non-numeric characters is not recognized"*/
          newVal = newVal.replace(/^(\d{0,3})/, '($1');
        } else if (newVal.length <= 6) {
          newVal = newVal.replace(/^(\d{0,3})(\d{0,3})/, '($1) $2');
        } else {
          newVal = newVal.replace(/^(\d{0,3})(\d{0,3})(.*)/, '($1) $2-$3');
        }
        //when typed value in input
      } else {


        if (newVal.length == 0) {
          newVal = '';
        }
        else if (newVal.length <= 3) {
          newVal = newVal.replace(/^(\d{0,3})/, '($1)');
        } else if (newVal.length <= 6) {
          newVal = newVal.replace(/^(\d{0,3})(\d{0,3})/, '($1) $2');
        } else {
          newVal = newVal.replace(/^(\d{0,3})(\d{0,3})(.*)/, '($1) $2-$3');
        }

      }
      this.registerForm.controls['fax'].setValue(newVal, { emitEvent: false });
    });
  }

}


/**
 * Confirm password validator
 *
 * @param {AbstractControl} control
 * @returns {ValidationErrors | null}
 */

export const confirmPasswordValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {

  if (!control.parent || !control) {
    return null;
  }

  const password = control.parent.get('password');
  const passwordConfirm = control.parent.get('passwordConfirm');

  if (!password || !passwordConfirm) {
    return null;
  }

  if (passwordConfirm.value === '') {
    return null;
  }

  if (password.value === passwordConfirm.value) {
    return null;
  }

  return { passwordsNotMatching: true };
};



