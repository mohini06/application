import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';
import {MatCardModule} from '@angular/material/card';
import { FuseSharedModule } from '@fuse/shared.module';
import {MatFormFieldModule} from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatOptionModule } from '@angular/material/core';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatInputModule } from '@angular/material/input';
import { ProfileComponent } from 'app/main/pages/profile/profile.component';
import { ProfileService } from './profile.service';
import { FileUploadModule } from 'ng2-file-upload';
import { AuthGuard } from 'app/_guard/auth.guard';
import { UpdatepswdComponent } from './updatepswd/updatepswd.component';
import { FuseConfirmDialogModule } from '@fuse/components/confirm-dialog/confirm-dialog.module';

const routes = [
    {
        path     : 'profile',
        component: ProfileComponent,canActivate: [AuthGuard],
    }
];

@NgModule({
    declarations: [
        ProfileComponent,
        UpdatepswdComponent,
    ],
    imports     : [
        RouterModule.forChild(routes),
        FuseConfirmDialogModule,
        MatButtonModule,
        MatDividerModule,
        MatIconModule,
        MatTabsModule,
        FuseSharedModule,
        MatCardModule,
        MatFormFieldModule,
        MatSelectModule, 
        MatOptionModule,
        MatCheckboxModule,
        MatInputModule,
        FileUploadModule
    ],
    providers   : [
        ProfileService
    ],
    entryComponents:[UpdatepswdComponent]
})
export class ProfileModule
{
}
