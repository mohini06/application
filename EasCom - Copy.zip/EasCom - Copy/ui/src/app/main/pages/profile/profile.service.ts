import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from 'environments/environment';
import { map } from 'rxjs/operators';

@Injectable()
export class ProfileService 
{
    updateData(formData: FormData, id: any) {
      throw new Error("Method not implemented.");
    }
    private pathUrl=environment.urlPath;

    constructor(
        private _httpClient: HttpClient
    ){}
 
    getProfile(user: string) {
        return this._httpClient.get<any>(this.pathUrl + "/login/profile?user=" + user)
    }

    updateProfile(registerForm:any)
    {
       return this._httpClient.post<any>(this.pathUrl+"/login/update",registerForm)
      .pipe(map( updateProfile => {
       return updateProfile;
       }));
    }

}
