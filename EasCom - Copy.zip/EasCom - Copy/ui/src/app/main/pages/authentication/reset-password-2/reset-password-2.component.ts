import { Component, Input, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/internal/operators';
import { FuseConfigService } from '@fuse/services/config.service';
import { fuseAnimations } from '@fuse/animations';
import { ResetPassword2Service } from './reset-password-2.service';
import { Router } from '@angular/router';
import { MatSnackBarConfig, MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';
import { Data } from '../../homecontent/data';


@Component({
    selector     : 'reset-password-2',
    templateUrl  : './reset-password-2.component.html',
    styleUrls    : ['./reset-password-2.component.scss'],
    encapsulation: ViewEncapsulation.None,
    animations   : fuseAnimations
})
export class ResetPassword2Component implements OnInit, OnDestroy
{
    @Input() email: any;
    @Input() otp: any;
    resetPasswordForm: FormGroup;

    
    // forgot pssword button
    hide = true;

    // Private
    horizontalPosition: MatSnackBarHorizontalPosition = 'right';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    private _unsubscribeAll: Subject<any>;

    constructor(
        private _fuseConfigService: FuseConfigService,
        private _formBuilder: FormBuilder,
        private resetpasswordService: ResetPassword2Service,
        private router:Router,
        private _snackBar: MatSnackBar,

    )
    {
        // Configure the layout
        this._fuseConfigService.config = {
            layout: {
                navbar   : {
                    hidden: true
                },
                toolbar  : {
                    hidden: true
                },
                footer   : {
                    hidden: true
                },
                sidepanel: {
                    hidden: true
                }
            }
        };

        // Set the private defaults
        this._unsubscribeAll = new Subject();
    }

    /**
     * On init
     */

    ngOnInit(): void
    {
        console.log(this.email)
        console.log(this.otp)
        this.resetPasswordForm = this._formBuilder.group({
            emailId         : ['', [Validators.required, Validators.email]],
            code            : ['', [Validators.required],[this.otpValidation.bind(this)]],
            password        : ['', Validators.required],
            passwordConfirm : ['', [Validators.required, confirmPasswordValidator]]
        });

        this.resetPasswordForm.get("emailId").setValue(this.email);
    }
    
    otpValidation(control: AbstractControl)
    {
        this.resetPasswordForm.get('code').setErrors(null);
    }

    /**
     * On destroy
     */

    ngOnDestroy(): void
    {
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

    submit() {

        if (!this.resetPasswordForm.valid) {
          return;
        } 
        else{
            this.resetPassword(); 
        }
    }
    
    openSnackBar(msg:any) {
        let config = new MatSnackBarConfig();
        config.panelClass = 'center';
        this._snackBar.open(msg, 'X', {
          duration: 1500,
         horizontalPosition: this.horizontalPosition,
         verticalPosition: this.verticalPosition,
        });
      }
 
    get emailId() { return this.resetPasswordForm.get('emailId') };
    get code() { return this.resetPasswordForm.get('code') };
    get password() { return this.resetPasswordForm.get('password') };
    get passwordConfirm() { return this.resetPasswordForm.get('passwordConfirm') };

    resetPassword() {
       
        const formData = new FormData();
        formData.append("email", this.emailId.value);
        formData.append("otp", this.code.value);
        formData.append("newpassword", this.password.value);
        formData.append("confirmpassword", this.passwordConfirm.value);
        console.log(formData)
        this.resetpasswordService.resetForgotPass(formData)
        .subscribe(data => {
            if(data.statusCode==200)
           {
            this.openSnackBar('Password changed successfully...!');
            this.router.navigate(['/pages/auth/login-2']);
           }
           else {
            
            this.resetPasswordForm.get('code').setErrors({ otpInvalid: true });
            return;
           }
        },
        error => {
        this.openSnackBar('Invalid Validate Code...!');
         error.statusMsg();
         this.router.navigate(['/pages/auth/forgot-password-2']);
         return
                      
        });
    }
      
}

/**
 * Confirm password validator
 *
 * @param {AbstractControl} control
 * @returns {ValidationErrors | null}
 */

export const confirmPasswordValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {

    if ( !control.parent || !control )
    {
        return null;
    }

    const password = control.parent.get('password');
    const passwordConfirm = control.parent.get('passwordConfirm');

    if ( !password || !passwordConfirm )
    {
        return null;
    }

    if ( passwordConfirm.value === '' )
    {
        return null;
    }

    if ( password.value === passwordConfirm.value )
    {
        return null;
    }

    return {passwordsNotMatching: true};
};
