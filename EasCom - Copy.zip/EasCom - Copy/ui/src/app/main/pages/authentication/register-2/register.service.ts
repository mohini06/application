import { Injectable } from '@angular/core';
import { HttpClient, HttpBackend } from '@angular/common/http';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot, Router } from '@angular/router';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from 'environments/environment';

@Injectable()
export class RegisterService
{
    private pathUrl=environment.urlPath;
  

    constructor(private http:HttpClient, private router : Router,private handler:HttpBackend) {
      this.http = new HttpClient(handler);
     }
     
    getComboList(type: string) {
      return this.http.get<any>(this.pathUrl + "/vendor/combolist?type=" + type)
    }
  
    getRoles() {
      return this.http.get<any>(this.pathUrl + "/login/roles")
    }

    register(user) {
      return this.http.post<any>(this.pathUrl + "/login/register", {
        "username": user.username, "password": user.password, "userTypeId": user.userType,
        "firstname": user.firstname, "lastname": user.lastname, "email": user.email,
        "address": user.address, "phone": user.phonenumber, "title": user.title, "fax": user.fax, "statusId": user.statusType
      })
        .pipe(map(signUp => {
          return signUp;
        }));
    }
  
    validateUser(username:any) {
      return this.http.post<any>(this.pathUrl + "/login/isvaliduser", { "username": username })
        .pipe(map(validateUser => {
          return validateUser;
        }));
    }
    validateEmail(email:any)
    {
      return this.http.post<any>(this.pathUrl + "/login/isvalidEmail", { "email": email })
        .pipe(map(validateEmail => {
          return validateEmail;
        }));
    }
    

}
