import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { FuseConfigService } from '@fuse/services/config.service';
import { fuseAnimations } from '@fuse/animations';
import { ForgotPassword2Service } from './forgot-password-2.service';
import { Router } from '@angular/router';
import { AbstractControl, ValidationErrors, ValidatorFn, FormControl } from '@angular/forms';

@Component({
    selector     : 'forgot-password-2',
    templateUrl  : './forgot-password-2.component.html',
    styleUrls    : ['./forgot-password-2.component.scss'],
    encapsulation: ViewEncapsulation.None,
    animations   : fuseAnimations
})
export class ForgotPassword2Component implements OnInit
{
    forgotPasswordForm: FormGroup;
      otpRes:any;
      forgotemail:any;
      showForgotPaswrd:boolean=true;
      showReset:boolean=false;
    /**
     * Constructor
     *
     * @param {FuseConfigService} _fuseConfigService
     * @param {FormBuilder} _formBuilder
     */
    constructor(
        private _fuseConfigService: FuseConfigService,
        private _formBuilder: FormBuilder,
        private forgotPaswdService:ForgotPassword2Service,
        private router:Router
    )
    {
        // Configure the layout
        this._fuseConfigService.config = {
            layout: {
                navbar   : {
                    hidden: true
                },
                toolbar  : {
                    hidden: true
                },
                footer   : {
                    hidden: true
                },
                sidepanel: {
                    hidden: true
                }
            }
        };
    }

    ngOnInit(): void
    {
        this.forgotPasswordForm = this._formBuilder.group({
            email: ['', [Validators.required], [this.emailValidate.bind(this)]]
        });
    }

    get email() { return this.forgotPasswordForm.get('email') };

    emailValidate(control: AbstractControl)
    {
      this.forgotPasswordForm.get('email').setErrors(null);
    }

    submit() {

        if (!this.forgotPasswordForm.valid) {
          return;
        } 

        this.forgotemail=this.forgotPasswordForm.value.email
        const formDataForgotPaswd = new FormData();
        formDataForgotPaswd.append('email',this.email.value);
 
         this.forgotPaswdService.forgot(formDataForgotPaswd)
         .subscribe(data => {
           console.log(data.statusMsg)
           if(data.statusCode==200)
           {
            this.otpRes=data.statusMsg;
            // this.router.navigate(['pages/auth/reset-password-2']);
            this.showForgotPaswrd=false;
            this.showReset=true;
           }
           else {
            this.forgotPasswordForm.get('email').setErrors({ emailValidate: true });
            return;
           }
        },
        error => {    
            this.forgotPasswordForm.get('email').setErrors({ emailValidate: true });
            return;  
        });
      }
}
