import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators, FormControl } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { FuseConfigService } from '@fuse/services/config.service';
import { fuseAnimations } from '@fuse/animations';

import { Router } from '@angular/router';
import { RegisterService } from './register.service';
import { map } from 'rxjs/operators';
import { of } from 'rxjs';
export interface Status {
    value: number;
    viewValue: string;
}

export interface Usertye {
    value: number;
    viewValue: string;
}
@Component({
    selector: 'register-2',
    templateUrl: './register-2.component.html',
    styleUrls: ['./register-2.component.scss'],
    encapsulation: ViewEncapsulation.None,
    animations: fuseAnimations
})
export class Register2Component implements OnInit, OnDestroy {
    selectedCar: string;
    registerForm: FormGroup;
    userTypeData :any;
    statusTypeData: any;
    isSubmitted: any = false;
    message: any;

    // Private
    private _unsubscribeAll: Subject<any>;

    constructor(
        private _fuseConfigService: FuseConfigService,
        private _formBuilder: FormBuilder,
        private registerService: RegisterService,
        private router: Router
    ) {
        this._fuseConfigService.config = {
          layout: {
              navbar: {
                  hidden: true
              },
              toolbar: {
                  hidden: true
              },
              footer: {
                  hidden: true
              },
              sidepanel: {
                  hidden: true
              }
          }
        };
        this._unsubscribeAll = new Subject();
    }

    /**
     * On init
     */

    ngOnInit(): void {
        this.registerForm = this._formBuilder.group({
            username: ['', [Validators.required,Validators.maxLength(32), Validators.minLength(8)],[this.ValidateUsername.bind(this)]],
            email: ['', [Validators.required, Validators.email],[this.ValidateEmail.bind(this)]],
            password: ['', [Validators.required,Validators.maxLength(32), Validators.minLength(8)]],
            title: [''],
            firstname: ['', Validators.required],
            lastname: ['', Validators.required],
            address: [''],
            phoneNumber: ['',[Validators.pattern(/^\(\d{3}\)\s\d{3}-\d{4}$/)]],
            fax: [''],
            userType: ["", Validators.required],
            statusType: ["", Validators.required],
        }
    
      );
      this.getuserType();
      this.getStatus('status');
      this.phoneValidate();
      this.faxValidate();
    }

    ValidateEmail(control: AbstractControl)
    {
      if (control.value) {
        this.registerService.validateEmail(control.value)
        .subscribe(data => {
          console.log(data)
          if(data.statusCode=="401")
          {
            this.registerForm.get('email').setErrors(null)
          }
          else if(data.statusCode=="200")
          {
          this.registerForm.get('email').setErrors({ emailExist: true });

          }
          else {
            return null;
          }
        },
        error => {
          return  null;
        });     
      }
      return null;
    }

  ValidateUsername(control: AbstractControl)
    {
      if (control.value) {
      this.registerService.validateUser(control.value)
      .subscribe(data => {
      if(data.statusCode=="401")
      {
        this.registerForm.get('username').setErrors(null)
      }
     else if(data.statusCode=="200")
     {
      this.registerForm.get('username').setErrors({ userNameExist: true });
     }
     else{
       return null;
      }
        },
        error => {
          return null;
        });     
      }
      return null;
    }
  
    phoneValidate(){
      const phoneControl:AbstractControl = this.registerForm.controls['phoneNumber'];
  
      phoneControl.valueChanges.subscribe(data => {
      
      let preInputValue:string = this.registerForm.value.phoneNumber;
      let lastChar:string = preInputValue.substr(preInputValue.length - 1);
  
      var newVal = data.replace(/\D/g, '');
      if (data.length < preInputValue.length) {
  
        if(lastChar == ')'){
           newVal = newVal.substr(0,newVal.length-1); 
        }
        if (newVal.length == 0) {
          newVal = '';
        } 
        else if (newVal.length <= 3) {
        
          newVal = newVal.replace(/^(\d{0,3})/, '($1');
        } else if (newVal.length <= 6) {
          newVal = newVal.replace(/^(\d{0,3})(\d{0,3})/, '($1) $2');
        } else {
          newVal = newVal.replace(/^(\d{0,3})(\d{0,3})(.*)/, '($1) $2-$3');
        }
      } else{
  
      if (newVal.length == 0) {
        newVal = '';
      } 
      else if (newVal.length <= 3) {
        newVal = newVal.replace(/^(\d{0,3})/, '($1)');
      } else if (newVal.length <= 6) {
        newVal = newVal.replace(/^(\d{0,3})(\d{0,3})/, '($1) $2');
      } else {
        newVal = newVal.replace(/^(\d{0,3})(\d{0,3})(.*)/, '($1) $2-$3');
      }
  
    }
    this.registerForm.controls['phoneNumber'].setValue(newVal,{emitEvent: false});
    });
   }

   faxValidate(){
    const faxControl:AbstractControl = this.registerForm.controls['fax'];

    faxControl.valueChanges.subscribe(data => {
    
    let preInputValue:string = this.registerForm.value.fax;
    let lastChar:string = preInputValue.substr(preInputValue.length - 1);

    var newVal = data.replace(/\D/g, '');
    
    if (data.length < preInputValue.length) {

      if(lastChar == ')'){
         newVal = newVal.substr(0,newVal.length-1); 
      }
      if (newVal.length == 0) {
        newVal = '';
      } 
      else if (newVal.length <= 3) {
        
        newVal = newVal.replace(/^(\d{0,3})/, '($1');
      } else if (newVal.length <= 6) {
        newVal = newVal.replace(/^(\d{0,3})(\d{0,3})/, '($1) $2');
      } else {
        newVal = newVal.replace(/^(\d{0,3})(\d{0,3})(.*)/, '($1) $2-$3');
      }
    
    } else{

    if (newVal.length == 0) {
      newVal = '';
    } 
    else if (newVal.length <= 3) {
      newVal = newVal.replace(/^(\d{0,3})/, '($1)');
    } else if (newVal.length <= 6) {
      newVal = newVal.replace(/^(\d{0,3})(\d{0,3})/, '($1) $2');
    } else {
      newVal = newVal.replace(/^(\d{0,3})(\d{0,3})(.*)/, '($1) $2-$3');
    }
  }
  this.registerForm.controls['fax'].setValue(newVal,{emitEvent: false});
  });
 }
  public hasError = (controlName: string, errorName: string) =>{
      return this.registerForm.controls[controlName].hasError(errorName);
    }

    get username() { return this.registerForm.get('username') };
    get password() { return this.registerForm.get('password') };
    get userType() { return this.registerForm.get('userType') };
    get firstname() { return this.registerForm.get('firstname') };
    get lastname() { return this.registerForm.get('lastname') };
    get email() { return this.registerForm.get('email') };
    get title() { return this.registerForm.get('title') };
    get fax() { return this.registerForm.get('fax') };
    get phonenumber() { return this.registerForm.get('phonenumber') };
    get statusType() { return this.registerForm.get('statusType') };

    getuserType() {	
        this.registerService.getRoles().subscribe(data => {	
          this.userTypeData = data;	
        });	
      }
    
    getStatus(type: string) {
        this.registerService.getComboList(type).subscribe(data => {
          this.statusTypeData = data;
        });
    }

    register() {
        this.isSubmitted = true;
        if (!this.registerForm.valid) {
          return;
        }
        else {
        
          this.registerService.register(this.registerForm.value)
            .subscribe(data => {
              this.message = "";
              this.router.navigate(['/pages/auth/login-2']);
            },
              error => {
                this.message = error.error.message;
              });
        }
      }

      validateUser(){
        return (formGroup: FormGroup) => {
        const control = formGroup.controls['username'];
        this.registerService.validateUser(this.registerForm.value)
        .subscribe(data => {
        this.registerForm.get('username').setErrors({ userNameExist: false })
        this.registerForm.get('username').updateValueAndValidity();
        },
          error => {
            this.registerForm.get('username').setErrors({ userNameExist: true });
            this.registerForm.get('username').updateValueAndValidity();
          });
        }
      }
      validateMail(){
        this.registerService.validateEmail(this.registerForm.value)
        .subscribe(data => {
          this.message = "";
        },
        error => {
          this.message = "Email already exists";
          console.log(error.error);
        });
      }

    /**
     * On destroy
     */

    ngOnDestroy(): void {
      this._unsubscribeAll.next();
      this._unsubscribeAll.complete();
    }
}

/**
 * Confirm password validator
 *
 * @param {AbstractControl} control
 * @returns {ValidationErrors | null}
 */

export const confirmPasswordValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {

  if (!control.parent || !control) {
      return null;
  }

  const password = control.parent.get('password');
  const passwordConfirm = control.parent.get('passwordConfirm');

  if (!password || !passwordConfirm) {
      return null;
  }

  if (passwordConfirm.value === '') {
      return null;
  }

  if (password.value === passwordConfirm.value) {
      return null;
  }

  return { passwordsNotMatching: true };
};
