import { Injectable } from '@angular/core';
import { HttpClient, HttpBackend } from '@angular/common/http';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot, Router } from '@angular/router';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from 'environments/environment';

@Injectable()
export class LoginService
{
    private pathUrl=environment.urlPath;
  

    constructor(private http:HttpClient, private router : Router,private handler:HttpBackend) {
      this.http = new HttpClient(handler);
     }
     
    login(user)
    {
        return this.http.post<any>(this.pathUrl+"/login/validateuser",{"username":user.userName,"password":user.password})
        .pipe(map(login => {
          return login;
      }));
    }   

}
