import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FuseConfigService } from '@fuse/services/config.service';
import { fuseAnimations } from '@fuse/animations';
import * as jwt_decode from "jwt-decode";
import { Router } from '@angular/router';
import { LoginService } from './login.service';

@Component({
    selector: 'login-2',
    templateUrl: './login-2.component.html',
    styleUrls: ['./login-2.component.scss'],
    encapsulation: ViewEncapsulation.None,
    animations: fuseAnimations
})
export class Login2Component implements OnInit {
    loginForm: FormGroup;
    isSubmitted: boolean = false;
    message: String;
    returnUrl: String;

    /**
     * Constructor
     *
     * @param {FuseConfigService} _fuseConfigService
     * @param {FormBuilder} _formBuilder
     */
    constructor(
        private _fuseConfigService: FuseConfigService,
        private _formBuilder: FormBuilder,
        private router: Router,
        private loginService: LoginService
    ) {
        // Configure the layout
        this._fuseConfigService.config = {
            layout: {
                navbar: {
                    hidden: true
                },
                toolbar: {
                    hidden: true
                },
                footer: {
                    hidden: true
                },
                sidepanel: {
                    hidden: true
                }
            }
        };


    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void {
        this.loginForm = this._formBuilder.group({
            userName: ['', [Validators.required,Validators.maxLength(32), Validators.minLength(8)]],
            password: ['', [Validators.required, Validators.maxLength(32), Validators.minLength(8)]]
        });
        localStorage.removeItem("authKey");
        localStorage.removeItem("user");
    }

    public hasError = (controlName: string, errorName: string) =>{
        return this.loginForm.controls[controlName].hasError(errorName);
      }

    get userName() { return this.loginForm.get('userName') };
    get password() { return this.loginForm.get('password') };

    login() {
        this.message = "";
        this.isSubmitted = true
        if (!this.loginForm.valid) {
            return;
        } else {
            this.loginService.login(this.loginForm.value)
                .subscribe(data => {
                    localStorage.setItem("authKey", data.token);
                    let tokenInfo = jwt_decode(data.token);
                    localStorage.setItem("user",tokenInfo.sub);
                    this.router.navigate(['pages/homepage']);
                },
                    error => {
                        this.message = "Invalid Username/Password";
                        console.log(this.message);
                    });
        }
    }
}
