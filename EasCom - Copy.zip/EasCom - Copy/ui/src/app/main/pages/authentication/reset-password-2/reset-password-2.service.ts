import { Injectable } from '@angular/core';
import { HttpClient, HttpBackend } from '@angular/common/http';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot, Router } from '@angular/router';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from 'environments/environment';
import { ResetPassword2Component } from '../reset-password-2/reset-password-2.component';

@Injectable({
  providedIn: 'root'
})
export class ResetPassword2Service {
  private pathUrl=environment.urlPath;

  constructor(private http:HttpClient, private router : Router,private handler:HttpBackend) {
    this.http = new HttpClient(handler) }

    resetForgotPass(resetForgotForm:any)
    {
      return this.http.post<any>(this.pathUrl+"/login/savenewpwd",resetForgotForm)
      .pipe(map(resetForgotPass => {
        return resetForgotPass;
      }));
    }  
   
}
