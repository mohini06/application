export class Data {  
    item :string;  
    count:Number;  
  }