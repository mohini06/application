import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomecontentComponent } from './homecontent.component';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import {MatChipsModule} from '@angular/material/chips';
import { MatInputModule } from '@angular/material/input';
import { FuseSharedModule } from '@fuse/shared.module';
import { FuseCountdownModule, FuseWidgetModule } from '@fuse/components';
import { HomeDashboardService } from './analytics.service';
import { MatMenuModule } from '@angular/material/menu';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';
import { AgmCoreModule } from '@agm/core';
import { ChartsModule } from 'ng2-charts';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { AuthGuard } from 'app/_guard/auth.guard';

const routes = [
  {
      path     : 'homepage',
      component: HomecontentComponent,canActivate: [AuthGuard],
       resolve  : {
        data: HomeDashboardService
    }
  }
];
@NgModule({
  declarations: [HomecontentComponent],
  imports: [
    RouterModule.forChild(routes),

    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatMenuModule,
    MatSelectModule,
    MatTabsModule,
    MatChipsModule,

    AgmCoreModule.forRoot({
        apiKey: 'AIzaSyD81ecsCj4yYpcXSLFcYU97PvRsE_X8Bx8'
    }),
    ChartsModule,
    NgxChartsModule,

    FuseSharedModule,
    FuseWidgetModule,
    NgxDatatableModule,

],
providers   : [
  HomeDashboardService
] 
})
export class HomecontentModule { }
