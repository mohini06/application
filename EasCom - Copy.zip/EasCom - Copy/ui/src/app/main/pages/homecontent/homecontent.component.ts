import { Component, OnInit, ViewEncapsulation } from '@angular/core';

import { FuseConfigService } from '@fuse/services/config.service';
import { fuseAnimations } from '@fuse/animations';
import { HomeDashboardService } from './analytics.service';
import { Data } from './data';

@Component({
  selector: 'app-homecontent',
  templateUrl: './homecontent.component.html',
  styleUrls: ['./homecontent.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations
})
export class HomecontentComponent implements OnInit {

  page = {
    limit: 7,
    count: 0,
    offset: 0,
    orderBy: 'item',
    orderDir: 'desc'
  };

  widgets: any;
  public contractCount: any;
  public insuranceCount: any;
  public invoiceCount: any;
  public financialCount: any;
  Label = [];
  Count = [];
  rows = [];
  public chartLabels: Array<any>;
  public chartDatasets: Array<any>;
  canvas: any
  ctx: any;
  gradientVal: any;

  canvas2: any
  ctx2: any;
  gradientVal2: any;

  canvas3: any
  ctx3: any;
  gradientVal3: any;

  canvas4: any
  ctx4: any;
  gradientVal4: any;


  canvas5: any
  ctx5: any;
  gradientVal5: any;
  /**
     * Constructor
     *
     * @param {FuseConfigService} _fuseConfigService
     * @param {HomeDashboardService} _analyticsDashboardService
     
     */

  constructor(
    private _fuseConfigService: FuseConfigService,
    private _analyticsDashboardService: HomeDashboardService
  ) {
    this._registerCustomChartJSPlugin();
    this._fuseConfigService.config = {
      layout: {
        navbar: {
          hidden: false
        },
        toolbar: {
          hidden: false
        },
        footer: {
          hidden: true
        },
        sidepanel: {
          hidden: true
        }
      }
    };
  }

  ngOnInit() {
    this.countData("30");
    this.renderBarchart();
    this.chartLabels = this.Label;
    this.chartDatasets = [
      { data: this.Count }
    ];
    this.pageCallback({ offset: 0 });
    this.widgets = this._analyticsDashboardService.widgets;
    console.log(this.widgets.widget2.colors)

    this.canvas = document.getElementById("mycanvas");
    this.ctx = this.canvas.getContext("2d");
    this.gradientVal = this.ctx.createLinearGradient(0, 0, 0, 90);
    this.gradientVal.addColorStop(0.2, "#9F8FCE");
    this.gradientVal.addColorStop(1, "#fff");
    this.widgets.widget2.colors[0].backgroundColor = this.gradientVal;
    this.widgets.widget2.colors[0].borderColor = "#9F8FCE";

    this.canvas2 = document.getElementById("mycanvas2");
    this.ctx2 = this.canvas2.getContext("2d");
    this.gradientVal2 = this.ctx2.createLinearGradient(0, 0, 0, 90);
    this.gradientVal2.addColorStop(0.2, "#4A86E3");
    this.gradientVal2.addColorStop(1, "#fff");
    this.widgets.widget3.colors[0].backgroundColor = this.gradientVal2;
    this.widgets.widget3.colors[0].borderColor = "#4A86E3";

    this.canvas3 = document.getElementById("mycanvas3");
    this.ctx3 = this.canvas3.getContext("2d");
    this.gradientVal3 = this.ctx3.createLinearGradient(0, 0, 0, 90);
    this.gradientVal3.addColorStop(0.2, "#EF82B2");
    this.gradientVal3.addColorStop(1, "#fff");
    this.widgets.widget4.colors[0].backgroundColor = this.gradientVal3;
    this.widgets.widget4.colors[0].borderColor = "#EF82B2";

    this.canvas4 = document.getElementById("mycanvas4");
    this.ctx4 = this.canvas4.getContext("2d");
    this.gradientVal4 = this.ctx4.createLinearGradient(0, 0, 0, 90);
    this.gradientVal4.addColorStop(0.2, "#5491CE");
    this.gradientVal4.addColorStop(1, "#fff");
    this.widgets.widget15.colors[0].backgroundColor = this.gradientVal4;
    this.widgets.widget15.colors[0].borderColor = "#5491CE";


    this.canvas5 = document.getElementById("mycanvas5");
    this.ctx5 = this.canvas5.getContext("2d");
    this.gradientVal5 = this.ctx5.createLinearGradient(0, 0, 0, this.ctx5.canvas5.width);
    this.gradientVal5.addColorStop(0.5, "#a9d3e4");
    this.gradientVal5.addColorStop(1, "#88a4c3");
    this.widgets.widget5.colors[0].backgroundColor = this.gradientVal5;
    this.widgets.widget5.colors[0].borderColor = "";


    // this.ctx.fillStyle = this.gradientVal;
    console.log(this.gradientVal)
  }

  onDayChange(ob) {
    let day = ob.value;
    this.countData(day);
  }

  countData(day: any) {
    this._analyticsDashboardService.getCountData(day).subscribe(data => {
      this.contractCount = data[0].count;
      this.insuranceCount = data[1].count;
      this.invoiceCount = data[2].count;
      this.financialCount = data[3].count;
    });
  }

  renderBarchart() {
    // console.log(this.widgets.widget5.options)
    this._analyticsDashboardService.getBarData().subscribe(
      (result: Data[]) => {
        if(result.length>0)
        {
          result.forEach(x => {
            this.Label.push(x.item);
            this.Count.push(x.count);
          })
          // this.Label.push(); 
          // this.Count.push(1,2,3,4,5,6);
        }
        else {
          this.Label.push(); 
          this.Count.push(1,2,3,4,5,6,7);
        }
    
      console.log(result);

    });

  }

  pageCallback(pageInfo: { count?: number, pageSize?: number, limit?: number, offset?: number }) {
    this.page.offset = pageInfo.offset;
    this.reloadTable();
  }

  sortCallback(sortInfo: { sorts: { dir: string, prop: string }[], column: {}, prevValue: string, newValue: string }) {
    // there will always be one "sort" object if "sortType" is set to "single"
    this.page.orderDir = sortInfo.sorts[0].dir;
    this.page.orderBy = sortInfo.sorts[0].prop;
    this.reloadTable();
  }

  reloadTable() {
    this._analyticsDashboardService.getPnpList(this.page.limit,this.page.offset,this.page.orderBy,this.page.orderDir)
      .subscribe(data => {
        this.page.count = data === null ? 0 : data[0].total;
        this.rows = data;
      })
  }

  private _registerCustomChartJSPlugin(): void {
    (window as any).Chart.plugins.register({
      afterDatasetsDraw: function (chart, easing): any {
        // Only activate the plugin if it's made available
        // in the options
        if (
          !chart.options.plugins.xLabelsOnTop ||
          (chart.options.plugins.xLabelsOnTop && chart.options.plugins.xLabelsOnTop.active === false)
        ) {
          return;
        }

        // To only draw at the end of animation, check for easing === 1
        const ctx = chart.ctx;

        chart.data.datasets.forEach(function (dataset, i): any {
          const meta = chart.getDatasetMeta(i);
          if (!meta.hidden) {
            meta.data.forEach(function (element, index): any {

              // Draw the text in black, with the specified font
              ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
              const fontSize = 13;
              const fontStyle = 'normal';
              const fontFamily = 'Roboto, Helvetica Neue, Arial';
              ctx.font = (window as any).Chart.helpers.fontString(fontSize, fontStyle, fontFamily);

              // Just naively convert to string for now
              const dataString = dataset.data[index].toString() + 'k';

              // Make sure alignment settings are correct
              ctx.textAlign = 'center';
              ctx.textBaseline = 'middle';
              const padding = 15;
              const startY = 24;
              const position = element.tooltipPosition();
              ctx.fillText(dataString, position.x, startY);

              ctx.save();

              ctx.beginPath();
              ctx.setLineDash([5, 3]);
              ctx.moveTo(position.x, startY + padding);
              ctx.lineTo(position.x, position.y - padding);
              ctx.strokeStyle = 'rgba(255,255,255,0.12)';
              ctx.stroke();

              ctx.restore();
            });
          }
        });
      }
    });
  }
}
