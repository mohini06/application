import { NgModule } from '@angular/core';

import { Login2Module } from 'app/main/pages/authentication/login-2/login-2.module';
import { Register2Module } from 'app/main/pages/authentication/register-2/register-2.module';
import { ForgotPassword2Module } from 'app/main/pages/authentication/forgot-password-2/forgot-password-2.module';
import { ResetPasswordModule } from 'app/main/pages/authentication/reset-password/reset-password.module';
import { ResetPassword2Module } from 'app/main/pages/authentication/reset-password-2/reset-password-2.module';
import { LockModule } from 'app/main/pages/authentication/lock/lock.module';
import { MailConfirmModule } from 'app/main/pages/authentication/mail-confirm/mail-confirm.module';
import { ComingSoonModule } from 'app/main/pages/coming-soon/coming-soon.module';
import { Error404Module } from 'app/main/pages/errors/404/error-404.module';
import { Error500Module } from 'app/main/pages/errors/500/error-500.module';
import { ProfileModule } from 'app/main/pages/profile/profile.module';
import { HomecontentModule } from './homecontent/homecontent.module';
import { RouterModule, Routes } from '@angular/router';
import { Login2Component } from './authentication/login-2/login-2.component';



const routes: Routes = [
    {
        path      : '',
        component:Login2Component,
       }
];
@NgModule({
    imports: [
        Login2Module,
        Register2Module,
        ForgotPassword2Module,
        ResetPassword2Module,
        ProfileModule,
        HomecontentModule,
        RouterModule.forChild(routes),
    ],
    
    declarations: []
})
export class PagesModule
{

}
