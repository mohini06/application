import { HttpClient, HttpBackend } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MasterService {

  private pathUrl = environment.urlPath;

  constructor(private http: HttpClient, private handler: HttpBackend) {
    this.http = new HttpClient(handler);
  }

  getComboList(type: string) {
    return this.http.get<any>(this.pathUrl + "/vendor/combolist?type=" + type)
  }

}
