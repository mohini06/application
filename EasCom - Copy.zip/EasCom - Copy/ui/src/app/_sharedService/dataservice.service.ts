import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataserviceService {
  private selectedParamSource = new BehaviorSubject<any>('');
  searchValue = this.selectedParamSource.asObservable();
  constructor() { }

  searchdata(data: any,type,displayDashboard?) {
    this.selectedParamSource.next({data:data,type:type,displaydashboard:displayDashboard})
  }

}
