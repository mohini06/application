
# Vendor Vetting --Frontend
 
 # Fuse - Angular Theme

   Material Design Admin Template with Angular 8 and Angular Material


# Application Dir
              src
              |__app-
                  |__ _guard 
                  |__ _helpers
                  |__ _sharedService
                  |__ fuse-config
                  |__ layout
                  |__  main-
                        |__questionnaire
                        |       |_question
                        |       |_questionlist
                        |       |_template
                        |       |_templates
                        |       |_questionnaire.module.ts
                        |__master
                        |       |__Add-edit-vendor 
                        |       |__Vendorlist
                        |       |__Vendorview
                        |       |__master.module.ts
                        |
                        |
                        |__pages 
                        |        |__authentication
                        |       |                   |__forgot-password-2
                        |       |                   |__register-2
                        |       |                   |__reset-password-2
                        |       |                   |__login-2
                        |       |__homecontent
                        |       |__profile
                        |__vendorsview_component
                        |       |__contact
                        |       |__contracts
                        |       |__Financials
                        |       |__Incidents
                        |       |__insurances
                        |       |__Invoices
                        |       |__pandp
                        |       |__questionnairelist
                        |       |__Questionnaires
                    |__app.component.html
                    |__app.component.scss
                    |__app.module.ts
                    |__app.theme.scss
                    |__environments
                    |          |__environment.prod.ts
                    |          |__environment.ts
                  __|__

## Third Party dependency library
 * Angular Material
 * swimlane/ngx-datatable
 * ng2-file-upload
 * chart.js
 * file-saver
 * perfect-scrollbar
 * jwt-decode
 

## Installtion of dependency library

Run  `npm install` to install all dependencies.
## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

# Vendor Vetting --Backend

# Spring Boot Application

# Application Dir
         src
          |__main
               |__java
                    |__com
                        |__datatemplate
                               |_common
                               |    |_Mailer
                               |	  |_Search
                               |    |_SearchCriteria
                               |    |_User
                               |_config
                               |    |_Iconstatnts
                               |    |_JwtAuthenticationEntryPoint
                               |    |_JwtRequestFilter
                               |    |_JwtTokenUtil
                               |    |_MvcConfig
                               |    |_Securityconfig
                               |_constatnts
                               |    |_SQLConstants
                               |_controller
                               |    |_ContactController
                               |    |_ContractController
                               |    |_DashBoardController
                               |    |_FinancialController
                               |    |_IncidentController
                               |    |_InsuranceController
                               |    |_InvoiceController
                               |    |_LoginController
                               |    |_PoliciesController
                               |    |_QuestControllerController
                               |    |_SimpleCORSFilterController
                               |    |_TemplateController
                               |    |_VendorControllerController
                               |_dao
                               |   |_impl
                               |        |_ComboListDAOImpl
                               |        |_CommonDAOImpl
                               |        |_ContactDAOImpl
                               |        |_ContractDAOImpl
                               |        |_FinancialDAOImpl
                               |        |_IncidentDAOImpl
                               |        |_InsuranceDAOImpl
                               |        |_InvoiceDAOImpl
                               |        |_LoginDAOImpl
                               |        |_PoliciesDAOImpl
                               |        |_QuestionnairesDAOImpl
                               |        |_TemplateDAOImpl
                               |        |_VendorDAOImpl
                               |   |_ComboListDAO
                               |   |_CommonDAO
                               |   |_ContactDAO
                               |	 |_ContractDAO
                               |   |_FinancialDAO
                               |	 |_IncidentDAO
                               |   |_InsuranceDAO
                               |	 |_InvoiceDAO
                               |   |_LoginDAO
                               |	 |_PoliciesDAO
                               |	 |_QuestionnairesDAO
                               |	 |_TemplateDAO
                               |	 |_UserDAO
                               |	 |_VendorDAO
                               |_dto
                               |   |_Answers	
                               |   |_ComboList
                               |   |_Contract
                               |   |_Finance
                               |   |_Graph
                               |   |_Incident
                               |   |_Insurance
                               |   |_Invoice
                               |   |_JwtRequest
                               |	 |_JwtResponse
                               |	 |_Role
                               |	 |_PoliciesAndProcedures
                               |	 |_Questionnaire
                               |	 |_Template	
                               |	 |_User	
                               |	 |_Vendor	
                               |	 |_VendorContacts	
                               |_entity
                               |   |_Error	
                               |   |_Vendorview
                               |_exception
                               |   |_GlobalExceptionHandler
                               |   |_GpxBussinessExceptionhandelr
                               |_jwt
                               |   |_model	
                               |       |_JwtRequest
                               |       |_JswtResponse
                               |_repository
                               |   |_AnswersRepo	
                               |   |_ComboListRepo
                               |   |_ContactRepo
                               |   |_ContractRepo 
                               |   |_FinancialRepo 
                               |	 |_IncidentRepo 
                               |   |_InsuranceRepo 
                               |	 |_InvoiceRepo 
                               |   |_PersonRepo 
                               |	 |_PoliciesRepo 
                               |	 |_QuestionnairesRepo 
                               |	 |_RoleRepo 
                               |	 |_TemplateRepo 
                               |	 |_UserRepo 
                               |	 |_VendorRepo 
                               |_response
                               |   |_AjaxResponseBody
                               |_service
                               |   |_impl
                               |        |_ComboListServiceImpl
                               |        |_DashBoardServiceServiceImpl
                               |        |_ContactServiceImpl
                               |        |_ContractServiceImpl
                               |        |_FinancialServiceImpl
                               |        |_IncidentServiceImpl
                               |        |_InsuranceServiceImpl
                               |        |_InvoiceServiceImpl
                               |        |_LoginServiceImpl
                               |        |_PoliciesServiceImpl
                               |        |_QuestionnairesServiceImpl
                               |        |_TemplateServiceImpl
                               |        |_VendorServiceImpl
                               |   |_ComboListService
                               |   |_ContactService
                               |	 |_ContractService
                               |   |_FinancialService
                               |	 |_IncidentService
                               |   |_InsuranceService
                               |	 |_InvoiceService
                               |   |_LoginService
                               |	 |_PoliciesService
                               |	 |_QuestionnairesService
                               |	 |_TemplateService
                               |	 |_JwtUserDetailsService
                               |	 |_VendorService
                               |	 |_TemplateService
                               |	 |_DashBoardService
                               |_MyApplication 		  
               |__resources
               |       |_public
               |           |_assets
               |               |_icons
               |               |_images
               |               |_img
               |
               |       |_application.properties
             __|__
 
## Third Party dependency library

* spring-boot-starter
* spring-boot-starter-data-jpa
* poi
* poi-ooxml
* mysql-connector-java
* spring-boot-devtools
* jackson-databind
* jackson-annotations
* flexjson
* commons-codec
* spring-boot-starter-security
* jjwt
* spring-boot-starter-web
* spring-boot-starter-artemis
* taglibs-standard-impl
* spring-boot-starter-mail
* spring-boot-starter-test
* junit-vintage-engine*

## Development server
To Run the project : Right click on project -> Run As -> SpringBoot app -> http://localhost:8190/
## Code scaffolding
src/main/java -> right click on this -> new -> Package/Class/Interface/Other.

## Build
To build the project: Right click on project -> Run As -> Mvaen Build.






