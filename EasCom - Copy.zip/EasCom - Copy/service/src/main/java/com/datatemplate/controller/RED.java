package com.datatemplate.controller;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.datatemplate.dto.Reviews;

//import statements
public class RED 
{
//  public static void main(String args[])
//  {
//	  try
//      {
//          FileInputStream file = new FileInputStream(new File("D:\\vendor-vetting\\MDL.xlsx"));
//          XSSFWorkbook workbook = new XSSFWorkbook(file);
//          XSSFSheet sheet = workbook.getSheetAt(0);
//          Iterator<Row> rowIterator = sheet.iterator();
//          int rowCount =  0;
//          Reviews reviews = new Reviews();
//          while (rowIterator.hasNext()) 
//          {
//              Row row = rowIterator.next();
//              if(rowCount>0) {
//	              Iterator<Cell> cellIterator = row.cellIterator();
//	              System.out.print(cellIterator.next().getStringCellValue() + "\n");
//	              System.out.print(cellIterator.next().getStringCellValue() + "\n");
//	              System.out.print(cellIterator.next().getStringCellValue() + "\n");
//	              System.out.print(cellIterator.next().getStringCellValue() + "\n");
//	              System.out.print(cellIterator.next().getStringCellValue() + "\n");
//              }
//              System.out.println("");
//              rowCount++;
//              
//          }
//          file.close();
//      } 
//      catch (Exception e) 
//      {
//          e.printStackTrace();
//      }
//  }
}
