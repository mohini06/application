package com.datatemplate.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.datatemplate.common.Search;
import com.datatemplate.dto.Incident;
import com.datatemplate.entity.Error;
import com.datatemplate.service.IncidentService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/incident")
@PropertySource("classpath:application.properties")
public class IncidentController {

	@Autowired
	private IncidentService incidentService;

	@Autowired
	private Environment env;

	@PostMapping("/incidents")
	public  ResponseEntity<List<Incident>> getIncidentList(@RequestBody String search) {

		ObjectMapper mapper = new ObjectMapper();
		Map resultMap =  new HashMap<>() ;
		List<Incident> incidentList = new ArrayList<Incident>();
		try {

			Search searchJson  = mapper.readValue(search, Search.class);
			resultMap = incidentService.getIncidentList(searchJson);
			com.datatemplate.entity.Error error = (com.datatemplate.entity.Error) resultMap.get("ERROR");
			if(error.getStatusCode().equals("500")) {
				//Incident incident  =  new Incident();
				//incident.setTotal(0);
				//incidentList.add(incident);
				return new ResponseEntity<List<Incident>>(null ,new HttpHeaders(), HttpStatus.OK);
			}
			incidentList = ( List<Incident> )resultMap.get("INCIDENTS");
			if(null != incidentList && incidentList.size()> 0) {
				Incident incident = incidentList.get(0);
				incident.setTotal(Integer.parseInt(resultMap.get("TOTAL").toString()));
			}
		} catch (JsonParseException e) {
			System.out.println(e.getMessage());
		} catch (JsonMappingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return new ResponseEntity<List<Incident>>(incidentList ,new HttpHeaders(), HttpStatus.OK);

	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ResponseEntity<?> saveIncident(@RequestParam("files") MultipartFile[] files,
			@RequestParam("name") String name,
			@RequestParam("notes") String notes,
			@RequestParam("startdate") String startdate,
			@RequestParam("enddate") String enddate,
			@RequestParam("severityId") String severityId,
			@RequestParam("duration") String duration,
			@RequestParam("id") String id,
			@RequestParam("vid") String vid,
			@RequestParam("userId") String userId) throws Exception {
		Incident incident = new Incident();
		FileOutputStream fileOutputStream = null;
		incident.setId(id.equals("") ? null : Long.parseLong(id));
		incident.setVid(vid.equals("") ? null : vid);
		incident.setUserId(userId.equals("") ? null : userId);
		incident.setName(name);
		incident.setNotes(notes);
		incident.setDuration(duration.equals("") || duration.equals("null") ? null : Double.parseDouble(duration));
		incident.setStartdate(new SimpleDateFormat("yyyy-MM-dd").parse(startdate));
		incident.setEnddate(new SimpleDateFormat("yyyy-MM-dd").parse(enddate));
		incident.setSeverityId(severityId);
		incident.setVid(vid);
		Map<String, Object>  resultMap  = incidentService.saveIncident(incident);
		Error error =  (Error)resultMap.get("ERROR");
		if(error.getStatusCode().equals("401")) {
			return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
		}
		Incident savedIncident = (Incident)resultMap.get("INCIDENT");

		if(files.length > 0) {

			File dir = new File(env.getProperty("uploadDir") + File.separator + "incident_docs");
			File subDir = new File(dir.getAbsolutePath()+ File.separator + savedIncident.getId());

			if (!dir.exists()){
				dir.mkdirs();
				if(!subDir.exists()){
					subDir.mkdirs();
				}
			}
			else if (!subDir.exists()){
				subDir.mkdirs();
			}
			StringBuilder fileName = new StringBuilder();
			for (MultipartFile multipartFile : files) {

				File uploadedFile = new File(subDir, multipartFile.getOriginalFilename().replace(",", ""));
				fileName.append(uploadedFile.getAbsoluteFile().getPath()).append(",");
				try {
					uploadedFile.createNewFile();
					fileOutputStream = new FileOutputStream(uploadedFile);
					fileOutputStream.write(multipartFile.getBytes());
					fileOutputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
			String f = fileName.toString();
			incident.setUploaddocument(f.substring(0, f.length() - 1));
			Map<String, Object>  resultMap1  = incidentService.saveIncident(incident);
			Error error1 =  (Error)resultMap1.get("ERROR");
			if(error1.getStatusCode().equals("401")) {
				return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
			}
			savedIncident = (Incident)resultMap1.get("INCIDENT");
		}

		return ResponseEntity.ok(savedIncident);
	}


	@RequestMapping(value="/incidents/{id}", method = RequestMethod.GET) 
	public ResponseEntity<?>  getByIncidentId(@PathVariable Long id) {
		Map resultMap =  incidentService.getIncident(id);
		Error error  = (Error)resultMap.get("ERROR");
		if(error.getStatusCode().equals("401")) {
			return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
		}
		Incident  incident =  (Incident)resultMap.get("INCIDENT");
		return ResponseEntity.ok(incident);
	}		

	@RequestMapping(path = "/downloadDocs", method = RequestMethod.GET)
	public void downloadFile(HttpServletResponse res,
			@RequestParam("id") String id,
			@RequestParam("filename") String filename) throws Exception {
		String filePath = env.getProperty("uploadDir") + File.separator + "incident_docs" + File.separator + id + File.separator + filename;
		res.setHeader("Content-Disposition", "attachment; filename=" + filename);
		res.getOutputStream().write(Files.readAllBytes(Paths.get(filePath)));
	}
	
	@RequestMapping(value = "/deleteDocs", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteFile(@RequestParam("id") Long id, @RequestParam("filename") String filename)
			throws Exception {

		ObjectMapper mapper = new ObjectMapper();
		Map resultMap = new HashMap<>();

		resultMap = incidentService.deleteFiles(id, filename);
		System.out.println(resultMap);
		Error error = (Error) resultMap.get("ERROR");
		if (error.getStatusCode().equals("200")) {
			return ResponseEntity.ok(resultMap.get("ERROR"));

		} else {
			return ResponseEntity.ok(resultMap.get("ERROR"));
		}

	}

}
