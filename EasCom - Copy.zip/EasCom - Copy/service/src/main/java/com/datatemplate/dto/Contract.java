package com.datatemplate.dto;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="contract") 
public class Contract  extends BaseEntity {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	private String uploaddocument;

	private String contractname;

	@Temporal(TemporalType.TIMESTAMP)
	private Date startdate;

	@Temporal(TemporalType.TIMESTAMP)
	private Date enddate;

	@Temporal(TemporalType.TIMESTAMP)
	private Date renewaldate;

	@OneToOne
	@JoinColumn(name="contractterm")
	private ComboList contractterm;

	@OneToOne
	@JoinColumn(name="feestructure")
	private ComboList feestructure;

	private String fee;

	@OneToOne
	@JoinColumn(name="status")
	private ComboList status;

	@Transient
	private String statusId;
	
	@Transient
	private String contracttermId;
	
	@Transient
	private String feestructureId;

	private String notes;

	@OneToOne
	@JoinColumn(name="createdby")
	private User createdby;

	@OneToOne
	@JoinColumn(name="modifiedby")
	private User modifiedby;

	@ManyToOne
	@JoinColumn(name="vendorid")
	private Vendor vendorid;

	@Transient
	private int total ;
	
	@Transient
	private String vid ;
	
	@Transient
	private String userId;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUploaddocument() {
		return uploaddocument;
	}

	public void setUploaddocument(String uploaddocument) {
		this.uploaddocument = uploaddocument;
	}

	public String getContractname() {
		return contractname;
	}

	public void setContractname(String contractname) {
		this.contractname = contractname;
	}

	public Date getStartdate() {
		return startdate;
	}

	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	public Date getEnddate() {
		return enddate;
	}

	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}

	public Date getRenewaldate() {
		return renewaldate;
	}

	public void setRenewaldate(Date renewaldate) {
		this.renewaldate = renewaldate;
	}

	public ComboList getContractterm() {
		return contractterm;
	}

	public void setContractterm(ComboList contractterm) {
		this.contractterm = contractterm;
	}

	public ComboList getFeestructure() {
		return feestructure;
	}

	public void setFeestructure(ComboList feestructure) {
		this.feestructure = feestructure;
	}

	public String getFee() {
		return fee;
	}

	public void setFee(String fee) {
		this.fee = fee;
	}

	public ComboList getStatus() {
		return status;
	}

	public void setStatus(ComboList status) {
		this.status = status;
	}

	public String getStatusId() {
		return statusId;
	}

	public void setStatusId(String statusId) {
		this.statusId = statusId;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public User getCreatedby() {
		return createdby;
	}

	public void setCreatedby(User createdby) {
		this.createdby = createdby;
	}

	public User getModifiedby() {
		return modifiedby;
	}

	public void setModifiedby(User modifiedby) {
		this.modifiedby = modifiedby;
	}

	public Vendor getVendorid() {
		return vendorid;
	}

	public void setVendorid(Vendor vendorid) {
		this.vendorid = vendorid;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public String getVid() {
		return vid;
	}

	public void setVid(String vid) {
		this.vid = vid;
	}

	public String getContracttermId() {
		return contracttermId;
	}

	public void setContracttermId(String contracttermId) {
		this.contracttermId = contracttermId;
	}

	public String getFeestructureId() {
		return feestructureId;
	}

	public void setFeestructureId(String feestructureId) {
		this.feestructureId = feestructureId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
