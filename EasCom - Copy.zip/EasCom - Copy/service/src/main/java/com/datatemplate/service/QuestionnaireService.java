package com.datatemplate.service;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.datatemplate.common.Search;
import com.datatemplate.constants.SQLConstants;
import com.datatemplate.dao.CommonDAO;
import com.datatemplate.dao.QuestionnaireDAO;
import com.datatemplate.dto.Answers;
import com.datatemplate.dto.Questionnaire;
import com.datatemplate.entity.Error;
import com.datatemplate.repository.TemplateRepo;
import com.datatemplate.service.impl.QuestionnaireServiceImpl;

@Service
public class QuestionnaireService implements QuestionnaireServiceImpl,SQLConstants{

	@Autowired
	private CommonDAO commonDAO;
	
	@Autowired
	private QuestionnaireDAO questionnaireDao ;
	
	@Autowired
	private TemplateRepo templateRepo ;
	
	@Override
	public Map<String, Object> saveQuestionnaire(Questionnaire questionnaire) {
		return questionnaireDao.saveQuestionnaire(questionnaire);
	}

	@Override
	public Map<String, Object> getQuestionnaireList(Search search) {
		search.setSelect(QUESTIONNAIRE_SELECT);
		if(search.getOrderby()== null) {
			search.setOrderby(QUESTIONNAIRE_ORDER_BY); 
		}else {
			if(search.getOrderby().equals("createdOn") || search.getOrderby().equals("createdOn desc")) {
				if(search.getOrderby().equals("createdOn")) {
					search.setOrderby(" order by created_on");
				}else {
					search.setOrderby(" order by created_on desc");
				}
			}else if(search.getOrderby().equals("templateId") || search.getOrderby().equals("templateId desc")){
				if(search.getOrderby().equals("templateId")) {
					search.setOrderby(" order by temp.name"); 
				}else {
					search.setOrderby(" order by temp.name desc");
				}		   
			}else {			   
				search.setOrderby(" order by "+search.getOrderby());
			}
		}
		Map<String, Object> resultMap  =  new HashMap<>();
		Questionnaire questionnaire = null;
		Error error =  new Error();
		error.setStatusCode("200");
		List<Questionnaire> questionnaireList =  new ArrayList<Questionnaire>();
		List<Object[]> rows = commonDAO.getMasterList(search,QUESTIONNAIRE_FIELDS);

		try {    

			if(null != rows && rows.isEmpty()) {
				error.setStatusCode("500");
				resultMap.put("ERROR",error);
				return resultMap;
			}
			//Object[] r = rows.get(0);
			//long vendorid = Long.parseLong(r[10].toString());
			int count = commonDAO.getMasterCount(search, QUESTIONNAIRE_FIELDS);
			for(Object[] row : rows){
				questionnaire = new Questionnaire();
				questionnaire.setId(null != row[0] ?  Long.parseLong(row[0].toString()) : null);
				questionnaire.setLabel(null != row[1] ?  row[1].toString() : "");
				questionnaire.setOptions(null != row[2] ? row[2].toString() : "");
				questionnaire.setType(null != row[3] ? row[3].toString() : "");
				questionnaire.setRequired(null != row[4] ? Boolean.valueOf(row[4].toString()) : null);
				questionnaire.setTemplateid(null != row[5] ? templateRepo.findById(Long.parseLong(row[5].toString())) : null);
				questionnaire.setCreatedOn(null != row[6] ?  (java.util.Date)row[6] : null);
				questionnaire.setTemplateId(null != questionnaire.getTemplateid() ? questionnaire.getTemplateid().getName() : "");
				questionnaireList.add(questionnaire);
			}
			resultMap.put("QUESTIONNAIRES",questionnaireList);
			//resultMap.put("TOTAL",policiesRepo.countByVendorId(vendorid));
			resultMap.put("TOTAL", count);
		} catch (NumberFormatException e) {
			error.setStatusCode("400");
		}
		resultMap.put("ERROR",error);
		return resultMap;
	}
	
	@Override
	public Map<String, Object> saveAnswer(Answers answer) {
		return questionnaireDao.saveAnswer(answer);
	}
	
	public Map<String, Object> saveAnswer(Questionnaire questionnaire, String answer) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Object> saveAnswers(MultipartFile[] file, String answer, Long vendorid, String lableid) {
	    return 	questionnaireDao.saveAnswers(file,answer,vendorid,lableid);
		
	}
	
	public String findFileName(String fileName){
		String[] fileNames = fileName.split(",");
		StringBuilder names = new StringBuilder();
		for(String fName : fileNames) {
			Path path = Paths.get(fName);
			names.append(path.getFileName().toString()).append(",");
		}
		String f = names.toString();
		return f.substring(0, f.length() - 1);
	}
	
	@Override
	public Map<String, Object> deleteFiles(Long id, String filename) {
	    return 	questionnaireDao.deleteFiles(id,filename);
		
	}
	
	
}
