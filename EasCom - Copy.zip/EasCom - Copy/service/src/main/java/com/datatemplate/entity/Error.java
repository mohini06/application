package com.datatemplate.entity;

import java.util.ArrayList;
import java.util.List;

public class Error {
	
	private String statusCode ;
	private String statusMsg  ;
	private int id ;
	private List<Integer>  ids  = new ArrayList<>();
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusMsg() {
		return statusMsg;
	}
	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public List<Integer> getIds() {
		return ids;
	}
	public void setIds(List<Integer> ids) {
		this.ids = ids;
	}
	 
	
	

}
