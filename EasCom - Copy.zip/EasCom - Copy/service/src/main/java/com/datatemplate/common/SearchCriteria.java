package com.datatemplate.common;

public class SearchCriteria {

	private String colname ;
	private String  value ;
	
	public String getColname() {
		return colname;
	}
	public void setColname(String colname) {
		this.colname = colname;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
 
    
	 
	
}
