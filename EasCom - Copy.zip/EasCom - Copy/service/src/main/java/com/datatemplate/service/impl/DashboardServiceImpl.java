package com.datatemplate.service.impl;

import java.util.List;
import java.util.Map;

import com.datatemplate.common.Search;
import com.datatemplate.dto.Graph;

public interface DashboardServiceImpl {

	List<Graph> getCountData(String days);
	
	List<Graph> getBarData();

	Map<String, Object> getTableData(Search search);
	
}
