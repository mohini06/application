package com.datatemplate.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.datatemplate.common.Search;
import com.datatemplate.dto.Template;
import com.datatemplate.repository.TemplateRepo;
import com.datatemplate.service.TemplateService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/template")
public class TemplateController {
	
	@Autowired
	private TemplateService templateService ;
	
	@Autowired
	private TemplateRepo templateRepo ;

	@RequestMapping(value = "/createtemp", method = RequestMethod.POST)
	public ResponseEntity<?> createTemplate(@RequestBody Template template) throws Exception{
		
		if(templateService.saveTemplate(template).get("ERROR") != null) {
			return new ResponseEntity(template,new HttpHeaders(),HttpStatus.FORBIDDEN);
		}else {
			return ResponseEntity.ok(templateService.saveTemplate(template));
		}
	}
	
	@SuppressWarnings("unchecked")
	@PostMapping("/templates")
	public  ResponseEntity<List<Template>> getTemplateList(@RequestBody String search) {

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> resultMap =  new HashMap<>();
		List<Template> templateList = new ArrayList<Template>();
		try {

			Search searchJson  = mapper.readValue(search, Search.class);
			resultMap = templateService.getTemplateList(searchJson);
			com.datatemplate.entity.Error error = (com.datatemplate.entity.Error) resultMap.get("ERROR");
			if(error.getStatusCode().equals("500")) {
				return new ResponseEntity<List<Template>>(null ,new HttpHeaders(), HttpStatus.OK);
			}
			templateList = ( List<Template> )resultMap.get("TEMPLATE");
			if(null != templateList && templateList.size()> 0) {
				Template template = templateList.get(0);
			    template.setTotal(Integer.parseInt(resultMap.get("TOTAL").toString()));
			}
		} catch (JsonParseException e) {
			System.out.println(e.getMessage());
		} catch (JsonMappingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return new ResponseEntity<List<Template>>(templateList ,new HttpHeaders(), HttpStatus.OK);

	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/validate", method = RequestMethod.GET)
	public ResponseEntity<?> validateTemplate(@RequestParam("name") String name) throws Exception{
		Template template = templateRepo.findByName(name);
		if(template == null) {
		 return new ResponseEntity("{\"statusMsg\":\"SUCCESS\"}",new HttpHeaders(),HttpStatus.OK);

		}
		return new ResponseEntity(template,new HttpHeaders(),HttpStatus.FORBIDDEN);
	}
	
	@RequestMapping(value = "/templatelist", method = RequestMethod.GET)
	public ResponseEntity<?> getTemplateList() throws Exception {
		return ResponseEntity.ok(templateRepo.findAll());
	}
	
	@RequestMapping(value = "/template/{id}", method = RequestMethod.GET)
	public ResponseEntity<?> getTemplateList(@PathVariable Long id) throws Exception {
		return ResponseEntity.ok(templateRepo.findById(id));
	}
	
}
