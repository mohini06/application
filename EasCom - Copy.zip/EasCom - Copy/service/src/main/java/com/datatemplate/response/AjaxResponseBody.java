package com.datatemplate.response;


import com.datatemplate.entity.User;

public class AjaxResponseBody {
	
	String privateToken = "TOKEN1";
 
	User user = new User();
	//String status ;
  
 
	public String getPrivateToken() {
		return privateToken;
	}
	public void setPrivateToken(String privateToken) {
		this.privateToken = privateToken;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	/*public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}*/
	
   
}
