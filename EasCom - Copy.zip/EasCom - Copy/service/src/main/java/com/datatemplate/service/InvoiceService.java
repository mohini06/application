package com.datatemplate.service;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.datatemplate.common.Search;
import com.datatemplate.constants.SQLConstants;
import com.datatemplate.dao.CommonDAO;
import com.datatemplate.dao.InvoiceDAO;
import com.datatemplate.dto.Invoice;
import com.datatemplate.entity.Error;
import com.datatemplate.repository.ComboListRepo;
import com.datatemplate.repository.VendorRepo;
import com.datatemplate.service.impl.InvoiceServiceImpl;

@Service
public class InvoiceService implements InvoiceServiceImpl,SQLConstants{

	@Autowired
	private CommonDAO commonDAO;

	@Autowired
	private InvoiceDAO invoiceDao ;

	@Autowired
	private ComboListRepo comboListRepo;

	@Autowired
	private VendorRepo vendorRepo;

	@Override
	public Map<String, Object> getInvoiceList(Search search) {
		search.setSelect(INVOICE_SELECT);
		if(search.getOrderby()== null) {
			search.setOrderby(INVOICE_ORDER_BY); 
		}else {
			if(search.getOrderby().equals("createdOn") || search.getOrderby().equals("createdOn desc")) {
				if(search.getOrderby().equals("createdOn")) {
					search.setOrderby(" order by created_on");
				}else {
					search.setOrderby(" order by created_on desc");
				}
			}else if(search.getOrderby().equals("statusId") || search.getOrderby().equals("statusId desc")){
				if(search.getOrderby().equals("statusId")) {
					search.setOrderby(" order by statusId"); 
				}else {
					search.setOrderby(" order by statusId desc");
				}		   
			}else {			   
				search.setOrderby(" order by "+search.getOrderby());
			}
		}
		Map<String, Object> resultMap  =  new HashMap<>();
		Invoice invoice = null;
		Error error =  new Error();
		error.setStatusCode("200");
		List<Invoice> invoiceList =  new ArrayList<Invoice>();
		List<Object[]> rows = commonDAO.getMasterList(search,INVOICE_FIELDS);

		try {    

			if(null != rows && rows.isEmpty()) {
				error.setStatusCode("500");
				resultMap.put("ERROR",error);
				return resultMap;
			}
			//Object[] r = rows.get(0);
			//long vendorid = Long.parseLong(r[10].toString());
			int count = commonDAO.getMasterCount(search, INVOICE_FIELDS);
			for(Object[] row : rows){
				invoice = new Invoice();
				invoice.setId(null != row[0] ?  Long.parseLong(row[0].toString()) : null);
				invoice.setStartdate(null != row[1] ?  (java.util.Date)row[1] : null);
				invoice.setEnddate(null != row[2] ?  (java.util.Date)row[2] : null);
				invoice.setDate(null != row[3] ?  (java.util.Date)row[3] : null);
				invoice.setNotes(null != row[4] ?  row[4].toString() : "");
				invoice.setUploaddocument(null != row[5] ?  findFileName(row[5].toString()) : "");
				invoice.setNumber(null != row[6] ?  row[6].toString() : "");
				invoice.setAmount(null != row[7] ?  Integer.parseInt(row[7].toString()) : null);
				invoice.setStatus(null != row[8] ? comboListRepo.findById(Integer.parseInt(row[8].toString())) : null);
				invoice.setCreatedOn((java.util.Date)row[9]);
				invoice.setStatusId(null != invoice.getStatus() ?  invoice.getStatus().getDisplayvalue() : "");
				if(null != row[10] && Integer.parseInt(row[10].toString()) >  0) {
					invoice.setVendorid(vendorRepo.findByvendorid(Long.parseLong(row[10].toString())));
				}
				invoiceList.add(invoice);
			}
			resultMap.put("INVOICES",invoiceList);
			//resultMap.put("TOTAL",policiesRepo.countByVendorId(vendorid));
			resultMap.put("TOTAL", count);
		} catch (NumberFormatException e) {
			error.setStatusCode("400");
		}
		resultMap.put("ERROR",error);
		return resultMap;
	}

	@Override
	public Map<String, Object> saveInvoice(Invoice invoice) {
		return invoiceDao.saveInvoice(invoice);
	}

	@Override
	public Map<String, Object> getInvoice(Long id) {
		return invoiceDao.getInvoice(id);
	}

	public String findFileName(String fileName){
		String[] fileNames = fileName.split(",");
		StringBuilder names = new StringBuilder();
		for(String fName : fileNames) {
			Path path = Paths.get(fName);
			names.append(path.getFileName().toString()).append(",");
		}
		String f = names.toString();
		return f.substring(0, f.length() - 1);
	}
	
	@Override
	public Map<String, Object> deleteFiles(Long id, String filename) {
	    return 	invoiceDao.deleteFiles(id,filename);
		
	}

}
