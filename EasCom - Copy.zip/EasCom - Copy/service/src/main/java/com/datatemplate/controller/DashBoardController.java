package com.datatemplate.controller;
 
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.datatemplate.common.Search;
import com.datatemplate.dto.Graph;
import com.datatemplate.service.DashboardService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/dashboard")
public class DashBoardController {
	
	@Autowired
	private DashboardService dashboardService;
	
	//@PreAuthorize("hasRole('ROLE_VV_ADMIN') or hasRole('ROLE_VENDOR_MANAGER')")
	@RequestMapping(value = "/countdata", method = RequestMethod.GET)
	public List<Graph> getcountData(@RequestParam("days") String days) throws Exception {
		return dashboardService.getCountData(days);
	}   

	@RequestMapping(value = "/barchart", method = RequestMethod.GET)
	public List<Graph> getBarData() throws Exception {
		return dashboardService.getBarData();
	}
	
	@PostMapping("/tabledata")
	public ResponseEntity<List<Graph>> getTableData(@RequestBody String search) {

		ObjectMapper mapper = new ObjectMapper();
		Map resultMap =  new HashMap<>() ;
		List<Graph> tableDataList = new ArrayList<Graph>();
		try {

			Search searchJson  = mapper.readValue(search, Search.class);
			resultMap = dashboardService.getTableData(searchJson);
			com.datatemplate.entity.Error error = (com.datatemplate.entity.Error) resultMap.get("ERROR");
			if(error.getStatusCode().equals("500")) {
				return new ResponseEntity<List<Graph>>(null ,new HttpHeaders(), HttpStatus.OK);
			}
			tableDataList = ( List<Graph> )resultMap.get("TABLEDATA");
			if(null != tableDataList && tableDataList.size()> 0) {
				Graph graph = tableDataList.get(0);
				graph.setTotal(Integer.parseInt(resultMap.get("TOTAL").toString()));
			}
		} catch (JsonParseException e) {
			System.out.println(e.getMessage());
		} catch (JsonMappingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return new ResponseEntity<List<Graph>>(tableDataList ,new HttpHeaders(), HttpStatus.OK);

	}
	
}
	    
	 
  