package com.datatemplate.dto;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="reviewsentity" ) 
public class ReviewsEntities extends BaseEntity{

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
	
    @OneToOne(targetEntity=Vendor.class,cascade=CascadeType.ALL)
   	@JoinColumn(name="vendorid")
    private Reviews reviewId;
    
    private int entityId;
    
    @OneToOne(targetEntity=User.class,cascade=CascadeType.ALL)
 	@JoinColumn(name="createdby")
     private User createdBy;
 	
    @OneToOne(targetEntity=User.class,cascade=CascadeType.ALL)
   	@JoinColumn(name="modifiedby")
    private User modifiedBy;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Reviews getReviewId() {
		return reviewId;
	}

	public void setReviewId(Reviews reviewId) {
		this.reviewId = reviewId;
	}

	public int getEntityId() {
		return entityId;
	}

	public void setEntityId(int entityId) {
		this.entityId = entityId;
	}

	public User getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	public User getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(User modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
    
    
    
}
