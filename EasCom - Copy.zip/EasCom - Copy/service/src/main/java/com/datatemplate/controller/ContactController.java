package com.datatemplate.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.datatemplate.common.Search;
import com.datatemplate.dto.Vendor;
import com.datatemplate.dto.VendorContacts;
import com.datatemplate.entity.Error;
import com.datatemplate.repository.ContactRepo;
import com.datatemplate.service.ContactService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/contact")
public class ContactController {
	
	@Autowired
	private ContactService contactService;
	
	@PostMapping("/contacts")
    public  ResponseEntity<List<VendorContacts>>    getContactList(@RequestBody String search) {
		
		 ObjectMapper mapper = new ObjectMapper();
		  Map resultMap =  new HashMap<>() ;
		  List<VendorContacts> contactList = new ArrayList<VendorContacts>();
		  try {
			 
			  Search searchJson  = mapper.readValue(search, Search.class);
			   resultMap = contactService.getContactList(searchJson);
				com.datatemplate.entity.Error error = (com.datatemplate.entity.Error) resultMap.get("ERROR");
				if(error.getStatusCode().equals("500")) {
					//VendorContacts vc  =  new VendorContacts();
					//vc.setTotal(0);
					//vc.setFax("No records to display");
					//contactList.add(vc);
					return new ResponseEntity<List<VendorContacts>>(null ,new HttpHeaders(), HttpStatus.OK);
				}
				contactList = ( List<VendorContacts> )resultMap.get("CONTACTS");
				if(null != contactList && contactList.size()> 0) {
					VendorContacts vc = contactList.get(0);
					vc.setTotal(Integer.parseInt(resultMap.get("TOTAL").toString()));
				}
		} catch (JsonParseException e) {
			System.out.println(e.getMessage());
		} catch (JsonMappingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		  return new ResponseEntity<List<VendorContacts>>(contactList ,new HttpHeaders(), HttpStatus.OK);
       
    }
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ResponseEntity<?> saveContact(@RequestBody VendorContacts  vc) throws Exception {
	   Map<String, Object>  resultMap  = contactService.saveContact(vc);
	   Error error =  (Error)resultMap.get("ERROR");
	   if(error.getStatusCode().equals("401")) {
		 	return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
	   }
	   VendorContacts savedVc = (VendorContacts)resultMap.get("CONTACT");
		return ResponseEntity.ok(savedVc);
	}
 

	  @RequestMapping(value="/contacts/{id}", method = RequestMethod.GET) 
	  public ResponseEntity<?>  getByContactId(@PathVariable Long id) {
		  Map resultMap =  contactService.getContact(id);
		  Error error  = (Error)resultMap.get("ERROR");
		  if(error.getStatusCode().equals("401")) {
			 	return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
		   }
		  VendorContacts  vc  =  (VendorContacts)resultMap.get("CONTACT");
		  return ResponseEntity.ok(vc);
	  }
	 

}
