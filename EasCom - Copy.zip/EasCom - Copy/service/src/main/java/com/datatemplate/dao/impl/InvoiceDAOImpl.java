package com.datatemplate.dao.impl;

import java.util.Map;

import com.datatemplate.dto.Invoice;

public interface InvoiceDAOImpl {

	Map<String, Object> getInvoice(Long id);

	Map<String, Object> saveInvoice(Invoice invoice);
	
	Map<String, Object> deleteFiles(Long id, String filename);

}
