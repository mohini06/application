package com.datatemplate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.datatemplate.dto.VendorContacts;

public interface ContactRepo extends JpaRepository<VendorContacts, Long>  {
	@Query(value = "SELECT count(*) FROM vendor_contacts "
			+"WHERE vendorid = :vendorId ", nativeQuery = true)
	int countByVendorId(@Param("vendorId") long vendorId);
}
