package com.datatemplate.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.datatemplate.dto.Incident;

public interface IncidentRepo extends JpaRepository<Incident, Long> {
	
	List<Incident> findById(Long id);

}
