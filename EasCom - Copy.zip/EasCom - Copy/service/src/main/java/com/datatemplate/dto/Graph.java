package com.datatemplate.dto;

public class Graph {
	
	private String item;
	
	private int count;
	
	private int total;
	
	private int inactive;

	public Graph(String item, int count) {
		super();
		this.item = item;
		this.count = count;
	}
	
	public Graph(String item, int count, int inactive) {
		super();
		this.item = item;
		this.count = count;
		this.inactive = inactive;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getInactive() {
		return inactive;
	}

	public void setInactive(int inactive) {
		this.inactive = inactive;
	}

}
