package com.datatemplate.dao.impl;

public interface CompanyDAOImpl {

}
