package com.datatemplate.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.datatemplate.dao.impl.ComboListDAOImpl;
import com.datatemplate.dto.ComboList;
import com.datatemplate.service.impl.ComboListServiceImpl;
 
@Service
public class ComboListService implements ComboListServiceImpl {
	@Autowired
	private ComboListDAOImpl comboListDAOImpl;
 

	@Override
	public boolean saveComboList( ) {
		return comboListDAOImpl.saveComboList();
	}

	@Override
	public List<ComboList> getComboList(String type) {
		return comboListDAOImpl.getComboList(type);
	}

 

	 
	 
	 
	 
	 
}
