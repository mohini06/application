package com.datatemplate.service;


import java.util.Map;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.datatemplate.dao.impl.LoginDAOImpl;
import com.datatemplate.dto.User;
import com.datatemplate.service.impl.LoginServiceImpl;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import com.datatemplate.repository.ComboListRepo;
import com.datatemplate.repository.RoleRepo;
import com.datatemplate.dto.Role;
 
@Service
public class LoginService implements LoginServiceImpl {
	@Autowired
	private LoginDAOImpl loginDAO;
	
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;
	
	@Autowired
	private RoleRepo roleRepo;
	
	@Autowired
	private ComboListRepo comboListRepo;

	@Override
	public String registerUser(User person) {
		return loginDAO.registerUser(person);
	}
	 
	@Override
	public Map validateuser(User person) {
		return loginDAO.validateuser(person);
	}

	@Override
	public Map Update(User user) {
		// TODO Auto-generated method stub
		user.setPassword(bcryptEncoder.encode(user.getPassword()));
		Set<Role> roles = new HashSet<>();
		Role role = roleRepo.findById(Long.parseLong(user.getUserTypeId()));
		roles.add(role);
		user.setRoles(roles);
		user.setStatus(comboListRepo.findById(Integer.parseInt(user.getStatusId())));
		return loginDAO.Update(user);
	}
	 
	@Override
	public Map forgotPswd(String email) {
		return loginDAO.forgotPswd(email);
	}
	 
	private JavaMailSender javaMailSender;

	/**
	 * 
	 * @param javaMailSender
	 */
	@Autowired
	public LoginService(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}

	/**
	 * This function is used to send mail without attachment.
	 * @param user
	 * @throws MailException
	 */

	public void sendEmail(User user) throws MailException {

		/*
		 * This JavaMailSender Interface is used to send Mail in Spring Boot. This
		 * JavaMailSender extends the MailSender Interface which contains send()
		 * function. SimpleMailMessage Object is required because send() function uses
		 * object of SimpleMailMessage as a Parameter
		 */

		SimpleMailMessage mail = new SimpleMailMessage();
		mail.setTo(user.getEmail());
		mail.setSubject("Testing Mail API");
		mail.setText("Hurray ! You have done that dude...");

		/*
		 * This send() contains an Object of SimpleMailMessage as an Parameter
		 */
		javaMailSender.send(mail);
	}
	
	@Override
	public Map savePswd(String email, String otp, String newpassword,String confirmpassword ){
		return loginDAO.savePswd(email, otp, newpassword, confirmpassword );
	}
	
	@Override
	public Map savechangePswd(Long userid, String password, String newpassword,String confirmpassword ){
		return loginDAO.savechangePswd(userid,password, newpassword, confirmpassword );
	}
}
