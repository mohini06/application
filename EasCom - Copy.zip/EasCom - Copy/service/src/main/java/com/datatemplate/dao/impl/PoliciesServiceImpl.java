package com.datatemplate.dao.impl;

import java.util.Map;

import com.datatemplate.dto.PoliciesAndProcedures;

public interface PoliciesServiceImpl {

	Map<String, Object> getPolicie(Long id);

	Map<String, Object> savePolicies(PoliciesAndProcedures policies);
	
	Map<String, Object> deleteFiles(Long id, String filename);

}
