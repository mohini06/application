package com.datatemplate.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpHeaders;
import com.datatemplate.common.Search;
import com.datatemplate.dto.User;
import com.datatemplate.dto.Vendor;
import com.datatemplate.entity.Error;
import com.datatemplate.entity.Vendorview;
import com.datatemplate.repository.VendorRepo;
import com.datatemplate.service.ComboListService;
import com.datatemplate.service.VendorService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/vendor")
public class VendorController {
	
	@Autowired
	private VendorRepo vendorRepo;
	
	@Autowired
	private VendorService vendorService ;
	
	@Autowired
	private ComboListService comboListService;
	
	@PostMapping("/vendors")
    public  ResponseEntity<List<Vendor>> getvendorList(@RequestBody String search) {
		
		 ObjectMapper mapper = new ObjectMapper();
		  Map resultMap =  new HashMap<>() ;
		  List<Vendor> vendorList = new ArrayList<Vendor>();
		  try {
			 
			  Search searchJson  = mapper.readValue(search, Search.class);
			   resultMap = vendorService.getVendorList(searchJson);
				com.datatemplate.entity.Error error = (com.datatemplate.entity.Error) resultMap.get("ERROR");
				if(error.getStatusCode().equals("500")) {
					//Vendor vendor  =  new Vendor();
					//vendor.setTotal(0);
					//vendorList.add(vendor);
					  return new ResponseEntity<List<Vendor>>(null ,new HttpHeaders(), HttpStatus.OK);
				}
				vendorList = ( List<Vendor> )resultMap.get("VENDORS");
				if(null != vendorList && vendorList.size() > 0) {
					Vendor ven = vendorList.get(0);
					ven.setTotal(Integer.parseInt(resultMap.get("TOTAL").toString()));
				}
		} catch (JsonParseException e) {
			System.out.println(e.getMessage());
		} catch (JsonMappingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		  return new ResponseEntity<List<Vendor>>(vendorList ,new HttpHeaders(), HttpStatus.OK);
       
    }

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ResponseEntity<?> saveVendor(@RequestBody Vendor  vendor) throws Exception {
	   Map<String, Object>  resultMap  = vendorService.saveVendor(vendor);
	   Error error =  (Error)resultMap.get("ERROR");
	   if(error.getStatusCode().equals("401")) {
		 	return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
	   }
	   Vendor vendorNew = (Vendor)resultMap.get("VENDOR");
		return ResponseEntity.ok(vendorNew);
	}
	
	@RequestMapping(value = "/combolist", method = RequestMethod.GET)
	public ResponseEntity<?> getComboList(@RequestParam("type") String type) throws Exception {
		return ResponseEntity.ok(comboListService.getComboList(type));
	}
	
	/*@RequestMapping(value = "/vendor", method = RequestMethod.GET)
	public ResponseEntity<?> getVendor(@RequestParam("vendorid") int vendorId) throws Exception {
		return ResponseEntity.ok(comboListService.getVendor(vendorId));
	}*/

	  @RequestMapping(value="/vendor/{id}", method = RequestMethod.GET) 
	  public ResponseEntity<?>  getByVendorId(@PathVariable Long id) {
		  Map resultMap =  vendorService.getVendor(id); 
		  Vendor  vendor  =  (Vendor)resultMap.get("VENDOR");
		  return ResponseEntity.ok(vendor);
	  }
	  
	  @RequestMapping(value="/vendorlist", method = RequestMethod.GET) 
	  public ResponseEntity<?>  getByVendorlist() {
		  Map resultMap =  new HashMap<>() ;
		  List<Vendorview> vendorList = new ArrayList<Vendorview>();
		  resultMap = vendorService.getVendorlist();
			com.datatemplate.entity.Error error = (com.datatemplate.entity.Error) resultMap.get("ERROR");
			if(error.getStatusCode().equals("500")) {
				  return new ResponseEntity<List<Vendor>>(null ,new HttpHeaders(), HttpStatus.OK);
			}
			vendorList = ( List<Vendorview> )resultMap.get("VENDOR");
		  return new ResponseEntity<List<Vendorview>>(vendorList ,new HttpHeaders(), HttpStatus.OK);
	  }
	  
	  @RequestMapping(value = "validatevendor", method = RequestMethod.POST)
		public ResponseEntity<?> isValidVendor(@RequestBody Vendor  vendor) throws Exception {
		  if(null != vendor.getVendorname() && vendor.getVendorname().trim().length() > 0 ) {
			Vendor vendorExist = vendorRepo.findByvendorname(vendor.getVendorname());
			if (null != vendorExist) {
				return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
			}
		  }
			return ResponseEntity.ok("200");
		}

}
