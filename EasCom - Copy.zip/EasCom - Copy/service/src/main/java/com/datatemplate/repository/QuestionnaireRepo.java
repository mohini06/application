package com.datatemplate.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.datatemplate.dto.Answers;
import com.datatemplate.dto.Questionnaire;
import com.datatemplate.dto.Template;
import com.datatemplate.dto.Vendor;

public interface QuestionnaireRepo extends JpaRepository<Questionnaire, Long> {
	
	List<Questionnaire> findByTemplateid(Template template);
	


}
