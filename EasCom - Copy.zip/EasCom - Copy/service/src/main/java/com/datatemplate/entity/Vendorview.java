package com.datatemplate.entity;

public class Vendorview {

	private Long vendorid;

	private String vendorname;

	public Vendorview(Long vendorid, String vendorname) {
		super();
		this.vendorid = vendorid;
		this.vendorname = vendorname;
	}

	public Long getVendorid() {
		return vendorid;
	}

	public void setVendorid(Long vendorid) {
		this.vendorid = vendorid;
	}

	public String getVendorname() {
		return vendorname;
	}

	public void setVendorname(String vendorname) {
		this.vendorname = vendorname;
	}
	
}
