package com.datatemplate.common;

import java.util.ArrayList;
import java.util.List;

public class Search {
	private String username; 
	private String per;
	private String page; 
	private String mastertype;
	private String orderby;
	private String select ;
	private List<SearchCriteria> startswith = new ArrayList<SearchCriteria>();
	private  List<SearchCriteria> endswith= new ArrayList<SearchCriteria>();
	private  List<SearchCriteria> contains= new ArrayList<SearchCriteria>();
	private  List<SearchCriteria> equal= new ArrayList<SearchCriteria>();
	private  List<SearchCriteria> notequal= new ArrayList<SearchCriteria>();
	private  List<SearchCriteria> dateequal= new ArrayList<SearchCriteria>();
	private  List<SearchCriteria> greaterthan= new ArrayList<SearchCriteria>();
	private  List<SearchCriteria> greaterthanorequal= new ArrayList<SearchCriteria>();
	private  List<SearchCriteria> lessthan = new ArrayList<SearchCriteria>();
	private  List<SearchCriteria> lessthanorequal= new ArrayList<SearchCriteria>();
	private  List<SearchCriteria> datenotequal= new ArrayList<SearchCriteria>();
	private  List<SearchCriteria> commonsearch= new ArrayList<SearchCriteria>();
	
	private int vendorid ;
	
	private int templateid;
	
	  public String getUsername() { return username; } public void
	  setUsername(String username) { this.username = username; }
	 
	public String getPer() {
		return per;
	}
	public void setPer(String per) {
		this.per = per;
	}
	public String getPage() {
		return page;
	}
	public void setPage(String page) {
		this.page = page;
	}
	 
	public String getMastertype() {
		return mastertype;
	}
	public void setMastertype(String mastertype) {
		this.mastertype = mastertype;
	}
	public String getOrderby() {
		return orderby;
	}
	public void setOrderby(String orderby) {
		this.orderby = orderby;
	}
	public List<SearchCriteria> getStartswith() {
		return startswith;
	}
	public void setStartswith(List<SearchCriteria> startswith) {
		this.startswith = startswith;
	}
	public List<SearchCriteria> getEndswith() {
		return endswith;
	}
	public void setEndswith(List<SearchCriteria> endswith) {
		this.endswith = endswith;
	}
	public List<SearchCriteria> getContains() {
		return contains;
	}
	public void setContains(List<SearchCriteria> contains) {
		this.contains = contains;
	}
	public List<SearchCriteria> getEqual() {
		return equal;
	}
	public void setEqual(List<SearchCriteria> equal) {
		this.equal = equal;
	}
	public List<SearchCriteria> getNotequal() {
		return notequal;
	}
	public void setNotequal(List<SearchCriteria> notequal) {
		this.notequal = notequal;
	}
	public List<SearchCriteria> getDateequal() {
		return dateequal;
	}
	public void setDateequal(List<SearchCriteria> dateequal) {
		this.dateequal = dateequal;
	}
	public List<SearchCriteria> getGreaterthan() {
		return greaterthan;
	}
	public void setGreaterthan(List<SearchCriteria> greaterthan) {
		this.greaterthan = greaterthan;
	}
	public List<SearchCriteria> getGreaterthanorequal() {
		return greaterthanorequal;
	}
	public void setGreaterthanorequal(List<SearchCriteria> greaterthanorequal) {
		this.greaterthanorequal = greaterthanorequal;
	}
	public List<SearchCriteria> getLessthan() {
		return lessthan;
	}
	public void setLessthan(List<SearchCriteria> lessthan) {
		this.lessthan = lessthan;
	}
	public List<SearchCriteria> getLessthanorequal() {
		return lessthanorequal;
	}
	public void setLessthanorequal(List<SearchCriteria> lessthanorequal) {
		this.lessthanorequal = lessthanorequal;
	}
	public List<SearchCriteria> getDatenotequal() {
		return datenotequal;
	}
	public void setDatenotequal(List<SearchCriteria> datenotequal) {
		this.datenotequal = datenotequal;
	}
	public List<SearchCriteria> getCommonsearch() {
		return commonsearch;
	}
	public void setCommonsearch(List<SearchCriteria> commonsearch) {
		this.commonsearch = commonsearch;
	}
	public String getSelect() {
		return select;
	}
	public void setSelect(String select) {
		this.select = select;
	}
	public int getVendorid() {
		return vendorid;
	}
	public void setVendorid(int vendorid) {
		this.vendorid = vendorid;
	}
	public int getTemplateid() {
		return templateid;
	}
	public void setTemplateid(int templateid) {
		this.templateid = templateid;
	}
	
}
