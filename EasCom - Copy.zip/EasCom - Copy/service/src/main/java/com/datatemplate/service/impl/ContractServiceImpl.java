package com.datatemplate.service.impl;

import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.datatemplate.common.Search;
import com.datatemplate.dto.Contract;

public interface ContractServiceImpl {

	public Map<String, Object> getContractList(Search search);

	public Map<String, Object> saveContract(Contract contract);

	public Map<String, Object> getContract(Long id);
	
	public Map<String, Object> deleteFiles(Long id, String filename);
}
