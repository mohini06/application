package com.datatemplate.controller;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class GetCellValueBasedonColumnName {
//	static  File file = new File("D:\\vendor-vetting\\combolistvalues.xlsx");
//	  FileInputStream fi ;
//	  static Workbook wb ;
//
// public static List<String> readdatafromExcelusingcolumnName(String ColumnName)
//   throws EncryptedDocumentException, InvalidFormatException, IOException {
//	 List<String>  resultList = new ArrayList<>();
//    Sheet sh = wb.getSheet(ColumnName);
// 
//  for(Row r : sh) {
//     Cell c = r.getCell(0);
//     if(c != null) {
//    	 resultList.add(c.getStringCellValue());
//         System.out.println(c.getStringCellValue());
//     }
//  }
//
//  return resultList;
//
// }
// 
// public static  void setWorkBook() throws InvalidFormatException, IOException {
//	  FileInputStream fi = new FileInputStream(file);
//	  wb = WorkbookFactory.create(fi);
// }
//       
////Main method called to ReadExcel Method
// public static void main(String[] args)
//   throws EncryptedDocumentException, InvalidFormatException, IOException {
//	 setWorkBook();
//    readdatafromExcelusingcolumnName("State");
//
// }
  
}
