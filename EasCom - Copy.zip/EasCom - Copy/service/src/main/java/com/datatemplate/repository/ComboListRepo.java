 package com.datatemplate.repository;

 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.datatemplate.dto.ComboList;
import com.datatemplate.dto.Role;
 


public interface ComboListRepo extends JpaRepository<ComboList, Long>{
	
 List<ComboList>  findByType(String type);
 
 ComboList findById(int id);

}
 