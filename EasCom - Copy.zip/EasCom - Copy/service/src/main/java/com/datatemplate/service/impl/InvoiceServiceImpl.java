package com.datatemplate.service.impl;

import java.util.Map;

import com.datatemplate.common.Search;
import com.datatemplate.dto.Invoice;

public interface InvoiceServiceImpl {

	Map<String, Object> getInvoiceList(Search search);

	Map<String, Object> saveInvoice(Invoice invoice);

	Map<String, Object> getInvoice(Long id);
	
	Map<String, Object> deleteFiles(Long id, String filename);

}
