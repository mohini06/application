package com.datatemplate.service.impl;

import java.util.Map;

import com.datatemplate.common.Search;
import com.datatemplate.dto.Vendor;

public interface VendorServiceImpl {

	public Map<String, Object> saveVendor(Vendor vendor);
	
	public Map<String, Object> getVendorList(Search search);
	
	public Map<String, Object> getVendor(Long vendorId);

	Map<String, Object> getVendorlist();
}
