package com.datatemplate.dao;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.datatemplate.constants.SQLConstants;
import com.datatemplate.dao.impl.LoginDAOImpl;
import com.datatemplate.dto.Forgotpassword;
import com.datatemplate.dto.User;
import com.datatemplate.repository.ForgotRepo;
import com.datatemplate.repository.PersonRepo;
import com.datatemplate.repository.RoleRepo;

import com.datatemplate.entity.Error;
import com.datatemplate.repository.UserRepo;

@Transactional
@Repository
public class LoginDAO implements LoginDAOImpl, SQLConstants {
	// @PersistenceContext
	// private EntityManager entityManager;

	@Autowired
	private PersonRepo personRepo;

	@Autowired
	private UserRepo userRepo;

	@Autowired
	private RoleRepo roleRepo;

	@Autowired
	private ForgotRepo forgotRepo;

	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	private JavaMailSender javaMailSender;

	/**
	 * 
	 * @param javaMailSender
	 * @return
	 */
	@Autowired
	public void MailService(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public String registerUser(User person) {
		String result = "FAIL";
		try {
			User dbPerson = personRepo.findByUsername(person.getUsername());
			if (null != dbPerson) {
				result = "Username Already Exist.";
			} else {
				personRepo.save(person);
				result = "SUCCESS";
			}
		} catch (Exception e) {
			result = "FAIL";
		}
		return result;
	}

	@Override
	public Map validateuser(User person) {
		User user = new User();
		Map resultMap = new HashMap<>();
		try {
			User dbPerson = personRepo.findByUsername(person.getUsername());
			// User personRole = personRoleRepo.findByPersonid(dbPerson.getUserid());
			// Role role = roleRepo.findByRoleid(personRole.getPersonroleid());
			if (null == dbPerson || !dbPerson.getPassword().equals(person.getPassword())) {
				return null;
			}
			user.setUserid(dbPerson.getUserid());
			user.setUsername(dbPerson.getUsername());
			user.setEmail(dbPerson.getEmail());
			resultMap.put(USER, user);
			String role = "SYSADMIN";
			resultMap.put(ROLE, role);
			// role[1] = "SUPERVISOR";
			// user.setRole(role);
		} catch (Exception e) {
			return null;
		}
		return resultMap;
	}

	@Override
	public Map Update(User user) {
		Error error = new Error();
		error.setStatusCode("200");
		Map resultMap = new HashMap<>();
		try {
			User userExist = userRepo.findByUsername(user.getUsername());
			User existuser = entityManager.find(User.class, userExist.getUserid());
			existuser.setUsername(user.getUsername());
			existuser.setFirstname(user.getFirstname());
			existuser.setLastname(user.getLastname());
			existuser.setPassword(user.getPassword());
			existuser.setTitle(user.getTitle());
			existuser.setEmail(user.getEmail());
			existuser.setAddress(user.getAddress());
			existuser.setPhone(user.getPhone());
			existuser.setFax(user.getFax());
			existuser.setStatus(user.getStatus());
			existuser.setRoles(user.getRoles());
			existuser.setResetToken(user.getResetToken());
			existuser.setProfilepic(user.getProfilepic() != null ? user.getProfilepic() : user.getProfilepic());
			entityManager.persist(existuser);
			resultMap.put("USER", existuser);
		} catch (Exception e) {
			return null;
		}
		return resultMap;
	}

	@Override
	public Map<String, Object> forgotPswd(String email) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();

		User existUser = new User();
		existUser = userRepo.findByEmail(email);

		Forgotpassword fpwd = new Forgotpassword();

		try {

			if (null != existUser.getEmail() && existUser.getEmail().equals(email)) {

				int leftLimit = 48; // numeral '0'
				int rightLimit = 122; // letter 'z'
				int targetStringLength = 6;
				Random random = new Random();
				String generatedString = random.ints(leftLimit, rightLimit + 1)
						.filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97)).limit(targetStringLength)
						.collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append).toString();
				entityManager.persist(existUser);
				send(email, generatedString);

				error.setStatusCode("200");
				error.setStatusMsg("OTP sent successfully...");
				Date objDate = new Date();
				Date date1 = objDate;

				if (forgotRepo.findByUserid((long) existUser.getUserid()) != null) {
					fpwd = forgotRepo.findByUserid((long) existUser.getUserid());
					fpwd.setOtp(generatedString);
					fpwd.setOtptime(date1);
					fpwd.setStatus("0");
					fpwd.setUserid(existUser.getUserid());
					entityManager.persist(fpwd);
				} else {
					fpwd.setUserid(existUser.getUserid());
					fpwd.setOtp(generatedString);
					fpwd.setStatus("0");
					fpwd.setOtptime(date1);
					System.out.println(existUser.getUserid());
					forgotRepo.save(fpwd);
				}

			} else {
				error.setStatusCode("401");
				error.setStatusMsg("Invalid email");
			}

		} catch (Exception e) {
			error.setStatusCode("401");
			error.setStatusMsg("Invalid email");
		}
		resultMap.put("ERROR", error);
		return resultMap;

	}

	public String send(String email, String generatedString) {
		User user = new User();
		/*
		 * Creating a User with the help of User class that we have declared and setting
		 * Email address of the sender.
		 */
		user.setEmail(email); // Receiver's email address
		/*
		 * Here we will call sendEmail() for Sending mail to the sender.
		 */
		try {
			SimpleMailMessage mail = new SimpleMailMessage();
			mail.setTo(user.getEmail());
			mail.setSubject("Testing Mail API");
			mail.setText("OTP : " + generatedString);

			/*
			 * This send() contains an Object of SimpleMailMessage as an Parameter
			 */
			javaMailSender.send(mail);
		} catch (MailException mailException) {
		}
		return "Congratulations! Your mail has been send to the user.";
	}

	@Override
	public Map<String, Object> savePswd(String email, String otp, String newpassword, String confirmpassword) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();

		User existUser = new User();
		Forgotpassword fpwd = new Forgotpassword();

		if (userRepo.findByEmail(email) != null) {
			existUser = userRepo.findByEmail(email);

			if (null != existUser.getEmail() && existUser.getEmail().equals(email)) {

				if (forgotRepo.findByUserid((long) existUser.getUserid()) != null) {
					fpwd = forgotRepo.findByUserid((long) existUser.getUserid());

					if (fpwd.getOtp().equals(otp) && fpwd.getStatus().contains("0")) {

						Date objDate = new Date();
						Date end = objDate;
						Date start = fpwd.getOtptime();

						long diff = end.getTime() - start.getTime();
						int diffInDays = (int) ((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
						long diffSeconds = diff / 1000 % 60;
						long diffMinutes = diff / (60 * 1000) % 60;
						long diffHours = diff / (60 * 60 * 1000);

						if (diffHours < 0.10) {
							error.setStatusCode("200");
							error.setStatusMsg("Valid OTP");
						} else {
							error.setStatusCode("401");
							error.setStatusMsg("OTP already used");
						}

						if (newpassword.equals(confirmpassword)) {
							existUser.setPassword(bcryptEncoder.encode(confirmpassword));
							entityManager.persist(existUser);

							fpwd.setStatus("1");
							entityManager.persist(fpwd);
							error.setStatusCode("200");
							error.setStatusMsg("SUCESS");

						}

					} else if (fpwd.getOtp().equals(otp) && fpwd.getStatus().contains("1")) {
						error.setStatusCode("401");
						error.setStatusMsg("OTP already used");
					} else {
						error.setStatusCode("401");
						error.setStatusMsg("Invalid OTP");
					}

				}

			}

		} else {
			error.setStatusCode("401");
			error.setStatusMsg("Invalid emailid");
		}
		resultMap.put("ERROR", error);
		return resultMap;
	}

	@Override
	public Map<String, Object> savechangePswd(Long userid, String password, String newpassword,
			String confirmpassword) {

		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();

		User existUser = new User();
		existUser = userRepo.findByUserid(userid);

		if (null != existUser.getUserid() && existUser.getUserid().equals(userid)) {

			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			boolean isPasswordMatch = passwordEncoder.matches(password, existUser.getPassword());

			if (isPasswordMatch) {

				if (newpassword.equals(confirmpassword)) {
					existUser.setPassword(bcryptEncoder.encode(confirmpassword));
					entityManager.persist(existUser);
					error.setStatusCode("200");
					error.setStatusMsg("SUCESS");
				}

			} else {
				error.setStatusCode("401");
				error.setStatusMsg("Invalid password");
			}

		} else {
			error.setStatusCode("401");
			error.setStatusMsg("Invalid userid");
		}
		resultMap.put("ERROR", error);
		return resultMap;
	}

}
