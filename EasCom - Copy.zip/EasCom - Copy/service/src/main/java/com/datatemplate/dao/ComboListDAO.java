package com.datatemplate.dao;
 
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.datatemplate.controller.GetCellValueBasedonColumnName;
import com.datatemplate.dao.impl.ComboListDAOImpl;
import com.datatemplate.dto.ComboList;
import com.datatemplate.dto.Company;
import com.datatemplate.dto.Contract;
import com.datatemplate.dto.Finance;
import com.datatemplate.dto.Incident;
import com.datatemplate.dto.Insurance;
import com.datatemplate.dto.Invoice;
import com.datatemplate.dto.PoliciesAndProcedures;
import com.datatemplate.dto.Reviews;
import com.datatemplate.dto.User;
import com.datatemplate.dto.Vendor;
import com.datatemplate.dto.VendorContacts;
import com.datatemplate.repository.ComboListRepo;

@Transactional
@Repository
public class ComboListDAO implements ComboListDAOImpl {
	@PersistenceContext	
	private EntityManager entityManager;	
	
 	@Autowired
	private ComboListRepo comboListRepo;
 
	@Override
	public Boolean saveComboList() {
		return null;
		 
//		  GetCellValueBasedonColumnName gvc = new GetCellValueBasedonColumnName(); 
//		  try
//		  { gvc.setWorkBook(); List<String> listNames = new ArrayList<String>();
//		  listNames.add("state"); listNames.add("review"); listNames.add("user");
//		  listNames.add("office"); listNames.add("riskcategory");
//		  listNames.add("contractterm"); listNames.add("feestructure");
//		  listNames.add("companyindustry"); listNames.add("vendorindustry");
//		  listNames.add("companylegalentity"); listNames.add("vendorlegalentity");
//		  listNames.add("status"); listNames.add("pnptype");
//		  listNames.add("financialtype"); listNames.add("invoicestatus");
//		  listNames.add("insurancetype"); listNames.add("incidentseverity"); for(String
//		  listName : listNames) { List<String> resultList =
//		  gvc.readdatafromExcelusingcolumnName(listName); ComboList cl = null;
//		  for(String str : resultList) { cl = new ComboList(); cl.setValue(str);
//		  cl.setDisplayvalue(str); cl.setType(listName); entityManager.persist(cl); } }
//		  
//		  
//		  ReadExcelDemo();
//		  
//		  return true; } catch (InvalidFormatException e) { // TODO Auto-generated
//		  } catch (EncryptedDocumentException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		 
//		
//		ReadExcelDemo();
//		return false;
//	}
//
//	 
//	//import statements
//		private void ReadExcelDemo()
//		{
//			 try
//		      {
//		          FileInputStream file = new FileInputStream(new File("D:\\vendor-vetting\\MDL.xlsx"));
//		          XSSFWorkbook workbook = new XSSFWorkbook(file);
//		          XSSFSheet sheet = workbook.getSheetAt(0);
//		          Iterator<Row> rowIterator = sheet.iterator();
//		          int rowCount =  0;
//		          Reviews reviews = null;
//		          while (rowIterator.hasNext()) 
//		          {
//		              Row row = rowIterator.next();
//		              if(rowCount>0) {
//			              Iterator<Cell> cellIterator = row.cellIterator();
//			              reviews =  new Reviews();
//			              reviews.setName(cellIterator.next().getStringCellValue());
//			              cellIterator.next().getStringCellValue();
//			              reviews.setType(null);
//			              reviews.setStartDate(getDate(cellIterator.next().getStringCellValue()));
//			              reviews.setEndDate(getDate(cellIterator.next().getStringCellValue()));
//			              reviews.setNotes(cellIterator.next().getStringCellValue());
//			              entityManager.persist(reviews);
//		              }
//		              System.out.println("");
//		              rowCount++;
//		              
//		          }
//		         
//		          //------Companies----------//
//		          sheet = workbook.getSheetAt(2);
//		         rowIterator = sheet.iterator();
//		           rowCount =  0;
//		          Company company=null;
//		          while (rowIterator.hasNext()) 
//		          {
//		              Row row = rowIterator.next();
//		              if(rowCount>0) {
//			              Iterator<Cell> cellIterator = row.cellIterator();
//			              company =  new Company();
//			              company.setAccountNumber(cellIterator.next().getStringCellValue());
//			              company.setName(cellIterator.next().getStringCellValue());
//			              company.setAddress1(cellIterator.next().getStringCellValue());
//			              company.setAddress2(cellIterator.next().getStringCellValue());
//			              company.setCity(null);
//			              company.setState(null);
//			              company.setZipCode(787788);
//			              try {
//			            	  cellIterator.next().getStringCellValue();
//			            	  company.setPhone("949-555-1212");
//						} catch (Exception e) {
//						}
//			             
//			              try {
//			            	  cellIterator.next().getStringCellValue();
//							company.setFax("9999-9909-000");
//						} catch (Exception e) {
//						}
//			              company.setWebsite("www.company.com"); 
//			              company.setEmail("info@company1.com");
//			              company.setStatus(null);
//			              company.setIndustry(null);
//			              company.setLegalEntity(null);
//			              company.setParent(null);
//			              entityManager.persist(company);
//		              }
//		              System.out.println("");
//		              rowCount++;
//		              
//		          }
//		          
//		          
//		          //------------Users------------//
//		             sheet = workbook.getSheetAt(3);
//			         rowIterator = sheet.iterator();
//			           rowCount =  0;
//			          User user=null;
//			          while (rowIterator.hasNext()) 
//			          {
//			              Row row = rowIterator.next();
//			              if(rowCount>0) {
//				              Iterator<Cell> cellIterator = row.cellIterator();
//				            //  if(cellIterator.hasNext()) {
//				              user =  new User();
//				              user.setUsername(cellIterator.next().getStringCellValue());
//				              
//				              try {
//				            	  cellIterator.next().getStringCellValue();
//								user.setPassword("1111");
//							} catch (Exception e) {
//							}
//				              user.setFirstname(cellIterator.next().getStringCellValue());
//				              user.setLastname(cellIterator.next().getStringCellValue());     
//				              user.setTitle(cellIterator.next().getStringCellValue());
//				              user.setEmail(cellIterator.next().getStringCellValue());
//				              user.setPhone(cellIterator.next().getStringCellValue());
//				              try {
//				            	  cellIterator.next().getStringCellValue();
//								company.setFax("9997-9909-000");
//							} catch (Exception e) {
//							}
//				              user.setUserType(null);
//				              user.setStatus(null); 
//				              //user.setPrimaryContact(1);
//				              user.setCompany(null);
//				              entityManager.persist(user);
//			              }
//			              System.out.println("");
//			              rowCount++;
//			            //  }
//			          }
//			          
//			       //------------Vendors------------//
//					
//				  sheet = workbook.getSheetAt(4); 
//				  rowIterator = sheet.iterator(); 
//				  rowCount = 0;
//				  Vendor vendor=null;
//				  while (rowIterator.hasNext()) { 
//				  Row row = rowIterator.next(); 
//				  if(rowCount>0) { Iterator<Cell> cellIterator = row.cellIterator(); 
//				  vendor = new Vendor();
//				  
//				  vendor.setAccountnumber(cellIterator.next().getStringCellValue());
//				  vendor.setVendorname(cellIterator.next().getStringCellValue());
//				  vendor.setStreetaddress1(cellIterator.next().getStringCellValue());
//				  vendor.setStreetaddress2(cellIterator.next().getStringCellValue());
//				  vendor.setCity(cellIterator.next().getStringCellValue());
//				  vendor.setState(null);
//				  
//				  vendor.setZipcode(787799);
//				  try {
//	            	  cellIterator.next().getStringCellValue();
//	            	  vendor.setPhone("3456789008");
//				} catch (Exception e) {
//				}
//				   vendor.setFax("22333-4443-44");
//				//  cellIterator.next().getStringCellValue();
//				    try {
//	            	  cellIterator.next().getStringCellValue();
//	            	  vendor.setWebsite("www.vendor1.com");
//				} catch (Exception e) {
//				}
//				  vendor.setEmail(cellIterator.next().getStringCellValue());
//				  vendor.setStatus(null);
//				  vendor.setIndustry(null); 
//				  vendor.setNumberofoffices(null);
//				  vendor.setOfficetype(null);
//				  vendor.setRiskcategory(null);
//				  vendor.setLegalentity(null); 
//				  vendor.setParent(null); 
//				  entityManager.persist(vendor);
//				  } System.out.println(""); rowCount++;
//				  
//				  }
//				 
//			         //------------Contacts---------//
//					
//				  sheet = workbook.getSheetAt(5);
//				  rowIterator = sheet.iterator();
//				  rowCount = 0;
//				  VendorContacts contact=null; 
//				  while (rowIterator.hasNext()) { 
//				  Row row = rowIterator.next(); 
//				  if(rowCount>0) { Iterator<Cell> 
//				  cellIterator = row.cellIterator();
//				  contact = new VendorContacts();
//				  contact.setTitle(cellIterator.next().getStringCellValue());
//				  contact.setEmail(cellIterator.next().getStringCellValue());
//				  try {
//	            	  cellIterator.next().getStringCellValue();
//	            	  contact.setPhone("949-234-8765");
//				} catch (Exception e) {
//				}
//				  
//				  contact.setFax(cellIterator.next().getStringCellValue());
//				  //contact.setVendorContact(null);
//				  contact.setCompanyId(null);
//				  contact.setVendorId(null);
//				  contact.setNotes(cellIterator.next().getStringCellValue());
//				  entityManager.persist(contact); }
//				  System.out.println(""); rowCount++;
//				  
//				  }
//				 
//				     //------------Contracts---------//
//		          sheet = workbook.getSheetAt(6);
//				  rowIterator = sheet.iterator(); 
//				  rowCount = 0;
//				  Contract contract=null;
//				  while(rowIterator.hasNext()) { Row row = rowIterator.next(); 
//				  if(rowCount>0) {
//				  Iterator<Cell> cellIterator = row.cellIterator(); 
//				  contract = new Contract();
//				  contract.setContractname(cellIterator.next().getStringCellValue());
//				  contract.setStartdate(getDate(cellIterator.next().getStringCellValue()));
//				  contract.setEnddate(getDate(cellIterator.next().getStringCellValue()));
//				  //contract.setContractTerm(null); 
//				  contract.setRenewaldate(getDate(cellIterator.next().getStringCellValue()));
//				  //contract.setFeeStructure(null);
//				  contract.setFee(null);
//				  contract.setStatus(null); 
//				  contract.setUploaddocument(cellIterator.next().getStringCellValue());
//				  contract.setNotes("contract note 1");
//				  entityManager.persist(contract); 
//				  }
//				  System.out.println(""); rowCount++;
//				  
//				  }
//
//
//	                  //------------Policies and procedures---------//
//		          sheet = workbook.getSheetAt(7);
//				  rowIterator = sheet.iterator(); 
//				  rowCount = 0;
//				  PoliciesAndProcedures policies=null;
//				  while(rowIterator.hasNext()) { Row row = rowIterator.next(); 
//				  if(rowCount>0) {
//				  Iterator<Cell> cellIterator = row.cellIterator(); 
//				  policies = new  PoliciesAndProcedures();
//				  policies.setName(cellIterator.next().getStringCellValue());
//				  //policies.setStartDate(getDate(cellIterator.next().getStringCellValue()));
//				  //policies.setEndDate(getDate(cellIterator.next().getStringCellValue()));
//				 // policies.setRenewalDate(getDate(cellIterator.next().getStringCellValue()));
//				  policies.setType(null); 
//				  //policies.setApprovedByExecutive(null);
//				  policies.setStatus(null); 
//				 // policies.setUploadDocument(cellIterator.next().getStringCellValue());
//				  policies.setNotes(cellIterator.next().getStringCellValue());
//				  entityManager.persist(policies); }
//				  System.out.println(""); rowCount++;
//				  
//				  }
//				 
//	                //------------Financial---------//
//		          sheet = workbook.getSheetAt(8);
//				  rowIterator = sheet.iterator(); 
//				  rowCount = 0;
//				  Finance finance=null;
//				  while(rowIterator.hasNext()) { Row row = rowIterator.next(); 
//				  if(rowCount>0) {
//				  Iterator<Cell> cellIterator = row.cellIterator(); 
//				  finance = new Finance();
//				  //finance.setName(cellIterator.next().getStringCellValue());
//				  //finance.setStartDate(getDate(cellIterator.next().getStringCellValue()));
//				 // finance.setEndDate(getDate(cellIterator.next().getStringCellValue()));
//				  //finance.setRenewalDate(getDate(cellIterator.next().getStringCellValue()));
//				  finance.setType(null); 
//				  //finance.setApprovedByExecutive(null);
//				  finance.setStatus(null); 
//				  //finance.setUploadDocument(cellIterator.next().getStringCellValue());
//				  finance.setNotes("audited financials 1 comment");
//				  entityManager.persist(finance); 
//				  }
//				  System.out.println(""); rowCount++;
//				  
//				  }
//
//	               
//		          //------------Invoices---------//
//		          sheet = workbook.getSheetAt(9);
//				  rowIterator = sheet.iterator(); 
//				  rowCount = 0;
//				  Invoice invoice=null;
//				  while(rowIterator.hasNext()) { Row row = rowIterator.next(); 
//				  if(rowCount>0) {
//				  Iterator<Cell> cellIterator = row.cellIterator(); 
//				  invoice = new Invoice();
//				  invoice.setNumber("INV"+rowCount);
//				  //invoice.setPeriodFrom(getDate("01/01/2021"));
//				  //invoice.setPeriodTo(getDate("01/01/2021"));
//				  invoice.setDate(getDate("01/01/2021"));
//				  invoice.setAmount(null);
//				  invoice.setStatus(null);
//				  //invoice.setUploadDocument("\\\\\\xxx\\\\xxx\\\\xxx\\invoiceid");
//				  invoice.setNotes("Invoice comment 1");
//				  entityManager.persist(invoice); 
//				  }
//				  System.out.println(""); rowCount++;
//				  
//				  }
//	            
//	                  //------------Insurance---------//
//		          sheet = workbook.getSheetAt(10);
//				  rowIterator = sheet.iterator(); 
//				  rowCount = 0;
//				  Insurance insurance=null;
//				  while(rowIterator.hasNext()) { Row row = rowIterator.next(); 
//				  if(rowCount>0) {
//				  Iterator<Cell> cellIterator = row.cellIterator(); 
//				  insurance = new Insurance();
//				  insurance.setName(cellIterator.next().getStringCellValue());
//				  insurance.setStartdate(getDate(cellIterator.next().getStringCellValue()));
//				  insurance.setEnddate(getDate(cellIterator.next().getStringCellValue()));
//				  insurance.setRenewaldate(getDate(cellIterator.next().getStringCellValue()));
//				  insurance.setType(null);
//				  insurance.setStatus(null);
//				  //insurance.setDoctitle(cellIterator.next().getStringCellValue());
//				  insurance.setNotes(cellIterator.next().getStringCellValue());
//				  entityManager.persist(insurance); 
//				  }
//				  System.out.println(""); rowCount++;
//				  
//				  }
//
//	               //------------Incidents---------//
//		          sheet = workbook.getSheetAt(11);
//				  rowIterator = sheet.iterator(); 
//				  rowCount = 0;
//				  Incident incident=null;
//				  while(rowIterator.hasNext()) { Row row = rowIterator.next(); 
//				  if(rowCount>0) {
//				  Iterator<Cell> cellIterator = row.cellIterator(); 
//				  incident = new Incident();
//				  //incident.setIncidentname(cellIterator.next().getStringCellValue());
//				  //incident.setStartDate(getDate(cellIterator.next().getStringCellValue()));
//				  //incident.setEndDate(getDate(cellIterator.next().getStringCellValue()));
//				  incident.setDuration(null);
//				  incident.setSeverity(null);
//				  //incident.setUploadDocument("xx\\xxxx\\xx");
//				  incident.setNotes("incident 1 notes");
//		 
//				  entityManager.persist(incident); 
//				  }
//				  System.out.println(""); rowCount++;
//				  
//				  }
//	  
//		          file.close();
//		      } 
//		      catch (Exception e) 
//		      {
//		          e.printStackTrace();
//		      }
		  }
		
		/**
		 * @purpose : Convert string to date format.
		 * 02/02/2019 10:15:00 AM

		 */
		private Date getDate(String strDate) {
			   String TIME_FORMAT = "MM/dd/yyyy hh:mm:ss";
			   SimpleDateFormat sdf = new SimpleDateFormat(TIME_FORMAT);
			try {
					//strDate = strDate.substring(0,10).replaceAll("-", "/");
				 return sdf.parse(strDate);
			} catch (ParseException e) {
				return new Date(); 
			}
		}


	@Override
	public List<ComboList> getComboList(String type) {
		return comboListRepo.findByType(type);
	}
	
	 
}
