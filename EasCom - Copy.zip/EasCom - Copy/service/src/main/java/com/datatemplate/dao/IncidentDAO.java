package com.datatemplate.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.datatemplate.dao.impl.IncidentDAOImpl;
import com.datatemplate.dto.Incident;
import com.datatemplate.dto.Vendor;
import com.datatemplate.entity.Error;
import com.datatemplate.repository.ComboListRepo;
import com.datatemplate.repository.IncidentRepo;
import com.datatemplate.repository.UserRepo;
import com.datatemplate.repository.VendorRepo;

@Transactional
@Repository
public class IncidentDAO implements IncidentDAOImpl{

	@Autowired
	private IncidentRepo incidentRepo;
	
	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private ComboListRepo comboListRepo;
	
	@PersistenceContext	
	private EntityManager entityManager;
	
	@Autowired
	private VendorRepo vendorRepo;
	
	@Override
	public Map<String, Object> saveIncident(Incident incident) {
		Map<String, Object>  resultMap  = new HashMap<String, Object>();
		Error error =  new Error();
		error.setStatusCode("200");
		if(null != incident.getSeverityId()) {
			incident.setSeverity(comboListRepo.findById(Integer.parseInt(incident.getSeverityId())));
		}

		if(null != incident.getVid()) { 
			Vendor vendor =vendorRepo.findByvendorid(Long.parseLong(incident.getVid()));
			incident.setVendorid(vendor); 
		}
		incident.setModifiedBy(userRepo.findByUsername(incident.getUserId()));
		try {
			if(null != incident.getId()) {
				Incident existIncident = entityManager.find(Incident.class, incident.getId());
				existIncident.setName(incident.getName());
				existIncident.setSeverity(incident.getSeverity());
				existIncident.setNotes(incident.getNotes());
				existIncident.setStartdate(incident.getStartdate());
				existIncident.setEnddate(incident.getEnddate());
				existIncident.setDuration(incident.getDuration());
				existIncident.setModifiedBy(incident.getModifiedBy());
				existIncident.setUploaddocument(incident.getUploaddocument() != null ? incident.getUploaddocument() : existIncident.getUploaddocument());
				entityManager.persist(existIncident);
				resultMap.put("INCIDENT", existIncident);
			}
			else {
				incident.setCreatedBy(incident.getModifiedBy());
				incident.setCreatedOn(new Date());
				resultMap.put("INCIDENT",  incidentRepo.save(incident));
			}
		} catch (Exception e) {
			error.setStatusCode("401");
		}
		resultMap.put("ERROR",error);
		return resultMap;
	}

	
	@Override
	public Map<String, Object> getIncident(Long id) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();
		error.setStatusCode("200");
		try {
			Incident incident =  entityManager.find(Incident.class, id);
			resultMap.put("INCIDENT", incident);
		} catch (Exception e) {
			error.setStatusCode("401");
		}
		resultMap.put("ERROR", error);
		return resultMap;
	}
	
	@Override
	public Map<String, Object> deleteFiles(Long id, String filename) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();
		error.setStatusCode("200");
        Incident existIncident = new Incident();
        System.out.println(id);
        existIncident = incidentRepo.findById(id).size() != 0
				? incidentRepo.findById(id).get(0)
				: null;
		try {
			if (null != existIncident.getId()) {
				existIncident.setUploaddocument(null);
					entityManager.persist(existIncident);
					error.setStatusMsg("File deleted successfully...");
			}
			else {

			}

		} catch (Exception e) {
			error.setStatusCode("401");
			error.setStatusMsg("Failure");
		}
		resultMap.put("ERROR", error);
		return resultMap;

	}

	
}
