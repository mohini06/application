package com.datatemplate.dao;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.datatemplate.dao.impl.QuestionnaireDAOImpl;
import com.datatemplate.dto.Answers;
import com.datatemplate.dto.Questionnaire;
import com.datatemplate.dto.Vendor;
import com.datatemplate.entity.Error;
import com.datatemplate.repository.AnswersRepo;
import com.datatemplate.repository.QuestionnaireRepo;
import com.datatemplate.repository.TemplateRepo;
import com.datatemplate.repository.UserRepo;
import com.datatemplate.repository.VendorRepo;

@Transactional
@Repository
public class QuestionnaireDAO implements QuestionnaireDAOImpl {

	private static final Vendor vendor = null;

	@Autowired
	private TemplateRepo templateRepo;

	@Autowired
	private VendorRepo vendorRepo;

	@Autowired
	private AnswersRepo answerRepo;

	@Autowired
	private UserRepo userRepo;

	@Autowired
	private QuestionnaireRepo questionnaireRepo;

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private Environment env;

	@Override
	public Map<String, Object> saveQuestionnaire(Questionnaire questionnaire) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();
		error.setStatusCode("200");
		if (null != questionnaire.getTemplateId()) {
			questionnaire.setTemplateid(templateRepo.findById(Long.parseLong(questionnaire.getTemplateId())));
		}

		if (null != questionnaire.getUserId()) {
			questionnaire.setModifiedBy(userRepo.findByUsername(questionnaire.getUserId()));
		}

		/*
		 * if(null != incident.getVid()) { Vendor vendor
		 * =vendorRepo.findByvendorid(Long.parseLong(incident.getVid()));
		 * incident.setVendorid(vendor); }
		 */

		try {
			if (null != questionnaire.getId()) {
				Questionnaire existQuestionnaire = entityManager.find(Questionnaire.class, questionnaire.getId());
				existQuestionnaire.setLabel(questionnaire.getLabel());
				existQuestionnaire.setType(questionnaire.getType());
				existQuestionnaire.setRequired(questionnaire.getRequired());
				existQuestionnaire.setOptions(questionnaire.getOptions());
				existQuestionnaire.setModifiedBy(questionnaire.getModifiedBy());
				entityManager.persist(existQuestionnaire);
				resultMap.put("QUESTIONNAIRE", existQuestionnaire);
			} else {
				questionnaire.setCreatedBy(questionnaire.getModifiedBy());
				questionnaire.setCreatedOn(new Date());
				resultMap.put("QUESTIONNAIRE", questionnaireRepo.save(questionnaire));
			}
		} catch (Exception e) {
			error.setStatusCode("401");
		}
		resultMap.put("ERROR", error);
		return resultMap;
	}

	@Override
	public Map<String, Object> saveAnswer(Answers answer) {

		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();
		error.setStatusCode("200");
		Vendor vendor = vendorRepo.findByvendorid(answer.getVendorId());
		answer.setVendor(vendor);
		Answers existingAnswer = answerRepo.findByVendor(vendor).size() != 0 ? answerRepo.findByVendor(vendor).get(0)
				: null;
		try {
			if (null != existingAnswer) {
				existingAnswer.setAnswer(answer.getAnswer());
				// existingAnswer.setModifiedBy(existingAnswer.getModifiedBy());
				entityManager.persist(existingAnswer);
				resultMap.put("QUESTIONNAIRE", existingAnswer);
			} else {
				// answer.setCreatedBy(questionnaire.getModifiedBy());
				answer.setCreatedOn(new Date());
				resultMap.put("ANSWER", answerRepo.save(answer));
			}
		} catch (Exception e) {
			error.setStatusCode("401");
		}
		resultMap.put("ERROR", error);
		return resultMap;

	}

	@Override
	public Map<String, Object> saveAnswers(MultipartFile[] files, String answer, Long vendor, String labelid) {

		Map<String, Object> resultMap = new HashMap<String, Object>();
		FileOutputStream fileOutputStream = null;
		String f = null;
		Error error = new Error();
		Vendor vendordata = vendorRepo.findByvendorid(vendor);
		Answers existingAnswer = new Answers();
		try {

			if (vendordata.getVendorid() != null) {
				existingAnswer = answerRepo.findByUploadlabelid(labelid).size() != 0
						? answerRepo.findByUploadlabelid(labelid).get(0)
						: null;
				if (existingAnswer != null) {
					f = Uploaddocument(files, existingAnswer.getId());
					existingAnswer.setVendor(vendordata);
					existingAnswer.setUploadlabelid(labelid);
					existingAnswer.setAnswer(answer);
					existingAnswer.setUploaddocument(f.substring(0, f.length() - 1));
					entityManager.persist(existingAnswer);
					resultMap.put("QUESTIONNAIRE", existingAnswer);
					error.setStatusCode("200");
					error.setStatusMsg("SUCCESS");
				} else {
					Answers newAnswer = new Answers();

					newAnswer.setUploadlabelid(labelid);
					newAnswer.setVendor(vendordata);
					newAnswer.setAnswer(answer);
					answerRepo.save(newAnswer);
					newAnswer = answerRepo.findByUploadlabelid(labelid).size() != 0
							? answerRepo.findByUploadlabelid(labelid).get(0)
							: null;
							f = Uploaddocument(files, newAnswer.getId());
					newAnswer.setUploaddocument(f.substring(0, f.length() - 1));
					resultMap.put("QUESTIONNAIRE", newAnswer);
					error.setStatusCode("200");
					error.setStatusMsg("SUCCESS");
				}
			}
		} catch (Exception e) {
			error.setStatusCode("401");
			error.setStatusMsg("Failure");
		}
		resultMap.put("ERROR", error);
		return resultMap;

	}

	public String Uploaddocument(MultipartFile[] files, Long id) {
		FileOutputStream fileOutputStream = null;
		String f = null;
		if (files.length > 0) {
			File dir = new File(env.getProperty("uploadDir") + File.separator + "questionare_docs");
			File subDir = new File(dir.getAbsolutePath() + File.separator + id);

			if (!dir.exists()) {
				dir.mkdirs();
				if (!subDir.exists()) {
					subDir.mkdirs();
				}
			} else if (!subDir.exists()) {
				subDir.mkdirs();
			}
			StringBuilder fileName = new StringBuilder();
			for (MultipartFile multipartFile : files) {
				File uploadedFile = new File(subDir, multipartFile.getOriginalFilename().replace(",", ""));
				fileName.append(uploadedFile.getAbsoluteFile().getPath()).append(",");
				try {
					uploadedFile.createNewFile();
					fileOutputStream = new FileOutputStream(uploadedFile);
					fileOutputStream.write(multipartFile.getBytes());
					fileOutputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
			f = fileName.toString();

		}
		return f;
	}
	
	@Override
	public Map<String, Object> deleteFiles(Long id, String filename) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();
		error.setStatusCode("200");
        Answers existAnswer = new Answers();
        System.out.println(id);
        existAnswer = answerRepo.findById(id).size() != 0
				? answerRepo.findById(id).get(0)
				: null;
		try {
			if (null != existAnswer.getId()) {
				existAnswer.setUploaddocument(null);
					entityManager.persist(existAnswer);
					error.setStatusMsg("File deleted successfully...");
			}
			else {

			}

		} catch (Exception e) {
			error.setStatusCode("401");
			error.setStatusMsg("Failure");
		}
		resultMap.put("ERROR", error);
		return resultMap;

	}

}
