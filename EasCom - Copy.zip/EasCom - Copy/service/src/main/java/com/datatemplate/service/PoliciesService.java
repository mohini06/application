package com.datatemplate.service;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.datatemplate.common.Search;
import com.datatemplate.constants.SQLConstants;
import com.datatemplate.dao.CommonDAO;
import com.datatemplate.dao.PoliciesDAO;
import com.datatemplate.dto.PoliciesAndProcedures;
import com.datatemplate.entity.Error;
import com.datatemplate.repository.ComboListRepo;
import com.datatemplate.repository.PoliciesRepo;
import com.datatemplate.repository.VendorRepo;
import com.datatemplate.service.impl.PoliciesServiceImpl;

@Service
public class PoliciesService implements PoliciesServiceImpl,SQLConstants {
	@Autowired
	private CommonDAO commonDAO;

	@Autowired
	private PoliciesDAO policiesDao ;

	@Autowired
	private ComboListRepo comboListRepo;

	@Autowired
	private VendorRepo vendorRepo;

	@Autowired
	private PoliciesRepo policiesRepo;

	@Override
	public Map<String, Object> getPoliciesList(Search search) {
		search.setSelect(POLICIES_SELECT);
		if(search.getOrderby()== null) {
			   search.setOrderby(POLICIES_ORDER_BY); 
		   }else {
			   if(search.getOrderby().equals("createdOn") || search.getOrderby().equals("createdOn desc")) {
				   if(search.getOrderby().equals("createdOn")) {
					   search.setOrderby(" order by created_on");
				   }else {
					   search.setOrderby(" order by created_on desc");
				   }
			   }else if(search.getOrderby().equals("statusId") || search.getOrderby().equals("statusId desc")){
				   if(search.getOrderby().equals("statusId")) {
					   search.setOrderby(" order by statusId"); 
				   }else {
					   search.setOrderby(" order by statusId desc");
				   }		   
			   }else {			   
				   search.setOrderby(" order by "+search.getOrderby());
			   }
		   }
		Map<String, Object> resultMap  =  new HashMap<>();
		PoliciesAndProcedures policies = null;
		Error error =  new Error();
		error.setStatusCode("200");
		List<PoliciesAndProcedures> policiesList =  new ArrayList<PoliciesAndProcedures>();
		List<Object[]> rows = commonDAO.getMasterList(search,POLICIES_FIELDS);
		
		try {    

			if(null != rows && rows.isEmpty()) {
				error.setStatusCode("500");
				resultMap.put("ERROR",error);
				return resultMap;
			}
			//Object[] r = rows.get(0);
	        //long vendorid = Long.parseLong(r[10].toString());
			int count = commonDAO.getMasterCount(search, POLICIES_FIELDS);
			for(Object[] row : rows){
				policies = new PoliciesAndProcedures();
				policies.setId(null != row[0] ?  Long.parseLong(row[0].toString()) : null);
				policies.setName(null != row[1] ?  row[1].toString() : "");
				policies.setStartdate(null != row[2] ?  (java.util.Date)row[2] : null);
				policies.setEnddate(null != row[3] ?  (java.util.Date)row[3] : null);
				policies.setRenewaldate(null != row[4] ?  (java.util.Date)row[4] : null);
				policies.setNotes(null != row[5] ?  row[5].toString() : "");
				policies.setUploaddocument(null != row[6] ?  findFileName(row[6].toString()) : "");
				policies.setType(null != row[7] ?  comboListRepo.findById(Integer.parseInt(row[7].toString())) : null);
				policies.setStatus(null != row[8] ? comboListRepo.findById(Integer.parseInt(row[8].toString())) : null);
				policies.setCreatedOn((java.util.Date)row[9]);
				policies.setStatusId(null != policies.getStatus() ?  policies.getStatus().getDisplayvalue() : "");
				if(null != row[10] && Integer.parseInt(row[10].toString()) >  0) {
					policies.setVendorid(vendorRepo.findByvendorid(Long.parseLong(row[10].toString())));
				}
				policies.setApprovedbyexecutive(null != row[11] ?  row[11].toString() : "");
				policiesList.add(policies);
			}
			resultMap.put("POLICIES",policiesList);
			//resultMap.put("TOTAL",policiesRepo.countByVendorId(vendorid));
			resultMap.put("TOTAL", count);
		} catch (NumberFormatException e) {
			error.setStatusCode("400");
		}
		resultMap.put("ERROR",error);
		return resultMap;
	}

	@Override
	public Map<String, Object> savePolicies(PoliciesAndProcedures policies) {
		return policiesDao.savePolicies(policies);
	}

	@Override
	public Map<String, Object> getPolicie(Long id) {
		return policiesDao.getPolicie(id);
	}
	
	public String findFileName(String fileName){
		String[] fileNames = fileName.split(",");
		StringBuilder names = new StringBuilder();
		for(String fName : fileNames) {
			Path path = Paths.get(fName);
			names.append(path.getFileName().toString()).append(",");
		}
		String f = names.toString();
		return f.substring(0, f.length() - 1);
	}
	
	@Override
	public Map<String, Object> deleteFiles(Long id, String filename) {
	    return 	policiesDao.deleteFiles(id,filename);
		
	}
	
}
