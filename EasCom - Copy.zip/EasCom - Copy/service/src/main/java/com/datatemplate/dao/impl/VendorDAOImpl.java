package com.datatemplate.dao.impl;

import java.util.Map;

import com.datatemplate.common.Search;
import com.datatemplate.dto.Vendor;

public interface VendorDAOImpl {

	public Map<String, Object> saveVendor(Vendor vendor);
 
}
