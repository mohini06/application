package com.datatemplate.entity;

public class User {
	
	private String id;
	private String username;
	private String displayname;
	private String  email;
	//private String[] role= new String[3];
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getDisplayname() {
		return displayname;
	}
	public void setDisplayname(String displayname) {
		this.displayname = displayname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
/*	public String[] getRole() {
		return role;
	}
	public void setRole(String[] role) {
		this.role = role;
	}*/

}
