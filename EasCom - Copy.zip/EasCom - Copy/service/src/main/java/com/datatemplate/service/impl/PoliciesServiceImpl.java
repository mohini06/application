package com.datatemplate.service.impl;

import java.util.Map;

import com.datatemplate.common.Search;
import com.datatemplate.dto.PoliciesAndProcedures;

public interface PoliciesServiceImpl {

	Map<String, Object> getPoliciesList(Search search);

	Map<String, Object> savePolicies(PoliciesAndProcedures policies);

	Map<String, Object> getPolicie(Long id);
	
	Map<String, Object> deleteFiles(Long id, String filename);

}
