package com.datatemplate.service.impl;

import java.util.Map;

import com.datatemplate.common.Search;
import com.datatemplate.dto.Answers;
import com.datatemplate.dto.Questionnaire;
import org.springframework.web.multipart.MultipartFile;

public interface QuestionnaireServiceImpl {
	
	Map<String, Object> saveQuestionnaire(Questionnaire questionnaire);

	Map<String, Object> getQuestionnaireList(Search search);

	Map<String, Object> saveAnswer(Answers answer);
	
	Map<String, Object> saveAnswers(MultipartFile[] file, String answer, Long vendorid, String lableid);
	
	Map<String, Object> deleteFiles(Long id, String filename);

}
