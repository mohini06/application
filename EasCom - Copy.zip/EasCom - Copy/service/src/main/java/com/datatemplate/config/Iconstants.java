package com.datatemplate.config;

public interface Iconstants {

	public static final String BEARER_TOKEN= "Bearer ";
	public static final String HEADER= "authorization";
	public static final String ISSUER= "ducat-springboot-jwttoken";
	public static final String SECRET_KEY= "Springbootjwt";
	public static final String AUTHORITIES_KEY = "scopes";

}