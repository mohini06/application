package com.datatemplate.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.datatemplate.dto.Contract;

public interface ContractRepo extends JpaRepository<Contract, Long> {
	@Query(value = "SELECT count(*) FROM contract WHERE vendorid = :vendorId ", nativeQuery = true)
	int countByVendorId(@Param("vendorId") long vendorId);
	
	@Query(value = "SELECT count(*) FROM contract where now() >= date_add(enddate,INTERVAL -:minusDays DAY) and status = 183", nativeQuery = true)
	int contractCount(@Param("minusDays") String minusDays);
	
	List<Contract> findById(Long id);
}
