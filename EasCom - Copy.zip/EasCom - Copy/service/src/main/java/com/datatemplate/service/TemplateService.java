package com.datatemplate.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.datatemplate.common.Search;
import com.datatemplate.constants.SQLConstants;
import com.datatemplate.dao.CommonDAO;
import com.datatemplate.dao.TemplateDAO;
import com.datatemplate.dto.Template;
import com.datatemplate.entity.Error;
import com.datatemplate.service.impl.TemplateServiceImpl;

@Service
public class TemplateService implements TemplateServiceImpl,SQLConstants{
	
	@Autowired
	private CommonDAO commonDAO;
	
	@Autowired
	private TemplateDAO templateDao ;
	
	@Override
	public Map<String, Object> saveTemplate(Template template) {
		return templateDao.saveTemplate(template);
	}
	
	@Override
	public Map<String, Object> getTemplateList(Search search) {
		search.setSelect(TEMPLATE_SELECT);
		if(search.getOrderby()== null) {
			search.setOrderby(TEMPLATE_ORDER_BY); 
		}else {
			if(search.getOrderby().equals("createdOn") || search.getOrderby().equals("createdOn desc")) {
				if(search.getOrderby().equals("createdOn")) {
					search.setOrderby(" order by created_on");
				}else {
					search.setOrderby(" order by created_on desc");
				}
			}else {			   
				search.setOrderby(" order by "+search.getOrderby());
			}
		}
		Map<String, Object> resultMap  =  new HashMap<>();
		Template template = null;
		Error error =  new Error();
		error.setStatusCode("200");
		List<Template> templateList =  new ArrayList<Template>();
		List<Object[]> rows = commonDAO.getMasterList(search,TEMPLATE_FIELDS);

		try {    

			if(null != rows && rows.isEmpty()) {
				error.setStatusCode("500");
				resultMap.put("ERROR",error);
				return resultMap;
			}
			//Object[] r = rows.get(0);
			//long vendorid = Long.parseLong(r[10].toString());
			int count = commonDAO.getMasterCount(search, TEMPLATE_FIELDS);
			for(Object[] row : rows){
				template = new Template();
				template.setId(null != row[0] ?  Long.parseLong(row[0].toString()) : null);
				template.setName(null != row[1] ?  row[1].toString() : "");
				template.setCreatedOn(null != row[2] ?  (java.util.Date)row[2] : null);
				templateList.add(template);
			}
			resultMap.put("TEMPLATE",templateList);
			//resultMap.put("TOTAL",policiesRepo.countByVendorId(vendorid));
			resultMap.put("TOTAL", count);
		} catch (NumberFormatException e) {
			error.setStatusCode("400");
		}
		resultMap.put("ERROR",error);
		return resultMap;
	}

}
