package com.datatemplate.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.datatemplate.dao.impl.TemplateDAOImpl;
import com.datatemplate.dto.Template;

import com.datatemplate.entity.Error;
import com.datatemplate.repository.TemplateRepo;
import com.datatemplate.repository.UserRepo;

@Transactional
@Repository
public class TemplateDAO implements TemplateDAOImpl {

	@Autowired
	private TemplateRepo templateRepo;
	
	@Autowired
	private UserRepo userRepo;
	
	@PersistenceContext	
	private EntityManager entityManager;
	
	@Override
    public Map<String, Object> saveTemplate(Template  template) {
		 Map<String, Object>  resultMap  = new HashMap<String, Object>();
		    Error error =  new Error();
		    error.setStatusCode("200");
		    template.setModifiedBy(userRepo.findByUsername(template.getUserId()));
		    Template temp = templateRepo.findByName(template.getName());
			if(temp == null) {
				try {
					if(null != template.getId()) {
						Template existTc = entityManager.find(Template.class, template.getId());
						existTc.setName(template.getName());
						existTc.setModifiedBy(template.getModifiedBy());
						entityManager.persist(existTc);
						resultMap.put("TEMPLATE", existTc);
					}
					else {
						template.setCreatedBy(template.getModifiedBy());
						template.setCreatedOn(new Date());
						resultMap.put("TEMPLATE",  templateRepo.save(template));
					}
				} catch (Exception e) {
					error.setStatusCode("403");
					resultMap.put("ERROR",error);
				}

			}else {
				error.setStatusCode("403");
				resultMap.put("ERROR",error);
			}
			
			return resultMap;
}
}
