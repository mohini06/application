package com.datatemplate.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.datatemplate.common.Search;
import com.datatemplate.dto.Finance;
import com.datatemplate.entity.Error;
import com.datatemplate.repository.FinancialRepo;
import com.datatemplate.service.FinancialService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/financial")
@PropertySource("classpath:application.properties")
public class FinancialController {

	@Autowired
	private FinancialService financialService;
	
	@Autowired
	private Environment env;

	@PostMapping("/financials")
	public  ResponseEntity<List<Finance>>    getFinancialList(@RequestBody String search) {

		ObjectMapper mapper = new ObjectMapper();
		Map resultMap =  new HashMap<>() ;
		List<Finance> financialList = new ArrayList<Finance>();
		try {

			Search searchJson  = mapper.readValue(search, Search.class);
			resultMap = financialService.getFinancialList(searchJson);
			com.datatemplate.entity.Error error = (com.datatemplate.entity.Error) resultMap.get("ERROR");
			if(error.getStatusCode().equals("500")) {
				//Finance finance  =  new Finance();
				//finance.setTotal(0);
				//financialList.add(finance);
				return new ResponseEntity<List<Finance>>(null ,new HttpHeaders(), HttpStatus.OK);
			}
			financialList = ( List<Finance> )resultMap.get("FINANCIALS");
			if(null != financialList && financialList.size()> 0) {
				Finance finance = financialList.get(0);
				finance.setTotal(Integer.parseInt(resultMap.get("TOTAL").toString()));
			}
		} catch (JsonParseException e) {
			System.out.println(e.getMessage());
		} catch (JsonMappingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return new ResponseEntity<List<Finance>>(financialList ,new HttpHeaders(), HttpStatus.OK);

	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ResponseEntity<?> saveFinance(@RequestParam("files") MultipartFile[] files,
			@RequestParam("name") String name,
			@RequestParam("notes") String notes,
			@RequestParam("startdate") String startdate,
			@RequestParam("enddate") String enddate,
			@RequestParam("renewaldate") String renewaldate,
			@RequestParam("statusId") String statusId,
			@RequestParam("id") String id,
			@RequestParam("vid") String vid,
			@RequestParam("typeId") String typeId,
			@RequestParam("approvedbyexecutive") String approvedbyexecutive,
			@RequestParam("userId") String userId) throws Exception {
		Finance finance = new Finance();
		FileOutputStream fileOutputStream = null;
		finance.setId(id.equals("") ? null : Long.parseLong(id));
		finance.setVid(vid.equals("") ? null : vid);
		finance.setTypeId(typeId.equals("") ? null : typeId);
		finance.setUserId(userId.equals("") ? null : userId);
		finance.setName(name);
		finance.setNotes(notes);
		finance.setApprovedbyexecutive(approvedbyexecutive);
		if(renewaldate.equals("null")) {
			finance.setRenewaldate(null);
		}else {
			finance.setRenewaldate(new SimpleDateFormat("yyyy-MM-dd").parse(renewaldate));
		}		
		finance.setStartdate(new SimpleDateFormat("yyyy-MM-dd").parse(startdate));
		finance.setEnddate(new SimpleDateFormat("yyyy-MM-dd").parse(enddate));
		finance.setStatusId(statusId);
		finance.setVid(vid);
		Map<String, Object>  resultMap  = financialService.saveFinancial(finance);
		Error error =  (Error)resultMap.get("ERROR");
		if(error.getStatusCode().equals("401")) {
			return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
		}
		Finance savedFinance = (Finance)resultMap.get("FINANCIAL");

		if(files.length > 0) {

			File dir = new File(env.getProperty("uploadDir") + File.separator + "finance_docs");
			File subDir = new File(dir.getAbsolutePath()+ File.separator + savedFinance.getId());

			if (!dir.exists()){
				dir.mkdirs();
				if(!subDir.exists()){
					subDir.mkdirs();
				}
			}
			else if (!subDir.exists()){
				subDir.mkdirs();
			}
			StringBuilder fileName = new StringBuilder();
			for (MultipartFile multipartFile : files) {

				File uploadedFile = new File(subDir, multipartFile.getOriginalFilename().replace(",", ""));
				fileName.append(uploadedFile.getAbsoluteFile().getPath()).append(",");
				try {
					uploadedFile.createNewFile();
					fileOutputStream = new FileOutputStream(uploadedFile);
					fileOutputStream.write(multipartFile.getBytes());
					fileOutputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
			String f = fileName.toString();
			finance.setUploaddocument(f.substring(0, f.length() - 1));
			Map<String, Object>  resultMap1  = financialService.saveFinancial(finance);
			Error error1 =  (Error)resultMap1.get("ERROR");
			if(error1.getStatusCode().equals("401")) {
				return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
			}
			savedFinance = (Finance)resultMap1.get("FINANCIAL");
		}

		return ResponseEntity.ok(savedFinance);
	}

	@RequestMapping(value="/financials/{id}", method = RequestMethod.GET) 
	public ResponseEntity<?>  getByFinancialId(@PathVariable Long id) {
		Map resultMap =  financialService.getFinancial(id);
		Error error  = (Error)resultMap.get("ERROR");
		if(error.getStatusCode().equals("401")) {
			return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
		}
		Finance  vf  =  (Finance)resultMap.get("FINANCIAL");
		return ResponseEntity.ok(vf);
	}		

	@RequestMapping(path = "/downloadDocs", method = RequestMethod.GET)
	public void downloadFile(HttpServletResponse res,
			@RequestParam("id") String id,
			@RequestParam("filename") String filename) throws Exception {
		String filePath = env.getProperty("uploadDir") + File.separator + "finance_docs" + File.separator + id + File.separator + filename;
		res.setHeader("Content-Disposition", "attachment; filename=" + filename);
		res.getOutputStream().write(Files.readAllBytes(Paths.get(filePath)));
	}
	
	@RequestMapping(value = "/deleteDocs", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteFile(@RequestParam("id") Long id, @RequestParam("filename") String filename)
			throws Exception {

		ObjectMapper mapper = new ObjectMapper();
		Map resultMap = new HashMap<>();

		resultMap = financialService.deleteFiles(id, filename);
		System.out.println(resultMap);
		Error error = (Error) resultMap.get("ERROR");
		if (error.getStatusCode().equals("200")) {
			return ResponseEntity.ok(resultMap.get("ERROR"));

		} else {
			return ResponseEntity.ok(resultMap.get("ERROR"));
		}

	}
	
}
