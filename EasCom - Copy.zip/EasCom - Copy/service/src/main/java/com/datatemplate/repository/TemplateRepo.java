package com.datatemplate.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.datatemplate.dto.Template;

public interface TemplateRepo extends JpaRepository<Template, Long> {

	Template findById(Long id);

	Template findByName(String name);

}
