package com.datatemplate.common;
/*
This class is for mail generation.  
*/

import java.security.Security;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.core.env.Environment;

public class Mailer {

    public synchronized void sendMail(String subject, String body, String recipients,Environment env) {
        try {
        		//protocol
	            Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());//to set security provider
	            
	            final Properties props = new Properties();
	            
	            props.setProperty("senderMail", env.getProperty("senderMail"));
	            props.setProperty("senderPwd", env.getProperty("senderPwd"));
	            props.setProperty("mail.transport.protocol", env.getProperty("mail.transport.protocol"));
	            props.setProperty("mail.host", env.getProperty("mail.host"));
	            props.setProperty("mail.smtp.auth", env.getProperty("mail.smtp.auth"));
	            props.setProperty("mail.smtp.port", env.getProperty("mail.smtp.port"));
	            props.setProperty("mail.smtp.socketFactory.port", env.getProperty("mail.smtp.socketFactory.port"));
	            props.setProperty("mail.debug", env.getProperty("mail.debug"));
	            props.setProperty("mail.smtp.socketFactory.class", env.getProperty("mail.smtp.socketFactory.class"));
	            props.setProperty("mail.smtp.socketFactory.fallback", env.getProperty("mail.smtp.socketFactory.fallback"));
	            props.setProperty("mail.smtp.quitwait", env.getProperty("mail.smtp.quitwait"));
	            props.setProperty("mail.smtp.starttls.enable", env.getProperty("mail.smtp.starttls.enable"));
	            
	            Session session = Session.getInstance(props, new javax.mail.Authenticator() {
	        		//password authenication
		            @Override
		            protected PasswordAuthentication getPasswordAuthentication() {
		                return new PasswordAuthentication(props.getProperty("senderMail"), props.getProperty("senderPwd"));
		            }
	            });
	            //to sent message
	            MimeMessage message = new MimeMessage(session);
	            message.setSender(new InternetAddress(props.getProperty("senderMail")));
	            message.setSubject(subject);
	            message.setContent(body, "text/plain");//message contetnt as text,it can be in file format
	            if (recipients.indexOf(',') > 0) {
	                message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipients));
	            } else {
	                message.setRecipient(Message.RecipientType.TO, new InternetAddress(recipients));
	            }
	            //to transport the message
	            Transport.send(message);
	            System.out.println("Mail sent successfully");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}    