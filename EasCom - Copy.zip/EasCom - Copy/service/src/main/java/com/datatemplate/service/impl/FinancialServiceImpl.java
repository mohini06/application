package com.datatemplate.service.impl;

import java.util.Map;

import com.datatemplate.common.Search;
import com.datatemplate.dto.Finance;


public interface FinancialServiceImpl {

	Map<String, Object> getFinancialList(Search search);

	Map<String, Object> saveFinancial(Finance financial);

	Map<String, Object> getFinancial(Long id);
	
	Map<String, Object> deleteFiles(Long id, String filename);

}
