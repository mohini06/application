package com.datatemplate.service.impl;

import java.util.Map;

import com.datatemplate.common.Search;
import com.datatemplate.dto.Template;


public interface TemplateServiceImpl {

	Map<String, Object> saveTemplate(Template template);

	Map<String, Object> getTemplateList(Search search);
	

}
