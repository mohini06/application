package com.datatemplate.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

@Entity
public class Answers extends BaseEntity{
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@OneToOne
	@JoinColumn(name="vendor")
	private Vendor vendor;
	
	private String answer;
	
	private String uploaddocument;
	
	private String uploadlabelid;
	
	@Transient
	private Long vendorId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Vendor getVendor() {
		return vendor;
	}

	public void setVendor(Vendor vendor) {
		this.vendor = vendor;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public Long getVendorId() {
		return vendorId;
	}

	public void setVendorId(Long vendorId) {
		this.vendorId = vendorId;
	}

	public String getUploaddocument() {
		return uploaddocument;
	}

	public void setUploaddocument(String uploaddocument) {
		this.uploaddocument = uploaddocument;
	}

	public String getUploadlabelid() {
		return uploadlabelid;
	}

	public void setUploadlabelid(String uploadlabelid) {
		this.uploadlabelid = uploadlabelid;
	}
	
	

}
