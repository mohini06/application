package com.datatemplate.service.impl;

public interface CompanyServiceImpl {

}
