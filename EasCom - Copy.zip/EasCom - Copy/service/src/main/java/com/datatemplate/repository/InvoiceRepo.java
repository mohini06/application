package com.datatemplate.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.datatemplate.dto.Invoice;

public interface InvoiceRepo extends JpaRepository<Invoice, Long> {
	
	@Query(value = "SELECT count(*) FROM invoice where now() >= date_add(enddate,INTERVAL -:minusDays DAY)", nativeQuery = true)
	int invoiceCount(@Param("minusDays") String minusDays);

	List<Invoice> findById(Long id);
}
