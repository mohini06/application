package com.datatemplate.service.impl;

import java.util.List;

import com.datatemplate.dto.ComboList;

public interface ComboListServiceImpl {
     
     boolean saveComboList( );
   
    List<ComboList> getComboList(String type);
     
   }  


     
     
     
     

