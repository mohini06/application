package com.datatemplate.service;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.datatemplate.common.Search;
import com.datatemplate.constants.SQLConstants;
import com.datatemplate.dao.CommonDAO;
import com.datatemplate.dao.ContractDAO;
import com.datatemplate.dto.Contract;
import com.datatemplate.entity.Error;
import com.datatemplate.repository.ComboListRepo;
import com.datatemplate.repository.ContractRepo;
import com.datatemplate.repository.VendorRepo;
import com.datatemplate.service.impl.ContractServiceImpl;

@Service
public class ContractService implements ContractServiceImpl,SQLConstants {


	@Autowired
	private CommonDAO commonDAO;
	
	@Autowired
	private ContractDAO contractDao ;
	
	@Autowired
	private ComboListRepo comboListRepo;
	
	@Autowired
	private ContractRepo contractRepo;
 
	@Autowired
	private VendorRepo vendorRepo;
	
	
	@Override
	public Map<String, Object> getContractList(Search search) {
		   search.setSelect(CONTRACT_SELECT);
		   if(search.getOrderby()== null) {
			   search.setOrderby(CONTRACT_ORDER_BY); 
		   }else {
			   if(search.getOrderby().equals("createdOn") || search.getOrderby().equals("createdOn desc")) {
				   if(search.getOrderby().equals("createdOn")) {
					   search.setOrderby(" order by created_on");
				   }else {
					   search.setOrderby(" order by created_on desc");
				   }
			   }else if(search.getOrderby().equals("statusId") || search.getOrderby().equals("statusId desc")){
				   if(search.getOrderby().equals("statusId")) {
					   search.setOrderby(" order by statusId"); 
				   }else {
					   search.setOrderby(" order by statusId desc");
				   }		   
			   }else {			   
				   search.setOrderby(" order by "+search.getOrderby());
			   }
		   }
			Map<String, Object> resultMap  =  new HashMap<>();
			Contract contract = null;
			Error error =  new Error();
			error.setStatusCode("200");
			List<Contract> contractList =  new ArrayList<Contract>();
			List<Object[]> rows = commonDAO.getMasterList(search,CONTRACT_FIELDS);
			
			 try {    
				 if(null != rows && rows.isEmpty()) {
						error.setStatusCode("500");
						 resultMap.put("ERROR",error);
						 return resultMap;
					}
				 //Object[] r = rows.get(0);
		         //long vendorid = Long.parseLong(r[12].toString());
				int count = commonDAO.getMasterCount(search, CONTRACT_FIELDS);
				for(Object[] row : rows){
					  contract = new Contract();
					  contract.setId(null != row[0] ?  Long.parseLong(row[0].toString()) : null);
					 contract.setContractname(null != row[1] ?  row[1].toString() : "");
					 contract.setStartdate(null != row[2] ?  (java.util.Date)row[2] : null);
					 contract.setEnddate(null != row[3] ?  (java.util.Date)row[3] : null);
					 contract.setRenewaldate(null != row[4] ?  (java.util.Date)row[4] : null);
					 contract.setFee(null != row[5] ?  row[5].toString() : "");
					 contract.setNotes(null != row[6] ?  row[6].toString() : "");
					 contract.setUploaddocument(null != row[7] ?  findFileName(row[7].toString()) : "");
					 contract.setStatus(null != row[10] ? comboListRepo.findById(Integer.parseInt(row[10].toString())) : null);
					 contract.setContractterm(null != row[8] ? comboListRepo.findById(Integer.parseInt(row[8].toString())) : null);
					 contract.setFeestructure(null != row[9] ? comboListRepo.findById(Integer.parseInt(row[9].toString())) : null);
					 contract.setCreatedOn((java.util.Date)row[11]);
					 contract.setStatusId(null != contract.getStatus() ?  contract.getStatus().getDisplayvalue() : "");
					 if(null != row[12] && Integer.parseInt(row[12].toString()) >  0) {
						 contract.setVendorid( vendorRepo.findByvendorid(Long.parseLong(row[12].toString())));
					 }
					 contract.setContracttermId(null != contract.getContractterm() ?  contract.getContractterm().getDisplayvalue() : "");
					 contract.setFeestructureId(null != contract.getFeestructure() ?  contract.getFeestructure().getDisplayvalue() : "");
					 contractList.add(contract);
				}
				resultMap.put("CONTRACTS",contractList);
				resultMap.put("TOTAL",count);
			} catch (NumberFormatException e) {
				error.setStatusCode("400");
			}
			 resultMap.put("ERROR",error);
			return resultMap;
	}

	@Override
	public Map<String, Object> saveContract(Contract contract) {
		return contractDao.saveContract(contract);
	}

	@Override
	public Map<String, Object> getContract(Long id) {
		return contractDao.getContract(id);
	}

	public String findFileName(String fileName){
		String[] fileNames = fileName.split(",");
		StringBuilder names = new StringBuilder();
		for(String fName : fileNames) {
			Path path = Paths.get(fName);
			names.append(path.getFileName().toString()).append(",");
		}
		String f = names.toString();
		return f.substring(0, f.length() - 1);
	}
	
	@Override
	public Map<String, Object> deleteFiles(Long id, String filename) {
	    return 	contractDao.deleteFiles(id,filename);
		
	}
	
}
