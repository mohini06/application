package com.datatemplate.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.datatemplate.dao.impl.InsuranceDAOImpl;
import com.datatemplate.dto.Insurance;
import com.datatemplate.dto.Vendor;
import com.datatemplate.entity.Error;
import com.datatemplate.repository.ComboListRepo;
import com.datatemplate.repository.InsuranceRepo;
import com.datatemplate.repository.UserRepo;
import com.datatemplate.repository.VendorRepo;


@Transactional
@Repository
public class InsuranceDAO implements InsuranceDAOImpl {

	@Autowired
	private InsuranceRepo insuranceRepo;
	
	@Autowired
	private UserRepo userRepo;

	@Autowired
	private ComboListRepo comboListRepo;

	@PersistenceContext	
	private EntityManager entityManager;

	@Autowired
	private VendorRepo vendorRepo;

	@Override
	public Map<String, Object> saveInsurance(Insurance insurance) {
		Map<String, Object>  resultMap  = new HashMap<String, Object>();
		Error error =  new Error();
		error.setStatusCode("200");
		if(null != insurance.getStatusId()) {
			insurance.setStatus(comboListRepo.findById(Integer.parseInt(insurance.getStatusId())));
		}
		
		if(null != insurance.getTypeId()) {
			insurance.setType(comboListRepo.findById(Integer.parseInt(insurance.getTypeId())));
		}

		if(null != insurance.getVid()) { 
			Vendor vendor =vendorRepo.findByvendorid(Long.parseLong(insurance.getVid()));
			insurance.setVendorid(vendor); 
		}
		insurance.setModifiedby(userRepo.findByUsername(insurance.getUserId()));
		try {
			if(null != insurance.getId()) {
				Insurance existInsurance = entityManager.find(Insurance.class, insurance.getId());
				existInsurance.setName(insurance.getName());
				existInsurance.setStatus(insurance.getStatus());
				existInsurance.setType(insurance.getType());
				existInsurance.setNotes(insurance.getNotes());
				existInsurance.setStartdate(insurance.getStartdate());
				existInsurance.setEnddate(insurance.getEnddate());
				existInsurance.setRenewaldate(insurance.getRenewaldate());
				existInsurance.setModifiedby(insurance.getModifiedby());
				existInsurance.setUploaddocument(insurance.getUploaddocument()!= null ? insurance.getUploaddocument() : existInsurance.getUploaddocument());
				entityManager.persist(existInsurance);
				resultMap.put("INSURANCE", existInsurance );
			}
			else {
				insurance.setCreatedby(insurance.getModifiedby());
				insurance.setCreatedOn(new Date());
				resultMap.put("INSURANCE",  insuranceRepo.save(insurance));
			}
		} catch (Exception e) {
			error.setStatusCode("401");
		}
		resultMap.put("ERROR",error);
		return resultMap;
	}

	@Override
	public Map<String, Object> getInsurance(Long id) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();
		error.setStatusCode("200");
		try {
			Insurance insurance =  entityManager.find(Insurance.class, id);
			resultMap.put("INSURANCE", insurance);
		} catch (Exception e) {
			error.setStatusCode("401");
		}
		resultMap.put("ERROR", error);
		return resultMap;
	}
	
	@Override
	public Map<String, Object> deleteFiles(Long id, String filename) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();
		error.setStatusCode("200");
        Insurance existInsurance = new Insurance();
        System.out.println(id);
        existInsurance = insuranceRepo.findById(id).size() != 0
				? insuranceRepo.findById(id).get(0)
				: null;
		try {
			if (null != existInsurance.getId()) {
				existInsurance.setUploaddocument(null);
					entityManager.persist(existInsurance);
					error.setStatusMsg("File deleted successfully...");
			}
			else {

			}

		} catch (Exception e) {
			error.setStatusCode("401");
			error.setStatusMsg("Failure");
		}
		resultMap.put("ERROR", error);
		return resultMap;

	}

}



