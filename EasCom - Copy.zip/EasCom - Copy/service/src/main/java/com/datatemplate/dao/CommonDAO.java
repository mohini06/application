package com.datatemplate.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.datatemplate.common.Search;
import com.datatemplate.common.SearchCriteria;
import com.datatemplate.constants.SQLConstants;
import com.datatemplate.dao.impl.CommonDAOImpl;
import com.datatemplate.repository.VendorRepo;
import com.mysql.jdbc.CallableStatement;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.internal.SessionImpl;

import java.sql.Connection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import com.datatemplate.entity.Error;

@Transactional
@Repository
public class CommonDAO implements CommonDAOImpl , SQLConstants{
	
	@Autowired
	private VendorRepo vendorrepo;
	
	@PersistenceContext	
	private EntityManager entityManager;
	
	@Override
	public List<Object[]>  getMasterList(Search search,String fields) {
	    String where = "";
		String sql = "";
		String subWhere = "";
		int per = Integer.parseInt(search.getPer());
		int pageNo  =  Integer.parseInt(search.getPage());
		String limit = " LIMIT 0,"+per;
		if( pageNo > 1 ) {
			limit = " LIMIT "+(pageNo*per-per)+","+pageNo*per;
		}
		Error error = new Error();
		Session session = entityManager.unwrap(Session.class);
		SessionImpl sessionImpl = (SessionImpl) session;
		Connection conn = sessionImpl.connection();
		CallableStatement proc;
		List<Object[]> rows = null;
		 try { 
			  where =   null != search ? composeWhere(search,fields) : "";
			  if( search.getVendorid() > 0 ) {
				  subWhere = "   vendorid  =  "+search.getVendorid();
			  }
			  if( search.getTemplateid() > 0 ) {
				  subWhere = "   templateid  =  "+search.getTemplateid();
			  }
			  if(where.length() > 0 ) {
				  if(subWhere.length() > 0) {
					  sql =   search.getSelect()+"  where "+where.substring(0,where.length()-6)+" and "+subWhere+search.getOrderby()+limit ;
				  }
				  else {
					  sql =   search.getSelect()+"  where "+where.substring(0,where.length()-6)+search.getOrderby()+limit ;

				  }
 			  }
			  else {
				  subWhere = subWhere.length() > 0 ? " where "+subWhere : "";
				  sql = search.getSelect()+ subWhere +search.getOrderby()+limit ;
			  }
			  
			  SQLQuery query = session.createSQLQuery(sql);
			   rows = query.list();
				 
			    
			} catch (Exception e ) {
				error.setStatusCode("400");
				error.setStatusMsg(e.getMessage());
			}
			 
	 return rows;

	}
	
	@Override
	public int getMasterCount(Search search,String fields) {
	    String where = "";
		String sql = "";
		String subWhere = "";
		Error error = new Error();
		Session session = entityManager.unwrap(Session.class);
		SessionImpl sessionImpl = (SessionImpl) session;
		Connection conn = sessionImpl.connection();
		CallableStatement proc;
		int count = 0;
		 try { 
			  where =   null != search ? composeWhere(search,fields) : "";
			  if( search.getVendorid() > 0 ) {
				  subWhere = "   vendorid  =  "+search.getVendorid();
			  }
			  if( search.getTemplateid() > 0 ) {
				  subWhere = "   templateid  =  "+search.getTemplateid();
			  }
			  if(where.length() > 0 ) {
				  if(subWhere.length() > 0) {
					  sql =   search.getSelect()+"  where "+where.substring(0,where.length()-6)+" and "+subWhere+search.getOrderby() ;
				  }
				  else {
					  sql =   search.getSelect()+"  where "+where.substring(0,where.length()-6)+search.getOrderby() ;

				  }
 			  }
			  else {
				  subWhere = subWhere.length() > 0 ? " where "+subWhere : "";
				  sql = search.getSelect()+ subWhere +search.getOrderby() ;
			  }
			  
			  SQLQuery query = session.createSQLQuery(sql);
			   count = query.list().size();
				 
			    
			} catch (Exception e ) {
				error.setStatusCode("400");
				error.setStatusMsg(e.getMessage());
			}
			 
	 return count;

	}
	
	private String composeWhere(Search search,String fields) {
		StringBuffer result = new StringBuffer();
		for(SearchCriteria sc: search.getStartswith()) {//starts with
			if(sc.getColname().equals("statusId")) {
				sc.setColname("cl.displayvalue"); 
			 }
			if(sc.getColname().equals("createdOn") && search.getMastertype().equals("questionnaire")) {
				sc.setColname("questionnaire.created_on"); 
			 }
			if(sc.getColname().equals("createdOn")) {
				sc.setColname("created_on"); 
			 }
			if(sc.getColname().equals("stateId")) {
				sc.setColname("cstate.displayvalue"); 
			 }
			if(sc.getColname().equals("severityId")) {
				sc.setColname("cl.displayvalue"); 
			 }
			if(sc.getColname().equals("templateId")) {
				sc.setColname("temp.name"); 
			 }

			  result.append(sc.getColname()).append(" like  '").append(composeSpecialCharacters(sc.getValue())).append("%'  and ");
		 
		}
		for(SearchCriteria sc: search.getEndswith()) {//ends with
			 
			  result.append(sc.getColname()).append(" like   '%").append(composeSpecialCharacters(sc.getValue())).append("'   and ");
		}
		for(SearchCriteria sc: search.getContains()) {//contains
			  result.append(sc.getColname()).append(") like  '%").append(composeSpecialCharacters(sc.getValue())).append("%' and ");
		}
		for(SearchCriteria sc: search.getEqual()) {//Equal
			if(sc.getColname().equals("createdOn") && search.getMastertype().equals("questionnaire")) {
				sc.setColname("questionnaire.created_on"); 
			 }
			if(sc.getColname().equals("createdOn")) {
				sc.setColname("created_on"); 
			 }
			if( sc.getColname().contains("date")) {
				if(isValidDate( sc.getColname())) {
					result.append(sc.getColname()).append(" =   '").append(sc.getValue()).append("'  and ");
				}else {
					result.append(sc.getColname()).append("  =  '").append(composeSpecialCharacters(sc.getValue())).append("'  and ");
				}
			}
			else {
			  result.append(sc.getColname()).append("  =  '").append(composeSpecialCharacters(sc.getValue())).append("'  and ");
			}
		}
		for(SearchCriteria sc: search.getNotequal()) {//Not Equal
			if( sc.getColname().contains("date")) {
				if(isValidDate( sc.getColname())) {
					result.append(sc.getColname()).append(" !=    '").append(sc.getValue()).append("'  and ");
				}
			}
			else {
		    	result.append(sc.getColname()).append("  !=  '").append(composeSpecialCharacters(sc.getValue())).append("'  and ");
			}
		}
		for(SearchCriteria sc: search.getGreaterthan()) {//Date Greateer than
			if(sc.getColname().equals("createdOn") && search.getMastertype().equals("questionnaire")) {
				sc.setColname("questionnaire.created_on"); 
			 }
			if(sc.getColname().equals("createdOn")) {
				sc.setColname("created_on"); 
			 }
			result.append(sc.getColname()).append(" >    '").append(sc.getValue()).append("'   and ");
		}
		for(SearchCriteria sc: search.getGreaterthanorequal()) {//Date Greateer than or equal
			if(sc.getColname().equals("createdOn") && search.getMastertype().equals("questionnaire")) {
				sc.setColname("questionnaire.created_on"); 
			 }
			if(sc.getColname().equals("createdOn")) {
				sc.setColname("created_on"); 
			 }
			result.append(sc.getColname()).append(" >=   ''").append(sc.getValue()).append("''  and ");
		}
		for(SearchCriteria sc: search.getLessthan()) {//less than
			if(sc.getColname().equals("createdOn") && search.getMastertype().equals("questionnaire")) {
				sc.setColname("questionnaire.created_on"); 
			 }
			if(sc.getColname().equals("createdOn")) {
				sc.setColname("created_on"); 
			 }
			result.append(sc.getColname()).append(" <    '").append(sc.getValue()).append("'   and ");
		}
		for(SearchCriteria sc: search.getLessthanorequal()) {//less than or Equal
			if(sc.getColname().equals("createdOn") && search.getMastertype().equals("questionnaire")) {
				sc.setColname("questionnaire.created_on"); 
			 }
			if(sc.getColname().equals("createdOn")) {
				sc.setColname("created_on"); 
			 }
			result.append(sc.getColname()).append(" <=   '").append(sc.getValue()).append("'   and ");
		}
		for(SearchCriteria sc: search.getCommonsearch()) {
			if(sc.getValue().contains("/")) {
				String[] date = sc.getValue().split("/");
				if(date.length >= 3) {
				  sc.setValue(date[2]+"-"+date[0]+"-"+date[1]);
				}	
			}
			result.append(fields.replaceAll("_DELIMITER_", sc.getValue())).append("  or  ");			 
		}
		 
		return result.toString();
	}
	
	private String composeSpecialCharacters(String str) {
		if(null != str && str.length() > 0 && str.contains("%")) {
			str = str.replaceAll("%", "!%");
		}
		return str;
	}
	  private   boolean isValidDate(String inDate) {
		    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	        sdf.setLenient(false);
	        try {
	        	sdf.parse(inDate.trim());
	        } catch (ParseException pe) {
	            return false;
	        }
	        return true;
	    }
	 
}
