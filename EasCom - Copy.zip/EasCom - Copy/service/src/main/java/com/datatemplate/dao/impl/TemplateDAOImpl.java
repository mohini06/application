package com.datatemplate.dao.impl;

import java.util.Map;

import com.datatemplate.dto.Questionnaire;
import com.datatemplate.dto.Template;

public interface TemplateDAOImpl {

	Map<String, Object> saveTemplate(Template template);

}
