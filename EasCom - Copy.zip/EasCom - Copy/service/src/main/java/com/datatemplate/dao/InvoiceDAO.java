package com.datatemplate.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.datatemplate.dao.impl.InvoiceDAOImpl;
import com.datatemplate.dto.Invoice;
import com.datatemplate.dto.Vendor;
import com.datatemplate.entity.Error;
import com.datatemplate.repository.ComboListRepo;
import com.datatemplate.repository.InvoiceRepo;
import com.datatemplate.repository.UserRepo;
import com.datatemplate.repository.VendorRepo;

@Transactional
@Repository
public class InvoiceDAO implements InvoiceDAOImpl {

	@Autowired
	private InvoiceRepo invoiceRepo;
	
	@Autowired
	private UserRepo userRepo;

	@Autowired
	private ComboListRepo comboListRepo;

	@PersistenceContext	
	private EntityManager entityManager;

	@Autowired
	private VendorRepo vendorRepo;
	
	@Override
	public Map<String, Object> saveInvoice(Invoice invoice) {
		Map<String, Object>  resultMap  = new HashMap<String, Object>();
		Error error =  new Error();
		error.setStatusCode("200");
		if(null != invoice.getStatusId()) {
			invoice.setStatus(comboListRepo.findById(Integer.parseInt(invoice.getStatusId())));
		}

		if(null != invoice.getVid()) { 
			Vendor vendor =vendorRepo.findByvendorid(Long.parseLong(invoice.getVid()));
			invoice.setVendorid(vendor); 
		}
		invoice.setModifiedBy(userRepo.findByUsername(invoice.getUserId()));
		try {
			if(null != invoice.getId()) {
				Invoice existInvoice = entityManager.find(Invoice.class, invoice.getId());
				existInvoice.setStatus(invoice.getStatus());
				existInvoice.setNotes(invoice.getNotes());
				existInvoice.setStartdate(invoice.getStartdate());
				existInvoice.setEnddate(invoice.getEnddate());
				existInvoice.setAmount(invoice.getAmount());
				existInvoice.setNumber(invoice.getNumber());
				existInvoice.setDate(invoice.getDate());
				existInvoice.setModifiedBy(invoice.getModifiedBy());
				existInvoice.setUploaddocument(invoice.getUploaddocument() != null ? invoice.getUploaddocument() : existInvoice.getUploaddocument());
				entityManager.persist(existInvoice);
				resultMap.put("INVOICE", existInvoice );
			}
			else {
				invoice.setCreatedOn(new Date());
				invoice.setCreatedBy(invoice.getModifiedBy());
				resultMap.put("INVOICE",  invoiceRepo.save(invoice));
			}
		} catch (Exception e) {
			error.setStatusCode("401");
		}
		resultMap.put("ERROR",error);
		return resultMap;
	}

	@Override
	public Map<String, Object> getInvoice(Long id) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();
		error.setStatusCode("200");
		try {
			Invoice invoice =  entityManager.find(Invoice.class, id);
			resultMap.put("INVOICE", invoice);
		} catch (Exception e) {
			error.setStatusCode("401");
		}
		resultMap.put("ERROR", error);
		return resultMap;
	}
	
	@Override
	public Map<String, Object> deleteFiles(Long id, String filename) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();
		error.setStatusCode("200");
        Invoice existInvoice = new Invoice();
        System.out.println(id);
        existInvoice = invoiceRepo.findById(id).size() != 0
				? invoiceRepo.findById(id).get(0)
				: null;
		try {
			if (null != existInvoice.getId()) {
				existInvoice.setUploaddocument(null);
					entityManager.persist(existInvoice);
					error.setStatusMsg("File deleted successfully...");
			}
			else {

			}

		} catch (Exception e) {
			error.setStatusCode("401");
			error.setStatusMsg("Failure");
		}
		resultMap.put("ERROR", error);
		return resultMap;

	}
	
}
