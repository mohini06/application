package com.datatemplate.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.datatemplate.common.Search;
import com.datatemplate.dto.PoliciesAndProcedures;
import com.datatemplate.entity.Error;
import com.datatemplate.service.PoliciesService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/policie")
@PropertySource("classpath:application.properties")
public class PoliciesController {

	@Autowired
	private PoliciesService policiesService;

	@Autowired
	private Environment env;

	@PostMapping("/policies")
	public  ResponseEntity<List<PoliciesAndProcedures>>  getPoliciesList(@RequestBody String search) {

		ObjectMapper mapper = new ObjectMapper();
		Map resultMap =  new HashMap<>() ;
		List<PoliciesAndProcedures> policiesList = new ArrayList<PoliciesAndProcedures>();
		try {

			Search searchJson  = mapper.readValue(search, Search.class);
			resultMap = policiesService.getPoliciesList(searchJson);
			com.datatemplate.entity.Error error = (com.datatemplate.entity.Error) resultMap.get("ERROR");
			if(error.getStatusCode().equals("500")) {
				//PoliciesAndProcedures policies  =  new PoliciesAndProcedures();
				//policies.setTotal(0);
				//policiesList.add(policies);
				return new ResponseEntity<List<PoliciesAndProcedures>>(null ,new HttpHeaders(), HttpStatus.OK);
			}
			policiesList = ( List<PoliciesAndProcedures> )resultMap.get("POLICIES");
			if(null != policiesList && policiesList.size()> 0) {
				PoliciesAndProcedures policies = policiesList.get(0);
				policies.setTotal(Integer.parseInt(resultMap.get("TOTAL").toString()));
			}
		} catch (JsonParseException e) {
			System.out.println(e.getMessage());
		} catch (JsonMappingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return new ResponseEntity<List<PoliciesAndProcedures>>(policiesList ,new HttpHeaders(), HttpStatus.OK);

	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ResponseEntity<?> savepolicie(@RequestParam("files") MultipartFile[] files,
			@RequestParam("name") String name,
			@RequestParam("notes") String notes,
			@RequestParam("startdate") String startdate,
			@RequestParam("enddate") String enddate,
			@RequestParam("renewaldate") String renewaldate,
			@RequestParam("statusId") String statusId,
			@RequestParam("id") String id,
			@RequestParam("vid") String vid,
			@RequestParam("typeId") String typeId,
			@RequestParam("approvedbyexecutive") String approvedbyexecutive,
			@RequestParam("userId") String userId) throws Exception {
		PoliciesAndProcedures policies = new PoliciesAndProcedures();
		FileOutputStream fileOutputStream = null;
		policies.setId(id.equals("") ? null : Long.parseLong(id));
		policies.setVid(vid.equals("") ? null : vid);
		policies.setUserId(userId.equals("") ? null : userId);
		policies.setTypeId(typeId.equals("") ? null : typeId);
		policies.setName(name);
		policies.setNotes(notes);
		policies.setApprovedbyexecutive(approvedbyexecutive);
		if(renewaldate.equals("null")) {
			policies.setRenewaldate(null);
		}else {
			policies.setRenewaldate(new SimpleDateFormat("yyyy-MM-dd").parse(renewaldate));
		}
		policies.setStartdate(new SimpleDateFormat("yyyy-MM-dd").parse(startdate));
		policies.setEnddate(new SimpleDateFormat("yyyy-MM-dd").parse(enddate));
		policies.setStatusId(statusId);
		policies.setVid(vid);
		Map<String, Object>  resultMap  = policiesService.savePolicies(policies);
		Error error =  (Error)resultMap.get("ERROR");
		if(error.getStatusCode().equals("401")) {
			return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
		}
		PoliciesAndProcedures savedPolicie = (PoliciesAndProcedures)resultMap.get("POLICIE");

		if(files.length > 0) {

			File dir = new File(env.getProperty("uploadDir") + File.separator + "policies_docs");
			File subDir = new File(dir.getAbsolutePath()+ File.separator + savedPolicie.getId());

			if (!dir.exists()){
				dir.mkdirs();
				if(!subDir.exists()){
					subDir.mkdirs();
				}
			}
			else if (!subDir.exists()){
				subDir.mkdirs();
			}
			StringBuilder fileName = new StringBuilder();
			for (MultipartFile multipartFile : files) {

				File uploadedFile = new File(subDir, multipartFile.getOriginalFilename().replace(",", ""));
				fileName.append(uploadedFile.getAbsoluteFile().getPath()).append(",");
				try {
					uploadedFile.createNewFile();
					fileOutputStream = new FileOutputStream(uploadedFile);
					fileOutputStream.write(multipartFile.getBytes());
					fileOutputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
			String f = fileName.toString();
			policies.setUploaddocument(f.substring(0, f.length() - 1));
			Map<String, Object>  resultMap1  = policiesService.savePolicies(policies);
			Error error1 =  (Error)resultMap1.get("ERROR");
			if(error1.getStatusCode().equals("401")) {
				return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
			}
			savedPolicie = (PoliciesAndProcedures)resultMap1.get("POLICIE");
		}

		return ResponseEntity.ok(savedPolicie);
	}

	@RequestMapping(value="/policies/{id}", method = RequestMethod.GET) 
	public ResponseEntity<?>  getByPolicieId(@PathVariable Long id) {
		Map resultMap =  policiesService.getPolicie(id);
		Error error  = (Error)resultMap.get("ERROR");
		if(error.getStatusCode().equals("401")) {
			return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
		}
		PoliciesAndProcedures  pAndp  =  (PoliciesAndProcedures)resultMap.get("POLICIE");
		return ResponseEntity.ok(pAndp);
	}
	
	@RequestMapping(path = "/downloadDocs", method = RequestMethod.GET)
	public void downloadFile(HttpServletResponse res,
			@RequestParam("id") String id,
			@RequestParam("filename") String filename) throws Exception {
		String filePath = env.getProperty("uploadDir") + File.separator + "policies_docs" + File.separator + id + File.separator + filename;
		res.setHeader("Content-Disposition", "attachment; filename=" + filename);
		res.getOutputStream().write(Files.readAllBytes(Paths.get(filePath)));
	}
	
	@RequestMapping(value = "/deleteDocs", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteFile(@RequestParam("id") Long id, @RequestParam("filename") String filename)
			throws Exception {

		ObjectMapper mapper = new ObjectMapper();
		Map resultMap = new HashMap<>();

		resultMap = policiesService.deleteFiles(id, filename);
		System.out.println(resultMap);
		Error error = (Error) resultMap.get("ERROR");
		if (error.getStatusCode().equals("200")) {
			return ResponseEntity.ok(resultMap.get("ERROR"));

		} else {
			return ResponseEntity.ok(resultMap.get("ERROR"));
		}

	}
	
}
