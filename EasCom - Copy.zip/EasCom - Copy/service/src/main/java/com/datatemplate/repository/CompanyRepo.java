package com.datatemplate.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.datatemplate.dto.Company;

public interface CompanyRepo extends JpaRepository<Company, Long> {

}
