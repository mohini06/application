package com.datatemplate.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.datatemplate.dto.Answers;
import com.datatemplate.dto.Vendor;

public interface AnswersRepo extends JpaRepository<Answers, Long> {

	List<Answers> findByVendor(Vendor vendor);
	
	List<Answers> findByUploadlabelid(String lableid);
	
	List<Answers> findById(Long id);
	
	
//	Answers findByVendor(int vendor);
	
	

}
