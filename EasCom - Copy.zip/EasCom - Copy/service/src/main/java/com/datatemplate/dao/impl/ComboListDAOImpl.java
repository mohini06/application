package com.datatemplate.dao.impl;

import java.util.List;

import com.datatemplate.dto.ComboList;

public interface ComboListDAOImpl {
    
   Boolean saveComboList();
 
   List<ComboList> getComboList(String type);
}
    
   
    
   
 