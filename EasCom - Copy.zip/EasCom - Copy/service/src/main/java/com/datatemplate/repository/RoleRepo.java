package com.datatemplate.repository;

import org.springframework.data.jpa.repository.JpaRepository;

 
import com.datatemplate.dto.Role;
 
public interface RoleRepo extends JpaRepository<Role, Long>{

	Role findById(long id);
	
 
}
 