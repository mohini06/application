package com.datatemplate.constants;


public interface SQLConstants {
	
	static String TIME_FORMAT = "yyyy/MM/dd";
	static String USER = "USER";
	static String ROLE = "ROLE";
	static String VENDOR =  "vendor";
	
	static String VENDORS_SELECT = "select distinct vendorname , accountnumber , email , phone , status, officetype , state , city ,created_on , createdby, fax,streetaddress1,streetaddress2,"
			+"vendorid,zipcode,riskcategory,industry,template,website,legalentity,cl.displayvalue statusId, cstate.displayvalue stateId from vendor left join combolist cl on vendor.status = cl.id left join combolist cstate on vendor.state = cstate.id";
	static String VENDOR_ORDER_BY  =  " order by created_on desc";
	static String VENDOR_FIELDS = "(vendorname like '%_DELIMITER_%' or accountnumber like '%_DELIMITER_%' or phone  like '%_DELIMITER_%'  or fax like '%_DELIMITER_%' "
			                      + " or zipcode  like '%_DELIMITER_%' or city like '%_DELIMITER_%' or created_on like '%_DELIMITER_%' or  cl.displayvalue like '%_DELIMITER_%' or  cstate.displayvalue like '%_DELIMITER_%')";

	static String CONTACT_SELECT  = "select firstname , lastname , email , fax , phone , status , created_on , createdby , vendor_contacts.id , vendorid, title ,notes,contactyesno,cl.displayvalue statusId  from vendor_contacts left join combolist cl on vendor_contacts.status = cl.id";
	static String CONTACT_ORDER_BY  = " order by created_on desc";
	static String CONTACT_FIELDS  =  "(firstname like '%_DELIMITER_%' or lastname like '%_DELIMITER_%' or email like '%_DELIMITER_%' or fax like '%_DELIMITER_%' or phone like '%_DELIMITER_%' or cl.displayvalue like '%_DELIMITER_%')";

	static String CONTRACT_SELECT = "select contract.id,contractname ,startdate, enddate , renewaldate , fee , notes , uploaddocument, contractterm ,"
			                         + " feestructure , status , created_on , vendorid,cl.displayvalue statusId from  contract left join combolist cl on contract.status = cl.id";
	static String CONTRACT_ORDER_BY  = " order by created_on desc";
	static String CONTRACT_FIELDS  =  "(contractname like '%_DELIMITER_%' or startdate like '%_DELIMITER_%' or enddate like '%_DELIMITER_%' or renewaldate like '%_DELIMITER_%' or cl.displayvalue like '%_DELIMITER_%')";

	static String INSURANCE_SELECT = "select insurance.id, name ,startdate, enddate , renewaldate , notes , uploaddocument, insurance.type, status , created_on ,"
			                        + " vendorid,cl.displayvalue statusId  from  insurance left join combolist cl on insurance.status = cl.id";
	static String INSURANCE_ORDER_BY  = " order by created_on desc";
	static String INSURANCE_FIELDS  =  "(name like '%_DELIMITER_%' or startdate like '%_DELIMITER_%' or enddate like '%_DELIMITER_%' or renewaldate like '%_DELIMITER_%' or cl.displayvalue like '%_DELIMITER_%')";
	
	static String POLICIES_SELECT = "select policiesprocedures.id, name ,startdate, enddate , renewaldate , notes , uploaddocument, policiesprocedures.type, status , created_on ,"
						                + " vendorid,approvedbyexecutive,cl.displayvalue statusId  from  policiesprocedures left join combolist cl on policiesprocedures.status = cl.id";
	static String POLICIES_ORDER_BY = " order by created_on desc";
	static String POLICIES_FIELDS = "(name like '%_DELIMITER_%' or startdate like '%_DELIMITER_%' or enddate like '%_DELIMITER_%' or renewaldate like '%_DELIMITER_%' or cl.displayvalue like '%_DELIMITER_%')";

	static String FINANCE_SELECT = "select finance.id, name ,startdate, enddate , renewaldate , notes , uploaddocument, finance.type, status , created_on ," 
									  +" vendorid,approvedbyexecutive,cl.displayvalue statusId  from  finance left join combolist cl on finance.status = cl.id";
	static String FINANCE_ORDER_BY = " order by created_on desc";
	static String FINANCE_FIELDS = "(name like '%_DELIMITER_%' or startdate like '%_DELIMITER_%' or enddate like '%_DELIMITER_%' or renewaldate like '%_DELIMITER_%' or cl.displayvalue like '%_DELIMITER_%')";
	
	static String INVOICE_SELECT = "select invoice.id ,startdate, enddate , date , notes , uploaddocument, number, amount, status , created_on ," 
			  +" vendorid,cl.displayvalue statusId  from  invoice left join combolist cl on invoice.status = cl.id";
    static String INVOICE_ORDER_BY = " order by created_on desc";
    static String INVOICE_FIELDS = "(number like '%_DELIMITER_%' or startdate like '%_DELIMITER_%' or enddate like '%_DELIMITER_%' or date like '%_DELIMITER_%' or cl.displayvalue like '%_DELIMITER_%')";
	
    static String INCIDENT_SELECT = "select incident.id, name ,startdate, enddate , duration , notes , uploaddocument, severity, created_on ," 
			  +" vendorid,cl.displayvalue severityId  from  incident left join combolist cl on incident.severity = cl.id";
    static String INCIDENT_ORDER_BY = " order by created_on desc";
    static String INCIDENT_FIELDS = "(name like '%_DELIMITER_%' or startdate like '%_DELIMITER_%' or enddate like '%_DELIMITER_%' or cl.displayvalue like '%_DELIMITER_%')";

    static String QUESTIONNAIRE_SELECT = "select questionnaire.id,label,options,type,required,questionnaire.templateid,questionnaire.created_on ,temp.name templateId from questionnaire left join "
    		  +"template temp on questionnaire.templateid = temp.id ";
    //static String QUESTIONNAIRE_ORDER_BY = " order by questionnaire.templateid ";
    static String QUESTIONNAIRE_ORDER_BY = " order by created_on desc ";
    static String QUESTIONNAIRE_FIELDS = "(label like '%_DELIMITER_%' or type like '%_DELIMITER_%' or temp.name like '%_DELIMITER_%' or questionnaire.created_on like '%_DELIMITER_%')";
    
    static String TEMPLATE_SELECT = "select id,name,created_on from template ";
    static String TEMPLATE_ORDER_BY = " order by created_on desc ";
    static String TEMPLATE_FIELDS = "(name like '%_DELIMITER_%' or created_on like '%_DELIMITER_%')";
    
    static String PNPCOUNTPERVENDOR = "select table1.item,table1.count,table1.inactive from " + 
    		"(SELECT vendorname as item,count(CASE WHEN policiesprocedures.status = 183 THEN policiesprocedures.id END) as count,count(CASE WHEN policiesprocedures.status = 184 THEN policiesprocedures.id END) as inactive  FROM policiesprocedures left join vendor on " + 
    		"policiesprocedures.vendorid = vendor.vendorid group by policiesprocedures.vendorid) as table1 ";
    static String PNPCOUNTPERVENDOR_FIELDS = "(item like '%_DELIMITER_%' or count like '%_DELIMITER_%' or inactive like '%_DELIMITER_%')";
    static String PNPCOUNTPERVENDOR_ORDER_BY = " order by item ";
  
}
