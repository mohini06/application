package com.datatemplate.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.datatemplate.dto.PoliciesAndProcedures;


public interface PoliciesRepo extends JpaRepository<PoliciesAndProcedures, Long> {
	
	@Query(value = "SELECT count(*) FROM policiesprocedures WHERE vendorid = :vendorId ", nativeQuery = true)
	int countByVendorId(@Param("vendorId") long vendorId);
	
	@Query(value = "SELECT vendorname,count(*) FROM policiesprocedures left join vendor on policiesprocedures.vendorid = vendor.vendorid where policiesprocedures.status = 183 group by policiesprocedures.vendorid", nativeQuery = true)
    List<Object[]> countPolicieByVendor();
	
    List<PoliciesAndProcedures> findById(Long id);
}
