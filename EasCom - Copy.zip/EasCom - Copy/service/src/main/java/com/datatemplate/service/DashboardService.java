package com.datatemplate.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.datatemplate.common.Search;
import com.datatemplate.constants.SQLConstants;
import com.datatemplate.dao.CommonDAO;
import com.datatemplate.dto.Graph;
import com.datatemplate.dto.Questionnaire;
import com.datatemplate.entity.Error;
import com.datatemplate.repository.ContractRepo;
import com.datatemplate.repository.FinancialRepo;
import com.datatemplate.repository.InsuranceRepo;
import com.datatemplate.repository.InvoiceRepo;
import com.datatemplate.repository.PoliciesRepo;
import com.datatemplate.repository.VendorRepo;
import com.datatemplate.service.impl.DashboardServiceImpl;

@Service
public class DashboardService implements DashboardServiceImpl,SQLConstants{
	
	@Autowired
	private ContractRepo contractRepo;
	
	@Autowired
	private InsuranceRepo insuranceRepo;
	
	@Autowired
	private InvoiceRepo invoiceRepo;
	
	@Autowired
	private FinancialRepo financialRepo;
	
	@Autowired
	private VendorRepo vendorRepo;
	
	@Autowired
	private PoliciesRepo policieRepo;
	
	@Autowired
	private CommonDAO commonDAO;

	@Override
	public List<Graph> getCountData(String days) {
		
		List<Graph> graphData = new ArrayList<Graph>();
		Graph contractCount = new Graph("Contract",contractRepo.contractCount(days));
		Graph insuranceCount = new Graph("Insurance",insuranceRepo.insuranceCount(days));
		Graph invoiceCount = new Graph("Invoice",invoiceRepo.invoiceCount(days));
		Graph financialCount = new Graph("Financial",financialRepo.financialCount(days));
		graphData.add(contractCount);
		graphData.add(insuranceCount);
		graphData.add(invoiceCount);
		graphData.add(financialCount);
		return graphData;
		
	}

	@Override
	public List<Graph> getBarData() {
		List<Object[]> rows = vendorRepo.findVendorByState();
		List<Graph> barDataList =  new ArrayList<Graph>();
		Graph barData = null;
		if(rows != null) {
			for(Object[] row : rows){
				barData = new Graph(row[0].toString(),Integer.parseInt(row[1].toString()));		
				barDataList.add(barData);
			}
		}else {
			barDataList = null;
		}
		return barDataList;
	}
	
//	@Override
//	public List<Graph> getTableData() {
//		List<Object[]> rows = policieRepo.countPolicieByVendor();
//		List<Graph> tableDataList =  new ArrayList<Graph>();
//		Graph tableData = null;
//		if(rows != null) {
//			for(Object[] row : rows){
//				tableData = new Graph(row[0].toString(),Integer.parseInt(row[1].toString()));		
//				tableDataList.add(tableData);
//			}
//		}else {
//			tableDataList = null;
//		}
//		return tableDataList;
//	}
	
	@Override
	public Map<String, Object> getTableData(Search search) {
		search.setSelect(PNPCOUNTPERVENDOR);
		if(search.getOrderby()== null) {
			search.setOrderby(PNPCOUNTPERVENDOR_ORDER_BY); 
		}
		else {
			search.setOrderby(" order by "+search.getOrderby());
		}
		
		Map<String, Object> resultMap  =  new HashMap<>();
		Graph tableData = null;
		Error error =  new Error();
		error.setStatusCode("200");
		List<Graph> tableDataList =  new ArrayList<Graph>();
		List<Object[]> rows = commonDAO.getMasterList(search,PNPCOUNTPERVENDOR_FIELDS);

		try {    

			if(null != rows && rows.isEmpty()) {
				error.setStatusCode("500");
				resultMap.put("ERROR",error);
				return resultMap;
			}
			//Object[] r = rows.get(0);
			//long vendorid = Long.parseLong(r[10].toString());
			int count = commonDAO.getMasterCount(search, PNPCOUNTPERVENDOR_FIELDS);
			for(Object[] row : rows){
				tableData = new Graph(row[0].toString(),Integer.parseInt(row[1].toString()),Integer.parseInt(row[2].toString()));		
	            tableDataList.add(tableData);
			}
			resultMap.put("TABLEDATA",tableDataList);
			//resultMap.put("TOTAL",policiesRepo.countByVendorId(vendorid));
			resultMap.put("TOTAL", count);
		} catch (NumberFormatException e) {
			error.setStatusCode("400");
		}
		resultMap.put("ERROR",error);
		return resultMap;
	}

}
