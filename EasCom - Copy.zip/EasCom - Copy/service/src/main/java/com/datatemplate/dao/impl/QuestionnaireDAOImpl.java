package com.datatemplate.dao.impl;

import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.datatemplate.dto.Answers;
import com.datatemplate.dto.Questionnaire;

public interface QuestionnaireDAOImpl {

	Map<String, Object> saveQuestionnaire(Questionnaire questionnaire);

	Map<String, Object> saveAnswer(Answers answer);
	
	
//	String saveAnswers(MultipartFile[] file, String answer, int vendorid);

	Map<String, Object> saveAnswers(MultipartFile[] file, String answer, Long vendorid, String lableid);
	
	Map<String, Object> deleteFiles(Long id, String filename);
	
}
