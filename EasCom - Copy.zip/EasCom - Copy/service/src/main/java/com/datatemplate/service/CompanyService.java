package com.datatemplate.service;

import org.springframework.stereotype.Service;

import com.datatemplate.service.impl.CompanyServiceImpl;

@Service
public class CompanyService implements CompanyServiceImpl{

}
