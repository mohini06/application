package com.datatemplate.dao.impl;

import java.util.Map;

import com.datatemplate.dto.VendorContacts;

public interface ContactDAOImpl {

	
	public Map<String, Object> saveContact(VendorContacts vc);
	
	public Map<String, Object> getContact(Long id);
}
