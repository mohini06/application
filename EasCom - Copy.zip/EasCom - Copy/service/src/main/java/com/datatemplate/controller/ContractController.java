package com.datatemplate.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.datatemplate.common.Search;
import com.datatemplate.dto.Contract;
import com.datatemplate.dto.Vendor;
import com.datatemplate.entity.Error;
import com.datatemplate.service.ContractService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/contract")
@PropertySource("classpath:application.properties")
public class ContractController {

	@Autowired
	private ContractService contractService;

	@Autowired
	private Environment env;

	@PostMapping("/contracts")
	public ResponseEntity<List<Contract>> getContractList(@RequestBody String search) {

		ObjectMapper mapper = new ObjectMapper();
		Map resultMap = new HashMap<>();
		List<Contract> contractList = new ArrayList<Contract>();
		try {

			Search searchJson = mapper.readValue(search, Search.class);
			resultMap = contractService.getContractList(searchJson);
			com.datatemplate.entity.Error error = (com.datatemplate.entity.Error) resultMap.get("ERROR");
			if (error.getStatusCode().equals("500")) {
				// Contract contract = new Contract();
				// contract.setTotal(0);
				// contractList.add(contract);
				return new ResponseEntity<List<Contract>>(null, new HttpHeaders(), HttpStatus.OK);
			}
			contractList = (List<Contract>) resultMap.get("CONTRACTS");

			if (contractList.size() > 0) {
				Contract con = contractList.get(0);
				con.setTotal(Integer.parseInt(resultMap.get("TOTAL").toString()));
			}
		} catch (JsonParseException e) {
			System.out.println(e.getMessage());
		} catch (JsonMappingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return new ResponseEntity<List<Contract>>(contractList, new HttpHeaders(), HttpStatus.OK);

	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ResponseEntity<?> saveContact(@RequestParam("files") MultipartFile[] files,
			@RequestParam("contractname") String contractname, @RequestParam("notes") String notes,
			@RequestParam("termId") String termId, @RequestParam("startdate") String startdate,
			@RequestParam("enddate") String enddate, @RequestParam("renewaldate") String renewaldate,
			@RequestParam("fee") String fee, @RequestParam("statusId") String statusId,
			@RequestParam("feeId") String feeId, @RequestParam("id") String id, @RequestParam("vid") String vid,
			@RequestParam("userId") String userId) throws Exception {
		Contract contract = new Contract();
		FileOutputStream fileOutputStream = null;
		contract.setId(id.equals("") ? null : Long.parseLong(id));
		contract.setVid(vid.equals("") ? null : vid);
		contract.setUserId(userId.equals("") ? null : userId);
		contract.setContractname(contractname);
		contract.setNotes(notes);
		contract.setFee(fee);
		if (renewaldate.equals("null")) {
			contract.setRenewaldate(null);
		} else {
			contract.setRenewaldate(new SimpleDateFormat("yyyy-MM-dd").parse(renewaldate));
		}
		contract.setStartdate(new SimpleDateFormat("yyyy-MM-dd").parse(startdate));
		contract.setEnddate(new SimpleDateFormat("yyyy-MM-dd").parse(enddate));
		contract.setStatusId(statusId);
		contract.setContracttermId(termId);
		contract.setFeestructureId(feeId);
		contract.setVid(vid);
		Map<String, Object> resultMap = contractService.saveContract(contract);
		Error error = (Error) resultMap.get("ERROR");
		if (error.getStatusCode().equals("401")) {
			return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
		}
		Contract ct = (Contract) resultMap.get("CONTRACT");

		if (files.length > 0) {

			File dir = new File(env.getProperty("uploadDir") + File.separator + "contract_docs");
			File subDir = new File(dir.getAbsolutePath() + File.separator + ct.getId());

			if (!dir.exists()) {
				dir.mkdirs();
				if (!subDir.exists()) {
					subDir.mkdirs();
				}
			} else if (!subDir.exists()) {
				subDir.mkdirs();
			}
			StringBuilder fileName = new StringBuilder();
			for (MultipartFile multipartFile : files) {

				File uploadedFile = new File(subDir, multipartFile.getOriginalFilename().replace(",", ""));
				fileName.append(uploadedFile.getAbsoluteFile().getPath()).append(",");
				try {
					uploadedFile.createNewFile();
					fileOutputStream = new FileOutputStream(uploadedFile);
					fileOutputStream.write(multipartFile.getBytes());
					fileOutputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
			String f = fileName.toString();
			contract.setUploaddocument(f.substring(0, f.length() - 1));
			Map<String, Object> resultMap1 = contractService.saveContract(contract);
			Error error1 = (Error) resultMap1.get("ERROR");
			if (error1.getStatusCode().equals("401")) {
				return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
			}
			ct = (Contract) resultMap1.get("CONTRACT");
		}

		return ResponseEntity.ok(ct);
	}

	@RequestMapping(value = "/contracts/{id}", method = RequestMethod.GET)
	public ResponseEntity<?> getByContactId(@PathVariable Long id) {
		Map resultMap = contractService.getContract(id);
		Error error = (Error) resultMap.get("ERROR");
		if (error.getStatusCode().equals("401")) {
			return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
		}
		Contract ct = (Contract) resultMap.get("CONTRACT");
		return ResponseEntity.ok(ct);
	}

	@RequestMapping(path = "/downloadDocs", method = RequestMethod.GET)
	public void downloadFile(HttpServletResponse res, @RequestParam("id") String id,
			@RequestParam("filename") String filename) throws Exception {
		String filePath = env.getProperty("uploadDir") + File.separator + "contract_docs" + File.separator + id
				+ File.separator + filename;
		res.setHeader("Content-Disposition", "attachment; filename=" + filename);
		res.getOutputStream().write(Files.readAllBytes(Paths.get(filePath)));
	}


	@RequestMapping(value = "/deleteDocs", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteFile(@RequestParam("id") Long id, @RequestParam("filename") String filename)
			throws Exception {

		ObjectMapper mapper = new ObjectMapper();
		Map resultMap = new HashMap<>();

		resultMap = contractService.deleteFiles(id, filename);
		System.out.println(resultMap);
		Error error = (Error) resultMap.get("ERROR");
		if (error.getStatusCode().equals("200")) {
			return ResponseEntity.ok(resultMap.get("ERROR"));

		} else {
			return ResponseEntity.ok(resultMap.get("ERROR"));
		}

	}

}
