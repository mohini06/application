package com.datatemplate.dao.impl;

import java.util.Map;

import com.datatemplate.dto.Finance;


public interface FinancialDAOImpl {

	Map<String, Object> getFinancial(Long id);
	
	Map<String, Object> saveFinancial(Finance vf);
	
	Map<String, Object> deleteFiles(Long id, String filename);
}
