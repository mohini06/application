package com.datatemplate.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.datatemplate.dao.impl.ContactDAOImpl;
import com.datatemplate.dto.Vendor;
import com.datatemplate.dto.VendorContacts;
import com.datatemplate.entity.Error;
import com.datatemplate.repository.ComboListRepo;
import com.datatemplate.repository.ContactRepo;
import com.datatemplate.repository.UserRepo;
import com.datatemplate.repository.VendorRepo;

@Transactional
@Repository
public class ContactDAO implements ContactDAOImpl {
	
	@Autowired
	private ContactRepo contactRepo;
	
	@Autowired
	private ComboListRepo comboListRepo;
	
	@Autowired
	private VendorRepo vendorRepo;
	
	@Autowired
	private UserRepo userRepo;
	
	@PersistenceContext	
	private EntityManager entityManager;

	@Override
	public Map<String, Object> saveContact(VendorContacts vc) {
		 Map<String, Object>  resultMap  = new HashMap<String, Object>();
		    Error error =  new Error();
		    error.setStatusCode("200");
		    if(null != vc.getStatusId()) {
		    vc.setStatus(comboListRepo.findById(Integer.parseInt(vc.getStatusId())));
		    }
		    if(null != vc.getVid()) {
		    	Vendor vv = vendorRepo.findByvendorid(Long.parseLong(vc.getVid()));
		    	vc.setVendorId(vv);
		    }
		    vc.setModifiedBy(userRepo.findByUsername(vc.getUserId()));
		    try {
				if(null != vc.getId()) {
					VendorContacts existVc = entityManager.find(VendorContacts.class, vc.getId());
					existVc.setFirstname(vc.getFirstname());
					existVc.setLastname(vc.getLastname());
					existVc.setEmail(vc.getEmail());
					existVc.setContactyesno(vc.getContactyesno());
					existVc.setFax(vc.getFax());
					existVc.setNotes(vc.getNotes());
					existVc.setPhone(vc.getPhone());
					existVc.setEmail(vc.getEmail());
					existVc.setStatus(vc.getStatus());
					existVc.setTitle(vc.getTitle());
					existVc.setNotes(vc.getNotes());
					existVc.setModifiedBy(vc.getModifiedBy());
					entityManager.persist(existVc);
					resultMap.put("CONTACT", existVc );
				}
				else {
					vc.setCreatedBy(vc.getModifiedBy());
					vc.setCreatedOn(new Date());
				    resultMap.put("CONTACT",  contactRepo.save(vc));
				}
			} catch (Exception e) {
				error.setStatusCode("401");
			}
		    resultMap.put("ERROR",error);
			return resultMap;
	}

	@Override
	public Map<String, Object> getContact(Long id) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();
		error.setStatusCode("200");
		try {
			VendorContacts vc =  entityManager.find(VendorContacts.class, id);
			resultMap.put("CONTACT", vc);
		} catch (Exception e) {
			error.setStatusCode("401");
		}
		resultMap.put("ERROR", error);
		return resultMap;
	}

}
