package com.datatemplate.service.impl;

import java.util.Map;

import com.datatemplate.common.Search;
import com.datatemplate.dto.VendorContacts;

public interface ContactServiceImpl {

	public Map<String, Object> getContactList(Search search);
	
	public Map<String, Object> saveContact(VendorContacts vc);
	
	public Map<String, Object> getContact(Long id);
}
