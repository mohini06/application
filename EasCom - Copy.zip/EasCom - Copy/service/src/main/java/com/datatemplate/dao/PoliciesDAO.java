package com.datatemplate.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.datatemplate.dao.impl.PoliciesServiceImpl;
import com.datatemplate.dto.PoliciesAndProcedures;
import com.datatemplate.dto.Vendor;
import com.datatemplate.entity.Error;
import com.datatemplate.repository.ComboListRepo;
import com.datatemplate.repository.PoliciesRepo;
import com.datatemplate.repository.UserRepo;
import com.datatemplate.repository.VendorRepo;

@Transactional
@Repository
public class PoliciesDAO implements PoliciesServiceImpl {
	@Autowired
	private PoliciesRepo policiesRepo;
	
	@Autowired
	private UserRepo userRepo;

	@Autowired
	private ComboListRepo comboListRepo;

	@PersistenceContext	
	private EntityManager entityManager;

	@Autowired
	private VendorRepo vendorRepo;

	@Override
	public Map<String, Object> savePolicies(PoliciesAndProcedures policies) {
		Map<String, Object>  resultMap  = new HashMap<String, Object>();
		Error error =  new Error();
		error.setStatusCode("200");
		if(null != policies.getStatusId()) {
			policies.setStatus(comboListRepo.findById(Integer.parseInt(policies.getStatusId())));
		}

		if(null != policies.getTypeId()) {
			policies.setType(comboListRepo.findById(Integer.parseInt(policies.getTypeId())));
		}

		if(null != policies.getVid()) { 
			Vendor vendor =vendorRepo.findByvendorid(Long.parseLong(policies.getVid()));
			policies.setVendorid(vendor); 
		}
		policies.setModifiedBy(userRepo.findByUsername(policies.getUserId()));
		try {
			if(null != policies.getId()) {
				PoliciesAndProcedures existPolicie = entityManager.find(PoliciesAndProcedures.class, policies.getId());
				existPolicie.setName(policies.getName());
				existPolicie.setStatus(policies.getStatus());
				existPolicie.setType(policies.getType());
				existPolicie.setNotes(policies.getNotes());
				existPolicie.setApprovedbyexecutive(policies.getApprovedbyexecutive());
				existPolicie.setStartdate(policies.getStartdate());
				existPolicie.setEnddate(policies.getEnddate());
				existPolicie.setRenewaldate(policies.getRenewaldate());
				existPolicie.setModifiedBy(policies.getModifiedBy());
				existPolicie.setUploaddocument(policies.getUploaddocument() != null ? policies.getUploaddocument() : existPolicie.getUploaddocument());
				entityManager.persist(existPolicie);
				resultMap.put("POLICIE", existPolicie );
			}
			else {
				policies.setCreatedBy(policies.getModifiedBy());
				policies.setCreatedOn(new Date());
				resultMap.put("POLICIE",  policiesRepo.save(policies));
			}
		} catch (Exception e) {
			error.setStatusCode("401");
		}
		resultMap.put("ERROR",error);
		return resultMap;
	}

	@Override
	public Map<String, Object> getPolicie(Long id) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();
		error.setStatusCode("200");
		try {
			PoliciesAndProcedures policie =  entityManager.find(PoliciesAndProcedures.class, id);
			resultMap.put("POLICIE", policie);
		} catch (Exception e) {
			error.setStatusCode("401");
		}
		resultMap.put("ERROR", error);
		return resultMap;
	}
	
	@Override
	public Map<String, Object> deleteFiles(Long id, String filename) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();
		error.setStatusCode("200");
		PoliciesAndProcedures  existPolicies = new PoliciesAndProcedures();
        System.out.println(id);
        existPolicies = policiesRepo.findById(id).size() != 0
				? policiesRepo.findById(id).get(0)
				: null;
		try {
			if (null != existPolicies.getId()) {
				existPolicies.setUploaddocument(null);
					entityManager.persist(existPolicies);
					error.setStatusMsg("File deleted successfully...");
			}
			else {

			}

		} catch (Exception e) {
			error.setStatusCode("401");
			error.setStatusMsg("Failure");
		}
		resultMap.put("ERROR", error);
		return resultMap;

	}
}
