package com.datatemplate.controller;

import java.util.Objects;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;

import com.datatemplate.config.JwtTokenUtil;
import com.datatemplate.dto.User;
import com.datatemplate.jwt.model.JwtRequest;
import com.datatemplate.jwt.model.JwtResponse;
import com.datatemplate.repository.RoleRepo;
import com.datatemplate.repository.UserRepo;
import com.datatemplate.service.ComboListService;
import com.datatemplate.service.JwtUserDetailsService;
import com.datatemplate.service.LoginService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.io.File;
import java.io.FileOutputStream;
import org.springframework.core.env.Environment;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.datatemplate.entity.Error;

@RestController
@RequestMapping("/login")
public class LoginController {

	@Autowired
	private ComboListService comboListService;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private JwtUserDetailsService userDetailsService;

	@Autowired
	private UserRepo userRepo;

	@Autowired
	private RoleRepo roleRepo;

	@Autowired
	private UserDetailsService jwtInMemoryUserDetailsService;

	@Autowired
	private Environment env;

	@Autowired
	private LoginService loginservice;

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ResponseEntity<?> saveUser(@RequestBody User user) throws Exception {
		User userExist = userRepo.findByUsername(user.getUsername());
		System.out.println(user.getAddress());
		User emailUser = userRepo.findByEmail(user.getEmail());
		if (null != userExist) {
			return new ResponseEntity<String>("{\"message\":\"Username already exists\"}", HttpStatus.CONFLICT);
		} else if (null != emailUser) {
			return new ResponseEntity<String>("{\"message\":\"Emailid already exists\"}", HttpStatus.CONFLICT);
		} else {
			return ResponseEntity.ok(userDetailsService.save(user));
		}
	}

	@RequestMapping(value = "/roles", method = RequestMethod.GET)
	public ResponseEntity<?> getUserRoles() throws Exception {
		return ResponseEntity.ok(roleRepo.findAll());
	}

	@RequestMapping(value = "validateuser", method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtRequest authenticationRequest) throws Exception {

		String valid = authenticate(authenticationRequest.getUsername(),
				null == authenticationRequest.getPassword() ? "" : authenticationRequest.getPassword());
		final UserDetails userDetails;
		if (valid.equals("INVALID_CREDENTIALS")) {
			return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
		}

		// final String token = jwtTokenUtil.generateToken(userDetails);
		final Authentication authentication = authenticationManager
				.authenticate(new UsernamePasswordAuthenticationToken(authenticationRequest.getUsername(),
						authenticationRequest.getPassword()));
		SecurityContextHolder.getContext().setAuthentication(authentication);
		final String token = jwtTokenUtil.generateToken(authentication);
		final String role = jwtTokenUtil.getUserRole(token);
		return ResponseEntity.ok(new JwtResponse(token, role));

	}

	@RequestMapping(value = "isvaliduser", method = RequestMethod.POST)
	public ResponseEntity<?> isValidUser(@RequestBody User user) throws Exception {
		Error error = new Error();
		User userExist = userRepo.findByUsername(user.getUsername());
		if (null != userExist) {
			error.setStatusCode("200");
			error.setStatusMsg("Username already exist..");
		} else {
			error.setStatusCode("401");
			error.setStatusMsg("Username not exist..");

		}
		return ResponseEntity.ok(error);
	}

	@RequestMapping(value = "isvalidEmail", method = RequestMethod.POST)
	public ResponseEntity<?> isValidEmail(@RequestBody User user) throws Exception {
		Error error = new Error();
		User userExist = userRepo.findByEmail(user.getEmail());
		if (null != userExist) {
			error.setStatusCode("200");
			error.setStatusMsg("Emailid already exist..");
		} else {
			error.setStatusCode("401");
			error.setStatusMsg("Emailid not exist..");
		}
		return ResponseEntity.ok(error);
	}

	private String authenticate(String username, String password) throws Exception {
		Objects.requireNonNull(username);
		Objects.requireNonNull(password);

		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		} catch (DisabledException e) {
			throw new Exception("USER_DISABLED", e);
		} catch (BadCredentialsException e) {
			return "INVALID_CREDENTIALS";
		}
		return "Valid";
	}

	@RequestMapping(value = "/usertype", method = RequestMethod.GET)
	public ResponseEntity<?> getUserType(@RequestParam("usertype") String userType) throws Exception {
		return ResponseEntity.ok(comboListService.getComboList(userType));
	}

	@RequestMapping(value = "/profile", method = RequestMethod.GET)
	public ResponseEntity<?> getProfile(@RequestParam("user") String user) throws Exception {
		return ResponseEntity.ok(userRepo.findByUsername(user));
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public ResponseEntity<?> updateUser(@RequestParam("files") MultipartFile[] files,
			@RequestParam("username") String username, @RequestParam("firstname") String firstname,
			@RequestParam("lastname") String lastname, @RequestParam("password") String password,
			@RequestParam("title") String title, @RequestParam("email") String email,
			@RequestParam("address") String address, @RequestParam("phone") String phone,
			@RequestParam("fax") String fax, @RequestParam("userid") String userid,
			@RequestParam("userTypeId") String userTypeId, @RequestParam("statusId") String statusId) throws Exception {

		User user = new User();
		user.setUserid(userid.equals("") ? null : Long.parseLong(userid));
		user.setUsername(username.equals("") ? null : username);
		user.setFirstname(firstname.equals("") ? null : firstname);
		user.setLastname(lastname.equals("") ? null : lastname);
		user.setPassword(password.equals("") ? null : password);
		user.setTitle(title.equals("") ? null : title);
		user.setEmail(email.equals("") ? null : email);
		user.setAddress(address.equals("") ? null : address);
		user.setPhone(phone.equals("") ? null : phone);
		user.setFax(fax.equals("") ? null : fax);
		user.setUserTypeId(userTypeId);
		user.setStatusId(statusId);
//			return ResponseEntity.ok(loginservice.Update(user));
		FileOutputStream fileOutputStream = null;
		User userExist = userRepo.findByUsername(user.getUsername());
		if (files.length > 0) {
			File dir = new File(env.getProperty("uploadDir") + File.separator + "user_docs");
			File subDir = new File(dir.getAbsolutePath() + File.separator + userExist.getUserid());
			if (!dir.exists()) {
				dir.mkdirs();
				if (!subDir.exists()) {
					subDir.mkdirs();
				}
			} else if (!subDir.exists()) {
				subDir.mkdirs();
			}
			StringBuilder fileName = new StringBuilder();
			for (MultipartFile multipartFile : files) {

				File uploadedFile = new File(subDir, multipartFile.getOriginalFilename().replace(",", ""));
				fileName.append(uploadedFile.getAbsoluteFile().getPath()).append(",");
				try {
					uploadedFile.createNewFile();
					fileOutputStream = new FileOutputStream(uploadedFile);
					fileOutputStream.write(multipartFile.getBytes());
					fileOutputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
			String f = fileName.toString();
			user.setProfilepic(f.substring(0, f.length() - 1));
		}
		return ResponseEntity.ok(loginservice.Update(user));
	}

	@RequestMapping(value = "/forgotpassword", method = RequestMethod.POST)
	public ResponseEntity<?> forgotPwd(@RequestParam("email") String email) throws Exception {

		ObjectMapper mapper = new ObjectMapper();
		Map resultMap = new HashMap<>();

		resultMap = loginservice.forgotPswd(email);
		Error error = (Error) resultMap.get("ERROR");
		if (error.getStatusCode().equals("200")) {

			return ResponseEntity.ok(resultMap.get("ERROR"));

		}  else{
			return new ResponseEntity<String>(error.getStatusMsg(),HttpStatus.UNAUTHORIZED);
		}
	}

	@RequestMapping(value = "/savenewpwd", method = RequestMethod.POST)
	public ResponseEntity<?> savePwd(@RequestParam("email") String email, @RequestParam("otp") String otp,
			@RequestParam("newpassword") String newpassword, @RequestParam("confirmpassword") String confirmpassword)
			throws Exception {

		ObjectMapper mapper = new ObjectMapper();
		Map resultMap = new HashMap<>();

		resultMap = loginservice.savePswd(email, otp, newpassword, confirmpassword);
		Error error = (Error) resultMap.get("ERROR");
		if (error.getStatusCode().equals("200")) {

			return ResponseEntity.ok(resultMap.get("ERROR"));

		} else {
//			return ResponseEntity.ok(resultMap.get("ERROR"));
			return new ResponseEntity<String>(error.getStatusMsg(),HttpStatus.UNAUTHORIZED);
		}

	}

	@RequestMapping(value = "/changepwd", method = RequestMethod.POST)
	public ResponseEntity<?> savechangePwd(@RequestParam("userid") Long userid,
			@RequestParam("password") String password, @RequestParam("newpassword") String newpassword,
			@RequestParam("confirmpassword") String confirmpassword) throws Exception {

		ObjectMapper mapper = new ObjectMapper();
		Map resultMap = new HashMap<>();
		resultMap = loginservice.savechangePswd(userid, password, newpassword, confirmpassword);
		Error error = (Error) resultMap.get("ERROR");
		if (error.getStatusCode().equals("200")) {

			return ResponseEntity.ok(resultMap.get("ERROR"));

		} else {
			return new ResponseEntity<String>(error.getStatusMsg(),HttpStatus.UNAUTHORIZED);
		}

	}

}
