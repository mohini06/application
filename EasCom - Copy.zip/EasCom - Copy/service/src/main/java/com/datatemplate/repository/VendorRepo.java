package com.datatemplate.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.datatemplate.dto.Graph;
import com.datatemplate.dto.Vendor;


public interface VendorRepo extends JpaRepository<Vendor, Long> {
	
    Vendor findByvendorid(Long vendorid);
    
    Vendor findByvendorname(String vendorname);
  
    @Query(value = "SELECT displayvalue,count(*) FROM vendor left join combolist on vendor.state = combolist.id where status = 183 group by state", nativeQuery = true)
    List<Object[]> findVendorByState();
    
    @Query(value = "select vendorid,vendorname from vendor",nativeQuery = true)
    List<Object[]> findVendorlist();
    
}
