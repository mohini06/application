package com.datatemplate.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.datatemplate.common.Search;
import com.datatemplate.dto.Answers;
import com.datatemplate.dto.Invoice;
import com.datatemplate.dto.Questionnaire;
import com.datatemplate.dto.Template;
import com.datatemplate.dto.Vendor;
import com.datatemplate.repository.AnswersRepo;
import com.datatemplate.repository.QuestionnaireRepo;
import com.datatemplate.repository.TemplateRepo;
import com.datatemplate.repository.VendorRepo;
import com.datatemplate.service.QuestionnaireService;
import com.datatemplate.service.impl.QuestionnaireServiceImpl;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.core.env.Environment;
import com.datatemplate.entity.Error;

@RestController
@RequestMapping("/questionnaire")
public class QuestionnaireController {

	@Autowired
	private QuestionnaireRepo questionnaireRepo;
	
	@Autowired
	private VendorRepo vendorRepo;
	
	@Autowired
	private TemplateRepo templateRepo;
	
	@Autowired
	private AnswersRepo answersRepo;
	
	@Autowired
	private QuestionnaireService questionnaireService ;
	
	
	@Autowired
	private QuestionnaireServiceImpl questionnaireServiceimpl ;
	
	@Autowired
	private Environment env;
	
	@RequestMapping(value = "/templates", method = RequestMethod.GET)
	public List<Template> getAllTemplates() throws Exception {
		return templateRepo.findAll();
	}
	
	@RequestMapping(value = "/questions/{vendorId}", method = RequestMethod.GET) 
	public List<Questionnaire> getQuestions(@PathVariable("vendorId") Long vendorId) throws Exception { 
		Vendor vendor = vendorRepo.findByvendorid(vendorId);
		return questionnaireRepo.findByTemplateid(vendor.getTemplate()); 
	}
	
	@RequestMapping(value = "/answer/{vendorId}", method = RequestMethod.GET) 
	public List<Answers> getAnswer(@PathVariable("vendorId") Long vendorId) throws Exception { 
		return answersRepo.findByVendor(vendorRepo.findByvendorid(vendorId)); 
	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ResponseEntity<?> saveAnswer(@RequestBody Answers answer) throws Exception{
		return ResponseEntity.ok(questionnaireService.saveAnswer(answer));
	}
	
	



				
	
	 
	@PostMapping("/questionnaires")
	public  ResponseEntity<List<Questionnaire>> getQuestionnaireList(@RequestBody String search) {

		ObjectMapper mapper = new ObjectMapper();
		Map resultMap =  new HashMap<>() ;
		List<Questionnaire> questionnaireList = new ArrayList<Questionnaire>();
		try {

			Search searchJson  = mapper.readValue(search, Search.class);
			resultMap = questionnaireService.getQuestionnaireList(searchJson);
			com.datatemplate.entity.Error error = (com.datatemplate.entity.Error) resultMap.get("ERROR");
			if(error.getStatusCode().equals("500")) {
				//Invoice invoice  =  new Invoice();
				//invoice.setTotal(0);
				//invoiceList.add(invoice);
				return new ResponseEntity<List<Questionnaire>>(null ,new HttpHeaders(), HttpStatus.OK);
			}
			questionnaireList = ( List<Questionnaire> )resultMap.get("QUESTIONNAIRES");
			if(null != questionnaireList && questionnaireList.size()> 0) {
				Questionnaire questionnaire = questionnaireList.get(0);
				questionnaire.setTotal(Integer.parseInt(resultMap.get("TOTAL").toString()));
			}
		} catch (JsonParseException e) {
			System.out.println(e.getMessage());
		} catch (JsonMappingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return new ResponseEntity<List<Questionnaire>>(questionnaireList ,new HttpHeaders(), HttpStatus.OK);

	}
	
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public ResponseEntity<?> createQuestion(@RequestBody Questionnaire questionnaire) throws Exception{
		return ResponseEntity.ok(questionnaireService.saveQuestionnaire(questionnaire));
	}
	
	
	@RequestMapping(value = "/filesave", method = RequestMethod.POST)
	public  ResponseEntity<?> saveAnswer(@RequestParam("Docs") MultipartFile[] files, @RequestParam("answer") String answer, @RequestParam("vendorid") Long vendorid, @RequestParam("labelid") String lableid) throws Exception
	{
		
		ObjectMapper mapper = new ObjectMapper();
	     Map resultMap =  new HashMap<>() ;
	     
	      resultMap  = questionnaireService.saveAnswers(files, answer, vendorid,lableid);
	      System.out.println(resultMap);
			Error error =  (Error)resultMap.get("ERROR");
			if(error.getStatusCode().equals("200")) {
			return ResponseEntity.ok(resultMap.get("ERROR"));
		
	}
			else {
				return ResponseEntity.ok(resultMap.get("ERROR"));
			}
			
	
}
	
	@RequestMapping(path = "/downloadDocs", method = RequestMethod.GET)
	public void downloadFile(HttpServletResponse res,
			@RequestParam("id") String id,
			@RequestParam("filename") String filename) throws Exception {
		String filePath = env.getProperty("uploadDir") + File.separator + "questionare_docs" + File.separator + id + File.separator + filename;
		res.setHeader("Content-Disposition", "attachment; filename=" + filename);
		res.getOutputStream().write(Files.readAllBytes(Paths.get(filePath)));
	}
	
	@RequestMapping(value = "/deleteDocs", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteFile(@RequestParam("id") Long id, @RequestParam("filename") String filename)
			throws Exception {

		ObjectMapper mapper = new ObjectMapper();
		Map resultMap = new HashMap<>();

		resultMap = questionnaireService.deleteFiles(id, filename);
		System.out.println(resultMap);
		Error error = (Error) resultMap.get("ERROR");
		if (error.getStatusCode().equals("200")) {
			return ResponseEntity.ok(resultMap.get("ERROR"));

		} else {
			return ResponseEntity.ok(resultMap.get("ERROR"));
		}

	}
	
}	
