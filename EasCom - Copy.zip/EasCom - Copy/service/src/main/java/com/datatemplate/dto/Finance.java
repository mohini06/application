package com.datatemplate.dto;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="finance") 
public class Finance extends BaseEntity{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	private String uploaddocument;

	@OneToOne
	@JoinColumn(name="type")
	private ComboList type;

	@Temporal(TemporalType.TIMESTAMP)
	private Date startdate;

	@Temporal(TemporalType.TIMESTAMP)
	private Date enddate;

	private String name;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date renewaldate;

	@OneToOne
	@JoinColumn(name="status")
	private ComboList status;

	@OneToOne
	@JoinColumn(name="createdby")
	private User createdBy;

	@OneToOne
	@JoinColumn(name="modifiedby")
	private User modifiedBy;

	@ManyToOne(targetEntity=Vendor.class,cascade=CascadeType.ALL)
	@JoinColumn(name="vendorid")
	private Vendor vendorid;

	private String approvedbyexecutive;

	private String notes;

	@Transient
	private String statusId;
	
	@Transient
	private String typeId;
	
	@Transient
	private int total;

	@Transient
	private String vid;
	
	@Transient
	private String userId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUploaddocument() {
		return uploaddocument;
	}

	public void setUploaddocument(String uploaddocument) {
		this.uploaddocument = uploaddocument;
	}

	public Date getStartdate() {
		return startdate;
	}

	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	public Date getEnddate() {
		return enddate;
	}

	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}

	public Date getRenewaldate() {
		return renewaldate;
	}

	public void setRenewaldate(Date renewaldate) {
		this.renewaldate = renewaldate;
	}
	
	public String getApprovedbyexecutive() {
		return approvedbyexecutive;
	}

	public void setApprovedbyexecutive(String approvedbyexecutive) {
		this.approvedbyexecutive = approvedbyexecutive;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public User getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	public User getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(User modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Vendor getVendorid() {
		return vendorid;
	}

	public void setVendorid(Vendor vendorid) {
		this.vendorid = vendorid;
	}

	public ComboList getType() {
		return type;
	}

	public void setType(ComboList type) {
		this.type = type;
	}

	public ComboList getStatus() {
		return status;
	}

	public void setStatus(ComboList status) {
		this.status = status;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatusId() {
		return statusId;
	}

	public void setStatusId(String statusId) {
		this.statusId = statusId;
	}

	public String getTypeId() {
		return typeId;
	}

	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public String getVid() {
		return vid;
	}

	public void setVid(String vid) {
		this.vid = vid;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
