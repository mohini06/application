package com.datatemplate.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.datatemplate.dto.Forgotpassword;


public interface ForgotRepo extends JpaRepository<Forgotpassword, Long> {

	Forgotpassword findByUserid(Long userid);
	
	Forgotpassword findById(long id);
}
