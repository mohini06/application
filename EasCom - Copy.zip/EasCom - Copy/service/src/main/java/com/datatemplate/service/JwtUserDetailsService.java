package com.datatemplate.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.datatemplate.dao.UserDao;
import com.datatemplate.dto.Role;
import com.datatemplate.dto.User;
import com.datatemplate.repository.ComboListRepo;
import com.datatemplate.repository.RoleRepo;

@Service(value = "userService")
public class JwtUserDetailsService implements UserDetailsService {
	
	@Autowired
	private UserDao userDao;

	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;
	
	@Autowired
	private ComboListRepo comboListRepo;
	
	@Autowired
	private RoleRepo roleRepo;
 
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userDao.findByUsername(username);
		if(user == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), getAuthority(user));
	}
	
	private Set<SimpleGrantedAuthority> getAuthority(User user) {
        Set<SimpleGrantedAuthority> authorities = new HashSet<>();
		user.getRoles().forEach(role -> {
			authorities.add(new SimpleGrantedAuthority(role.getName()));
            //authorities.add(new SimpleGrantedAuthority("ROLE_" + role.getName()));
		});
		return authorities;
		//return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}
	
	public User save(User user) {
		user.setPassword(bcryptEncoder.encode(user.getPassword()));
		Set<Role> roles = new HashSet<>();
		Role role = roleRepo.findById(Long.parseLong(user.getUserTypeId()));
		roles.add(role);
		user.setRoles(roles);
		user.setStatus(comboListRepo.findById(Integer.parseInt(user.getStatusId())));
		return userDao.save(user);
	}
	
	public User update(User user) {
		User userExist = userDao.findByUsername(user.getUsername());
		userExist.setPassword(bcryptEncoder.encode(user.getPassword()));
		Set<Role> roles = new HashSet<>();
		Role role = roleRepo.findById(Long.parseLong(user.getUserTypeId()));
		roles.add(role);
		userExist.setRoles(roles);
		userExist.setStatus(comboListRepo.findById(Integer.parseInt(user.getStatusId())));
		return userDao.save(userExist);
	}
}