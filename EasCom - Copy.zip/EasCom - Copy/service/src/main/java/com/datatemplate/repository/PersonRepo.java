 package com.datatemplate.repository;

 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.datatemplate.dto.User;

 


public interface PersonRepo extends JpaRepository<User, Long>{
	
	User findByUsername(String username);
	List<User> findAll();

}
 