package com.datatemplate.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.datatemplate.dao.impl.VendorDAOImpl;
import com.datatemplate.dto.Vendor;
import com.datatemplate.repository.ComboListRepo;
import com.datatemplate.repository.TemplateRepo;
import com.datatemplate.repository.UserRepo;
import com.datatemplate.repository.VendorRepo;


 
import com.datatemplate.entity.Error;

@Transactional
@Repository
public class VendorDAO implements VendorDAOImpl{
	
	@Autowired
	private VendorRepo vendorRepo;
	
	@Autowired
	private TemplateRepo templateRepo;
	
	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private ComboListRepo comboListRepo;
	
	@PersistenceContext	
	private EntityManager entityManager;
	
	@Override
	public Map<String, Object> saveVendor(Vendor vendor) {
	    Map<String, Object>  resultMap  = new HashMap<String, Object>();
	    Error error =  new Error();
	    error.setStatusCode("200");
	    vendor.setState(comboListRepo.findById(Integer.parseInt(vendor.getStateId())));
	    vendor.setStatus(comboListRepo.findById(Integer.parseInt(vendor.getStatusId())));
	    vendor.setOfficetype(comboListRepo.findById(Integer.parseInt(vendor.getOfficeId())));
	    vendor.setRiskcategory(comboListRepo.findById(Integer.parseInt(vendor.getRiskId())));
	    vendor.setIndustry(comboListRepo.findById(Integer.parseInt(vendor.getIndustryId())));
	    vendor.setLegalentity(comboListRepo.findById(Integer.parseInt(vendor.getLegalentityId())));
	    vendor.setModifiedBy(userRepo.findByUsername(vendor.getUserId()));
	    vendor.setTemplate(vendor.getTemplateId().equals("") ? null : templateRepo.findById(Long.parseLong(vendor.getTemplateId())));
	    try {
			if(null != vendor.getVendorid()) {
				Vendor existVendor = entityManager.find(Vendor.class, vendor.getVendorid());
				existVendor.setAccountnumber(vendor.getAccountnumber());
				existVendor.setState(vendor.getState());
				existVendor.setCity(vendor.getCity());
				existVendor.setZipcode(vendor.getZipcode());
				existVendor.setFax(vendor.getFax());
				existVendor.setPhone(vendor.getPhone());
				existVendor.setEmail(vendor.getEmail());
				existVendor.setWebsite(vendor.getWebsite());
				existVendor.setStatus(vendor.getStatus());
				existVendor.setStreetaddress1(vendor.getStreetaddress1());
				existVendor.setStreetaddress2(vendor.getStreetaddress2());
				existVendor.setOfficetype(vendor.getOfficetype());
				existVendor.setTemplate(existVendor.getTemplate() != null ? existVendor.getTemplate() : vendor.getTemplate());
				existVendor.setRiskcategory(vendor.getRiskcategory());
				existVendor.setIndustry(vendor.getIndustry());
				existVendor.setLegalentity(vendor.getLegalentity());
				existVendor.setModifiedBy(vendor.getModifiedBy());
				entityManager.persist(existVendor);
				resultMap.put("VENDOR", existVendor );
			}
			else {
				vendor.setCreatedOn(new Date());
				vendor.setCreatedBy(vendor.getModifiedBy());
			    Vendor existVendor  = vendorRepo.findByvendorname(vendor.getVendorname());
			    if(null != existVendor) {
			    	error.setStatusCode("401");
			    }else {
			    	resultMap.put("VENDOR",  vendorRepo.save(vendor));
			    }
			    
				resultMap.put("TOTAL",vendorRepo.count());
			}
		} catch (Exception e) {
			error.setStatusCode("401");
		}
	    resultMap.put("ERROR",error);
		return resultMap;
	}

	 
}
