package com.datatemplate.dto;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="incident") 
public class Incident extends BaseEntity{
  
	@SuppressWarnings("unused")
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
	
    private String name;
		
	@Temporal(TemporalType.TIMESTAMP)
	private Date startdate;
		
	@Temporal(TemporalType.TIMESTAMP)
    private Date enddate;
    
    private Double duration;
    
	@OneToOne
	@JoinColumn(name="severity")
	private ComboList severity;
    
    private String uploaddocument;
    
    private String notes;

	@Transient
	private String severityId;
	
	@Transient
	private int total;

	@Transient
	private String vid;
	
	@Transient
	private String userId;
 
    @OneToOne
 	@JoinColumn(name="createdby")
    private User createdBy;
 	
    @OneToOne
   	@JoinColumn(name="modifiedby")
    private User modifiedBy;
    
    @ManyToOne(targetEntity=Vendor.class,cascade=CascadeType.ALL)
   	@JoinColumn(name="vendorid")
    private Vendor vendorid;
    
	public User getCreatedBy() {
		return createdBy;
	}

	public User getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(User modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public ComboList getSeverity() {
		return severity;
	}

	public void setSeverity(ComboList severity) {
		this.severity = severity;
	}

	public Double getDuration() {
		return duration;
	}

	public void setDuration(Double duration) {
		this.duration = duration;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getStartdate() {
		return startdate;
	}

	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	public Date getEnddate() {
		return enddate;
	}

	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}

	public String getUploaddocument() {
		return uploaddocument;
	}

	public void setUploaddocument(String uploaddocument) {
		this.uploaddocument = uploaddocument;
	}

	public String getSeverityId() {
		return severityId;
	}

	public void setSeverityId(String severityId) {
		this.severityId = severityId;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public String getVid() {
		return vid;
	}

	public void setVid(String vid) {
		this.vid = vid;
	}

	public Vendor getVendorid() {
		return vendorid;
	}

	public void setVendorid(Vendor vendorid) {
		this.vendorid = vendorid;
	}

	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
}
