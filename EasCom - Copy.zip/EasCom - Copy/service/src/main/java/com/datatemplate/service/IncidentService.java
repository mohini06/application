package com.datatemplate.service;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.datatemplate.common.Search;
import com.datatemplate.constants.SQLConstants;
import com.datatemplate.dao.CommonDAO;
import com.datatemplate.dao.IncidentDAO;
import com.datatemplate.dto.Incident;
import com.datatemplate.entity.Error;
import com.datatemplate.repository.ComboListRepo;
import com.datatemplate.repository.VendorRepo;
import com.datatemplate.service.impl.IncidentServiceImpl;

@Service
public class IncidentService implements IncidentServiceImpl,SQLConstants{

	@Autowired
	private CommonDAO commonDAO;

	@Autowired
	private IncidentDAO incidentDao ;

	@Autowired
	private ComboListRepo comboListRepo;

	@Autowired
	private VendorRepo vendorRepo;

	@Override
	public Map<String, Object> getIncidentList(Search search) {
		search.setSelect(INCIDENT_SELECT);
		if(search.getOrderby()== null) {
			search.setOrderby(INCIDENT_ORDER_BY); 
		}else {
			if(search.getOrderby().equals("createdOn") || search.getOrderby().equals("createdOn desc")) {
				if(search.getOrderby().equals("createdOn")) {
					search.setOrderby(" order by created_on");
				}else {
					search.setOrderby(" order by created_on desc");
				}
			}else if(search.getOrderby().equals("severityId") || search.getOrderby().equals("severityId desc")){
				if(search.getOrderby().equals("severityId")) {
					search.setOrderby(" order by severityId"); 
				}else {
					search.setOrderby(" order by severityId desc");
				}		   
			}else {			   
				search.setOrderby(" order by "+search.getOrderby());
			}
		}
		Map<String, Object> resultMap  =  new HashMap<>();
		Incident incident = null;
		Error error =  new Error();
		error.setStatusCode("200");
		List<Incident> incidentList =  new ArrayList<Incident>();
		List<Object[]> rows = commonDAO.getMasterList(search,INCIDENT_FIELDS);

		try {
			if(null != rows && rows.isEmpty()) {
				error.setStatusCode("500");
				resultMap.put("ERROR",error);
				return resultMap;
			}
			//Object[] r = rows.get(0);
			//long vendorid = Long.parseLong(r[10].toString());
			int count = commonDAO.getMasterCount(search, INCIDENT_FIELDS);
			for(Object[] row : rows){
				incident = new Incident();
				incident.setId(null != row[0] ?  Long.parseLong(row[0].toString()) : null);
				incident.setName(null != row[1] ?  row[1].toString() : "");
				incident.setStartdate(null != row[2] ?  (java.util.Date)row[2] : null);
				incident.setEnddate(null != row[3] ?  (java.util.Date)row[3] : null);
				incident.setDuration(null != row[4] ? Double.parseDouble(row[4].toString()) : null);
				incident.setNotes(null != row[5] ?  row[5].toString() : "");
				incident.setUploaddocument(null != row[6] ?  findFileName(row[6].toString()) : "");
				incident.setSeverity(null != row[7] ? comboListRepo.findById(Integer.parseInt(row[7].toString())) : null);
				incident.setCreatedOn((java.util.Date)row[8]);
				incident.setSeverityId(null != incident.getSeverity() ?  incident.getSeverity().getDisplayvalue() : "");
				if(null != row[9] && Integer.parseInt(row[9].toString()) >  0) {
					incident.setVendorid(vendorRepo.findByvendorid(Long.parseLong(row[9].toString())));
				}
				incidentList.add(incident);
			}
			resultMap.put("INCIDENTS",incidentList);
			resultMap.put("TOTAL", count);
		} catch (NumberFormatException e) {
			error.setStatusCode("400");
		}
		resultMap.put("ERROR",error);
		return resultMap;
	}

	@Override
	public Map<String, Object> saveIncident(Incident incident) {
		return incidentDao.saveIncident(incident);
	}

	@Override
	public Map<String, Object> getIncident(Long id) {
		return incidentDao.getIncident(id);
	}	

	public String findFileName(String fileName){
		String[] fileNames = fileName.split(",");
		StringBuilder names = new StringBuilder();
		for(String fName : fileNames) {
			Path path = Paths.get(fName);
			names.append(path.getFileName().toString()).append(",");
		}
		String f = names.toString();
		return f.substring(0, f.length() - 1);
	}
	
	@Override
	public Map<String, Object> deleteFiles(Long id, String filename) {
	    return 	incidentDao.deleteFiles(id,filename);
		
	}

}
