package com.datatemplate.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.datatemplate.common.Search;
import com.datatemplate.constants.SQLConstants;
import com.datatemplate.dao.CommonDAO;
import com.datatemplate.dao.ContactDAO;
import com.datatemplate.dto.Vendor;
import com.datatemplate.dto.VendorContacts;
import com.datatemplate.entity.Error;
import com.datatemplate.repository.ComboListRepo;
import com.datatemplate.repository.ContactRepo;
import com.datatemplate.repository.VendorRepo;
import com.datatemplate.service.impl.ContactServiceImpl;

@Service
public class ContactService implements ContactServiceImpl,SQLConstants{
	
	@Autowired
	private CommonDAO commonDAO;
	
	
	@Autowired
	private ContactDAO contactDao ;
	
	@Autowired
	private ComboListRepo comboListRepo;
	
	@Autowired
	private VendorRepo vendorRepo  ;
	
	@Autowired
	private ContactRepo contactRepo;
	@Override
	public Map<String, Object> getContactList(Search search) {
		   search.setSelect(CONTACT_SELECT);
		   if(search.getOrderby()== null) {
			   search.setOrderby(CONTACT_ORDER_BY); 
		   }else {
			   if(search.getOrderby().equals("createdOn") || search.getOrderby().equals("createdOn desc")) {
				   if(search.getOrderby().equals("createdOn")) {
					   search.setOrderby(" order by created_on");
				   }else {
					   search.setOrderby(" order by created_on desc");
				   }
			   }else if(search.getOrderby().equals("statusId") || search.getOrderby().equals("statusId desc")){
				   if(search.getOrderby().equals("statusId")) {
					   search.setOrderby(" order by statusId"); 
				   }else {
					   search.setOrderby(" order by statusId desc");
				   }		   
			   }else {			   
				   search.setOrderby(" order by "+search.getOrderby());
			   }
		   }
			Map<String, Object> resultMap  =  new HashMap<>();
			VendorContacts vc = null;
			Error error =  new Error();
			error.setStatusCode("200");
			List<VendorContacts> contactList =  new ArrayList<VendorContacts>();
			List<Object[]> rows = commonDAO.getMasterList(search,CONTACT_FIELDS);
			
			 try {
				 
				 if(null != rows && rows.isEmpty()) {
						error.setStatusCode("500");
						 resultMap.put("ERROR",error);
						 return resultMap;
					}
				 //Object[] r = rows.get(0);
		         //long vendorid = Long.parseLong(r[9].toString());
				 int count = commonDAO.getMasterCount(search, CONTACT_FIELDS);
				for(Object[] row : rows){
					 vc = new VendorContacts();
					 vc.setFirstname(null != row[0] ?  row[0].toString() : "");
					 vc.setLastname(null != row[1] ?  row[1].toString() : "");
					 vc.setEmail(null != row[2] ?  row[2].toString() : "");
					 vc.setFax(null != row[3] ?  row[3].toString() : "");
					 vc.setPhone(null != row[4] ?  row[4].toString() : "");
					 vc.setStatus(null != row[5] ? comboListRepo.findById(Integer.parseInt(row[5].toString())) : null);
					 vc.setCreatedOn((java.util.Date)row[6]);
					 vc.setId(null != row[8] ?  Long.parseLong(row[8].toString()) : null);
					 vc.setStatusId(null != vc.getStatus() ?  vc.getStatus().getDisplayvalue() : "");
					 if(null != row[9] && Integer.parseInt(row[9].toString()) >  0) {
						 vc.setVendorId( vendorRepo.findByvendorid(Long.parseLong(row[9].toString())));
					 }
					 vc.setTitle(null != row[10] ?  row[10].toString() : "");
					 vc.setNotes(null != row[11] ?  row[11].toString() : "");
					 vc.setContactyesno(null != row[12] ?  row[12].toString() : "");
					 contactList.add(vc);
				}
	
				resultMap.put("CONTACTS",contactList);
				resultMap.put("TOTAL",count);
			} catch (NumberFormatException e) {
				error.setStatusCode("400");
			}
			 resultMap.put("ERROR",error);
			return resultMap;
	}


	@Override
	public Map<String, Object> saveContact(VendorContacts vc) {
		return contactDao.saveContact(vc);
	}


	@Override
	public Map<String, Object> getContact(Long id) {
		return contactDao.getContact(id);
	}

}
