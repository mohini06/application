package com.datatemplate.dao.impl;

import java.util.Map;

import com.datatemplate.dto.Incident;

public interface IncidentDAOImpl {

	Map<String, Object> saveIncident(Incident incident);
	
	Map<String, Object> getIncident(Long id);
	
	Map<String, Object> deleteFiles(Long id, String filename);
}
