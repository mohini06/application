package com.datatemplate.service.impl;

import java.util.Map;

import com.datatemplate.common.Search;
import com.datatemplate.dto.Insurance;

public interface InsuranceServiceImpl {

	Map<String, Object> getInsuranceList(Search search);

	Map<String, Object> saveInsurance(Insurance insurance);

	Map<String, Object> getInsurance(Long id);
	
    Map<String, Object> deleteFiles(Long id, String filename);

}
