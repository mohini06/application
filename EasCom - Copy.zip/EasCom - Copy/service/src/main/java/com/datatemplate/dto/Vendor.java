package com.datatemplate.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="vendor") 
public class Vendor extends BaseEntity{

	@SuppressWarnings("unused")
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long vendorid;

	private String vendorname;

	private String accountnumber;

	private String streetaddress1;

	private String streetaddress2;

	@OneToOne 
	@JoinColumn(name="state")
	private ComboList state;

	private String city;

	private String email;

	private String fax;

	private Integer zipcode;

	private String phone;

	private String website;

	@OneToOne
	@JoinColumn(name="legalentity")
	private ComboList legalentity;

	@OneToOne
	@JoinColumn(name="status")
	private ComboList status;

	@OneToOne
	@JoinColumn(name="industry")
	private ComboList industry;

	@OneToOne
	@JoinColumn(name="riskcategory")
	private ComboList riskcategory;

	private String typeofservice;

	@OneToOne 
	@JoinColumn(name="officetype")
	private ComboList officetype;

	@OneToOne
	@JoinColumn(name="template")
	private Template template;
	
	@Transient
	private String templateId;
	
	@Transient
	private String stateId;

	@Transient
	private String statusId;

	@Transient
	private String officeId;
	
	@Transient
	private String industryId;
	
	@Transient
	private String legalentityId;

    @Transient	
	private int total ;

	@OneToOne 
	@JoinColumn(name="createdby")
	private User createdBy;

	@OneToOne 
	@JoinColumn(name="modifiedby")
	private User modifiedBy;

	@ManyToOne
	private Vendor parent;
	
	@Transient
	private String userId;
	
	@Transient
	private String riskId;

	public User getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	public User getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(User modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Vendor getParent() {
		return parent;
	}

	public void setParent(Vendor parent) {
		this.parent = parent;
	}

	private Integer numberofoffices;


	public Long getVendorid() {
		return vendorid;
	}

	public void setVendorid(Long vendorid) {
		this.vendorid = vendorid;
	}
	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}


	public ComboList getState() {
		return state;
	}

	public void setState(ComboList state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}
	public ComboList getStatus() {
		return status;
	}

	public void setStatus(ComboList status) {
		this.status = status;
	}

	public ComboList getIndustry() {
		return industry;
	}

	public void setIndustry(ComboList industry) {
		this.industry = industry;
	}
	public ComboList getOfficetype() {
		return officetype;
	}

	public void setOfficetype(ComboList officetype) {
		this.officetype = officetype;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getStateId() {
		return stateId;
	}

	public void setStateId(String stateId) {
		this.stateId = stateId;
	}

	public String getStatusId() {
		return statusId;
	}

	public void setStatusId(String statusId) {
		this.statusId = statusId;
	}

	public String getVendorname() {
		return vendorname;
	}

	public void setVendorname(String vendorname) {
		this.vendorname = vendorname;
	}

	public String getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}

	public String getStreetaddress1() {
		return streetaddress1;
	}

	public void setStreetaddress1(String streetaddress1) {
		this.streetaddress1 = streetaddress1;
	}

	public String getStreetaddress2() {
		return streetaddress2;
	}

	public void setStreetaddress2(String streetaddress2) {
		this.streetaddress2 = streetaddress2;
	}

	public Integer getZipcode() {
		return zipcode;
	}

	public void setZipcode(Integer zipcode) {
		this.zipcode = zipcode;
	}

	public ComboList getLegalentity() {
		return legalentity;
	}

	public void setLegalentity(ComboList legalentity) {
		this.legalentity = legalentity;
	}

	public ComboList getRiskcategory() {
		return riskcategory;
	}

	public void setRiskcategory(ComboList riskcategory) {
		this.riskcategory = riskcategory;
	}

	public String getTypeofservice() {
		return typeofservice;
	}

	public void setTypeofservice(String typeofservice) {
		this.typeofservice = typeofservice;
	}

	public Integer getNumberofoffices() {
		return numberofoffices;
	}

	public void setNumberofoffices(Integer numberofoffices) {
		this.numberofoffices = numberofoffices;
	}

	public String getOfficeId() {
		return officeId;
	}

	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRiskId() {
		return riskId;
	}

	public void setRiskId(String riskId) {
		this.riskId = riskId;
	}

	public String getIndustryId() {
		return industryId;
	}

	public void setIndustryId(String industryId) {
		this.industryId = industryId;
	}

	public Template getTemplate() {
		return template;
	}

	public void setTemplate(Template template) {
		this.template = template;
	}

	public String getTemplateId() {
		return templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	public String getLegalentityId() {
		return legalentityId;
	}

	public void setLegalentityId(String legalentityId) {
		this.legalentityId = legalentityId;
	}

}
