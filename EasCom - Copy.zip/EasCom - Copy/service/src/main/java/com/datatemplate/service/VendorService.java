package com.datatemplate.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.datatemplate.common.Search;
import com.datatemplate.constants.SQLConstants;
import com.datatemplate.dao.CommonDAO;
import com.datatemplate.dao.VendorDAO;
import com.datatemplate.dto.Vendor;
import com.datatemplate.entity.Error;
import com.datatemplate.entity.Vendorview;
import com.datatemplate.repository.ComboListRepo;
import com.datatemplate.repository.TemplateRepo;
import com.datatemplate.repository.VendorRepo;
import com.datatemplate.service.impl.VendorServiceImpl;

@Service
public class VendorService implements VendorServiceImpl,SQLConstants {

	
	@Autowired
	private VendorDAO vendorDao;
	
	@Autowired
	private CommonDAO commonDAO;
	
	@Autowired
	private VendorRepo vendorRepo ;
	
	@Autowired
	private ComboListRepo comboListRepo;
	
	@Autowired
	private TemplateRepo templateRepo;
	
	@Override
	public Map<String, Object> saveVendor(Vendor vendor) {
		return vendorDao.saveVendor(vendor);
	}
 
	@Override
	public Map<String, Object> getVendorList(Search search) {
	   search.setSelect(VENDORS_SELECT);
	   if(search.getOrderby()== null) {
		   search.setOrderby(VENDOR_ORDER_BY); 
	   }else {
		   if(search.getOrderby().equals("createdOn") || search.getOrderby().equals("createdOn desc")) {
		   if(search.getOrderby().equals("createdOn")) {
			   search.setOrderby(" order by created_on");
		   }else {
			   search.setOrderby(" order by created_on desc");
		   }
	   }else if(search.getOrderby().equals("statusId") || search.getOrderby().equals("statusId desc")){
		   if(search.getOrderby().equals("statusId")) {
			   search.setOrderby(" order by statusId"); 
		   }else {
			   search.setOrderby(" order by statusId desc");
		   }		   
	   }else if(search.getOrderby().equals("stateId desc") || search.getOrderby().equals("stateId")){
		   if(search.getOrderby().equals("stateId")) {
			   search.setOrderby(" order by stateId"); 
		   }else {
			   search.setOrderby(" order by stateId desc");
		   }	
	   }else {			   
		   search.setOrderby(" order by "+search.getOrderby());
	   }
	}
	   
		Map<String, Object> resultMap  =  new HashMap<>();
		Vendor vendor = null;
		Error error =  new Error();
		error.setStatusCode("200");
		List<Vendor>  vendorList =  new ArrayList<Vendor>();
		List<Object[]> rows = commonDAO.getMasterList(search,VENDOR_FIELDS);
		
		 try {
			 
			 if(null != rows && rows.isEmpty()) {
					error.setStatusCode("500");
					 resultMap.put("ERROR",error);
					 return resultMap;
				}
			int count = commonDAO.getMasterCount(search, VENDOR_FIELDS);
			for(Object[] row : rows){
				  vendor = new Vendor();
				  vendor.setVendorname(null != row[0] ? row[0].toString() : "");
				  vendor.setAccountnumber(null != row[1] ? row[1].toString() : "");
				  vendor.setEmail(null != row[2] ? row[2].toString() : "");
				  vendor.setPhone(null != row[3] ? row[3].toString() : "");
				  vendor.setStatus(null != row[4]? comboListRepo.findById(Integer.parseInt(row[4].toString())) : null);
				  vendor.setState(null != row[6] ? comboListRepo.findById(Integer.parseInt(row[6].toString())) :  null);
				  vendor.setOfficetype(null != row[5] ? comboListRepo.findById(Integer.parseInt(row[5].toString())) :  null);
				  vendor.setCity(null != row[7] ? row[7].toString() : "");
				  vendor.setStatusId(null != vendor.getStatus() ? vendor.getStatus().getDisplayvalue() : "");
				  vendor.setStateId(null !=vendor.getState() ? vendor.getState().getDisplayvalue() : "");
				  vendor.setOfficeId(null !=vendor.getOfficetype() ? vendor.getOfficetype().getDisplayvalue() : "");
				  vendor.setCreatedOn((java.util.Date)row[8]);
				  vendor.setFax(null != row[10]  ?  row[10].toString() : "");
				  vendor.setStreetaddress1(null != row[11] ? row[11].toString() : "");
				  vendor.setStreetaddress2(null != row[12] ? row[12].toString() : "");
				  vendor.setVendorid(null != row[13] ? Long.parseLong(row[13].toString()) : 0);
				  vendor.setZipcode(null != row[14] ? Integer.parseInt(row[14].toString()) : 0);
				  vendor.setRiskcategory(null != row[15] ? comboListRepo.findById(Integer.parseInt(row[15].toString())) : null);
				  vendor.setRiskId(null != vendor.getRiskcategory() ? vendor.getRiskcategory().getDisplayvalue() : "");
				  vendor.setIndustry(null != row[16] ? comboListRepo.findById(Integer.parseInt(row[16].toString())) : null);
				  vendor.setIndustryId(null != vendor.getIndustry() ? vendor.getIndustry().getDisplayvalue() : "");
				  vendor.setTemplate(null != row[17] ? templateRepo.findById(Long.parseLong(row[17].toString())) : null);
				  vendor.setWebsite(null != row[18] ? row[18].toString() : "");
				  vendor.setLegalentity(null != row[19] ? comboListRepo.findById(Integer.parseInt(row[19].toString())) : null);
				  vendor.setLegalentityId(null != vendor.getLegalentity() ? vendor.getLegalentity().getDisplayvalue() : "");
				  vendorList.add(vendor);
			}
			resultMap.put("VENDORS",vendorList);
			resultMap.put("TOTAL",count);
		} catch (NumberFormatException e) {
			error.setStatusCode("400");
		}
		 resultMap.put("ERROR",error);
		return resultMap;
	}

	@Override
	public Map<String, Object> getVendor(Long vendorId) {
		 Map<String, Object> resultMap =  new HashMap<String, Object>();
		 resultMap.put("VENDOR",vendorRepo.findByvendorid(vendorId));
		 return resultMap;
	}
	
	@Override
	public Map<String, Object> getVendorlist() {
		 Map<String, Object> resultMap =  new HashMap<String, Object>();
		 Vendorview vendor = null;
		 Error error =  new Error();
		 error.setStatusCode("200");
		 List<Vendorview>  vendorList =  new ArrayList<Vendorview>();
		 List<Object[]> rows = vendorRepo.findVendorlist();
         try {
			 
			 if(null != rows && rows.isEmpty()) {
					error.setStatusCode("500");
					 resultMap.put("ERROR",error);
					 return resultMap;
				}
			
			for(Object[] row : rows){
				  vendor = new Vendorview(null != row[0] ? Long.parseLong(row[0].toString()) : 0,null != row[1] ? row[1].toString() : "");
				  vendorList.add(vendor);
			}
			resultMap.put("VENDOR",vendorList);
			
		} catch (NumberFormatException e) {
			error.setStatusCode("400");
		}
		 resultMap.put("ERROR",error);
		 return resultMap;
	}
}
