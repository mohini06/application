package com.datatemplate.service.impl;

import java.util.Map;

import com.datatemplate.dto.User;

public interface LoginServiceImpl {
     
     String registerUser(User person);
     
     Map validateuser(User person);
     
     Map Update(User user);
     
     Map<String, Object> forgotPswd(String email);
     
     Map<String, Object> savePswd(String email, String otp, String newpassword, String confirmpassword);
     
     Map<String, Object> savechangePswd(Long userid, String password, String newpassword, String confirmpassword);
   
   }  


     
     
     
     

