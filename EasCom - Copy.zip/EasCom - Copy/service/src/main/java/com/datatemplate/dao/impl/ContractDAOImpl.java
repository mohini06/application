package com.datatemplate.dao.impl;

import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.datatemplate.dto.Contract;

public interface ContractDAOImpl {

	
   public Map<String, Object> saveContract(Contract contract);
	
   public Map<String, Object> getContract(Long id);
	
   public Map<String, Object> deleteFiles(Long id, String filename);
	
}
