package com.datatemplate.dao;

import java.io.FileOutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.datatemplate.dao.impl.ContractDAOImpl;
import com.datatemplate.dto.Answers;
import com.datatemplate.dto.Contract;
import com.datatemplate.dto.Vendor;
import com.datatemplate.entity.Error;
import com.datatemplate.repository.ComboListRepo;
import com.datatemplate.repository.ContractRepo;
import com.datatemplate.repository.UserRepo;
import com.datatemplate.repository.VendorRepo;

@Transactional
@Repository
public class ContractDAO implements ContractDAOImpl {

	@Autowired
	private ContractRepo contractRepo;

	@Autowired
	private UserRepo userRepo;

	@Autowired
	private ComboListRepo comboListRepo;

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private VendorRepo vendorRepo;

	@Override
	public Map<String, Object> saveContract(Contract contract) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();
		error.setStatusCode("200");
		if (null != contract.getStatusId()) {
			contract.setStatus(comboListRepo.findById(Integer.parseInt(contract.getStatusId())));
		}

		if (null != contract.getVid()) {
			Vendor vv = vendorRepo.findByvendorid(Long.parseLong(contract.getVid()));
			contract.setVendorid(vv);
		}

		if (null != contract.getContracttermId()) {
			contract.setContractterm(comboListRepo.findById(Integer.parseInt(contract.getContracttermId())));
		}

		if (null != contract.getFeestructureId()) {
			contract.setFeestructure(comboListRepo.findById(Integer.parseInt(contract.getFeestructureId())));
		}
		contract.setModifiedby(userRepo.findByUsername(contract.getUserId()));
		try {
			if (null != contract.getId()) {
				Contract existContract = entityManager.find(Contract.class, contract.getId());
				existContract.setContractname(contract.getContractname());
				existContract.setStatus(contract.getStatus());
				existContract.setContractterm(contract.getContractterm());
				existContract.setFeestructure(contract.getFeestructure());
				existContract.setNotes(contract.getNotes());
				existContract.setFee(contract.getFee());
				existContract.setStartdate(contract.getStartdate());
				existContract.setEnddate(contract.getEnddate());
				existContract.setRenewaldate(contract.getRenewaldate());
				existContract.setModifiedby(contract.getModifiedby());
				existContract.setUploaddocument(contract.getUploaddocument() != null ? contract.getUploaddocument()
						: existContract.getUploaddocument());
				entityManager.persist(existContract);
				resultMap.put("CONTRACT", existContract);
			} else {
				contract.setCreatedby(contract.getModifiedby());
				contract.setCreatedOn(new Date());
				resultMap.put("CONTRACT", contractRepo.save(contract));
			}
		} catch (Exception e) {
			error.setStatusCode("401");
		}
		resultMap.put("ERROR", error);
		return resultMap;
	}

	@Override
	public Map<String, Object> getContract(Long id) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();
		error.setStatusCode("200");
		try {
			Contract contract = entityManager.find(Contract.class, id);
			resultMap.put("CONTRACT", contract);
		} catch (Exception e) {
			error.setStatusCode("401");
		}
		resultMap.put("ERROR", error);
		return resultMap;
	}

	@Override
	public Map<String, Object> deleteFiles(Long id, String filename) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();
		error.setStatusCode("200");
        Contract existContract = new Contract();
        System.out.println(id);
        existContract = contractRepo.findById(id).size() != 0
				? contractRepo.findById(id).get(0)
				: null;
		try {
			if (null != existContract.getId()) {
					existContract.setUploaddocument(null);
					entityManager.persist(existContract);
					error.setStatusMsg("File deleted successfully...");
			}
			else {

			}

		} catch (Exception e) {
			error.setStatusCode("401");
			error.setStatusMsg("Failure");
		}
		resultMap.put("ERROR", error);
		return resultMap;

	}

	
}
