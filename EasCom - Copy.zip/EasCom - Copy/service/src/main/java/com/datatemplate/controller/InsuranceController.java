package com.datatemplate.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.datatemplate.common.Search;
import com.datatemplate.dto.Insurance;
import com.datatemplate.dto.VendorContacts;
import com.datatemplate.entity.Error;
import com.datatemplate.service.InsuranceService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/insurance")
@PropertySource("classpath:application.properties")
public class InsuranceController {

	@Autowired
	private InsuranceService insuranceService ;

	@Autowired
	private Environment env;

	@PostMapping("/insurances")
	public  ResponseEntity<List<Insurance>>  getInsuranceList(@RequestBody String search) {

		ObjectMapper mapper = new ObjectMapper();
		Map resultMap =  new HashMap<>() ;
		List<Insurance> insuranceList = new ArrayList<Insurance>();
		try {

			Search searchJson  = mapper.readValue(search, Search.class);
			resultMap = insuranceService.getInsuranceList(searchJson);
			com.datatemplate.entity.Error error = (com.datatemplate.entity.Error) resultMap.get("ERROR");
			if(error.getStatusCode().equals("500")) {
				//Insurance insurance  =  new Insurance();
				//insurance.setTotal(0);
				//insuranceList.add(insurance);
				return new ResponseEntity<List<Insurance>>(null ,new HttpHeaders(), HttpStatus.OK);
			}
			insuranceList = ( List<Insurance> )resultMap.get("INSURANCES");
			if(null != insuranceList && insuranceList.size()> 0) {
				Insurance insurance = insuranceList.get(0);
				insurance.setTotal(Integer.parseInt(resultMap.get("TOTAL").toString()));
			}
		} catch (JsonParseException e) {
			System.out.println(e.getMessage());
		} catch (JsonMappingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return new ResponseEntity<List<Insurance>>(insuranceList ,new HttpHeaders(), HttpStatus.OK);

	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ResponseEntity<?> saveInsurance(@RequestParam("files") MultipartFile[] files,
			@RequestParam("name") String name,
			@RequestParam("notes") String notes,
			@RequestParam("startdate") String startdate,
			@RequestParam("enddate") String enddate,
			@RequestParam("renewaldate") String renewaldate,
			@RequestParam("statusId") String statusId,
			@RequestParam("id") String id,
			@RequestParam("vid") String vid,
			@RequestParam("typeId") String typeId,
			@RequestParam("userId") String userId) throws Exception {
		Insurance insurance = new Insurance();
		FileOutputStream fileOutputStream = null;
		insurance.setId(id.equals("") ? null : Long.parseLong(id));
		insurance.setVid(vid.equals("") ? null : vid);
		insurance.setUserId(userId.equals("") ? null : userId);
		insurance.setTypeId(typeId.equals("") ? null : typeId);
		insurance.setName(name);
		insurance.setNotes(notes);
		if(renewaldate.equals("null")) {
			insurance.setRenewaldate(null);
		}else {
			insurance.setRenewaldate(new SimpleDateFormat("yyyy-MM-dd").parse(renewaldate));
		}
		insurance.setStartdate(new SimpleDateFormat("yyyy-MM-dd").parse(startdate));
		insurance.setEnddate(new SimpleDateFormat("yyyy-MM-dd").parse(enddate));
		insurance.setStatusId(statusId);
		insurance.setVid(vid);
		Map<String, Object>  resultMap  = insuranceService.saveInsurance(insurance);
		Error error =  (Error)resultMap.get("ERROR");
		if(error.getStatusCode().equals("401")) {
			return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
		}
		Insurance savedInsurance = (Insurance)resultMap.get("INSURANCE");

		if(files.length > 0) {

			File dir = new File(env.getProperty("uploadDir") + File.separator + "insurance_docs");
			File subDir = new File(dir.getAbsolutePath()+ File.separator + savedInsurance.getId());

			if (!dir.exists()){
				dir.mkdirs();
				if(!subDir.exists()){
					subDir.mkdirs();
				}
			}
			else if (!subDir.exists()){
				subDir.mkdirs();
			}
			StringBuilder fileName = new StringBuilder();
			for (MultipartFile multipartFile : files) {
				File uploadedFile = new File(subDir, multipartFile.getOriginalFilename().replace(",", ""));
				fileName.append(uploadedFile.getAbsoluteFile().getPath()).append(",");
				try {
					uploadedFile.createNewFile();
					fileOutputStream = new FileOutputStream(uploadedFile);
					fileOutputStream.write(multipartFile.getBytes());
					fileOutputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
			String f = fileName.toString();
			insurance.setUploaddocument(f.substring(0, f.length() - 1));
			Map<String, Object>  resultMap1  = insuranceService.saveInsurance(insurance);
			Error error1 =  (Error)resultMap1.get("ERROR");
			if(error1.getStatusCode().equals("401")) {
				return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
			}
			savedInsurance = (Insurance)resultMap1.get("INSURANCE");
		}

		return ResponseEntity.ok(savedInsurance);
	}

	@RequestMapping(value="/insurances/{id}", method = RequestMethod.GET) 
	public ResponseEntity<?>  getByInsuranceId(@PathVariable Long id) {
		Map resultMap =  insuranceService.getInsurance(id);
		Error error  = (Error)resultMap.get("ERROR");
		if(error.getStatusCode().equals("401")) {
			return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
		}
		Insurance  vi  =  (Insurance)resultMap.get("INSURANCE");
		return ResponseEntity.ok(vi);
	}		

	@RequestMapping(path = "/downloadDocs", method = RequestMethod.GET)
	public void downloadFile(HttpServletResponse res,
			@RequestParam("id") String id,
			@RequestParam("filename") String filename) throws Exception {
		String filePath = env.getProperty("uploadDir") + File.separator + "insurance_docs" + File.separator + id + File.separator + filename;
		res.setHeader("Content-Disposition", "attachment; filename=" + filename);
		res.getOutputStream().write(Files.readAllBytes(Paths.get(filePath)));
	}
	
	@RequestMapping(value = "/deleteDocs", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteFile(@RequestParam("id") Long id, @RequestParam("filename") String filename)
			throws Exception {

		ObjectMapper mapper = new ObjectMapper();
		Map resultMap = new HashMap<>();

		resultMap = insuranceService.deleteFiles(id, filename);
		System.out.println(resultMap);
		Error error = (Error) resultMap.get("ERROR");
		if (error.getStatusCode().equals("200")) {
			return ResponseEntity.ok(resultMap.get("ERROR"));

		} else {
			return ResponseEntity.ok(resultMap.get("ERROR"));
		}

	}
	
}


