package com.datatemplate.dao;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.datatemplate.dao.impl.CompanyDAOImpl;

@Transactional
@Repository
public class CompanyDAO implements CompanyDAOImpl {

}
