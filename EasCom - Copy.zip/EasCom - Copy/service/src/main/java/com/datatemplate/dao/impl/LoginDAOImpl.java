package com.datatemplate.dao.impl;
import java.util.Map;

import com.datatemplate.dto.User;


 
public interface LoginDAOImpl {
    
   String registerUser(User user);
   
   Map validateuser(User user);
   
   Map Update(User user);
   
   Map<String, Object> forgotPswd(String email);
   
   Map<String, Object> savePswd(String email, String otp, String newpassword, String confirmpassword);
   
   Map<String, Object> savechangePswd(Long userid, String password, String newpassword, String confirmpassword);
  
}
    
   
    
   
 