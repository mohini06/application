package com.datatemplate.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.datatemplate.dao.impl.FinancialDAOImpl;
import com.datatemplate.dto.Finance;
import com.datatemplate.dto.Vendor;
import com.datatemplate.entity.Error;
import com.datatemplate.repository.ComboListRepo;
import com.datatemplate.repository.FinancialRepo;
import com.datatemplate.repository.UserRepo;
import com.datatemplate.repository.VendorRepo;

@Transactional
@Repository
public class FinancialDAO implements FinancialDAOImpl{

	@Autowired
	private FinancialRepo financialRepo;
	
	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private ComboListRepo comboListRepo;
	
	@PersistenceContext	
	private EntityManager entityManager;
	
	@Autowired
	private VendorRepo vendorRepo;
	
	@Override
	public Map<String, Object> saveFinancial(Finance vf) {
		 Map<String, Object>  resultMap  = new HashMap<String, Object>();
		    Error error =  new Error();
		    error.setStatusCode("200");
		    if(null != vf.getStatusId()) {
		    vf.setStatus(comboListRepo.findById(Integer.parseInt(vf.getStatusId())));
		    }
		    
		    if(null != vf.getTypeId()) {
				vf.setType(comboListRepo.findById(Integer.parseInt(vf.getTypeId())));
			}

			if(null != vf.getVid()) { 
				Vendor vendor =vendorRepo.findByvendorid(Long.parseLong(vf.getVid()));
				vf.setVendorid(vendor); 
			}
			vf.setModifiedBy(userRepo.findByUsername(vf.getUserId()));
		    try {
		    	if(null != vf.getId()) {
		    		Finance existVf = entityManager.find(Finance.class, vf.getId());
		    		existVf.setName(vf.getName());
		    		existVf.setStatus(vf.getStatus());
		    		existVf.setType(vf.getType());
		    		existVf.setNotes(vf.getNotes());
		    		existVf.setApprovedbyexecutive(vf.getApprovedbyexecutive());
		    		existVf.setStartdate(vf.getStartdate());
		    		existVf.setEnddate(vf.getEnddate());
		    		existVf.setRenewaldate(vf.getRenewaldate());
		    		existVf.setModifiedBy(vf.getModifiedBy());
					existVf.setUploaddocument(vf.getUploaddocument() != null ? vf.getUploaddocument() : existVf.getUploaddocument());
					entityManager.persist(existVf);
					resultMap.put("FINANCIAL", existVf );
				}
		    	else {
		    		vf.setCreatedBy(vf.getModifiedBy());
					vf.setCreatedOn(new Date());
				    resultMap.put("FINANCIAL",  financialRepo.save(vf));
				}
			} catch (Exception e) {
				error.setStatusCode("401");
			}
		    resultMap.put("ERROR",error);
			return resultMap;
	}
	
	@Override
	public Map<String, Object> getFinancial(Long id) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();
		error.setStatusCode("200");
		try {
			Finance vf =  entityManager.find(Finance.class, id);
			resultMap.put("FINANCIAL", vf);
		} catch (Exception e) {
			error.setStatusCode("401");
		}
		resultMap.put("ERROR", error);
		return resultMap;
	}
	
	@Override
	public Map<String, Object> deleteFiles(Long id, String filename) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Error error = new Error();
		error.setStatusCode("200");
        Finance existInsurance = new Finance();
        System.out.println(id);
        existInsurance = financialRepo.findById(id).size() != 0
				? financialRepo.findById(id).get(0)
				: null;
		try {
			if (null != existInsurance.getId()) {
				existInsurance.setUploaddocument(null);
					entityManager.persist(existInsurance);
					error.setStatusMsg("File deleted successfully...");
			}
			else {

			}

		} catch (Exception e) {
			error.setStatusCode("401");
			error.setStatusMsg("Failure");
		}
		resultMap.put("ERROR", error);
		return resultMap;

	}

	
		
}
