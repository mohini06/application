package com.datatemplate.dao.impl;

import java.util.List;

import com.datatemplate.common.Search;

public interface CommonDAOImpl {

	public  List<Object[]> getMasterList(Search search,String fields);

	int getMasterCount(Search search, String fields);
}
