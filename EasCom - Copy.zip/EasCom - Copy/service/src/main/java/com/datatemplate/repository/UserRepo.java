package com.datatemplate.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.datatemplate.dto.User;


public interface UserRepo extends JpaRepository<User, Long> {
	
    User findByUsername(String username);
    
    User findByEmail(String email);
    
    User findByUserid(Long userid);
    
	Optional<User> findByResetToken(String resetToken);
	
}
