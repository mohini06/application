<div class="container-fluid">
    <div class="row">
        <div class="col-md-6">
            <div>
              <h3>{{$restaurant[0]->name}}</h3>
                <div class="address">
                    <p><?php echo html_entity_decode($restaurant[0]->address);?></p>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="">
                <h3 class="text-right">Customer Details</h3>
                <div class="address">
                    <p class="text-right">Bill No : <?php echo $orders['details']['order_id'];?><br/>
                        Date : <?php echo $orders['details']['date'];?><br/>
                        Customer : <?php echo $orders['details']['customer_name'];?><br/>
                        Supplier : <?php echo $orders['details']['supplier_name'];?><br/>
                        Table : <?php echo $orders['details']['table_name'];?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?php
            if(count($orders['food_menu']) > 0)
            {
            ?>
            <table id="example" class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th width="10%">#</th>
                    <th width="50%">Food Item</th>
                    <th width="20%" class="text-right">Price</th>
                    <th width="20%" class="text-right">Total</th>
                </tr>
                </thead>
                <tbody>
                <?php
                    $count = 1;
                    $food_sub =0;
                ?>

                @foreach ($orders['food_menu'] as $food)
                    <tr>
                        <td>{{$count}}</td>
                        <td style="position: relative;">
                        <?php
                            $veg = asset('public/images/veg.png');
                            $non_veg = asset('public/images/non_veg.png');

                            if ($food['isVeg'] == '1') {
                                echo "<p class='m-0 p-0'><span style='margin: 0; padding:0px; position: absolute; top:10px;' ><img width='15px' src='https://img.icons8.com/color/48/000000/vegetarian-food-symbol.png'></span>";
                            } else if ($food['isVeg'] == '0') {
                                echo "<p class='m-0 p-0'><span style='margin: 0; padding:0px; position: absolute; top:10px;' ><img width='15px'  src='https://img.icons8.com/color/48/000000/non-vegetarian-food-symbol.png'></span>";
                            } else {
                                echo "<span></span>";
                            }
                        ?>

                        <?php echo "<span style='margin-left:18px;'>".$food['menu_name'] . "<small> x " . $food['quantity'] . "</small></span></p>";?></td>
                        <td class="text-right"><?php echo number_format($food['menu_price'], 2);?></td>
                        <td class="text-right"><?php echo number_format($food['quantity'] * $food['menu_price'], 2);?></td>
                        <?php
                            $food_sub +=$food['quantity'] * $food['menu_price'];

                        ?>
                    </tr>
                    <?php $count++; ?>
                @endforeach
<tr>
                    <td></td>
                    <td colspan="2" class="text-right">Tax Amount <small>({{$taxes[0]->food_rate}}%)</small> </td>
                    <td class="text-right"><?php
                        $food_tax = ($food_sub*$taxes[0]->food_rate)/100;
                        echo number_format($food_tax,2);
                     ?></td>
                </tr>
                <tr>
                    <td></td>
                    <td colspan="2" class="text-right">Sub Total</td>
                    <td class="text-right"><strong>
                    <?php

                                            echo number_format($food_sub+$food_tax,2);
                                         ?>
                    </strong></td>
                </tr>
                </tbody>
            </table>
            <?php } ?>
            <?php
            if(count($orders['bar_menu']) > 0)
            {
            ?>
            <table id="example" class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th width="10%">#</th>
                    <th width="50%">Bar Item</th>
                    <th class="text-right" width="20%">Price</th>
                    <th class="text-right" width="20%">Total</th>
                </tr>
                </thead>
                <tbody>
                <?php
                                    $count = 1;
                                    $bar_sub =0;
                                ?>
                @foreach ($orders['bar_menu'] as $food)
                    <tr>
                        <td>{{$count}}</td>
                        <td>
                        <?php echo $food['menu_name'] . '<small> x ' . $food['quantity'] . "</small>";?></td>
                        <td class="text-right"><?php echo number_format($food['menu_price'], 2);?></td>
                        <td class="text-right"><?php echo number_format($food['quantity'] * $food['menu_price'], 2);?></td>
                         <?php
                              $bar_sub +=$food['quantity'] * $food['menu_price'];
                         ?>
                    </tr>
                    <?php $count++; ?>
                @endforeach
<tr>
                    <td></td>
                    <td colspan="2" class="text-right">Tax <small>({{$taxes[0]->bar_rate}}%)</small></td>
                    <td class="text-right"><?php
                                                $bar_tax = ($bar_sub*$taxes[0]->bar_rate)/100;
                                                echo number_format($bar_tax,2);
                                             ?></td>
                </tr>
                <tr>
                    <td></td>
                    <td colspan="2" class="text-right">Sub Total</td>
                    <td class="text-right"><strong><?php

                         echo number_format($bar_sub+$bar_tax,2);
                                                                     ?></strong></td>
                </tr>
                </tbody>
            </table>
            <?php } ?>
            <table id="example" class="table table-striped table-bordered">
                <tbody>
                <tr>
                    <td width="80%" colspan="3" class="text-right"><strong>Total</strong></td>
                    <td width="20%" class="text-right"><strong>
                    <?php
                       $total = $bar_sub+$food_sub;
                         echo number_format($total,2);
                    ?>
                    </strong></td>
                </tr>

                <tr>
                    <td width="80%" colspan="3" class="text-right"><strong>Tax</strong></td>
                    <td width="20%" class="text-right"><strong>
                    <?php
                       $total_tax = $bar_tax+$food_tax;
                       echo number_format($total_tax,2);
                    ?>

                    </strong></td>
                </tr>
                <tr>
                                    <td width="80%" colspan="3" class="text-right"><strong>Discount ( <?php echo $orders['offer_code']; ?> )</strong></td>
                                    <td width="20%" class="text-right"><strong><?php

                                     $discount = (($total+$total_tax)*$orders['offer_value'])/100;
                                     $discount =($discount>=$orders['max_discount'])?$orders['max_discount']:$discount;
                                     if(0 < $discount )
                                     {
                                        echo "-".number_format($discount,2);
                                     }
                                     else
                                     {
                                        echo "-".number_format('0',2);
                                     }


                                     ?></strong></td>
                                </tr>
                <tr>
                    <td width="80%" colspan="3" class="text-right"><strong>Grand Total</strong></td>
                    <td width="20%" class="text-right"><h5><strong>
                        <?php
                                                                   $grand_total = $total_tax+$total;
                                                                     echo number_format($grand_total-$discount,2);
                                                                ?>

                    </strong></h5></td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>


