@extends('layouts.dash')

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>

                        <div class="info-box-content">
                            <span class="info-box-text">Users</span>
                            <span class="info-box-number">{{$users}}</span>
                        </div>
                    <!-- /.info-box-content -->
                    </div>
                  <!-- /.info-box -->
                </div>
                <!-- <div class="card">
                    <div class="card-header">Dashboard</div>
                    <div class="card-body">
                        
                    </div>
                </div> -->
            </div>
        </div>
    </div>
@endsection
