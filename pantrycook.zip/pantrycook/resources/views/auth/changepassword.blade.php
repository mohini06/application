@extends('layouts.dash')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Change password</div>

                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-primary" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif
                        <div class="error_pass"></div>
                        <form id="reset_password" class="form-horizontal" method="POST"
                              action="{{ url('reset_password') }}">
                            {{ csrf_field() }}
                            <input id="user_id" type="hidden" class="form-control" name="user_id"
                                   value="<?php echo $id; ?>">

                            <div class="row form-group{{ $errors->has('new-password') ? ' has-error' : '' }}">
                                <label for="new-password" class="col-md-4 control-label text-md-right">New Password</label>

                                <div class="col-md-6">
                                    <!--<input id="new-password" type="password" class="form-control" name="new_password" autocomplete="off"  required>-->
                                    <div class="input-group">
                                        <input id="new-password" type="password" class="password form-control" name="new_password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 6 or more characters" required />
                                        <div class="input-group-append">
                                            <span class="input-group-text password_eye">
                                                <i class="fa fa-eye-slash" aria-hidden="true"></i>
                                            </span>
                                        </div>
                                    </div> 
                                    @if ($errors->has('new-password'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('new-password') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="row form-group">
                                <label for="new-password-confirm" class="col-md-4 control-label text-md-right">Confirm New Password</label>

                                <div class="col-md-6">
                                    <!-- <input id="new-password-confirm" type="password" class="form-control"  name="new_password_confirmation" required> -->
                                    <div class="input-group">
                                    <input id="new-password-confirm" type="password" class="password form-control" name="new_password_confirmation"   required />
                                        <div class="input-group-append">
                                            <span class="input-group-text password_eye">
                                                <i class="fa fa-eye-slash" aria-hidden="true"></i>
                                            </span>
                                        </div>
                                    </div>     
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-4">
                                    <button type="submit" class="btn btn-primary user_reset">
                                        Change Password
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection