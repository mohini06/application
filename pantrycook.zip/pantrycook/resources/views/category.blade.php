@extends('layouts.dash')

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Category Details</div>

                    <div class="card-body">
                        @if(count($errors) > 0)
                            <div class="alert alert-danger">
                                @foreach($errors->all() as $error)
                                        {{$error}}
                                @endforeach
                            </div>
                        @endif
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif
                    <div class="row">
                        <div class="col-md-12">
                            <table id="example" class="table table-striped table-bordered menu">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>No of Items</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($categories as $category)
                                        <tr>
                                            <td>{{$category->name}}</td>
                                            <td>{{$cat_count[$category->id]}}</td>
                                            <td class="text-center" category_id="{{$category->id}}">
                                            <i class="fa fa-edit category_edit ml-2 mr-2" data-toggle="modal" data-target="#category_edit"></i>
                                            <i class="fa fa-trash category_trash mr-2 ml-2" data-toggle="modal" data-target="#category_del"></i>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        <nav class="navbar navbar-expand-sm">
                            <ul class="navbar-nav">
                                <li class="nav-item m-2">
                                    <a class="nav navbar-nav" style="text-decoration: none" href="#" data-toggle="modal" data-target="#addcategory">Add Category</a>
                                </li>
                            </ul>
                        </nav>
                </div>
            </div>
        </div>
        <div id="accordion" class="mt-2">
            <div class="card">
                <div class="card-header"> Deleted Category Details
                  <a class="collapsed card-link" data-toggle="collapse" href="#collapseTwo">
                    <span class="fa fa-caret-down float-right"></span>

                  </a>
                </div>
                <div id="collapseTwo" class="collapse" data-parent="#accordion">
                  <div class="card-body">
                    <div class="row">
                    <div class="col-md-12">
                            <table id="delete" class="table table-striped table-bordered menu">
                            <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>No of Items</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($del_categories as $del_category)
                                        <tr>
                                            <td>{{$del_category->name}}</td>
                                            <td>{{$delcat_count[$del_category->id]}}</td>
                                            <td class="text-center" category_id="{{$del_category->id}}">
                                                <a href="#"
                                                    class="category_restore mr-2 ml-2" data-toggle="modal"
                                                    data-target="#restoreCategory">Restore</a>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                  </div>
                </div>
          </div>
        </div>
</div>

    </div>

    

<div id="addcategory" class="modal" role="dialog" >
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Category</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="{{url('/category_add')}}">
                    @csrf
                    <div class="form-group row">
                        <label for="category_name" class="col-md-4 col-form-label text-md-right">Name</label>
                        <div class="col-md-6">
                            <input id="category_name" type="text" name="category_name" class="form-control" pattern="(?=.*[a-zA-Z])[A-Za-z\s]{2,}" title="The name field accepts alphabets and  combination of alphabets and space." required autofocus/>
                        </div>
                    </div>
                    <hr>
                    <div class="form-group row ">
                        <div class="col-md-7"></div>
                        <div class="col-md-5">
                            <input type="submit" value="Create" name="submit" class="btn btn-primary ">
                            <!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div id="category_del" class="modal fade category" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Confirmation</h4><button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <p>If you delete the category belong this category ingredient also got delete, are you sure want to delete ?</p>
            </div>
            <div class="modal-footer">
                <a class="btn btn-primary" categoryid="" action="" href="">OK</a>
                <!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
            </div>
        </div>
    </div>
</div>

<div id="category_edit" class="modal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit Category</h4><button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="{{ url('category_update') }}">
                    @csrf
                    <input id="edit_categoryid" type="hidden" value="" name="edit_categoryid" />
                    <div class="form-group row">
                        <label for="category_name" class="col-md-4 col-form-label text-md-right">Category Name</label>
                        <div class="col-md-6">
                            <input id="category_name" type="text" name="category_name" value="" class="form-control category_name" pattern="(?=.*[a-zA-Z])[A-Za-z\s]{2,}" title="The name field accepts alphabets and  combination of alphabets and space." required autofocus />
                        </div>
                    </div>
                    <div class="form-group row ">
                        <div class="col-md-7"></div>
                        <div class="col-md-5">
                            <input type="submit" value="Update" name="submit" class="btn btn-primary ">
                            <!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div id="restoreCategory" class="modal fade categoryRestore" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Confirmation</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <p>Are you sure want to restore?</p>
            </div>
            <div class="modal-footer">
                <a class="btn btn-primary" categoryid="" action="" href="">OK</a>
                <!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
            </div>
        </div>
    </div>
</div>

@endsection
