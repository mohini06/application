@extends('layouts.dash')

@section('content')
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Ingredients Details</div>
                <div class="card-body">
                    @if(count($errors) > 0)
                        <div class="alert alert-danger">
                            @foreach($errors->all() as $error)
                                {{$error}}
                            @endforeach
                        </div>
                    @endif
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <div class="row">
                        <div class="col-md-12">
                            <table id="example" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Category</th>
                                        <th class="isVeg_icon">IsVegan</th>
                                        <th>Updated On</th>
                                        <th class="no-sort">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $count=1; ?>
                                    @foreach ($ingredients as $ingredient)
                                        <tr>
                                            <td>{{$ingredient->ing_name}}</td>
                                            <td>{{$ingredient->cat_name}}</td>
                                            <td class="text-center">
                                                @if($ingredient->isVeg=="0")
                                                    <img class="food_icon" src="{{url('/public/images/veg.png')}}" />
                                                @else
                                                    <img class="food_icon" src="{{url('/public/images/non_veg.png')}}" />
                                                @endif



                                            </td>
                                            <td>{{$ingredient->ing_updated_on}}</td>
                                        <td class="text-center" ingredient_id="{{$ingredient->ing_id}}">
                                            <i class="fa fa-edit ingredient_edit mr-2 ml-2" data-toggle="modal" data-target="#ingredient_edit"></i>
                                            <i class="fa fa-trash ingredient_trash mr-2 ml-2" data-toggle="modal" data-target="#ingredient_del"></i>
                                        </td>
                                        <?php $count++; ?>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <nav class="navbar navbar-expand-sm">
                            <ul class="navbar-nav">
                                <li class="nav-item m-2">
                                    <a class="nav navbar-nav" style="text-decoration: none" href="#" data-toggle="modal" data-target="#ingredient_add">Add Ingredient</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="accordion" class="mt-2">
            <div class="card">
                <div class="card-header"> Deleted Ingredient Details
                  <a class="collapsed card-link" data-toggle="collapse" href="#collapseTwo">
                    <span class="fa fa-caret-down float-right"></span>

                  </a>
                </div>
                <div id="collapseTwo" class="collapse" data-parent="#accordion">
                  <div class="card-body">
                    <div class="row">
                    <div class="col-md-12">
                            <table id="delete" class="table table-striped table-bordered menu">
                            <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Category</th>
                                        <th class="isVeg_icon">IsVegan</th>
                                        <th>Updated On</th>
                                        <th class="no-sort">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $count=1; ?>
                                    @foreach ($delingredients as $delingredient)
                                        <tr>
                                            <td>{{$delingredient->ing_name}}</td>
                                            <td>{{$delingredient->cat_name}}</td>
                                            <td class="text-center">
                                                @if($delingredient->isVeg=="0")
                                                    <img class="food_icon" src="{{url('/public/images/veg.png')}}" />
                                                @else
                                                    <img class="food_icon" src="{{url('/public/images/non_veg.png')}}" />
                                                @endif
                                            </td>
                                            <td>{{$delingredient->ing_updated_on}}</td>
                                            <td class="text-center" ingredient_id="{{$delingredient->ing_id}}">
                                            <a href="#"
                                                    class="ingredient_restore mr-2 ml-2" data-toggle="modal"
                                                    data-target="#restoreIngredient">Restore</a></td>
                                        <?php $count++; ?>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                  </div>
                </div>
          </div>
        </div>
</div>
</div>


<div id="ingredient_add" class="modal" role="dialog" >
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Ingredient</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <form method="POST" action="{{ url('ingredient_add') }}">
                    @csrf
                    <div class="form-group row">
                        <label for="ingredient_name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>
                        <div class="col-md-6">
                            <input id="ingredient_name" type="text" class="form-control{{ $errors->has('ingredient_name') ? ' is-invalid' : '' }}" name="ingredient_name" pattern="(?=.*[a-zA-Z])[A-Za-z\s]{2,}" title="The name field accepts alphabets and  combination of alphabets and space." required />
                            @if ($errors->has('ingredient_name'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('ingredient_name') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="category" class="col-md-4 col-form-label text-md-right">{{ __('Category') }}</label>
                        <div class="col-md-6">
                            <select class="form-control" name="category" required>
								<option selected="true" value="" disabled="disabled">Choose Tagging</option>
                                @foreach ($categories as $category)
                                    <option value="{{$category->id}}">{{$category->name}}</option>        
                                @endforeach
                            </select>
                            @if ($errors->has('category'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('category') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="isVeg" class="col-md-4 col-form-label text-md-right">{{ __('IsVegan') }}</label>
                        <div class="col-md-6 mt-2">
                            <input type="radio" name="isVeg" value="0" checked> Vegan
                            <input type="radio" name="isVeg" value="1"> Non-Vegan
                            @if ($errors->has('isVeg'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('isVeg') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="comments" class="col-md-4 col-form-label text-md-right">{{ __('Comments') }}</label>
                        <div class="col-md-6">
                            <textarea class="form-control" name="comment" ></textarea>
                            @if ($errors->has('comments'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('comments') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>
                    <div class="form-group row mb-0">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-primary">
                            {{ __('Create') }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div id="ingredient_del" class="modal fade ingredient" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Confirmation</h4><button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <p>Are you sure want to delete ?</p>
            </div>
            <div class="modal-footer">
                <a class="btn btn-primary" ingredientid="" action="" href="">OK</a>
                <!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
            </div>
        </div>
    </div>
</div>

<div id="ingredient_edit" class="modal" role="dialog" >
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit Ingredient</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <form method="POST" action="{{ url('ingredient_update') }}">
                    @csrf
                    <input id="edit_ingredientid" type="hidden" value="" name="edit_ingredientid"/>
                    <div class="form-group row">
                        <label for="ing_name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>
                        <div class="col-md-6">
                            <input id="ingr_name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="ingredient_name" value="" pattern="(?=.*[a-zA-Z])[A-Za-z\s]{2,}" title="The name field accepts alphabets and  combination of alphabets and space."  required />
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="ing_cat" class="col-md-4 col-form-label text-md-right">{{ __('Category') }}</label>
                        <div class="col-md-6">
                            <select id="ing_cat" class="form-control{{ $errors->has('Category') ? ' is-invalid' : '' }}" name="category" required>
                                <option selected="true" value="" disabled="disabled">Choose Tagging</option>
								@foreach ($categories as $category)
                                    <option value="{{$category->id}}">{{$category->name}}</option>     
                                @endforeach
                            </select>
                            @if ($errors->has('category'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('category') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="ing_isVeg" class="col-md-4 col-form-label text-md-right">{{ __('isVegan') }}</label>
                        <div class="col-md-6">
                            <input class="radio_veg" type="radio" name="isVeg" value="0" checked> Vegan  
                            <input class="radio_veg" type="radio" name="isVeg" value="1"> Non-Vegan
                            @if ($errors->has('isVeg'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('isVeg') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>

                    
                    <div class="form-group row">
                        <label for="comment" class="col-md-4 col-form-label text-md-right">{{ __('Comments') }}</label>
                        <div class="col-md-6">
                            <textarea id="comment_edit" class="form-control{{ $errors->has('comment') ? ' is-invalid' : '' }}" name="comment" autofocus></textarea>
                            @if ($errors->has('comment'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('comment') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>
                    <div class="form-group row mb-0">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-primary">
                                {{ __('Update') }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div id="restoreIngredient" class="modal fade ingredientRestore" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Confirmation</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <p>Are you sure want to restore?</p>
            </div>
            <div class="modal-footer">
                <a class="btn btn-primary" ingredientid="" action="" href="">OK</a>
                <!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
            </div>
        </div>
    </div>
</div>

@endsection
