@extends('layouts.dash')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">User Details</div>
                <div class="card-body">
                    @if(count($errors) > 0)
                        <div class="alert alert-danger">
                            @foreach($errors->all() as $error)
                                {{$error}}
                            @endforeach
                        </div>
                    @endif
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <div class="row">
                        <div class="col-md-12">
                            <table id="example" class="table table-striped table-bordered menu">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Role</th>
                                        <th>Updated On</th>
                                        <th  class="no-sort">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($users as $user)
                                        <tr>
                                            <td>{{$user->name}}</td>
                                            <td>{{$user->email}}</td>
                                            @if($user->role == "1")
                                                <td>Admin</td>
                                            @else
                                                <td>User</td>
                                            @endif       
                                            <td>{{$user->updated_on}}</td>
                                            <td class="text-center" user_id="{{$user->id}}"><i
                                            class="fa fa-edit user_edit ml-2 mr-2" data-toggle="modal"
                                            data-target="#user_edit"></i><i
                                            class="fa fa-trash user_trash mr-2 ml-2" data-toggle="modal"
                                            data-target="#myModal"></i></td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <nav class="navbar navbar-expand-sm">
                            <ul class="navbar-nav">
                                <li class="nav-item m-2">
                                    <a class="nav navbar-nav" style="text-decoration: none"
                                    href="{{ route('register') }}">{{ __('Register') }}</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="accordion" class="mt-2">
            <div class="card">
                <div class="card-header"> Deleted Users Details
                  <a class="collapsed card-link" data-toggle="collapse" href="#collapseTwo">
                    <span class="fa fa-caret-down float-right"></span>

                  </a>
                </div>
                <div id="collapseTwo" class="collapse" data-parent="#accordion">
                  <div class="card-body">
                    <div class="row">
                    <div class="col-md-12">
                            <table id="delete" class="table table-striped table-bordered menu">
                                <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                
                                    <th>Role</th>
                                    
                                    <th>Updated On</th>
                                    <th class="no-sort">Actions</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach ($del_users as $del_user)
                                    <tr>
                                        <td>{{$del_user->name}}</td>
                                        <td>{{$del_user->email}}</td>
                                        
                                        <td><?php if ($user->role == '1') {
                                                echo "Admin";
                                            } else {
                                                echo "User";
                                            }?></td>
                                        
                                        <td>{{$del_user->updated_on}}</td>
                                        <td class="text-center" user_id="{{$del_user->id}}"><a href="#"
                                                    class="user_restore mr-2 ml-2" data-toggle="modal"
                                                    data-target="#restoreUser">Restore</a></td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>




                    </div>
                  </div>
                </div>
          </div>
        </div>
</div>


<div id="myModal" class="modal fade user" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Confirmation</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <p>Are you sure want to delete ?</p>
            </div>
            <div class="modal-footer">
                <a class="btn btn-primary" userid="" action="" href="">OK</a>
                <!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
            </div>
        </div>
    </div>
</div>

<div id="user_edit" class="modal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit User</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">

                <form method="POST" action="{{ url('user_update') }}">
                    @csrf
                    <input id="edit_userid" type="hidden" value="" name="edit_userid"/>

                    <div class="form-group row">
                        <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>
                        <div class="col-md-6">
                            <input id="name" type="text" class="form-control" name="name" value="" pattern="(?=.*[a-zA-Z])[A-Za-z\s]{2,}" title="It will not accept digits and special characters." required />
                            @if ($errors->has('name'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('name') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>
                        <div class="col-md-6">
                            <input id="email" type="email" readonly class="form-control" name="email" value="" required>
                        </div>
                    </div>
                  <!--  <div class="form-group row">
                        <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('New Password') }}</label>
                        <div class="col-md-6">
                            <div class="input-group">
                                  <input id="password" type="password" class=" password form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" autofocus>
                                    <div class="input-group-append">
                                        <span class="input-group-text password_eye">
                                            <i class="fa fa-eye-slash" aria-hidden="true"></i>
                                        </span>
                                    </div>
                                </div>
                            
                            
                            <span class="password_error"><strong></strong></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Confirm Password') }}</label>
                        <div class="col-md-6">
                            <div class="input-group">
                                <input id="password-confirm" type="password" class="password form-control" name="password_confirmation">
                                    <div class="input-group-append">
                                        <span class="input-group-text password_eye">
                                            <i class="fa fa-eye-slash" aria-hidden="true"></i>
                                        </span>
                                    </div>
                                </div>
                        </div>
                    </div>-->
                    <div class="form-group row">
                        <label for="role" class="col-md-4 col-form-label text-md-right">{{ __('Role') }}</label>
                        <div class="col-md-6">
                            <select id="role" class="form-control" name="role" required>
                                <option selected="true" value="" disabled="disabled">Choose Tagging</option>
                                <option value="1">Admin</option>
                                <option value="0">User</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="comment" class="col-md-4 col-form-label text-md-right">{{ __('Comments') }}</label>
                        <div class="col-md-6">
                            <textarea id="comment" class="form-control" name="comment" placeholder="Drop your comments here.."></textarea>
                        </div>
                    </div>
                    <div class="form-group row mb-0">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-primary user_update">
                                {{ __('Update') }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div id="restoreUser" class="modal fade userRestore" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Confirmation</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <p>Are you sure want to restore?</p>
            </div>
            <div class="modal-footer">
                <a class="btn btn-primary" userid="" action="" href="">OK</a>
                <!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
            </div>
        </div>
    </div>
</div>
@endsection