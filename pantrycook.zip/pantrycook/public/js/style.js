$(document).ready( function () 
{
   
    
    //paste this code under the head tag or in a separate js file.
    // Animate loader off screen
    $(".se-pre-con").hide();
    $(".password_eye").click( function() 
    {
        if ($(this).parent().parent().find(".password").attr("type") == "password") 
        {
            $(this).find("i").removeClass("fa-eye-slash");
            $(this).find("i").addClass("fa-eye");
            $(this).parent().parent().find(".password").attr("type", "text");
        } 
        else 
        {
            $(this).find("i").removeClass("fa-eye");
            $(this).find("i").addClass("fa-eye-slash");
            $(this).parent().parent().find(".password").attr("type", "password");
        }
    });
    
    $('#example').DataTable();
    

    /*$('#datepicker_start').datetimepicker({ uiLibrary: 'bootstrap4',footer: true, modal: true });
    $('#datepicker_end').datetimepicker({ uiLibrary: 'bootstrap4',footer: true, modal: true });
    $('#datepicker_start_edit').datetimepicker({ uiLibrary: 'bootstrap4',footer: true, modal: true });
    $('#datepicker_end_edit').datetimepicker({ uiLibrary: 'bootstrap4',footer: true, modal: true });*/


    /*$(".collapsed .fa-caret-down").click( function () {
        $(this).toggleClass("fa-caret-up");
    });*/

    $('body').on('click', '[data-toggle="modal"]', function(){
        $('#bill .modal-body').load($(this).data("remote"));
    });

    $(".user_restore").click( function ()
    {
        var userid = $(this).parent().attr("user_id");
        $(".userRestore .modal-footer .btn-primary").attr("href","user_restore/"+userid);
    });
   

    $(".category_restore").click( function ()
    {
        var categoryid = $(this).parent().attr("category_id");
        $(".categoryRestore .modal-footer .btn-primary").attr("href","category_restore/"+categoryid);
    });

   

    $(".user_update").click( function ()
    {
        var pass1 = $("#password").val();
        var pass2 = $("#password-confirm").val();
        if(pass1 != "")
        {
            if(pass1 != pass2)
            {
                $("#user_edit").submit(function(e)
                {
                    $(".password_error strong").html("Password missmatch");
                    e.preventDefault();
                });
            }
        }

    });

    $(".user_reset").click( function ()
    {
        var pass1 = $("#new-password").val();
        var pass2 = $("#new-password-confirm").val();

        if(pass1 != "")
        {
            if(pass1 != pass2)
            {
                $("#reset_password").submit(function(e)
                {
                    $(".error_pass").addClass("alert");
                    $(".error_pass").addClass("alert-danger");
                    $(".error_pass").html("Password missmatch");
                    e.preventDefault();
                });
            }
        }

    });
   
    //$("table th:last").removeClass('sorting');
    //$("table .isVeg_icon").removeClass('sorting');
});