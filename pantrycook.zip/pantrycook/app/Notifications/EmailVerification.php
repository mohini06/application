<?php
namespace App\Notifications;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Support\HtmlString;

class EmailVerification extends Notification implements ShouldQueue
{
    use Queueable;
    protected $token;
    /**
    * Create a new notification instance.
    *
    * @return void
    */
    public function __construct($token)
    {
        $this->token = $token;
    }
    /**
    * Get the notification's delivery channels.
    *
    * @param  mixed  $notifiable
    * @return array
    */
    public function via($notifiable)
    {
        return ['mail'];
    }
     /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
     
     public function toMail($notifiable)
     {
        $otp = $this->token;
        return (new MailMessage)
            ->line('You are receiving this verification code because your email address has been associated with a new Pantry Cook account. To complete the verification please enter the following code in the Pantry Cook app.')
            ->line(new HtmlString('<p style="font-size:20px; text-align:center; font-weight: bold;">'.$otp.'</p>'))
            ->line('If you did not make the request to create a new Pantry Cook account no further action is required.');
     }
    /**
    * Get the array representation of the notification.
    *
    * @param  mixed  $notifiable
    * @return array
    */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}