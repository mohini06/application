<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{

    protected $addHttpCookie = true;

    protected $except = [
        '/*/user_edit*/','/*/ingredient_edit*/','/*/category_edit*/',
        '/*api/login*/','/*api/register*/','/*api/passwordreset*/',
    ];
}
