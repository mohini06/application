<?php

namespace App\Http\Controllers;

use DB;
use Response;
use App\ScannedItem;
use Illuminate\Http\Request;

class ScannedController extends Controller
{
    public function api_add_scannedItem(Request $request)
    {
        $email = $request->email;
        
        $barcode_number = $request->barcode_number;
        $barcode_type = $request->barcode_type;
        $product_name = $request->product_name;
        $updated_name = "";
        $category = $request->category;
        $manufacturer = $request->manufacturer;
        $brand = $request->brand;
        $size = $request->size;
        $ingredients = $request->ingredients;
        $description = $request->description;
        $status = 0;
        
        $user_details = DB::table('user')->where('email', '=', $email)->get();
        $user_id = $user_details[0]->id;

        $ingredients_exist = DB::table('scanned_item')->where([['user_id','=',$user_id],['barcode_number','=',$barcode_number]])->get();
       
        if(count($ingredients_exist)!=0)
        {
            return Response::json(['message'=>"Data already exist"], 409);
        }

        try {
            ScannedItem::create([
                'user_id' => $user_id,
                'barcode_number' => $barcode_number,
                'barcode_type' => $barcode_type,
                'product_name' => $product_name,
                'updated_name' => $updated_name,
                'category' => $category,
                'manufacturer' => $manufacturer,
                'brand' => $brand,
                'ingredients' => $ingredients,
                'size' => $size,
                'description' => $description,
                'status' => $status
            ]);
        } catch (\Illuminate\Database\QueryException $e) {
            return response()->json(['message' => 'Failed to store']);
        }

        return response()->json(['message' => 'Successfully Stored']);
    }
    
    public function api_get_ScannedItems(Request $request)
    {
        $email = $request->email;
        //return $email;
        $user_details = DB::table('user')->where('email', '=', $email)->get();
        $user_id = $user_details[0]->id;

        $items = DB::table('scanned_item')->where('user_id', '=', $user_id)->get();
        
        $loop = 0;
        $item_details = array();
       foreach($items as $item)
       {
            $item_name = $item->product_name;
            $item_brand = $item->brand;
            $item_manufacturer = $item->manufacturer;
            $item_category = $item->category;
            $item_status = $item->status;
            $items_details = array();

            //$cat_arr = explode (">", $item_category); 
            
            //$count_arr = count($cat_arr); 
           
            $item_details[$loop]['ProductName'] = $item_name;
            //$item_details[$loop]['Category'] = trim($cat_arr[$count_arr-2]);
            $item_details[$loop]['Category'] = $item_category;
            $item_details[$loop]['Status'] = $item_status;
            $items_details = $item_details;
            $loop++;
        }
        if(!empty($items_details))
        {
            return json_encode($items_details);
        }
        else
        {
            return Response::json(['message'=>"Data Not Found"], 404);
        }
    }
   
    public function api_get_ScannedItem_GenericName(Request $request)
    {
        $email = $request->email;
        $item_name = $request->item;
        
        $user_details = DB::table('user')->where('email', '=', $email)->get();
        $user_id = $user_details[0]->id;

        $items = DB::table('scanned_item')
            ->where('user_id', '=', $user_id)
            ->where('product_name', '=', $item_name)
            ->get();
       
        $loop = 0;
        $item_details = array();
       foreach($items as $item)
       {
            $item_name = $item->product_name;
            $item_brand = $item->brand;
            $item_manufacturer = $item->manufacturer;
            $item_category = $item->category;
            $item_size = $item->size;
        
            $brand_cleared = str_ireplace($item_brand, '', $item_name);
            
            $manufacturer_cleared = str_ireplace($item_manufacturer, '', $brand_cleared);

            $size_cleared = str_ireplace($item_size, '', $manufacturer_cleared);
            
            $trim_item_name =  trim(ltrim($size_cleared, ','));

            $result = preg_split("/[0-9]+/", $trim_item_name); 

            $item_details['GenericName'] = rtrim(trim(rtrim(trim($result[0]),',')),',');
        }
        
        $ing_list = DB::table('ingredient')->select('name')->get();
        $item_name = array();
        foreach($ing_list as $ing)
        {
            $generic_name = $item_details['GenericName'];
            $ingredient = $ing->name;
            if (strpos($generic_name, $ingredient) !== false) 
            {
                $item_name['GenericName'][] = $ing->name;
            }
        }
        
        if(!empty($item_name['GenericName']) && count($item_name['GenericName'])<2 )
        {
            $item_name['GenericName'] = $item_name['GenericName'][0];
            return json_encode($item_name);
        }
        elseif(count($item_details)>0)
        {
            return json_encode($item_details);
        }
        else
        {
            return Response::json(['message'=>"Data Not Found"], 404);
        }
    }

    public function api_get_VoiceSearch_Items(Request $request)
    {
        $item_name = $request->VoiceSearchString;
        

        $correct_string = preg_replace("/(?<!\d)\,(?!\d)/", "", ucwords($item_name)); //Removing Commas from the input

        $split_name = explode(" ",$correct_string); //Splitting the scanned item name
        
        $split_name = array_values(array_filter($split_name)); //Removed the empty index and reindexed the array
        
        $matching_items = array();
        $proper_result = array();
        $all_data = array();

        foreach($split_name as $word)
        {
            $matching_items[] = DB::table('ingredient as ing')
                ->where('ing.name', 'LIKE' ,$word.' '.'%')
                //->orWhere('ing.name', 'LIKE' ,'%'.' '.$word)
                //->orWhere('ing.name', 'LIKE' ,'%'.' '.$word.' '.'%')
                ->orWhere('ing.name', '=' ,$word)
                ->leftjoin('category as cat','ing.category_id','=','cat.id')
                ->select('ing.name')
                ->get();            
            foreach($matching_items as $items)
            {
                if(count($items) != 0) 
                {
                    foreach($items as $item)
                    {
                        $all_data[] = $item;
                    }
                }
            }
        }
        if(count($all_data) == 0)
        {
            return Response::json(['message'=>"Sorry we doesn't have the ingredient."], 404);
        }
       
        $array = json_decode(json_encode($all_data), TRUE);
        
        $array = array_values(array_unique($array, SORT_REGULAR));
       
        $size_strings = sizeof($split_name);
        $size_all_data = sizeof($array);
         
        if($size_strings == 1)
        {
            foreach ($array as $match)
            {
                if($split_name[0] == $match['name'])
                {
                    $proper_result[] = $match['name'];
                }                  
            }
        }
        else
        {
            for($j=0; $j<sizeof($split_name); $j++)
            {
                $next = $j+1;
                if($next<sizeof($split_name))
                {
                    $first_string = $split_name[$j];
                    $second_string = $split_name[$j+1];
                    if($j+2 < sizeof($split_name))
                    {
                        $last_string = $split_name[$j+2];
                    }
                    else
                    {
                        $last_string = "";
                    }
                   
                    $two_strings = $first_string." ".$second_string;
                    $three_strings = $first_string." ".$second_string." ".$last_string;
                    foreach ($array as $match)
                    {
                        if($two_strings == $match['name'] or $three_strings == $match['name'])
                        {
                            $proper_result[] = $match['name'];
                        }             
                        elseif ($first_string == $match['name'] or $second_string == $match['name'])
                        {
                            $proper_result[] = $match['name'];
                        }
                    }
                }
            }
            
        }

        $result['items'] = array_values(array_unique($proper_result, SORT_REGULAR));
        return json_encode($result);
    }
    public function api_add_scannedItemStatus(Request $request)
    {
        $email = $request->email;
        $product_name = $request->product_name;
        $edited_name = $request->edited_name;
        $status = 1;

        $user = DB::table('user')->where('email', '=', $email)->get();

        $scanned_item = DB::table('scanned_item')->where([['user_id','=',$user[0]->id],['product_name','=',$product_name]])->get();
        
        if(empty($scanned_item[0]))
        {
            return Response::json(['message'=>"Failed to Add"], 404);
        }
        else
        {
            $update_status = ScannedItem::where('id', '=',  $scanned_item[0]->id)->update(array('updated_name' => $edited_name, 'status' => $status));
            return Response::json(['message'=>"Successfully Added"], 200);
        }
    }

    public function api_remove_scannedItemStatus(Request $request)
    {
        $email = $request->email;
        $edited_name = $request->edited_name;
        $status = 0;

        $user = DB::table('user')->where('email', '=', $email)->get();
        $scanned_item = DB::table('scanned_item')->where([['user_id','=',$user[0]->id],['updated_name','=',$edited_name]])->get();
        if(count($scanned_item) == 0)
        {
            return Response::json(['message'=>"Failed to Remove"], 404);
        }
        else
        {
            $update_status = ScannedItem::where('id', '=',  $scanned_item[0]->id)->update(array('status' => $status));
            return Response::json(['message'=>"Successfully Removed"], 200);
        }
    }

    public function api_remove_allscannedItem(Request $request)
    {
        $email = $request->email;
        $status = 0;
    
        $user = DB::table('user')->where('email', '=', $email)->get();
        
        $scanned_items = DB::table('scanned_item')->where('user_id','=',$user[0]->id)->get();
        
        if(count($scanned_items) == 0)
        {
            return Response::json(['message'=>"Failed to Remove"], 404);
        }
        else
        {
            foreach($scanned_items as $scanned_item)
            {
                ScannedItem::where('id', '=',  $scanned_item->id)->update(array('status' => $status));
            }
        }
        $scanned_items = DB::table('scanned_item')->where('user_id','=',$user[0]->id)->get();
        return Response::json(['message'=>"Cleared all Items"], 200);
    }

    public function api_remove_scannedItem(Request $request)
    {
        $email = $request->email;
        $scanned_item = $request->scanned_item;

        $status = 0;
    
        $user = DB::table('user')->where('email', '=', $email)->get();
        
        $scanned_items = DB::table('scanned_item')->where([['user_id','=',$user[0]->id],['product_name','=',$scanned_item]])->get();
        
        if(count($scanned_items) == 0)
        {
            return Response::json(['message'=>"Failed to Remove"], 404);
        }
        else
        {
            DB::table('scanned_item')->where([['user_id','=',$user[0]->id],['product_name','=',$scanned_item]])->delete();
        }
        return Response::json(['message'=>"Cleared the Item"], 200);
    }
    

    public function api_scannedItemSuggestion(Request $request)
    {
        $item_name = $request->scanned_item;

        $correct_string = preg_replace("/(?<!\d)\,(?!\d)/", "", ucwords($item_name)); //Removing Commas from the input
        
        $split_name = explode(" ",$correct_string); //Splitting the scanned item name
        $split_name = array_values(array_filter($split_name)); //Removed the empty index and reindexed the array
        $matching_items = array();
        $proper_result = array();
        $all_data = array();
        
        foreach($split_name as $word)
        {
            $matching_items[] = DB::table('ingredient as ing')
                ->where('ing.name', 'LIKE' ,$word.' '.'%')
                //->orWhere('ing.name', 'LIKE' ,'%'.' '.$word)
                //->orWhere('ing.name', 'LIKE' ,'%'.' '.$word.' '.'%')
                ->orWhere('ing.name', '=' ,$word)
                ->leftjoin('category as cat','ing.category_id','=','cat.id')
                ->select('ing.name')
                ->get();            

            foreach($matching_items as $items)
            {
                if(count($items) != 0) 
                {
                    foreach($items as $item)
                    {
                        $all_data[] = $item;
                    }
                }
            }
        }

        if(count($all_data) == 0)
        {
            $items = ScannedItem::where('product_name', '=',  $item_name)->get();
            foreach($items as $item)
            {
                $item_name = $item->product_name;
                $item_brand = $item->brand;
                $item_manufacturer = $item->manufacturer;
                $item_category = $item->category;
                $item_size = $item->size;
            
                $brand_cleared = str_ireplace($item_brand, '', $item_name);
                
                $manufacturer_cleared = str_ireplace($item_manufacturer, '', $brand_cleared);
                $item_details['items'][0] = trim($manufacturer_cleared);
                //$size_cleared = str_ireplace($item_size, '', $manufacturer_cleared);
                //$trim_item_name =  trim(ltrim($size_cleared, ','));
                //return $trim_item_name;
                //$result = preg_split("/[0-9]+/", $trim_item_name); 
                //$item_details['GenericName'] = rtrim(trim(rtrim(trim($result[0]),',')),',');
            }
            return json_encode($item_details);
        }
       
        $array = json_decode(json_encode($all_data), TRUE);

        $array = array_values(array_unique($array, SORT_REGULAR));

        $size_strings = sizeof($split_name);
        $size_all_data =  sizeof($array);

        for($j=0; $j<sizeof($split_name); $j++)
        {
            $next = $j+1;
            if($next<sizeof($split_name))
            {
                $first_string = $split_name[$j];
                $last_string = $split_name[$j+1];
                $nearest_strings = $first_string." ".$last_string;
                    foreach ($array as $match)
                {
                    if($nearest_strings == $match['name'])
                    {
                        $proper_result[] = $match['name'];
                    }
                    
                    if($first_string == $match['name'] or $last_string == $match['name'])
                    {
                        $proper_result[] = $match['name'];
                    }
                }
            }
        }
        
        $result['items'] = array_values(array_unique($proper_result, SORT_REGULAR));
        return json_encode($result);

      /*  $proper_result = $array;
        
        $cat_based_result['items'] = [];
  
        foreach($proper_result as $result)
        {
            if(array_key_exists($result['category'],$cat_based_result)) 
            {
                $cat_based_result['items'][$result['category']][] = array_push($cat_based_result[$result['category']],$result['name']);
                array_pop($cat_based_result[$result['category']]); 
            }
            else
            {
                $cat_based_result['items'][$result['category']][] =  $result['name'];
            }
        }
        return json_encode($cat_based_result);
       */ 
    }
}