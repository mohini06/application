<?php

namespace App\Http\Controllers;

use DB;
use App\Visitor;
use Response;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class VisitorController extends Controller
{
    public function api_storeVisitor(Request $request)
    {
        $email_id = $request->email;
        $site_url = $request->site; 

        $user_details = DB::table('user')->where('email', '=',$email_id )->get();
        $user = $user_details[0]->id;

        $visitor_details = DB::table('visitor')->where('user_id', '=',$user)
                                ->where('site_url', '=',$site_url)->get();
        //return json_encode($visitor_details);
        if(!count($visitor_details))
        {
            Visitor::create([
                'user_id' => $user,
                'site_url' => $site_url,
                'count' => 1,
                'percentage' => 1
            ]);

            return Response::json(['message'=>"User visited new site"], 200);
        }
        else
        {
            $count = $visitor_details[0]->count+1;
            DB::table('visitor')
                ->where('user_id', $user)->where('site_url', '=',$site_url)
                ->update(['count' => $count]);
            
            return Response::json(['message'=>"Updated the visit count"], 200);     
        } 
    }
    public function api_SortVisitor(Request $request)
    {
        $email_id = $request->email;
        $user_details = DB::table('user')->where('email', '=',$email_id )->get();
        $user = $user_details[0]->id;

        $visitor_details = DB::table('visitor')->orderByRaw("FIELD(user_id, $user) DESC")->orderBy('count', 'DESC')->get();
        $result = [];
        $sort = [];
        if(count($visitor_details))
        {
            foreach($visitor_details as $visitor)
            {
                $contains = Str::contains($visitor->site_url, 'www.');
                 if($contains)
                 {
                    $result[]= $visitor->site_url;
                 }
                 else {
                    $result[]= 'www.'.$visitor->site_url;
                 }
                
            }
        }
        else
        {
            $visitor_details = DB::table('visitor')->distinct()->orderBy('count', 'DESC')->get(['site_url']);

            foreach($visitor_details as $visitor)
            {
            
               $result[]= $visitor->site_url;
            }
        }
        $sort['site'] = array_values(array_unique($result));
    
        return json_encode($sort);
    }
}
