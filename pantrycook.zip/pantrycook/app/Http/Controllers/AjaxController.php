<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use DB;

class AjaxController extends Controller
{
    public function getUserDetails(request $request)
    {
        $user_id = $request->id;
        $user = DB::table('user')->where('id',$user_id)->get();
        return json_encode($user[0]);
    }

    public function getIngredientDetails(request $request)
    {
        $ingredient_id = $request->id;
        $ingredient = DB::table('ingredient')->where('id',$ingredient_id)->get();
        return json_encode($ingredient[0]);
    }

    public function getCategoryDetails(request $request)
    {
        $category_id = $request->id;
        $category = DB::table('category')->where('id',$category_id)->get();
        return json_encode($category[0]);
    }

   
}
