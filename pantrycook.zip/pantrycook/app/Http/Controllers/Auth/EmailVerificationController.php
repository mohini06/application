<?php
namespace App\Http\Controllers\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Notifications\EmailVerification;
use App\User;
use Mail;
use App\EmailVerify;

class EmailVerificationController extends Controller
{
    /**
     * Create token password reset
     *
     * @param  [string] email
     * @return [string] message
     */
    public function create(Request $request)
    {
        $email = $request->email;
        $request->validate([
            'email' => 'required|string|email',
        ]);
        $data = User::where('email', $request->email)->first();
        
        if ($data)
        {
            return response()->json([
                'message' => 'User already Exist.'
            ], 404);
        }
    
        $passwordReset = EmailVerify::updateOrCreate(
            ['email' => $request->email],
            [
                'email' => $request->email,
                'token' => mt_rand(100000, 999999)
            ]
        ); 

        $user = EmailVerify::where('email', $request->email)->first();
    
        if ($user && $passwordReset)
        {
            $user->notify(
                new EmailVerification($passwordReset->token)
            );
            return response()->json(['message' => 'We have e-mailed your verification code!.']);
            /*$mail_data = array('email'=>$email, 'otp'=>$passwordReset->token);
            Mail::send('emails.otp_mail', $mail_data, function($message) use ($mail_data) {
                $message->to($mail_data['email'], 'PantryCook Support')->subject
                   ('Email Verification');
                $message->from('tempmail3984@gmail.com','PantryCook Support');
             });
            if(Mail::failures())
            {
                return response()->json(['error'=>'Email Error']);
            }
            else
            {
                return response()->json(['message' => 'We have e-mailed your verification code!.']);
            }
*/        }
        
    }
    public function basic_email() {
      Mail::raw('Hi, welcome user!', function ($message) {
  $message->to('tempmail3984@gmail.com')
    ->subject("demo");
});
   }
}