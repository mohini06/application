<?php

namespace App\Http\Controllers;

use DB;
use App\Cart;
use App\User;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function api_showCart(Request $request)
    {
        /*
        $details = [];
        $i = 0;
        foreach($ingredients['ingredients'] as $ingredient)
        {
            $category = DB::table('ingredient as ing')
                ->select('ing.name','cat.name' )
                ->where('ing.name','=',$ingredient)
                ->join('category as cat', 'ing.category_id', '=', 'cat.id')
                ->get(); 
                
            //$details[$category[0]->name] = (array_key_exists($category[0]->name,$details)) ? $details[$category[0]->name]."|".$ingredient :  $ingredient ; 
            //$details[$category[0]->name][] = (array_key_exists($category[0]->name,$details)) ? array_push($details[$category[0]->name],$ingredient) :  $ingredient;
        
            if(array_key_exists($category[0]->name,$details)) 
            {
                $details[$category[0]->name][] = array_push($details[$category[0]->name],$ingredient);  
                array_pop($details[$category[0]->name]); 
            }
            else
            {
                $details[$category[0]->name][] =  $ingredient;
            }
        }
         $data['category']= $details;
        
         return json_encode($data);*/

         $email = $request->email;
         $ingredients = [];
         $userId = User::select('id')->where('email', $email)->first();
         if($userId){
            $items = Cart::select('ingredients')->where('user_id', $userId->id)->get();
            if($items->isNotEmpty())
            {
                foreach ($items as $item) {
                    $ingredients['ingredients'][] = $item->ingredients;
                }
                return json_encode($ingredients);
            }
            else
            {
                return response()->json(['message'=>"Data Not Found"], 404);
            }
         }
         else{
            return response()->json(['message'=>"Invalid Id"], 404);
         }
         
    }

    public function api_addCart(Request $request)
    {
        /*$email_id = $request->email;
        
        $user = DB::table('user')->where('email', '=',$email_id )->get();
        $user_id = $user[0]->id;
        $search_text = implode('|',$request->items);
        $result = Cart::where('user_id', '=', $user_id)->get();
        if(count($result) == 0)
        {
            DB::table('cart')->insert(
				array(
					'user_id' => $user_id, 
					'ingredients' => $search_text
            ));
        }
        else
        {
            
         DB::table('cart')
                ->where('user_id', $user_id)
                ->update(['ingredients' => $search_text]);
        }*/
        $email = $request->email;
        $items = $request->items;
        $userId = User::select('id')->where('email', $email)->first();
        $datas = [];
        foreach($items as $item){
            $data[] = ['user_id'=>$userId->id, 'ingredients'=>$item];
        }
        $insert = Cart::insert($data);
        if($insert){
            return json_encode(array('success' => true,'code'=>'200','message'=>'Inserted Your Cart item.'));
        }
        
    }
    public function cartCount($email)
    {
        $userId = User::select('id')->where('email', $email)->first();
        if($userId){
            $count = Cart::where('user_id', $userId->id)->count();
            return json_encode(['count'=>$count]);
        }
    }

}
