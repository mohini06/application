<?php

namespace App\Http\Controllers;

use DB;
use App\Category;
use App\Ingredient;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function api_show(Request $request)
    {
        $suggestion_datas = Category::select('id','name')->get();
        return json_encode($suggestion_datas);
    }

    public function api_subCategory(Request $request)
    {
        $category_id = $request->id;
        $incredients = Ingredient::select('id','name')->where('category_id',$category_id)->get();
        return json_encode($incredients);
    }

    public function admin_show(Request $request)
    {
        $categories = DB::table('category')
            ->where('isActive', '1')
            ->get();
           
        $categories_list = DB::table('category')
            ->select('id')
            ->where('isActive','1')
            ->get();    

        foreach($categories_list as $category_list)
        {
            $cat_count[$category_list->id] = DB::table('ingredient')
                ->where('category_id','=',$category_list->id)
                ->where('isActive','=','1')
                ->count();            
        }

        $delcategories_list = DB::table('category')
            ->select('id')
            ->where('isActive','0')
            ->get();

        foreach($delcategories_list as $delcategory_list)
        {
            $delcat_count[$delcategory_list->id] = DB::table('ingredient')
                ->where('category_id','=',$delcategory_list->id)
                ->where('isActive','=','0')
                ->count();
        }

        //return $delcat_count;
        $del_category = DB::table('category')->where('isActive', '0')->get();
    
        return view('category')->with('categories',$categories)->with('cat_count',$cat_count)->with('del_categories',$del_category)->with('delcat_count',$delcat_count);
    }

    public function admin_create(Request $request)
    {
        $cat_name = $request->category_name;


        //return redirect()->back()->withErrors(['name' => 'Category name should not accept special Characters.']);
        
        $category = Category::select('name')->where('name',$cat_name)->get();
        
        if(count($category) != 0)
        {
            return redirect()->back()->withErrors(['name' => 'Category already exist.']);
        }
        Category::create([
            'name' => $cat_name,
            'isActive' => '1'
        ]);

        return redirect('category')->with('status', 'Created New Category Successfully');
    }

    public function admin_delete(request $request )
    {
        $id = $request->id;
       		
		DB::table('category')->where('id',$id)->update([ 'isActive' => 0]);
		DB::table('ingredient')->where('category_id',$id)->update([ 'isActive' => 0]);
		return redirect('category')->with('status', 'Category Deleted Successfully'); 
    }

    public function admin_update(request $request )
    {
        $id = $request->edit_categoryid;
        $name = $request->category_name;
       
        $category = Category::select('name')->where('name',$name)->get();
        
        if(count($category) != 0)
        {
            return redirect()->back()->withErrors(['name' => 'Category already exist.']);
        }

        Category::where('id', $id)->update([ 'name' => $name]);

        return redirect('category')->with('status', 'Category Updated Successfully');
    }

    public function restore(request $request )
    {
        $id = $request->id;
        Category::where('id', $id)->update([ 'isActive' => '1']);
        DB::table('ingredient')->where('category_id',$id)->update([ 'isActive' => 1]);
        return redirect('category')->with('status', 'Category Restored Successfully');
    }

}
