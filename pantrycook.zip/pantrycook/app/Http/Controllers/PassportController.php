<?php

namespace App\Http\Controllers;

use DB;
use Auth;
use App\User;
use App\EmailVerify;
use Illuminate\Http\Request;

class PassportController extends Controller
{
    public function register(Request $request)
    {
        $email = $request->email;
        $otp = $request->otp;

        $data = User::where('email', $request->email)->first();
        if( $data)
        {
            return response()->json([
                'message' => 'User already Exist.'
            ], 409);
        }
        
        $verify = EmailVerify::where('email', $request->email)->first();
        $token = $verify->token;

        if( $token != $otp)
        {
            return response()->json([
                'message' => 'OTP is not valid.'
            ], 404);
        }
        
        $this->validate($request, [
            'email' => 'required|email|unique:user',
            'password' => 'required|min:6|string|confirmed'
        ]);

        $user = User::create([
            'name' => "Guest",
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'isActive' => 1,
            'role' => 0 
        ]);

        $token = $user->createToken('PantryCook')->accessToken;

        return response()->json(['token' => $token], 200);
    }

    public function login(Request $request)
    {
        $credentials = [
            'email' => $request->email,
            'password' => $request->password,
            'isActive' => 1
        ];

        if (auth()->attempt($credentials))
        {
            $token = auth()->user()->createToken('PantryCook')->accessToken;
            return response()->json(['token' => 'Bearer '.$token,'user' => auth()->user(), 'success' => '200'], 200);
        }
        else
        {
            return response()->json(['error' => '404'], 401);
        }
    }

    public function details()
    {
        return response()->json(['user' => auth()->user()], 200);
    }

    public function logout(Request $request)
    {
        $accessToken = Auth::user()->token();

        DB::table('oauth_refresh_tokens')
            ->where('access_token_id', $accessToken->id)
            ->update([
                'revoked' => true
            ]);

        $accessToken->revoke();
        
        $json = [
            'success' => true,
            'code' => 200,
            'message' => 'You are Logged out.',
        ];
        return response()->json($json, '200');
    }

    public function change_password(Request $request)
    {
        $user_id = auth()->user()->id;
        $this->validate($request, [
            'password' => 'required|min:6|string|confirmed'
        ]);

        $user = User::find($user_id);
        $user->password = bcrypt($request->password);
        $user->save();

        $token = $user->createToken('PantryCook')->accessToken;

        return response()->json(['token' => 'Bearer '.$token], 200);
    }
}
