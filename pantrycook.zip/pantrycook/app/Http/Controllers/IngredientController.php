<?php

namespace App\Http\Controllers;

use DB;
use App\Category;
use App\Ingredient;
use Illuminate\Http\Request;

class IngredientController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function api_suggest(Request $request)
    {
        $search_string = $request->id;
        $suggestion_datas = Ingredient::select('id','name')->where('name', 'LIKE', '%' . $search_string . '%')->get();
        return json_encode($suggestion_datas);
    }

    public function admin_show(Request $request)
    {
        $datas=DB::table('ingredient As ing')
            ->leftjoin('category As cat','cat.id','=','ing.category_id')
            ->select('ing.id As ing_id','ing.name As ing_name','cat.name As cat_name','ing.isVeg As isVeg','ing.created_on As ing_created_on','ing.updated_on As ing_updated_on')
            ->where('ing.isActive', '=', 1)
            ->get();

        $deldatas=DB::table('ingredient As ing')
            ->leftjoin('category As cat','cat.id','=','ing.category_id')
            ->select('ing.id As ing_id','ing.name As ing_name','cat.name As cat_name','ing.isVeg As isVeg','ing.created_on As ing_created_on','ing.updated_on As ing_updated_on')
            ->where('ing.isActive', '=', 0)
            ->get();    

        $category = Category::select('id','name')->get();    
        
        return view('ingredient')->with('ingredients',$datas)->with('categories',$category)->with('delingredients',$deldatas);
    }

    public function admin_create(Request $request)
    {
        $ing_name = $request->ingredient_name;
        $ing_comment = $request->comment;
        $ing_isVeg = $request->isVeg;
        $ing_category = $request->category;

        $ingredient = Ingredient::select('name')->where('name',$ing_name)->get();
        
        if(count($ingredient) != 0)
        {
            return redirect()->back()->withErrors(['name' => 'Ingredient already exist.']);
        }

        Ingredient::create([
            'name' => $ing_name,
            'category_id' => $ing_category,
            'isVeg' => $ing_isVeg,
            'comments' => $ing_comment,
            'isActive' => 1
        ]);

        return redirect('ingredient')->with('status', 'Created new Ingredient Successfully');
    }

    public function admin_update(Request $request)
    {
        $ing_id = $request->edit_ingredientid;
        $ing_name = $request->ingredient_name;
        $ing_comment = $request->comment;
        $ing_category = $request->category;
        $ing_isVeg = $request->isVeg;
        
        $ingredient = Ingredient::select('name')->where('name',$ing_name)->get();
        
        if(count($ingredient) != 0)
        {
            return redirect()->back()->withErrors(['name' => 'Ingredient already exist.']);
        }

        Ingredient::where('id', '=',  $ing_id)->update(array('name' => $ing_name, 'category_id' => $ing_category, 'isVeg' => $ing_isVeg, 'comments' => $ing_comment));

        return redirect('ingredient')->with('status', 'Ingredient Updated Successfully');
    }

    public function admin_delete(Request $request)
    {
        $id = $request->id;
        DB::table('ingredient')->where('id',$id)->update([ 'isActive' => 0]);
       return redirect('ingredient')->with('status', 'Ingredient Deleted Successfully');
    }

    public function restore(request $request )
    {
        $id = $request->id;
        DB::table('ingredient')->where('id',$id)->update([ 'isActive' => 1]);
        return redirect('ingredient')->with('status', 'Ingredient Restored Successfully');
    }

}
