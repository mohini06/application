<?php

namespace App\Http\Controllers;

use DB;
use App\User;
use App\Cart;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function api_showCart(Request $request)
    {
        $email_id = $request->email;
        
		$user = DB::table('user')->where('email', '=',$email_id )->get();
        $user_id = $user[0]->id;
       
        $search_list = DB::table('cart')->where('user_id', '=', $user_id)->get();
         if (count($search_list))
        {
            // $search_list=[];
            // $ingredients['ingredients'] = explode('|','');
            $ingredients['ingredients'] = explode('|',$search_list[0]->ingredients);
            return json_encode($ingredients);

        }
         else {
            $ingredients['ingredients'] = [''];
            return json_encode($ingredients);
            // return Response::json(['message'=>"Data Not Found"], 404);

         }

        
        /*
        $details = [];
        $i = 0;
        foreach($ingredients['ingredients'] as $ingredient)
        {
            $category = DB::table('ingredient as ing')
                ->select('ing.name','cat.name' )
                ->where('ing.name','=',$ingredient)
                ->join('category as cat', 'ing.category_id', '=', 'cat.id')
                ->get(); 
                
            //$details[$category[0]->name] = (array_key_exists($category[0]->name,$details)) ? $details[$category[0]->name]."|".$ingredient :  $ingredient ; 
            //$details[$category[0]->name][] = (array_key_exists($category[0]->name,$details)) ? array_push($details[$category[0]->name],$ingredient) :  $ingredient;
        
            if(array_key_exists($category[0]->name,$details)) 
            {
                $details[$category[0]->name][] = array_push($details[$category[0]->name],$ingredient);  
                array_pop($details[$category[0]->name]); 
            }
            else
            {
                $details[$category[0]->name][] =  $ingredient;
            }
        }
         $data['category']= $details;
        
         return json_encode($data);*/
    }

    public function api_addCart(Request $request)
    {
        $email_id = $request->email;
       
        $user = DB::table('user')->where('email', '=',$email_id )->get();
        $user_id = $user[0]->id;
        $search_text = implode('|',$request->items);
        $result = Cart::where('user_id', '=', $user_id)->get();
        if(count($result) == 0)
        {
            DB::table('cart')->insert(
				array(
					'user_id' => $user_id, 
					'ingredients' => $search_text
            ));
        }
        else
        {
            
         DB::table('cart')
                ->where('user_id', $user_id)
                ->update(['ingredients' => $search_text]);
        }
       
        return json_encode(array('success' => true,'code'=>'200','message'=>'Inserted Your Cart item.'));
    }
    public function addSingleItem(Request $request)
    {
        $email = $request->email;
        $item = $request->item;
        $userId = User::select('id')->where('email', $email)->first();
         if($userId){
            $items = Cart::where('user_id', $userId->id)->first();
            if($items){
                if(empty($items->ingredients)){
                    Cart::where('user_id', $userId->id)->update(['ingredients'=>$item]);
                }
                else{
                    $itemArr = explode('|', $items->ingredients);
                    if(in_array(strtolower($item), array_map('strtolower', $itemArr))){
                        return response()->json(['message' => 'Item already Exist'], 409);
                    }
                    else{
                        array_push($itemArr, $item);
                        Cart::where('user_id', $userId->id)->update(['ingredients'=>implode("|", $itemArr)]);
                    } 
                }
            }
            else{
                Cart::create(['user_id'=>$userId->id, 'ingredients'=>$item]);
            }
            return response()->json(['message' => 'Added to Cart'], 200);
         }
    }
    public function deleteSingleItem(Request $request)
    {
        $email = $request->email;
        $item = $request->item;
        $userId = User::select('id')->where('email', $email)->first();
         if($userId){
             $items = Cart::where('user_id', $userId->id)->first();
             if($items){
                $itemArr = explode('|', $items->ingredients);
                if(in_array(strtolower($item), array_map('strtolower', $itemArr))){
                    $pos = array_search(strtolower($item), array_map('strtolower', $itemArr));
                    unset($itemArr[$pos]);
                    Cart::where('user_id', $userId->id)->update(['ingredients'=>implode("|", $itemArr)]);
                    return response()->json(['message' => 'Deleted from Cart'], 200); 
                }
                else{
                    return response()->json(['message'=>'Item Not found'], 404);
                }
                
             }
         }
    }
    public function cartCount($email)
    {
        $userId = User::select('id')->where('email', $email)->first();
        if($userId){
            $ingredients = Cart::select('ingredients')->where('user_id', $userId->id)->first();
            $count = count(explode('|', $ingredients));
            return json_encode(['count'=>$count]);
        }
    }

}
