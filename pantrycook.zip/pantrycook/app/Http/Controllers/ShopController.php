<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Http\Request;

class ShopController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function api_addShop(Request $request)
    {
        $email = $request->email;
        $ingredient = $request->ingredient;
       
        $user_details = DB::table('user')->where('email',$email)->get();
        $user_id = $user_details[0]->id;
        
        $new_items = implode('|',$ingredient);
        
        $shop_details = DB::table('shop')->where('user_id',$user_id)->get();

        if(sizeof($shop_details) > 0)
        {
            $row_id = $shop_details[0]->id;
            $exist_items = $shop_details[0]->ingredient;
            $exist_items .= "|".$new_items;
            
            $latest = implode('|',array_unique(explode('|', $exist_items)));
            $result = DB::table('shop')->where('id', $row_id)->update(['ingredient' => $latest]);
        }
        else
        {
            $result = DB::table('shop')->insert([
                ['user_id' => $user_id, 'ingredient' => $new_items]
            ]);
        }

        if($result == 1)
        {
            $message = "Success";
        }
        else
        {
            $message = "Already Exist";
        }
        return json_encode(array('success' => true,'code'=>'200','message'=>$message));
    }

    public function api_showShop(Request $request)
    {
        $email = $request->email;

        $user_details = DB::table('user')->where('email',$email)->get();
        $user_id = $user_details[0]->id;

        $shop_data = DB::table('shop')->where('user_id', $user_id)->get();
        $ingredient['shop data'] = $shop_data[0]->ingredient;
        return json_encode($ingredient);
    }
}
