<?php

namespace App\Http\Controllers;

use App\User;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function show()
    {
        $users = DB::table('user')->where('isActive', '1')->get();
        $del_users = DB::table('user')->where('isActive', '0')->get();
        return view('user')->with('users',$users)->with('del_users',$del_users);
    }

    public function delete(request $request )
    {
        $id = $request->id;
        User::where('id', $id)->update([ 'isActive' => '0']);
        return redirect('user')->with('status', 'User Deleted Successfully');
    }

    public function update(request $request )
    {
        $id = $request->edit_userid;
        $name = $request->name;
        $email = $request->email;
        $role = $request->role;
        $comment = $request->comment;
        /*$password = $request->password;
        $con_pass = $request->password_confirmation;*/

        /*if(!empty($password))
        {
            if($password==$con_pass)
            {
                User::where('id', $id)->update([ 'name' => $name,'email' => $email,'role' => $role,'comments' => $comment, 'password' => Hash::make($request->password)]);
            }
        }*/
        
        User::where('id', $id)->update([ 'name' => $name,'email' => $email,'role' => $role,'comments' => $comment]);
        
        return redirect('user')->with('status', 'User Updated Successfully');
    }

    public function restore(request $request )
    {
        $id = $request->id;
        User::where('id', $id)->update([ 'isActive' => '1']);
        return redirect('user')->with('status', 'User Restored Successfully');
    }

    public function change(request $request )
    {
        $id = $request->user_id;
        $password = $request->new_password;
        $con_pass = $request->new_password_confirmation;

        if($password==$con_pass)
        {
            User::where('id', $id)->update(['password' => Hash::make($password)]);
        }
        //return redirect('/change-password/'.$id)->with('status', 'Password Changed');
        return redirect('/home')->with('status', 'Password Changed successfully');
    }

    public function getId(request $request )
    {
        $id = $request->id;
        return view('auth.changepassword')->with('id',$id);
    }

}
