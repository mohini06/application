<?php

namespace App\Http\Controllers;

use DB;
use App\Favourite;
use Illuminate\Http\Request;

class FavouriteController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function api_addFavourite(Request $request)
    {
        $email = $request->email;
        $user_details = DB::table('user')->where('email', '=', $email)->get();
        $user_id = $user_details[0]->id;
        
        $search_text = implode('|',$request->items);
         
        $result = Favourite::where('user_id', '=', $user_id)->get();

        if(count($result) != 0)
        {
            DB::table('favourite')
                ->where('user_id', $user_id)
                ->update(['items' => $search_text]);

            $message = "Updated Your Favourite items.".$user_id; 
        }
        else
        {
            Favourite::create([
                'user_id' => $user_id,
                'items' => $search_text
            ]);
            $message = "Inserted you Favourite items.";     
        }
        
        return json_encode(array('success' => true,'code'=>'200','message'=>$message));
    }

    public function api_showFavourite(Request $request)
    {
        $email = $request->email;
     
        $user_details = DB::table('user')->where('email', '=', $email)->get();
       
        $user_id = $user_details[0]->id;
        
        $favourite_items = DB::table('favourite')->where('user_id', '=', $user_id)->select('items')->get();
       
           if (count($favourite_items))
        {
            // $search_list=[];
            // $ingredients['ingredients'] = explode('|','');
            $favourites['favourites'] = explode('|',$favourite_items[0]->items);
            return json_encode($favourites);

        }
         else {
            $favourites['favourites']  = [''];
            return json_encode($favourites);
            // return Response::json(['message'=>"Data Not Found"], 404);

         }
    }
}
