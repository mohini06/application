<?php

namespace App\Http\Controllers;

use App\Customer;
use App\Referral;
use DB;
use App\Order;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function show()
    {
        $customers = DB::table('customer')->where('isActive', '1')->get();
        $del_customers = DB::table('customer')->where('isActive', '0')->get();
        return view('customer')->with('customers',$customers)->with('del_customers',$del_customers);
    }

    public function delete(request $request )
    {
        $id = $request->id;
        DB::table('customer')->where('id',$id)->update([ 'isActive' => 0]);
        return redirect('customer')->with('status', 'Customer Deleted Successfully');
    }

    public function restore(request $request )
    {
        $id = $request->id;
        DB::table('customer')->where('id',$id)->update([ 'isActive' => 1]);
        return redirect('customer')->with('status', 'Customer Restored Successfully');
    }

    public function referral()
    {
        $referrals = DB::table('referral')
            ->leftjoin('customer', 'referral.customer_id', '=', 'customer.id')
            ->where('referral.isActive', '=', '1')
            ->select('referral.email','customer.name','referral.dob')
            ->get();

        $del_referrals = DB::table('referral')
            ->leftjoin('customer', 'referral.customer_id', '=', 'customer.id')
            ->where('referral.isActive', '=', '0')
            ->select('referral.email','customer.name','referral.dob')
            ->get();
        return view('referral')->with('referrals', $referrals)->with('del_referrals',$del_referrals);
    }

    public function update(request $request )
    {
        $id = $request->edit_customerid;
        $name = $request->customer_name;
        $email = $request->customer_email;
        $phone = $request->customer_phone;
        $reward = $request->customer_reward;

        Customer::where('id', $id)->update([ 'name' => $name,'email' => $email, 'phone' => $phone, 'rewards' => $reward]);

        return redirect('customer')->with('status', 'Customer Updated Successfully');
    }

    public function api_create(Request $request)
    {
        $ifExist = DB::table('customer')
            ->where('email',$request->email)
            ->get();

        $tax = DB::table('tax')
            ->where('isActive','1')
            ->orderBy('id','desc')
            ->take(1)
            ->get();

        if (count($ifExist))
        {
            $order = Order::insertGetId([
                'user_id' => $request->user_id,
                'customer_id' => $ifExist[0]->id,
                'dine_space_id' => $request->table_id,
                'tax_id' => $tax
            ]);
            $ifExist[0]->order = $order;
            return json_encode($ifExist[0]);
        }
        else
        {
            $insert_id = Customer::insertGetId([
                'name' => $request->name,
                'phone' => $request->phone,
                'email' => $request->email,
                'isActive' => '1',
                'rewards' => '0'
            ]);

            $customer = DB::table('customer')
                ->where('id',$insert_id)
                ->get();

            $order = Order::insertGetId([
                'user_id' => $request->user_id,
                'customer_id' => $customer[0]->id,
                'dine_space_id' => $request->table_id,
                'tax_id' => $tax
            ]);

            $customer[0]->order = $order;
            return json_encode($customer[0]);
        }
    }

    public function api_show(Request $request)
    {
        $customers = DB::table('customer')->where('isActive', '1')->get();
        return json_encode($customers);
    }
}
