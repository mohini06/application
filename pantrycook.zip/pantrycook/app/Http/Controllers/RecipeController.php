<?php

namespace App\Http\Controllers;

use DB;
use App\Recipe;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;

class RecipeController extends Controller
{
    public function api_storeReceipe(Request $request)
    {
    	$reqs = $request->results;
        $type= "";
    	foreach ($reqs as $req) {
    		if(stripos($req['title'], '\n') !== false)
    		{
    			$req['title'] =preg_replace('/[^A-Za-z0-9\-] /', '', $req['title']);
    		}
    		$title = $req['title'];
    		if(stripos($title, 'breakfast') !== false)
            {
                $type = "breakfast";
            }
            elseif (stripos($title, 'lunch')!== false) {
                $type = "lunch";
            }
            elseif (stripos($title, 'dinner')!== false) {
                $type = "dinner";
            }
            else
            {
                $type = "";
            }
            $recipe_details = DB::table('recipes')->where('href', '=', $req['href'])->get();
            if(count($recipe_details)==0)
            {
                $recipe = new Recipe;
                $recipe->recipe_title = $req['title'];
                $recipe->href = $req['href'];
                $recipe->ingredients = $req['ingredients'];
                $recipe->thumbnail = $req['thumbnail'];
                $recipe->ratings = $req['ratings'];
                $recipe->type = $type;
                $recipe->save();
                    
            }

            /*try
    		{
    			$recipe = new Recipe;
    			$recipe->recipe_title = $req['title'];
		    	$recipe->href = $req['href'];
		    	$recipe->ingredients = $req['ingredients'];
		    	$recipe->thumbnail = $req['thumbnail'];
		    	$recipe->save();
    		}
    		catch(\Exception $e)
    		{
    			$e->getMessage();
    		}*/
    		
    		/*$validator = $this->validate($req, [
    			'href' => 'unique:recipes'
    		]);
    		return $validator;*/
    	}
        return response()->json(['success' => 'success'], 201);
    }

    public function api_getReceipe(Request $request)
    {
        $ingredients = $request->i;
        $type = $request->q;
        $result_set = [];
        $res_arr = [];
        $item = [];
        $all = [];
        $page_res = [];
        $ing_arr = explode(',', $ingredients);
        $all['title'] = "Recipe Puppy";
        $all['version'] =  0.1;
        $all['href'] = "http://www.recipepuppy.com/";
        try
        {
            if(empty($type))
            {
                foreach ($ing_arr as $ingredient) {
                    /*$results = Recipe::where('ingredients', 'like', '%'.$ingredient.'%')->take(100)->get();*/
                    $results = Recipe::distinct()->where('ingredients', 'like', '%'.$ingredient.'%')->orderBy('recipe_id', 'DESC')->get();
                    $result_set[] = $results;
                }
                //return $result_set;
                foreach ($result_set as $result) {
                    foreach ($result as $res) {
                        $item['title'] = $res->recipe_title;
                        $item['href'] = $res->href;
                        $item['ingredients'] = $res->ingredients;
                        $item['thumbnail'] = $res->thumbnail;
                        $res_arr[] = $item;
                    }
                    $all['results'] = $res_arr;
                }
               $all['results'] = array_values(array_unique($all['results'], SORT_REGULAR));    
            }
            else
            {
                foreach ($ing_arr as $ingredient) {
                    /*$results = Recipe::where('ingredients', 'like', '%'.$ingredient.'%')->take(100)->get();*/
                    $results = Recipe::distinct()->where(function($q) use($ingredient, $type){
                        $q->where('ingredients', 'like', '%'.$ingredient.'%');
                        $q->where('type' ,$type);
                    })->get();
                    $result_set[] = $results;
                }
                foreach ($result_set as $result) {
                    foreach ($result as $res) {
                        $item['title'] = $res->recipe_title;
                        $item['href'] = $res->href;
                        $item['ingredients'] = $res->ingredients;
                        $item['thumbnail'] = $res->thumbnail;
                        $res_arr[] = $item;
                    }
                    $all['results'] = $res_arr;
                }
                $all['results'] = array_values(array_unique($all['results'], SORT_REGULAR));
            }
        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }


        // Get current page form url e.x. &page=1
        $currentPage = LengthAwarePaginator::resolveCurrentPage();
 
        // Create a new Laravel collection from the array data
        $itemCollection = collect($all['results']);
 
        // Define how many items we want to be visible in each page
        $perPage = 30;
 
        // Slice the collection to get the items to display in current page
        $currentPageItems = $itemCollection->slice(($currentPage * $perPage) - $perPage, $perPage)->all();
 
        // Create our paginator and pass it to the view
        $paginatedItems= new LengthAwarePaginator($currentPageItems , count($itemCollection), $perPage);
 
        // set url path for generted links
        $paginatedItems->setPath($request->url());

        foreach($paginatedItems as $paginatedItem)
        {
            $page_res[] = $paginatedItem;
        } 
        $all['results'] = $page_res;
        $all['last_page'] = $paginatedItems->lastPage();
        return json_encode($all);
    }

    public function api_getTopRecipe(Request $request)
    {
        $ingredients = $request->i;

        $type = $request->q;
        $result_set = [];
        $res_arr = [];
        $item = [];
        $all = [];
        $page_res = [];
        $ingredients = str_replace(' ', '%20', $ingredients);
        $ing_arr = explode(',', $ingredients);

        try
        {

            $all['title'] = "AI Engine";
            $all['version'] =  0.1;
            $all['href'] = "http://52.7.15.247:5001/recipe";

            // API URL
            $url = 'http://52.7.15.247:5001/recipe';

            // Create a new cURL resource
            $ch = curl_init($url);
            
            // Setup request to send json via POST
            $data['ingredients'] = $ing_arr;
            $payload = json_encode($data);

            // Attach encoded JSON string to the POST fields
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);

            // Set the content type to application/json
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));

            // Return response instead of outputting
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            // Execute the POST request
            $AI_Engine = curl_exec($ch);
            
            // Close cURL resource
            curl_close($ch);
            
            $result_set = json_decode($AI_Engine, TRUE);
           
            foreach ($result_set as $result) 
            {
                $ai_result = $result;
            }
            
            $all['results'] = $ai_result;
            
            
        }
        catch(\Exception $e)
        {
            $all['title'] = "Recipe Puppy";
            $all['version'] =  0.1;
            $all['href'] = "http://www.recipepuppy.com/";         
          
            // API URL
           if(empty($type))
            {
                $url = 'https://recipe-puppy.p.rapidapi.com/?i='.$ingredients;
            }
            else
            {
                $url = 'https://recipe-puppy.p.rapidapi.com/?i='.$ingredients.'&q='.$type;
            }
          
            $ch = curl_init();
     
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-type: application/json',
                'x-rapidapi-key: abf847fad6msh382719868ef0bbcp1b423cjsn9983e4864aa5'
            ));

            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $puppy_result = curl_exec($ch);
            
            curl_close($ch);

            $result_data = json_decode($puppy_result,TRUE);
           
            foreach ($result_data as $data) 
            { 
                $ai_result = $data;
            }
            $all['results'] = $ai_result;
        }

        // Get current page form url e.x. &page=1
        $currentPage = LengthAwarePaginator::resolveCurrentPage();

        // Create a new Laravel collection from the array data
        $itemCollection = collect($all['results']);

        // Define how many items we want to be visible in each page
        $perPage = 30;

        // Slice the collection to get the items to display in current page
        $currentPageItems = $itemCollection->slice(($currentPage * $perPage) - $perPage, $perPage)->all();

        // Create our paginator and pass it to the view
        $paginatedItems= new LengthAwarePaginator($currentPageItems , count($itemCollection), $perPage);

        // set url path for generted links
        $paginatedItems->setPath($request->url());

        foreach($paginatedItems as $paginatedItem)
        {
            $page_res[] = $paginatedItem;
        } 
        $all['results'] = $page_res;
        $all['last_page'] = $paginatedItems->lastPage();
        return json_encode($all);
    }
}
