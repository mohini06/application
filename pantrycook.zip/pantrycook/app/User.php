<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, Notifiable;

    protected $table='user';
    public $timestamps = false;
    protected $fillable = [
        'name', 'email', 'password', 'created_on', 'updated_on', 'role',  'isActive', 'comments', 'user_image',
    ];


    protected $hidden = [
        'password', 'remember_token',
    ];
}
