<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class EmailVerify extends Model
{
    use Notifiable;

	protected $table = 'emailverify';
    protected $fillable = [
        'email', 'token'
    ];
}
