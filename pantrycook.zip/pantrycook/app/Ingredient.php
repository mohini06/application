<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ingredient extends Model
{
    protected $table = 'ingredient';
    public $timestamps = false;
    protected $fillable = [
        'category_id', 'name','isVeg','comments','isActive',
    ];
}
