<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ScannedItem extends Model
{
    protected $table = 'scanned_item';
    public $timestamps = false;
    protected $fillable = [
        'user_id', 'barcode_number','barcode_type','product_name','category','manufacturer','brand','ingredients',
        'size','description',
    ];
}

