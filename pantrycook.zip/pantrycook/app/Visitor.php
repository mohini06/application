<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Visitor extends Model
{
    protected $table='visitor';
    public $timestamps = false;
    protected $fillable = [
        'user_id', 'site_url', 'count', 'percentage',
    ];
}
