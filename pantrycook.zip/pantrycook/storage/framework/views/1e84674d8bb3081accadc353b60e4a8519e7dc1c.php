

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Ingredients Details</div>
                <div class="card-body">
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($error); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-md-12">
                            <table id="example" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Category</th>
                                        <th class="isVeg_icon">IsVegan</th>
                                        <th>Updated On</th>
                                        <th class="no-sort">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $count=1; ?>
                                    <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($ingredient->ing_name); ?></td>
                                            <td><?php echo e($ingredient->cat_name); ?></td>
                                            <td class="text-center">
                                                <?php if($ingredient->isVeg=="0"): ?>
                                                    <img class="food_icon" src="<?php echo e(url('/public/images/veg.png')); ?>" />
                                                <?php else: ?>
                                                    <img class="food_icon" src="<?php echo e(url('/public/images/non_veg.png')); ?>" />
                                                <?php endif; ?>



                                            </td>
                                            <td><?php echo e($ingredient->ing_updated_on); ?></td>
                                        <td class="text-center" ingredient_id="<?php echo e($ingredient->ing_id); ?>">
                                            <i class="fa fa-edit ingredient_edit mr-2 ml-2" data-toggle="modal" data-target="#ingredient_edit"></i>
                                            <i class="fa fa-trash ingredient_trash mr-2 ml-2" data-toggle="modal" data-target="#ingredient_del"></i>
                                        </td>
                                        <?php $count++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <nav class="navbar navbar-expand-sm">
                            <ul class="navbar-nav">
                                <li class="nav-item m-2">
                                    <a class="nav navbar-nav" style="text-decoration: none" href="#" data-toggle="modal" data-target="#ingredient_add">Add Ingredient</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="accordion" class="mt-2">
            <div class="card">
                <div class="card-header"> Deleted Ingredient Details
                  <a class="collapsed card-link" data-toggle="collapse" href="#collapseTwo">
                    <span class="fa fa-caret-down float-right"></span>

                  </a>
                </div>
                <div id="collapseTwo" class="collapse" data-parent="#accordion">
                  <div class="card-body">
                    <div class="row">
                    <div class="col-md-12">
                            <table id="delete" class="table table-striped table-bordered menu">
                            <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Category</th>
                                        <th class="isVeg_icon">IsVegan</th>
                                        <th>Updated On</th>
                                        <th class="no-sort">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $count=1; ?>
                                    <?php $__currentLoopData = $delingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($delingredient->ing_name); ?></td>
                                            <td><?php echo e($delingredient->cat_name); ?></td>
                                            <td class="text-center">
                                                <?php if($delingredient->isVeg=="0"): ?>
                                                    <img class="food_icon" src="<?php echo e(url('/public/images/veg.png')); ?>" />
                                                <?php else: ?>
                                                    <img class="food_icon" src="<?php echo e(url('/public/images/non_veg.png')); ?>" />
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($delingredient->ing_updated_on); ?></td>
                                            <td class="text-center" ingredient_id="<?php echo e($delingredient->ing_id); ?>">
                                            <a href="#"
                                                    class="ingredient_restore mr-2 ml-2" data-toggle="modal"
                                                    data-target="#restoreIngredient">Restore</a></td>
                                        <?php $count++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                  </div>
                </div>
          </div>
        </div>
</div>
</div>


<div id="ingredient_add" class="modal" role="dialog" >
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Ingredient</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?php echo e(url('ingredient_add')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label for="ingredient_name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>
                        <div class="col-md-6">
                            <input id="ingredient_name" type="text" class="form-control<?php echo e($errors->has('ingredient_name') ? ' is-invalid' : ''); ?>" name="ingredient_name" pattern="(?=.*[a-zA-Z])[A-Za-z\s]{2,}" title="The name field accepts alphabets and  combination of alphabets and space." required />
                            <?php if($errors->has('ingredient_name')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('ingredient_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="category" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Category')); ?></label>
                        <div class="col-md-6">
                            <select class="form-control" name="category" required>
								<option selected="true" value="" disabled="disabled">Choose Tagging</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('category')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('category')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="isVeg" class="col-md-4 col-form-label text-md-right"><?php echo e(__('IsVegan')); ?></label>
                        <div class="col-md-6 mt-2">
                            <input type="radio" name="isVeg" value="0" checked> Vegan
                            <input type="radio" name="isVeg" value="1"> Non-Vegan
                            <?php if($errors->has('isVeg')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('isVeg')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="comments" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Comments')); ?></label>
                        <div class="col-md-6">
                            <textarea class="form-control" name="comment" ></textarea>
                            <?php if($errors->has('comments')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('comments')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row mb-0">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-primary">
                            <?php echo e(__('Create')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div id="ingredient_del" class="modal fade ingredient" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Confirmation</h4><button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <p>Are you sure want to delete ?</p>
            </div>
            <div class="modal-footer">
                <a class="btn btn-primary" ingredientid="" action="" href="">OK</a>
                <!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
            </div>
        </div>
    </div>
</div>

<div id="ingredient_edit" class="modal" role="dialog" >
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit Ingredient</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?php echo e(url('ingredient_update')); ?>">
                    <?php echo csrf_field(); ?>
                    <input id="edit_ingredientid" type="hidden" value="" name="edit_ingredientid"/>
                    <div class="form-group row">
                        <label for="ing_name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>
                        <div class="col-md-6">
                            <input id="ingr_name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="ingredient_name" value="" pattern="(?=.*[a-zA-Z])[A-Za-z\s]{2,}" title="The name field accepts alphabets and  combination of alphabets and space."  required />
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="ing_cat" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Category')); ?></label>
                        <div class="col-md-6">
                            <select id="ing_cat" class="form-control<?php echo e($errors->has('Category') ? ' is-invalid' : ''); ?>" name="category" required>
                                <option selected="true" value="" disabled="disabled">Choose Tagging</option>
								<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>     
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('category')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('category')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="ing_isVeg" class="col-md-4 col-form-label text-md-right"><?php echo e(__('isVegan')); ?></label>
                        <div class="col-md-6">
                            <input class="radio_veg" type="radio" name="isVeg" value="0" checked> Vegan  
                            <input class="radio_veg" type="radio" name="isVeg" value="1"> Non-Vegan
                            <?php if($errors->has('isVeg')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('isVeg')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    
                    <div class="form-group row">
                        <label for="comment" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Comments')); ?></label>
                        <div class="col-md-6">
                            <textarea id="comment_edit" class="form-control<?php echo e($errors->has('comment') ? ' is-invalid' : ''); ?>" name="comment" autofocus></textarea>
                            <?php if($errors->has('comment')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('comment')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row mb-0">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Update')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div id="restoreIngredient" class="modal fade ingredientRestore" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Confirmation</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <p>Are you sure want to restore?</p>
            </div>
            <div class="modal-footer">
                <a class="btn btn-primary" ingredientid="" action="" href="">OK</a>
                <!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>