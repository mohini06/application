<?php

/*----------------WEB SERVICES------------------------*/

Route::get('/', function () {
	if(Auth::check())
	{
		return view('home');
	}
	else
	{
		return view('auth.login');
	}
    
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
    /*---------------User Functions---------------*/
Route::get('/user', 'UserController@show');
Route::get('/user_delete/{id}', 'UserController@delete');
Route::post('/user_update', 'UserController@update');
Route::post('/user_edit', 'AjaxController@getUserDetails');
Route::get('/user_restore/{id}', 'UserController@restore');
Route::get('/change-password/{id}', 'UserController@getId');
Route::post('/reset_password','UserController@change');

/*---------------Incredient Functions----------------*/
Route::get('/ingredient', 'IngredientController@admin_show');
Route::post('/ingredient_add', 'IngredientController@admin_create');
Route::post('ingredient_edit', 'AjaxController@getIngredientDetails');
Route::post('ingredient_update', 'IngredientController@admin_update');
Route::get('/ingredient_delete/{id}', 'IngredientController@admin_delete');
Route::get('/ingredient_restore/{id}', 'IngredientController@restore');

/*---------------Category Functions-------------*/
Route::get('/category', 'CategoryController@admin_show');
Route::post('/category_add', 'CategoryController@admin_create');
Route::get('/category_delete/{id}', 'CategoryController@admin_delete');
Route::post('/category_edit', 'AjaxController@getCategoryDetails');
Route::post('/category_update', 'CategoryController@admin_update');
Route::get('/category_restore/{id}', 'CategoryController@restore');