<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::middleware('auth:api')->get('/call', function (Request $request) {
    return $request;
});

Route::post('login', 'PassportController@login'); /*----------- Login ----------- */
Route::post('register', 'PassportController@register'); /*----------- Register ----------- */

Route::group([    
    'namespace' => 'Auth',    
    'middleware' => 'api',    
    'prefix' => 'password'
], function () {    
    Route::post('create', 'PasswordResetController@create'); /*-----------Send Reset mail into particular id-----------*/
    Route::get('find/{token}', 'PasswordResetController@find');/*-----------Verify the token----------- */
    Route::post('reset', 'PasswordResetController@reset'); /*-----------Resetting Password-----------*/
});

Route::group([    
    'namespace' => 'Auth',    
    'middleware' => 'api',    
    'prefix' => 'email'
], function () {    
    Route::post('verification', 'EmailVerificationController@create'); /*-----------Send Reset mail into particular id-----------*/
    Route::get('test', 'EmailVerificationController@basic_email');
});

Route::middleware('auth:api')->group(function () {
    Route::get('user', 'PassportController@details');   /*-----------User details-----------*/
    Route::get('suggestion/{id}', 'IngredientController@api_suggest');/*-----------Search Suggestions-----------*/
    Route::get('categories', 'CategoryController@api_show');/*-----------Category List-----------*/
    Route::get('incredients/{id}', 'CategoryController@api_subCategory');/*-----------Subcategory List-----------*/
    Route::post('add_cart', 'CartController@api_addCart');/*-----------Adding items to Cart-----------*/
    Route::get('show_cart/{email}', 'CartController@api_showCart');/*-----------Display Cart items-----------*/
    Route::post('add-cart-single','CartController@addSingleItem');
    Route::post('delete-cart-single', 'CartController@deleteSingleItem');
    Route::get('cart-count/{email}', 'CartController@cartCount');
    Route::post('changepassword', 'PassportController@change_password');/*-----------Change Password-----------*/
    Route::post('add_favourite', 'FavouriteController@api_addFavourite');/*-----------Adding items to Favourite-----------*/
    Route::get('show_favourite/{email}', 'FavouriteController@api_showFavourite');/*-----------Display Favourite items-----------*/
    Route::get('logout', 'PassportController@logout');/*-----------Logout-----------*/
    //Route::post('add_ingredientShop', 'ShopController@api_addShop');/*-----------Used Ingredients-----------*/
    //Route::get('show_ingredientShop/{email}', 'ShopController@api_showShop');/*-----------Display the Used Ingredients-----------*/
    Route::post('add_scanned_item', 'ScannedController@api_add_scannedItem');
    Route::get('get_ScannedItems/{email}', 'ScannedController@api_get_ScannedItems');
    //Route::post('get_scannedItem_GenericName', 'ScannedController@api_get_ScannedItem_GenericName');
    Route::post('get_VoiceSearch_Items', 'ScannedController@api_get_VoiceSearch_Items');
    Route::post('add_scannedItemStatus','ScannedController@api_add_scannedItemStatus');
    Route::post('remove_scannedItemStatus','ScannedController@api_remove_scannedItemStatus');
    Route::post('remove_allscannedItem','ScannedController@api_remove_allscannedItem');
    Route::post('scannedItemSuggestion','ScannedController@api_scannedItemSuggestion');
    Route::post('remove_scannedItem','ScannedController@api_remove_scannedItem');

    Route::post('add_visitor','VisitorController@api_storeVisitor');
    Route::post('sort_visitor','VisitorController@api_SortVisitor');

    Route::post('store_receipe','RecipeController@api_storeReceipe');
    Route::get('getReceipe', 'RecipeController@api_getReceipe');
    Route::get('getTopReceipe', 'RecipeController@api_getTopRecipe');
});


            
