** Git: https://code.agiledevers.com/garcia/BLMA-DataEntry.git **

# Frontend

This project was generated with Angular CLI version 8.3.21

Angular 8.1.0

** libraries: **

  "@angular/animation": "^4.0.0-beta.8",
    "@angular/animations": "^8.2.14",
    "@angular/cdk": "^8.2.3",
    "@angular/common": "^8.1.0",
    "@angular/compiler": "^8.1.0",
    "@angular/core": "^8.1.0",
    "@angular/flex-layout": "^8.0.0-beta.26",
    "@angular/forms": "^8.1.0",
    "@angular/material": "^8.2.3",
    "@angular/platform-browser": "^8.1.0",
    "@angular/platform-browser-dynamic": "^8.1.0",
    "@angular/router": "^8.1.0",
    "@ng-select/ng-select": "^3.7.0",
    "@ngrx/core": "1.2.0",
    "@ngrx/data": "^8.0.1",
    "@ngrx/effects": "^8.0.1",
    "@ngrx/entity": "^8.0.1",
    "@ngrx/router-store": "^8.0.1",
    "@ngrx/store": "^8.0.1",
    "@syncfusion/ej2": "^17.2.36",
    "@syncfusion/ej2-angular-buttons": "^17.4.43",
    "@syncfusion/ej2-angular-calendars": "^17.2.36",
    "@syncfusion/ej2-angular-charts": "^17.4.43",
    "@syncfusion/ej2-angular-dropdowns": "^17.2.36",
    "@syncfusion/ej2-angular-grids": "^17.2.35",
    "@syncfusion/ej2-angular-inputs": "^17.4.43",
    "@syncfusion/ej2-angular-navigations": "^17.2.39",
    "@syncfusion/ej2-angular-notifications": "^17.2.47",
    "@syncfusion/ej2-angular-popups": "^17.2.35",
    "@syncfusion/ej2-angular-splitbuttons": "^17.4.39",
    "@syncfusion/ej2-navigations": "^17.2.34",
    "@webcomponents/custom-elements": "^1.0.0",
    "angular-plotly.js": "^1.3.2",
    "angular2-ladda": "^2.0.2",
    "canvasjs": "^1.8.3",
    "chart.js": "^2.8.0",
    "core-js": "^3.1.4",
    "ej-angular2": "^17.2.34",
    "file-saver": "^2.0.2",
    "font-awesome": "^4.7.0",
    "gojs": "^2.1.8",
    "gojs-angular": "^1.0.1",
    "increase-memory-limit": "^1.0.7",
    "jquery": "^3.4.1",
    "jszip": "^3.2.2",
    "jwt-decode": "^2.2.0",
    "lodash": "^4.17.15",
    "material-steppers": "^2.0.0",
    "moment": "^2.24.0",
    "moment-timezone": "^0.5.26",
    "ng-multiselect-dropdown": "^0.2.3",
    "ng-zorro-antd": "^8.2.1",
    "ng2-charts": "^2.3.0",
    "ng2-scroll-to-el": "^1.2.1",
    "ng2-tag-input": "^1.4.1",
    "ngx-autosize": "^1.6.3",
    "ngx-bootstrap": "^2.0.0-rc.0",
    "ngx-bootstrap-datetime-popup": "^1.2.7",
    "ngx-chips": "^1.6.7",
    "ngx-loading": "^1.0.14",
    "ngx-pagination": "^3.1.1",
    "object-path": "^0.11.4",
    "plotly.js": "^1.48.3",
    "reflect-metadata": "^0.1.13",
    "rxjs": "^6.5.2",
    "rxjs-compat": "^6.5.2",
    "string-format": "^2.0.0",
    "syncfusion-javascript": "^17.2.34",
    "ts-md5": "^1.2.6",
    "tslib": "^1.9.0",
    "xlsx": "^0.15.3",
    "zone.js": "~0.9.1"

** API URL path: /src/environments/environment.ts **

Execute: npm install
Run development mode:Execute npm start and navigate to localhost:4200

## Deployment:
Execute: ng build
Copy /dist elements of to /backend/public

# Backend

JAVA

* Spring boot

Create all tables: Execute rake:db migrate
