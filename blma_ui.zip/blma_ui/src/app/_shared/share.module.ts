import { AttributesComponent } from './../admin/attributes/attributes.component';
import { NewBatchComponent } from './../batches/new/new.component';
import { CommentsComponent } from './../admin/comments/comments.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TagsComponent } from './../admin/tags/tags.component';
import { FilterPipe } from './../pipes/filter.pipe';
import { DateAgoPipe } from './../pipes/date-ago.pipe';
import { TabsModule } from 'ngx-bootstrap/tabs';

import { AlertService } from './../_core/services/alert.service';
import { AlertComponent } from './../alert/alert.component';

//Modules
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

//Components
import { SidebarComponent } from './sidebar/sidebar.component';
import { TopbarComponent } from './topbar/topbar.component';
import { LayoutComponent } from './layout/layout.component';
import { AuditComponent } from './../data-entry/components/form-info/audit/audit.component';
import { ChildAlertComponent } from './child-alert/child-alert.component';
import { HeaderlayoutComponent } from './headerlayout/headerlayout.component';
//Routes
import { routes } from '../app.routes';

//SyncFusion
import { GridModule,ToolbarService, ExcelExportService } from '@syncfusion/ej2-angular-grids';
import { PageService, SortService, FilterService, GroupService } from '@syncfusion/ej2-angular-grids';
import { DropDownListModule } from '@syncfusion/ej2-angular-dropdowns';
import { DateTimePickerModule,DatePickerModule,TimePickerModule } from '@syncfusion/ej2-angular-calendars';
import { ToastModule } from '@syncfusion/ej2-angular-notifications';



import { NgSelectModule } from '@ng-select/ng-select';

//NG-Zorro
import { NgZorroAntdModule, NZ_ICONS } from 'ng-zorro-antd';
import { IconDefinition } from '@ant-design/icons-angular';
import * as AllIcons from '@ant-design/icons-angular/icons';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzCommentModule } from 'ng-zorro-antd/comment';
import { InactivityTimerComponent } from './inactivity-timer/inactivity-timer.component';

import { DateRangePickerModule } from '@syncfusion/ej2-angular-calendars';
import { EsigComponent } from './esig/esig.component';
import { ModalModule } from 'ngx-bootstrap/modal';

const antDesignIcons = AllIcons as {
  [key: string]: IconDefinition;
};
const icons: IconDefinition[] = Object.keys(antDesignIcons).map(key => antDesignIcons[key])


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild([]),
    GridModule,
    DateTimePickerModule,
    DropDownListModule,
    DatePickerModule,
    TimePickerModule,
    NgZorroAntdModule,
    NzIconModule,
    ToastModule,
    NgSelectModule,
    TabsModule,
    FormsModule,
    NzCommentModule,
    FormsModule,
    ReactiveFormsModule,
    DateRangePickerModule,
    ModalModule.forRoot(),

  ],
  exports: [
    LayoutComponent,
    CommonModule,
    SidebarComponent,
    TopbarComponent,
    AlertComponent,
    ChildAlertComponent,
    RouterModule ,
    AuditComponent,
    GridModule,
    DateTimePickerModule,
    DropDownListModule,
    DatePickerModule,
    TimePickerModule,
    NgZorroAntdModule,
    NzIconModule,
    ToastModule,
    NgSelectModule,
    TabsModule,
    DateAgoPipe,
    FilterPipe,
    TagsComponent,
    CommentsComponent,
    InactivityTimerComponent,
    NewBatchComponent,
    DateRangePickerModule,
    AttributesComponent,
    EsigComponent,
    ModalModule,

  ],
  declarations: [
    SidebarComponent,
    TopbarComponent,
    LayoutComponent,
    AuditComponent,
    AlertComponent,
    HeaderlayoutComponent,
    ChildAlertComponent,
    DateAgoPipe,
    FilterPipe,
    TagsComponent,
    CommentsComponent,
    InactivityTimerComponent,
    NewBatchComponent,
    AttributesComponent,
    EsigComponent,

  
  ],
  providers: [ PageService, SortService, FilterService, GroupService,ExcelExportService, ToolbarService,AlertService,{ provide: NZ_ICONS, useValue: icons }]
})
export class SharedModule {}

