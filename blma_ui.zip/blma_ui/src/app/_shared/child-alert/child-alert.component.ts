import { AlertService } from './../../_core/services/alert.service';
import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-child-alert',
  templateUrl: './child-alert.component.html',
  styleUrls: ['./child-alert.component.scss']
})
export class ChildAlertComponent implements OnInit {
  messageChild: any;
  private subscription: Subscription;
  constructor(private alertService: AlertService) { }

  ngOnInit() {
    this.subscription = this.alertService.getMessageChild().subscribe(message => {
      this.messageChild = message;
    });
  }

  closeAlertChild() {
    this.alertService.removeAlertChild()
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
