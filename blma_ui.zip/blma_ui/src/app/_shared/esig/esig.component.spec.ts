import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EsigComponent } from './esig.component';

describe('EsigComponent', () => {
  let component: EsigComponent;
  let fixture: ComponentFixture<EsigComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EsigComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EsigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
