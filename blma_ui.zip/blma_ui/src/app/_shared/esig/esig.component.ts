import { GetGenericService } from './../../_core/services/get-generic.service';
import { AlertService } from './../../_core/services/alert.service';
import { AuthService } from './../../_core/services/auth.service';
import { LoginService } from './../../_core/services/login.service';
import { PostgenericService } from './../../_core/services/postgeneric.service';
import { BatchesService } from './../../_core/services/batches.service';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { BsModalService, BsModalRef, ModalDirective } from 'ngx-bootstrap/modal';
import { Component, OnInit, TemplateRef, ViewChild, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-esig',
  templateUrl: './esig.component.html',
  styleUrls: ['./esig.component.scss']
})
export class EsigComponent implements OnInit {
  @Input() parentData: any;
  @Input() parent: any;

  @Output() esigChildData: EventEmitter<any> = new EventEmitter<any>();

  esigForm: FormGroup

  dataToDisplay = []

  meaningData=[]
  roleData=[]

  panels = [
    {
      active: false,
      name: 'Preview data',
      arrow: true
    }
  ];
  config = {
    backdrop: true,
    ignoreBackdropClick: true,
    show: true
  };



  
  @ViewChild('autoShownModal', { static: false }) autoShownModal: ModalDirective;
  isModalShown = false;

  showModal(): void {
    this.isModalShown = true;
  }

  hideModal(): void {
    this.autoShownModal.hide();
  }

  onHidden(): void {
    this.isModalShown = false;
  }
  constructor(private formBuilder: FormBuilder, private batchesService: BatchesService,
    private postGeneric: PostgenericService,
     private auth: AuthService, private alert: AlertService, private getGeneric:GetGenericService) { }

  ngOnInit() {

    this.esigForm = this.formBuilder.group({
      username: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(500)]],
      password: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(500)]],
      comment: ['', [Validators.minLength(2), Validators.maxLength(500)]],
      meaning: ['', [ Validators.minLength(2), Validators.maxLength(500)]],
      role: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(500)]],

    });


    this.showModal()
    // console.log(this.parentData)
    // console.log(this.parent)
    for (let key in this.parentData) {
      // console.log ('key: ' +  key + ',  value: ' + this.parentData[key]);
      this.dataToDisplay.push({ key: key, value: this.parentData[key] })
    }
    // console.log(this.dataToDisplay)
    this.username.setValue(this.batchesService.getUserName())

    this.getDropDownData()
  }


  get username() { return this.esigForm.get('username'); }
  get password() { return this.esigForm.get('password'); }
  get comment() { return this.esigForm.get('comment'); }
  get meaning() { return this.esigForm.get('meaning'); }
  get role() { return this.esigForm.get('role'); }




  postEsigDoc() {
    this.postGeneric.postEsigDoc(this.esigForm.value, this.parentData, this.parent).subscribe(data => {
      // console.log(data['INSERTED_ROW_ID'][0].id)
      this.postEsigSigner(data['INSERTED_ROW_ID'][0].id)
     
    },
      error => {

        console.log(error.error)
      })

  }

  savedvalue:number;
  
  
  

  postEsigSigner(DocId) {
    console.log(DocId)
    this.postGeneric.postEsigSigner(DocId, this.esigForm.value)
      .subscribe(data => {
         console.log(data)
        this.updateEsigDoc(DocId)
      },
        error => {

          console.log(error.error)
        })
  }

  //////Update EsigDoc
  updateEsigDoc(docId) {
    this.postGeneric.updateEsigDoc(docId).subscribe(data => {
      // console.log(data)
      this.esigChildData.emit({status:true})
      this.hideModal()
    },
      error => {

        console.log(error.error)
      })
  }


  validateUser() {
    this.auth.validateEsig(this.username.value, this.password.value).subscribe(data => {
      // console.log(data)
      this.postEsigDoc()
    },
      error => {
        console.log(error.error)
        this.alert.error("Invalid Password")
      })
  }


  getDropDownData()
  {
    this.getGeneric.getEsigSigner().subscribe(data => {
      
      this.meaningData=data.esigsigner_meaning
      this.roleData=data.esigsigner_roles
      console.log(this.roleData)
      
    },
      error => {
        console.log(error.error)
      
      })
  }

  items = [
    {id: 1, name: 'Python'},
    {id: 2, name: 'Node Js'},
    {id: 3, name: 'Java'},
    {id: 4, name: 'PHP', disabled: true},
    {id: 5, name: 'Django'},
    {id: 6, name: 'Angular'},
    {id: 7, name: 'Vue'},
    {id: 8, name: 'ReactJs'},
  ];
  selected = [
    {id: 2, name: 'Node Js'},
    {id: 8, name: 'ReactJs'}
  ];

}
