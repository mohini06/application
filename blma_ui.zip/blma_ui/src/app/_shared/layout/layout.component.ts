import { Component, OnInit } from '@angular/core';
import { AppRoutesModule } from '../../app.routes';
import { contentAnimation } from '../../_core/animations/page.animations'
import {
  trigger,
  state,
  style,
  animate,
  transition,
  query,
} from '@angular/animations';

@Component({
  selector: 'layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss'],
  animations: [ contentAnimation ]
})
export class LayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  
  getRouteAnimation(outlet) {
    return outlet.activatedRouteData.animation
  }

}
