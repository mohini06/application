import { filter } from 'rxjs/operators';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute, ActivatedRouteSnapshot, NavigationStart } from '@angular/router';
import { Item } from '../../_core/interfaces/sidebar'
import { Store } from '@ngrx/store';
import { SideBarState, sideBarStateActions } from '../../_core/store/side-bar.actions';
import { DataEntryService } from '../../_core/services/data-entry.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { ItemmasterService } from '../../_core/services/itemmaster.service';

@Component({
  selector: 'app-headerlayout',
  templateUrl: './headerlayout.component.html',
  styleUrls: ['./headerlayout.component.scss']
})
export class HeaderlayoutComponent implements OnInit {

  @ViewChild('autoShownModal', { static: false }) autoShownModal: ModalDirective;
  isModalShown = true;
 
  showModal(): void {
    this.isModalShown = true;
  }
 
  hideModal(): void {
    this.autoShownModal.hide();
  }
 
  onHidden(): void {
    this.isModalShown = false;
  }



  isCollapsed = false;
  items: Item[];
  user$;
  user;
  currentRoute
  sideBarState$
  subItems$;
  subItems;
  sidebar: boolean = false;
  sidebar2:boolean=false;
  addrecipeActive: boolean = false

  modalRef: BsModalRef;
    config = {
      backdrop: true,
      ignoreBackdropClick: true
    };

  constructor(
    private masterservice: ItemmasterService,
    private route: ActivatedRoute,
    private store: Store<SideBarState>,
    private router: Router,
    private dataEntryService: DataEntryService,
    private modalService: BsModalService
  ) {

    this.sideBarState$ = this.store.select('sideBar');

    this.user$ = this.sideBarState$
      .map(state => state.user);

    this.subItems$ = this.sideBarState$
      .map(state => state.elements);

    this.items = [
      // {link: '/batches', title: 'Batches', active: true },
      { link: '/itemlist', title: 'Item', nzSelected: true },
      { link: '/recipelist', title: 'Recipe', nzSelected: this.addrecipeActive },
      { link: '/parameterlist', title: 'Parameter', nzSelected: false },
      { link: '/attributelist', title: 'Attribute', nzSelected: false },
      { link: '/taglist', title: 'Tag', nzSelected: false }
    ]
    this.subItems = [];
    router.events.pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => this.activeItemSideBar(event.url))


    router.events.subscribe((event: NavigationEnd) => {
      // console.log(event.url)

      if (event.url) {

        // if (event.url == "/addrecipe") {
        //   console.log('gghdgh');
        //   this.addrecipeActive = true;
        // }

        if (event.url == "/itemlist" || event.url == "/recipelist" ||
          event.url == "/parameterlist" || event.url == "/attributelist"
          || event.url == "/taglist" || event.url == "/addrecipe") {

          this.sidebar = true
          this.sidebar2 = false
        }

        else if ((event.url == "/Roles")||(event.url=="/Privileges") ){
          this.sidebar2=true
          this.sidebar = false
        }
        // if (event.url == "/data-entry") {

        //   this.sidebar=false
        // } 
        else {
          this.sidebar = false
          this.sidebar2=false
        }

      }

    });


  }

  activeItemSideBar = (url: string) => {
    this.items.forEach((d: Item) => d.link === url ? d.nzSelected = true : d.nzSelected = false)
    this.subItems.forEach((d: any) => url.indexOf(d.title) !== -1 ? d.nzSelected = true : d.nzSelected = false)
    this.store.dispatch({ type: sideBarStateActions.setElements, payload: this.subItems })
  }

  showBatch = (batchid: number, recipeid: number, batch: number, recipeName: string, recipeDescription: string, itemCode: string) => {

    // Set DataEntryHeader
    this.dataEntryService.setItemCode(itemCode);
    this.dataEntryService.setRecipeName(recipeName);
    this.dataEntryService.setRecipeDescription(recipeDescription);

    // Clean params & errors
    this.cleanParameter();

    // Get Data
    this.dataEntryService.getBatch({ batchid: batchid, recipeid: recipeid })
      .subscribe(resp => {
        this.dataEntryService.setBatch(resp);
      })
    this.router.navigate(['/data-entry'], { queryParams: { batchid: batchid, recipeid: recipeid, batch: batch } })
  }

  cleanParameter = () => {
    const batchinit = [{ title: '', nzSelected: false, parameters: [] }];
    this.dataEntryService.setBatch(batchinit);
    this.dataEntryService.setErrorParams([]);
  }

  ngOnInit() {
    this.getViewItemMasterDetails();
    this.user$.subscribe(user => this.user = user)
    this.subItems$.subscribe(items => this.subItems = items)
    // console.log(window.location.href)

    
  }

  logout = () => {
    this.dataEntryService.logOut();
    this.router.navigate(['/'])
  }


  test() {
    console.log(this.user)
  }

  itemtypeData=[];
  getViewItemMasterDetails() {
    this.masterservice.getViewItemDetail().
      subscribe(data => {
        //  console.log('data', data);
        // this.itemstatusData = data.item_status;
         this.itemtypeData = data.item_type;
         console.log(this.itemtypeData[0].displayvalue)
      })
  }

  dropdownlist:boolean=false;
  showitemtype()
  {
this.dropdownlist=true;
  }

  hideitemtype()
  {
    this.dropdownlist=false;
  }

  sidebarvalue(value:any)
  {
console.log(value)
  }
  
}
