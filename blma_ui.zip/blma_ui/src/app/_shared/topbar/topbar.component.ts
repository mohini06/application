import { Component, OnInit } from '@angular/core';
import {Router } from "@angular/router";

@Component({
  selector: 'top-bar',
  templateUrl: './topbar.component.html',
  styleUrls: ['./topbar.component.scss']
})
export class TopbarComponent implements OnInit {

  constructor(
    private router: Router
  ) { }

  ngOnInit() {
  }
  
  searchMobileToggle = false;
  searchMobile(){
    this.searchMobileToggle = ! this.searchMobileToggle;
  }
  onSubmit() {
    this.router.navigate(['/miscellaneous/search']);
  }
  showPopUpLogOut(){
    alert('Salida')
  }
  collapseMenu(){
    
  }
}
