
import {filter} from 'rxjs/operators';
import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { Item } from '../../_core/interfaces/sidebar'
import { Store } from '@ngrx/store';
import { SideBarState, sideBarStateActions } from '../../_core/store/side-bar.actions';
import { DataEntryService } from '../../_core/services/data-entry.service';

import { Observable } from 'rxjs';


@Component({
  selector: 'side-bar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  // items: Item [];
  // user$;
  // user;
  // currentRoute
  // sideBarState$
  // subItems$;
  // subItems;
  // constructor(
  //   private store: Store<SideBarState>,
  //   private router: Router,
  //   private dataEntryService: DataEntryService
  // ) {
    
  //   this.sideBarState$ = this.store.select('sideBar');
    
  //   this.user$ = this.sideBarState$
  //                    .map(state => state.user);
    
  //   this.subItems$ = this.sideBarState$
  //                       .map(state => state.elements);

  //   this.items = [
  //     {link: '/batches', title: 'Batches', active: true },
  //     {link: '/itemlist', title: 'Item Master', active: false },
  //     {link: '/recipelist', title: 'Recipe Master', active: false },
  //     {link: '/parameterlist', title: 'Parameter Master', active: false },
  //     {link: '/attributelist', title: 'Attribute Master', active: false },
  //     {link: '/taglist', title: 'Tag Master', active: false }
  //   ]
  //   this.subItems = [];
  //    router.events.pipe(filter(event => event instanceof NavigationEnd))
  //                 .subscribe((event: NavigationEnd) =>  this.activeItemSideBar(event.url))
                          
  //  }
  
  // activeItemSideBar = (url: string) => { 
  //   this.items.forEach((d: Item) => d.link === url ? d.active = true : d.active = false)
  //   this.subItems.forEach((d: any) => url.indexOf(d.title) !== -1 ? d.active = true : d.active = false)
  //   this.store.dispatch({ type: sideBarStateActions.setElements, payload: this.subItems })
  //  }
  
  // showBatch = (batchid: number, recipeid: number, batch: number, recipeName: string, recipeDescription: string, itemCode: string) => {
    
  //   // Set DataEntryHeader
  //   this.dataEntryService.setItemCode(itemCode);
  //   this.dataEntryService.setRecipeName(recipeName);
  //   this.dataEntryService.setRecipeDescription(recipeDescription);
    
  //   // Clean params & errors
  //   this.cleanParameter();

  //   // Get Data
  //   this.dataEntryService.getBatch({batchid: batchid, recipeid: recipeid})
  //       .subscribe(resp => {
  //         this.dataEntryService.setBatch(resp);
  //       })
  //   this.router.navigate(['/data-entry'], { queryParams: {batchid: batchid, recipeid: recipeid, batch: batch }})
  // }

  // cleanParameter = () => {
  //   const batchinit = [{ title: '', active: false, parameters: [] }];
  //   this.dataEntryService.setBatch(batchinit);
  //   this.dataEntryService.setErrorParams([]);
  // }

  ngOnInit() {
    // this.user$.subscribe(user => this.user = user)
    // this.subItems$.subscribe(items => this.subItems = items)
  }

  // logout = () => {
  //   this.dataEntryService.logOut();
  //   this.router.navigate(['/'])
  // }


  // test()
  // {
  //   console.log(this.user)
  // }
}
