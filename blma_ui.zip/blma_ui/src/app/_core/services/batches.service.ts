import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';

import { Observable, Subject ,  BehaviorSubject } from 'rxjs';

import { Params } from '../interfaces/data-entry.interface'

import { ApiService } from './api.service';

import { DataEntryState, dataEntryStateActions } from '../../_core/store/data-entry.actions';

import { SideBarState, sideBarStateActions } from '../../_core/store/side-bar.actions'

@Injectable()

export class BatchesService{
    constructor(
        private store: Store<DataEntryState | SideBarState>,
        private api: ApiService
    ){}
    
    // API
    createBatch = (batches,type) => this.api.createBatch(batches,type) ;

    getRecipes = (param) => this.api.getRecipes(param);

    checkRecipeBatchNumber = (params: {recipeid: string, batchnumber: string,batchid:number }) => this.api.checkRecipeBatchNumber(params);

    getUserName = () => this.api.getUserName();

    editBatch = (batchid: string) => this.api.editBatch(batchid);

    updateBatch = (params: any) => this.api.updateBatch(params);

    // Store

    setSideElement = (elements: {title: string, recipeid: string, batchid: string, active: boolean, recipeName: string, recipeDescription: string, itemcode: string } []) => this.store.dispatch({ type: sideBarStateActions.setElements, payload: elements })
}