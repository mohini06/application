import { ItemmasterService } from './itemmaster.service';
import { AuthService } from './auth.service';
import { DataEntryService } from './data-entry.service';
import { Injectable, Injector } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { ApiService } from './api.service';
import { Observable } from 'rxjs';


@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  auth: AuthService;
  dataEntryService: DataEntryService;
  masterServices: ItemmasterService

  constructor(public inj: Injector) {
  }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    this.auth = this.inj.get(AuthService);
    // this.dataEntryService = this.inj.get(DataEntryService);
    // this.masterServices = this.inj.get(ItemmasterService);
    // console.log(this.auth.getToken())
    request = request.clone({
      setHeaders: {
        Authorization: `Bearer ${this.auth.getToken()}`
        // Authorization: `Bearer sdgfsdgsdgdfgdfg`
      }
    });

    return next.handle(request);
  }
}
