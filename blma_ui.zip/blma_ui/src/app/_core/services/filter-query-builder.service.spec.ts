import { TestBed } from '@angular/core/testing';

import { FilterQueryBuilderService } from './filter-query-builder.service';

describe('FilterQueryBuilderService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FilterQueryBuilderService = TestBed.get(FilterQueryBuilderService);
    expect(service).toBeTruthy();
  });
});
