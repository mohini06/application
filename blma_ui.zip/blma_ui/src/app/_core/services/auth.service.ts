import { Router } from '@angular/router';
import { LoginService } from './login.service';


import { environment } from './../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { setToken } from './../store/data-entry.actions';

import { map } from 'rxjs/operators';
import { ApiService } from './api.service';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

import { sideBarStateActions, SideBarState } from '../store/side-bar.actions';
import { dataEntryStateActions, DataEntryState } from '../store/data-entry.actions';

import { Store, Action } from '@ngrx/store';

import * as jwt_decode from "jwt-decode";

export interface ActionWithPayloadInterface extends Action {
  payload: any;
}

@Injectable()
export class AuthService {
  apiUrl = environment.apiUrl;
  userId: number;
  user: { userName: string, email: string }
  dataEntryState$;
  token$
  token: string;
  personId:number;

  constructor(
    private api: ApiService,private loginService:LoginService,
    private store: Store<SideBarState | DataEntryState>, private http: HttpClient,private router: Router,
  ) {
    this.dataEntryState$ = this.store.select('dataEntry');
    this.token$ = this.dataEntryState$
      .map(state => state.token);
  }



  checkRoles = (roles: string[]): boolean => roles.findIndex(d => d !== 'VIEWER') !== -1

  // Store

  setUser = (user: any) => this.store.dispatch({ type: sideBarStateActions.setUser, payload: user })
  setToken = (token: any) => this.store.dispatch({ type: dataEntryStateActions.setToken, payload: token })

  setRole = (role: string[]) => this.store.dispatch({ type: dataEntryStateActions.setCurrentRole, payload: role })

  setAllowedRole = (allowed: boolean) => this.store.dispatch({ type: dataEntryStateActions.setAllowedRole, payload: allowed })

  setUserSig = (username: string) => this.store.dispatch({ type: dataEntryStateActions.setUserSig, payload: username })

  // Api

  getToken() {
    this.token$.subscribe(token => this.token = token);
    //  console.log(this.token)
    // sessionStorage.setItem("token",this.token)
    return this.token;

  }

  getUser() {
    return this.user;
  }

 
  register(email: string, password: string, name: string, surname: string, userName: string): Observable<boolean> {
    return this.api.register(email, password, name, surname, userName);
  }

 

  // login(username: string, password: string) {
  //   return this.http.post<any>(this.apiUrl + '/login/validateuser', { username: username, password: password })
  //     .pipe(map(resp => {
  //       console.log(jwt_decode(resp))
  //       let data = jwt_decode(resp)
  //       this.token = resp;
  //       // this.userId = data.;
  //       this.setToken(resp)
  //       this.setUser(data.user);
  //       this.setRole(resp.roles)
  //       this.setAllowedRole(this.checkRoles(resp.roles || []));

  //       // if (this.checkRoles(resp.roles)) this.setUserSig(resp.user.userName);      
  //       return this.token
  //     }));
  // }


  login(username: string, password: string): Observable<boolean> {
    // console.log('auth api service', this.api);
    return this.loginService.login(username, password).pipe(
      map((resp) => {
        // console.log(jwt_decode(resp))
        let data=jwt_decode(resp)
        console.log(data.user.personid);
        this.personId=data.user.personid;
        this.token = resp;
        // sessionStorage.setItem("token",resp)
        // this.userId = data.;
        this.setToken(resp)
        this.setUser(data.user);
        this.setRole(resp.roles)
        this.setAllowedRole(this.checkRoles(resp.roles || []));  

        // if (this.checkRoles(resp.roles)) this.setUserSig(resp.user.userName);      
        return this.token !== undefined;
      }));

  }


  
  getPersonId()
  {
   return this.personId;
  }

  validateUser(username: string, password: string): Observable<boolean> {
    return this.api.validateUser(username, password);
  }

  logout(): Observable<boolean> {
    return Observable.create(observer => {
      this.token = undefined;
      this.userId = undefined;
      observer.next(true);
      observer.complete();
    });
  }

  upload(file: File, filename: string) {
    return this.api.upload(this.userId, filename, file);
  }



  _userActionOccured: Subject<void> = new Subject();
  get userActionOccured(): Observable<void> { return this._userActionOccured.asObservable() };

  notifyUserAction() {
    this._userActionOccured.next();
  }

  loginUser() {
    console.log('user login');
  }

  logOutUser() {
    // console.log('user logout');
    this.router.navigate(['/login'])

  }


  validateEsig(username: string, password: string) {
    return this.http.post<any>(this.apiUrl+'/login/validateuser', { username: username, password: password })
        .pipe(map(user => {
        
            return user;
        }));
}

}
