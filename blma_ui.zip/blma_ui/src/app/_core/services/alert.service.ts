import { Injectable } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import { Observable, Subject } from 'rxjs';

@Injectable()
export class AlertService {
    private subject = new Subject<any>();
    private keepAfterNavigationChange = false;

    private subjectChild = new Subject<any>();
    private keepAfterNavigationChangeChild = false;

    constructor(private router: Router) {
        // clear alert message on route change
        router.events.subscribe(event => {
            if (event instanceof NavigationStart) {
                if (this.keepAfterNavigationChange) {
                    // only keep for a single location change
                    this.keepAfterNavigationChange = false;
                } else {
                    // clear alert
                    this.subject.next();
                }
            }
        });


        router.events.subscribe(event => {
            if (event instanceof NavigationStart) {
                if (this.keepAfterNavigationChangeChild) {
                    // only keep for a single location change
                    this.keepAfterNavigationChangeChild = false;
                } else {
                    // clear alert
                    this.subjectChild.next();
                }
            }
        });

    }



    removeAlert() {
        this.subject.next();

    }

    success(message: string, keepAfterNavigationChange = false) {
        this.keepAfterNavigationChange = keepAfterNavigationChange;
        this.subject.next({ type: 'success', text: message });
    }

    error(message: string, keepAfterNavigationChange = false) {
        this.keepAfterNavigationChange = keepAfterNavigationChange;
        this.subject.next({ type: 'error', text: message });
    }

    getMessage(): Observable<any> {
        return this.subject.asObservable();
    }

//////////Child Component

    removeAlertChild() {
        this.subjectChild.next();

    }

    successChild(message: string, keepAfterNavigationChangeChild = false) {
        this.keepAfterNavigationChange = keepAfterNavigationChangeChild;
        this.subjectChild.next({ typeChild: 'success', textChild: message });
    }

    errorChild(message: string, keepAfterNavigationChangeChild = false) {
        this.keepAfterNavigationChange = keepAfterNavigationChangeChild;
        this.subjectChild.next({ typeChild: 'error', textChild: message });
    }

    getMessageChild(): Observable<any> {
        return this.subjectChild.asObservable();
    }



}