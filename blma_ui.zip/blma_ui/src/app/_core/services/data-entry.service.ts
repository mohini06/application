
import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable, Subject, BehaviorSubject } from 'rxjs';

import { Params } from '../interfaces/data-entry.interface'

import { ApiService } from './api.service';

import { DataEntryState, dataEntryStateActions } from '../../_core/store/data-entry.actions';

@Injectable()

export class DataEntryService {

  constructor(
    private store: Store<DataEntryState>,
    private api: ApiService) { }

  // Store

  setTopFormInfo = (topFormInfo: number) => this.store.dispatch({ type: dataEntryStateActions.setTopFormInfo, payload: topFormInfo });

  setParamsSelect = (name: string, params: any, clean: boolean = false) => {
    this.store.dispatch({ type: dataEntryStateActions.setParamsSelect, payload: clean ? params : params.findIndex(d => d.title === name) })
  };

  setBatchData = (name: string, params: any, clean: boolean = false) => this.store.dispatch({ type: dataEntryStateActions.setBatchData, payload: clean ? params : params.findIndex(d => d.parameter.uniquename === name) });

  setBatch = (batch) => this.store.dispatch({ type: dataEntryStateActions.setBatch, payload: batch });

  setBatches = (batches) => this.store.dispatch({ type: dataEntryStateActions.setBatches, payload: batches });

  setRecipeName = (recipeName: string) => this.store.dispatch({ type: dataEntryStateActions.setRecipeName, payload: recipeName });

  setRecipeDescription = (recipeDescription: string) => this.store.dispatch({ type: dataEntryStateActions.setRecipeDescription, payload: recipeDescription });

  setItemCode = (itemCode: string) => this.store.dispatch({ type: dataEntryStateActions.setItemCode, payload: itemCode });

  setErrorParams = (error: any[]) => this.store.dispatch({ type: dataEntryStateActions.setErrorParams, payload: error })

  setParameterIdSelected = (id: number) => this.store.dispatch({ type: dataEntryStateActions.setParameterIdSelected, payload: id })

  setFilters = (filters: string[]) => this.store.dispatch({ type: dataEntryStateActions.setFilters, payload: filters });

  setNewBatchesData = (newBatchesData: any) => this.store.dispatch({ type: dataEntryStateActions.setNewBatchesData, payload: newBatchesData })

  setUpdateBatchesData = (updateBatchesData: any) => this.store.dispatch({ type: dataEntryStateActions.setUpdateBatchesData, payload: updateBatchesData });

  setCurrentStatus = (currentStatus: any) => this.store.dispatch({ type: dataEntryStateActions.setCurrentStatus, payload: currentStatus });

  setCurrentStatusDrop = (currentStatusDropDown: any) => this.store.dispatch({ type: dataEntryStateActions.setCurrentStatusDropDown, payload: currentStatusDropDown });

  setBatchNumber = (batchNumber: any) => this.store.dispatch({ type: dataEntryStateActions.setCurrentStatus, payload: batchNumber });
  setParameterDetails = (parameter: any) => this.store.dispatch({ type: dataEntryStateActions.setParameters, payload: parameter });
  setFilterParams(parameter: any) {
    // e.preventDefault();
    // e.stopPropagation();
    // e.stopImmediatePropagation();
   // parameter.callback(parameter);
      // setTimeout(() => {
    this.store.dispatch({ type: dataEntryStateActions.setFiltersParam, payload: parameter });
      // }, 5000)
    // return false;
  }

  // this.store.select(this.selector.getCountry())
  // .take(1)
  // .subscribe(country => {
  //     this.store.dispatch(this.action.login({
  //         loginData,
  //         country 
  //     }));
  // });


  setAllParams(parameters: any) {
    
      this.store.dispatch({ type: dataEntryStateActions.setAllParam, payload: parameters })
   
  };

  setGraph(data: any) {
    
    this.store.dispatch({ type: dataEntryStateActions.setGraph ,payload: data })

};

  setAllComment(parameters: any) {

    this.store.dispatch({ type: dataEntryStateActions.setAllcomment, payload: parameters })
  };

  setTableData(data: any) {
      //  setTimeout(() => {
    this.store.dispatch( { type: dataEntryStateActions.setTableData, payload: data })
    //  }, 50000)
  };

  setNewTableData(data: any) {

    this.store.dispatch({ type: dataEntryStateActions.setNewTableData, payload: data })
  };


  setSelectedParamIndex(data: any) {
   
      this.store.dispatch({ type: dataEntryStateActions.setSelectedParamIndex, payload: data })
    
   
   
  };

  setSelectedCommIndex(data: any) {
  
    this.store.dispatch({ type: dataEntryStateActions.setSelectedCommIndex, payload: data })
 
  };
  //API

  getAnalysisView = (params: any) => this.api.getAnalysisView(params);

  getAuditView = (pageno, batchdataid, table) => this.api.getAuditView(pageno, batchdataid, table);

  getRecipeSection = (params: any) => this.api.getRecipeSection(params);
  //params

  logOut = () => this.api.logout();

  getUserName = () => this.api.getUserName();

  getBatches = (page: number, filters: any) => this.api.getBatches(page, filters);

  getBatch = (params: { batchid: number, recipeid: number }) => this.api.getBatch(params);

  postBatch = (params) => this.api.postBatch(params);

  postComment = (params: { text: string, username: string, parameterid: number, batchid: number }) => this.api.postComment(params);

  updateBatch = (params: any) => this.api.updateBatch(params);

  checkUpdateStatus = (params: any) => this.api.checkUpdateStatus(params);

  allowedRole = (params: any) => this.api.allowedRole(params);

  postEsig = (params) => this.api.postEsig(params);

  // AllowedRole

  changeEsig = (batch: any, uniquename: string, esig): [any[], number] => {
    let index;
    batch.forEach(d => d.parameters.forEach((r, j) => {
      if (r.parameter.uniquename === uniquename) {
        r.batch_data[0].esig = esig;
        index = r.batch_data[0].batchdataid;
      }
    }
    ))
    return [batch, index];
  }

  setEsig = (username: string, roles: string[]) => {
    const signature = 'Electronic Signature - Verified by ' + username + ', role: SUPERVISOR' + ' on ' + new Date();
    return signature;
  }

  //Filter

  setFilterBatch = (filters: string[], batch: any): any => {
    let batchFiltered = batch.map(d => Object.assign({}, d));
    filters.map((filter: string) => {
      switch (filter) {
        case 'comment':
          batchFiltered.forEach(recipeSection => recipeSection.parameters = recipeSection.parameters.filter(parameter => parameter.comments.length > 0))
          break;
        case 'flag':
          batchFiltered.forEach(recipeSection => recipeSection.parameters = recipeSection.parameters.filter(parameter => parameter.batch_data.slice(-1).pop().isflag !== null))
          break;
        case 'lock':
          batchFiltered.forEach(recipeSection => recipeSection.parameters = recipeSection.parameters.filter(parameter => parameter.batch_data.slice(-1).pop().esig !== null));
          break;
      }
      if (filter !== 'comment' && filter !== 'flag' && filter !== 'lock') {
        const filterUperCase = filter.toUpperCase();
        batchFiltered.forEach(recipeSection => recipeSection.parameters = recipeSection.parameters.filter(parameter => parameter.parameter.label.toUpperCase().indexOf(filterUperCase) !== -1));
      }
    })
    return batchFiltered;
  }

selecttabid:number;
selecttab(tab)
{
this.selecttabid=tab;
}

}

