import { Injectable } from '@angular/core';
import { environment } from './../../../environments/environment';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AnalyticsService {

  apiUrl = environment.apiUrl;
  constructor(private http: HttpClient) { }


  //spc/hisogram
  getspcSingleAnalyticplot(parameter: string) {
    return this.http.post<any>(this.apiUrl + '/generic/view',
      {
        "p_listname": 'chart_spchisto',
        //  "p_where":'parameterid= 459'
        "p_where": 'parameterid= ' + parameter + ''

      })
  }

  getspcAllAnalyticplot(parameter: string) {
    return this.http.post<any>(this.apiUrl + '/generic/view',
      {
        "p_listname": 'chart_spchisto',
        "p_where": 'parameterid= 459'

      })
  }






  //Box plot]
  getspecificAnalyticplot(Recipesectionid: string, parameter: string) {

    return this.http.post<any>(this.apiUrl + '/generic/view',
      {
        "p_listname": 'chart_boxplot',
        "p_where": "" + Recipesectionid + "," + parameter + ""

      })
  }


  //Box plot All parameters
  getAllAnalyticplot(Recipesectionid: string) {

    return this.http.post<any>(this.apiUrl + '/generic/view',
      {
        "p_listname": "chart_boxplot",
        "p_where": "" + Recipesectionid + "",

      })
  }


  getRangeAnalyticplot() {

    return this.http.post<any>(this.apiUrl + '/generic/view',
      {
        "p_listname": "chart_spchisto",
        "p_where": "parameterid between 459 and 700"

      })
  }


  getNodeAnalyticplot() {

    return this.http.post<any>(this.apiUrl + '/generic/view',
      {
        // "p_listname":"analytics_tree"
        "p_listname": 'an_nodedata', "p_json": '{"nodetype":"main"}'

      })
  }



  recipesecctionid: number;
  recipejsondata: String;
  getrecipetab(recipesection: string) {

    this.recipejsondata = '{"nodetype":"recipesection","nodekey":"' + recipesection + '"}';

    return this.http.post<any>(this.apiUrl + '/generic/view', {
      "p_listname": "an_nodedata", "p_json": this.recipejsondata,

    });

    //  return this.http.post<any>(this.apiUrl + '/generic/view', { 
    //   "p_listname":"an_nodedata","p_json":'{"nodetype":"recipesection","nodekey":"269"}'

    // });
  }



  parameterjsondata: String;
  parameterid: String;
  getparametertab(parameterid: string) {

    this.parameterjsondata = '{"nodetype":"parameter","nodekey":"' + parameterid + '"}';

    return this.http.post<any>(this.apiUrl + '/generic/view', {
      "p_listname": "an_nodedata", "p_json": this.parameterjsondata

    });
  }


}
