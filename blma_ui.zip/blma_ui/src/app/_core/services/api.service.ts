import { PreferenceService } from './preference.service';

import { from as observableFrom, of as observableOf, Observable } from 'rxjs';

import { catchError, switchAll, map } from 'rxjs/operators';
import { paramsData } from './../../data-entry/data.service';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { Store } from '@ngrx/store';
import { SideBarState } from './../store/side-bar.actions';

@Injectable()
export class ApiService {
  apiUrl = environment.apiUrl;
  urls: { [endpoint: string]: string };
  token: string;
  refreshToken: string;
  userName: string = ''
  sideBarState$
  user$;

  constructor(private http: HttpClient, private preference: PreferenceService, private store: Store<SideBarState>) {
    // this.userName = 'john';
    this.urls = {
      'register': this.apiUrl + '/users',
      'login': this.apiUrl + '/login/validateuser',
      'upload': this.apiUrl + '/images',
      'batches': this.apiUrl + '/batches/batches',
      'batch': this.apiUrl + '/batch',
      'dataentry': this.apiUrl + '/dataentry/batch',
      'parameter': this.apiUrl + '/dataentry/parameter',
      'editbatchdatacomment': this.apiUrl + '/comment/create',
      'postbatch': this.apiUrl + '/dataentry/save',
      'audit': this.apiUrl + '/audit/view',
      'analysis': this.apiUrl + '/dataentry/analysis'
    };
    this.sideBarState$ = this.store.select('sideBar');
    this.user$ = this.sideBarState$
    .map(state => state.user);
  // this.username = this.batchesService.getUserName();

  this.user$.subscribe(user => this.userName = user.username)
  }

  // Users
  getToken() {
    return this.token;
  }

  getUserName() {
    return this.userName;
  }

  // Recipe
  getRecipes(batchid: any): Observable<any> {
    let params = new HttpParams().set('username', this.userName);
    params = params.set('batchid', batchid);
    return this.http.get(this.urls['batch'] + '/recipes', { params: params, observe: 'response' }).pipe(
      map((resp: HttpResponse<any>) => {
        return resp.body
        // return {recipes: resp.body.recipes, templates: resp.body.templates, users: resp.body.users, itemcodes: resp.body.items, batchType: resp.body.batch_type }
      }), catchError((err: any) => observableOf({ recipes: undefined })));
  }
  //Batch

  checkRecipeBatchNumber(params: { recipeid: string, batchnumber: string, batchid: number }): Observable<any> {
    let body = new HttpParams().set('username', this.userName);
    Object.keys(params).forEach(key => body = body.append(key, params[key]));
    return this.http.get(this.urls['batch'] + '/check', { params: body, responseType: "text" })
      .pipe(map(resp => {
        return resp;
      }));
  }

  createBatch(params, type): Observable<any> {
    // console.log(params)
    let paramdata = params.params;
    for (let i = 0; i < paramdata.length; i++) {
      paramdata[i].currentstatus = type
      // delete paramdata[i].id;
      // delete paramdata[i].checked;
      if (paramdata[i].planstartdate) {
        let planenddate = this.preference.setDateFormate(paramdata[i].planstartdate[1])
        paramdata[i].planstartdate = this.preference.setDateFormate(paramdata[i].planstartdate[0])
        paramdata[i].planenddate = planenddate

      }
      if (paramdata[i].batchstartdate) {
        let batchenddate = this.preference.setDateFormate(paramdata[i].batchstartdate[1])
        paramdata[i].batchstartdate = this.preference.setDateFormate(paramdata[i].batchstartdate[0])
        paramdata[i].batchenddate = batchenddate
      }


    }
    const body = { 'username': this.userName, 'batches': paramdata };
console.log(body.batches[0])
    return this.http.post<any>(this.urls['batch'] + '/create', body, { observe: 'response' })
      .pipe(map(resp => {
        return resp;
      }));
  }

  updateBatch(params): Observable<any> {
    const body = { 'username': this.userName, 'batch': params, batchid: params.batchid };
    console.log(body)
    return this.http.post(this.urls['batch'] + '/update', body, { observe: 'response' }).pipe(
      map((resp: HttpResponse<any>) => {
        return resp.body.response;
      }),
      catchError((err: any) => observableOf(false)));
  }
//Update batch  New function
  putBatch(params, type) {

    let paramdata = params.params;
    for (let i = 0; i < paramdata.length; i++) {
      paramdata[i].currentstatus = type
      // delete paramdata[i].id;
      // delete paramdata[i].checked;
      if (paramdata[i].planstartdate) {
        let planenddate = this.preference.setDateFormate(paramdata[i].planstartdate[1])
        paramdata[i].planstartdate = this.preference.setDateFormate(paramdata[i].planstartdate[0])
        paramdata[i].planenddate = planenddate

      }
      if (paramdata[i].batchstartdate) {
        let batchenddate = this.preference.setDateFormate(paramdata[i].batchstartdate[1])
        paramdata[i].batchstartdate = this.preference.setDateFormate(paramdata[i].batchstartdate[0])
        paramdata[i].batchenddate = batchenddate
      }


    }

    const body = { 'username': this.userName, 'batch': paramdata,batchid: paramdata[0].batchid };
    
    return this.http.post<any>(this.urls['batch'] + '/update', body)
      .pipe(map(data => {
        return data;
      }));
  }

  checkUpdateStatus(params): Observable<any> {
    let body = new HttpParams().set('username', this.userName);
    Object.keys(params).forEach(key => body = body.append(key, params[key]));
    return this.http.get(this.urls['batch'] + '/check/status', { params: body, observe: 'response' }).pipe(
      map((resp: HttpResponse<any>) => {
        return resp.body;
      }), catchError((err: any) => observableOf({ response: undefined })));
  }

  editBatch(batchid: string): Observable<any> {
    let params = new HttpParams().set('username', this.userName)
    params = params.append('batchid', batchid)
    return this.http.get(this.urls['batch'] + '/edit', { params: params, observe: 'response' }).pipe(
      map((resp: HttpResponse<any>) => {
        return resp.body.batch
      }), catchError((err: any) => observableOf({ batch: undefined })));
  }

  //Data Entry

  postEsig(params): Observable<any> {
    let body = new HttpParams().set('username', this.userName);
    Object.keys(params).forEach(key => body = body.append(key, params[key]));
    return this.http.post(this.urls['batches'] + '/' + params.batchid + '/esig' + '/' + params.batchdataid, body, { observe: 'response' }).pipe(
      map((resp: HttpResponse<any>) => {
        const status = resp.body.response;
        if (status) return { status: true };
        return { status: false, errors: resp.body.error }
      }),
      catchError((err: any) => observableOf(false)));
  }

  getRecipeSection(params: any): Observable<any> {
    let body = new HttpParams();

    Object.keys(params).forEach(key => body = body.append(key, params[key]))
    return this.http.get<any>(this.urls['parameter'], { params: body, observe: 'response' }).pipe(
      map((resp: HttpResponse<any>) => {
        if (!resp.body)
          return false
        return resp.body
      }), catchError((err: any) => observableOf({ parameters: undefined })));
  }

  // getRecipeSection(): Observable<any> {


  //   return this.http.get("./data-entry/data.service.ts" )
  //   .map((resp: HttpResponse<any>) => {
  //     console.log(resp)

  //         return resp.body.parameters
  //     }).catch((err: any) => Observable.of({parameters: undefined }));
  // }



  getAnalysisView(batchdataid: any) {
    let params = new HttpParams()
      .set('objrecid', batchdataid)
    return this.http.get<any>(this.urls['analysis'], { params: params })
      .pipe(map(data => {
        return data;
      }));
  }


  getAuditView(page, batchdataid, table) {
    let params = new HttpParams().set('tablename', table)
      .set('objrecid', batchdataid)
      .set('pageno', page)


    return this.http.get<any>(this.urls['audit'], { params: params })
      .pipe(map(data => {
        return data;
      }));

  }

  postComment(body): Observable<any> {
    return this.http.post(this.urls['batches'] + '/' + body.parameterid + '/comment/create', body, { observe: 'response' }).pipe(
      map((resp: HttpResponse<any>) => {
        const status = resp.body.response;
        if (status) return { status: true };
        return { status: false, errors: resp.body.error }
      }),
      catchError((err: any) => observableOf(false)));
  }

  postBatch(data: any) {
    return this.http.post<any>(this.urls['postbatch'], data)
      .pipe(map(data => {
        return data;
      }));
  }


  getBatches(page, filters): Observable<any> {
    let params = new HttpParams().set('username', this.userName)
      .set('per', '20')
      .set('page', page)
      .set('filter', JSON.stringify(filters));

    return this.http.get(this.urls['batches'], { params: params, observe: 'response' }).pipe(
      map((resp: HttpResponse<any>) => {
        return resp.body
      }), catchError((err: any) => observableOf({ batches: undefined })));
  }

  getBatch(params: { batchid: number, recipeid: number }) {
    let body = new HttpParams()
    Object.keys(params).forEach(key => body = body.append(key, params[key]));
    return this.http.get<any>(this.urls['dataentry'], { params: body, observe: 'response' }).pipe(map((resp: HttpResponse<any>) => {
      return resp.body
    }), catchError((err: any) => observableOf({ batch: undefined })))
  }

  // getBatch(params: { batchid: number, recipeid: number }){
  //   let body = new HttpParams()
  //   Object.keys(params).forEach( key => body = body.append(key, params[key]) );
  //   return this.http.get('assets/parameter.json').map((resp: HttpResponse<any>) => {
  //       return resp.body
  //   }).catch((err: any) => Observable.of({ batch: undefined }))
  // }
  //Sesions

  register(email: string, password: string, name: string, surname: string, userName: string): Observable<boolean> {
    const body = {
      firstname: name,
      lastname: surname,
      email,
      password,
      password_confirmation: password,
      username: userName
    };
    return this.http.post(this.urls['register'], body, { observe: 'response' }).pipe(
      map((resp: HttpResponse<any>) => resp.ok),
      catchError((err: any) => observableOf(false)));
  }

  login(username: string, password: string) {

    return this.http.post(this.urls['login'], { username: username, password: password }, { observe: 'response' }).pipe(
      map((resp: HttpResponse<any>) => {
        //  console.log(resp.body.token)
        if (resp.ok) {

         return resp.body.token

        }
      
      }),
      catchError((err: any) => observableOf({ token: undefined, userId: undefined, user: undefined })));
  }

  validateUser(userName: string, password: string): Observable<boolean> {
    // let body = new HttpParams();
    // body = body.set('username', userName);
    // body = body.set('password', password);
    return this.http.post(this.urls['login'],
      {
        "username": userName,
        "password": password
      }, { observe: 'response' })
      .map((resp: HttpResponse<any>) => {
        return resp.body
      })
  }

  logout(): Observable<boolean> {
    return Observable.create(observer => {
      this.token = undefined;
      observer.next(true);
      observer.complete();
    });
  }

  allowedRole = (params: { validateuser: string, password: string }): Observable<any> => {
    let body = new HttpParams();
    Object.keys(params).forEach(key => body = body.append(key, params[key]));
    return this.http.get(this.urls['batches'] + '/checkAllowed/' + params.validateuser, { params: body, observe: 'response' }).pipe(
      map((resp: HttpResponse<any>) => {
        return resp.body
      }), catchError((err: any) => observableOf({ allowed: undefined })))
  }

  upload(userId: number, name: string, picture: File) {
    function getBase64(file) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
      });
    }

    return observableFrom(getBase64(picture)).pipe(
      map(data => {
        // return this.htt
        const body = {
          image: data,
          image_name: name,
          image_content_type: 'png'
        };

        return this.http.post(`${this.apiUrl}/user/${userId}/images`, body, { observe: 'response' }).pipe(
          map((resp: HttpResponse<any>) => resp.ok),
          catchError((err: any) => observableOf(false)));
      }), switchAll());

    // const formData: FormData = new FormData();
    // formData.append('image', picture, name);
    // const headers = new HttpHeaders().append('Content-Type', 'multipart/form-data');
  }

  getAll(userId: number) {
    return this.http.get(`${this.apiUrl}/users/${userId}/images`);
  }


  editCommentBatchData(batchid: any, batchdataid: any, commentid: any, comment: any) {

    return this.http.post<any>(this.urls['editbatchdatacomment'], { 'id': batchid, 'objrecid': batchdataid, 'commentid': commentid, 'comment': comment, 'username': this.userName, 'context': 'doc', 'objname': 'batchdata' })
      // return this.http.post<any>(this.apiUrl+'dataentry/comment/create?batchid=123&batchdataid=11&context=dataentry&username='+this.userName+'&commentid='+commentid+'&comment='+comment,{})
      .pipe(map(data => {

        return data;
      }));
  }



saveBatch(params, type): Observable<any>
{
  let paramdata = params.params;
  for (let i = 0; i < paramdata.length; i++) {
    paramdata[i].currentstatus = type
    
    if (paramdata[i].planstartdate) {
      let planenddate = this.preference.setDateFormate(paramdata[i].planstartdate[1])
      paramdata[i].planstartdate = this.preference.setDateFormate(paramdata[i].planstartdate[0])
      paramdata[i].planenddate = planenddate
    }
    if (paramdata[i].batchstartdate) {
      let batchenddate = this.preference.setDateFormate(paramdata[i].batchstartdate[1])
      paramdata[i].batchstartdate = this.preference.setDateFormate(paramdata[i].batchstartdate[0])
      paramdata[i].batchenddate = batchenddate
    }
  }
  const body = { 'username': this.userName, 'batches': paramdata };


  return this.http.post<any>(this.apiUrl + '/generic/save', 
  {
    "batch":[{
"recipeid":body.batches[0].recipeid,
"batch":body.batches[0].batch,
"templatetagid":body.batches[0].templatetagid,
"bpdversionno":body.batches[0].bpdversionno,
"batchtype":body.batches[0].batchtype,
"batchstartdate":body.batches[0].batchstartdate,
"batchenddate":body.batches[0].batchenddate,
"planstartdate":body.batches[0].planstartdate,
"planenddate":body.batches[0].planenddate,
// "setBatchenddate":body.batches[0].recipeid,
// "percentcomplete":body.batches[0].recipeid,
"assignedto":body.batches[0].assignedto,
"parentbatch":body.batches[0].parentbatch,
"currentstatus":body.batches[0].currentstatus,
"deletionflag":false,
"objname":"batch"

    }]
  }, 
  { 
    observe: 'response'
   })
    .pipe(map(resp => {
      return resp;
    }));

}

CreateBatchData(batchid:any)
{
  return this.http.post<any>(this.apiUrl + '/generic/save',
  {
    "createbatchdata": [
      {
          "batchid": batchid
      }
  ]    
    
  })
}



UpdateBatches(params, type) {
  let paramdata = params.params;
  for (let i = 0; i < paramdata.length; i++) {
    paramdata[i].currentstatus = type
    // delete paramdata[i].id;
    // delete paramdata[i].checked;
    if (paramdata[i].planstartdate) {
      let planenddate = this.preference.setDateFormate(paramdata[i].planstartdate[1])
      paramdata[i].planstartdate = this.preference.setDateFormate(paramdata[i].planstartdate[0])
      paramdata[i].planenddate = planenddate

    }
    if (paramdata[i].batchstartdate) {
      let batchenddate = this.preference.setDateFormate(paramdata[i].batchstartdate[1])
      paramdata[i].batchstartdate = this.preference.setDateFormate(paramdata[i].batchstartdate[0])
      paramdata[i].batchenddate = batchenddate
    }


  }
    const body = { 'username': this.userName, 'batch': paramdata,batchid: paramdata[0].batchid };
  console.log(body)
  if(body.batch[0].batchstartdate=="")
  {
    body.batch[0].batchstartdate=null;
  }
  return this.http.post<any>(this.apiUrl + '/generic/save',
  
  {
    "batch":[ 
    {
    "batchid":body.batch[0].batchid,
    "recipeid":body.batch[0].recipeid,
    "batch":body.batch[0].batch,
    "templatetagid":body.batch[0].templatetagid,
    "bpdversionno":body.batch[0].bpdversionno,
    "batchtype":body.batch[0].batchtype,


    "batchstartdate":body.batch[0].batchstartdate === "" ? null:body.batch[0].batchstartdate ,
    "batchenddate":body.batch[0].batchenddate === "" ? null:body.batch[0].batchenddate,
    "planstartdate":body.batch[0].planstartdate === "" ? null:body.batch[0].planstartdate,
    "planenddate":body.batch[0].planenddate === "" ? null:body.batch[0].planstartdate,
    // "setBatchenddate":body.batches[0].recipeid,
    // "percentcomplete":body.batches[0].recipeid,
    "assignedto":body.batch[0].assignedto,
    "parentbatch":body.batch[0].parentbatch,
    "currentstatus":body.batch[0].currentstatus,
    "deletionflag":false,
     "objname":"batch"
    }]
      }
  )
  .pipe(map(data => {
    return data;
  }));

}




  


}
