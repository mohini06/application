import { ApiService } from './api.service';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { environment } from './../../../environments/environment';
@Injectable()
export class ItemRecipeService {

    apiUrl = environment.apiUrl;


    constructor(private http: HttpClient, private api: ApiService) { }



    getRecipeItemList() {
        return this.http.post<any>(this.apiUrl + '/recipe/recipes', {
            "draw": 3,
            "columns": [
                {
                    "data": "recipename",
                    "name": "",
                    "searchable": true,
                    "orderable": true,
                    "search": {
                        "value": "",
                        "regex": false
                    }
                },
                {
                    "data": "batchgroup",
                    "name": "",
                    "searchable": true,
                    "orderable": true,
                    "search": {
                        "value": "",
                        "regex": false
                    }
                },
                {
                    "data": "processstage",
                    "name": "",
                    "searchable": true,
                    "orderable": true,
                    "search": {
                        "value": "",
                        "regex": false
                    }
                }
            ],
            "order": [
                {
                    "column": 0,
                    "dir": "asc"
                }
            ],
            "start": 0,
            "length": 10,
            "search": {
                "value": "",
                "regex": false
            }
        })
        // .pipe(map(data => {
        //   return data;
        // }));
    }
}
