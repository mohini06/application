import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpBackend , HttpResponse } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { map, catchError } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { from as observableFrom, of as observableOf } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  apiUrl = environment.apiUrl;
  Rolesdata:any;
  private httpClient: HttpClient;
  constructor(private http: HttpClient,handler: HttpBackend) { 
    this.httpClient = new HttpClient(handler);
  }

  username:string;
  password:string;
  login(username: string, password: string) {
this.username=username;
this.password=password;
    return this.httpClient.post(this.apiUrl+'/login/validateuser', { username: username, password: password }, { observe: 'response' }).pipe(
      map((resp: HttpResponse<any>) => {
        //  console.log(resp.body.token)
        if (resp.ok) {

         return resp.body.token

        }
      
      }),
      catchError((err: any) => observableOf({ token: undefined, userId: undefined, user: undefined })));
  }

  roles()
  {
    return this.httpClient.post(this.apiUrl+'/generic/getroleaccess', { "sql":"select core.rbac_checkaccess('{\"parentobjname\" : \"all\"}')"}, { observe: 'response' }).pipe(
      map((resp: HttpResponse<any>) => {
        //  console.log(resp.body.token)
        this.Rolesdata=resp.body;
        return resp;
      
      }))
  }
  
}
