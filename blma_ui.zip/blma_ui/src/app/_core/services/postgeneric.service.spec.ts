import { TestBed } from '@angular/core/testing';

import { PostgenericService } from './postgeneric.service';

describe('PostgenericService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PostgenericService = TestBed.get(PostgenericService);
    expect(service).toBeTruthy();
  });
});
