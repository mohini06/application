import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class DataService {

  private selectedParamSource = new BehaviorSubject<any>('');
  currentParam = this.selectedParamSource.asObservable();

  private commentClicked = new BehaviorSubject<boolean>(true);
  comment = this.commentClicked.asObservable();
  
  private itemIdClick = new BehaviorSubject<boolean>(true);
  itemid = this.itemIdClick.asObservable();

  private pushFlagComment = new BehaviorSubject<boolean>(true);
  commentFlag = this.pushFlagComment.asObservable();

  private perCent = new BehaviorSubject<boolean>(true);
  percentCalc = this.perCent.asObservable();

  private recipeSec = new BehaviorSubject<boolean>(true);
  recepiSetionId = this.recipeSec.asObservable();

  private graph = new BehaviorSubject<boolean>(true);
  graphData = this.graph.asObservable();

  constructor() { }

  changeParam(message: any) {
    this.selectedParamSource.next({message:message.message,table:message.table,parameterid:message.parameterplotid})
  }


  toggleComment(message:boolean) {
    this.commentClicked.next(message)
  }

  getItemId(itemid:any) {
    this.itemIdClick.next(itemid)
  }

  pushCommentFlag(data:any) {
    this.pushFlagComment.next(data)
  }


  fnPercentCalc(data:any) {
    this.perCent.next(data)
  }


  fnRecipeSectionId(data:any) {
    this.recipeSec.next(data)
  }

  fnSetGraph(data:any) {
    this.graph.next(data)
  }



}