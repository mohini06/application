import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators'
import { Observable, of } from 'rxjs';
import { DatePipe } from '@angular/common';
import { environment } from './../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GetGenericService {
  apiUrl = environment.apiUrl;
  constructor(private http: HttpClient) { }

  getParameterAnalysis(data:string) {
    return this.http.post<any>(this.apiUrl+'/generic/view',{p_listname:'parameter_analysis',p_objrecid:data.toString()})
        .pipe(map(data => {
            return data;
        }));
  }

  getTagCommentCount(data)
  {
    return this.http.post<any>(this.apiUrl+'/generic/view',{p_listname:'batchdata_tagcomment',p_objrecid:data.toString()})
    .pipe(map(data => {
        return data;
    }));
  }

  getEsigSigner()
  {
    return this.http.post<any>(this.apiUrl+'/generic/view',{"p_targetobjname":"esigsigner"})
    .pipe(map(data => {
        return data;
    }));
  }



  getAnalysisAll(recipeSectionId,recipeId)
  {
    return this.http.post<any>(this.apiUrl+'/generic/view',
    {"p_where":"recipesectionid = " + recipeSectionId + " and recipeid = "+ recipeId ,"p_listname" :"batchdata_analysis"})
    .pipe(map(data => {
        return data;
    }));
  }


}
