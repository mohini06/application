import { PreferenceService } from './preference.service';
import { ApiService } from './api.service';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators'
import { environment } from './../../../environments/environment';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class PostgenericService {
  apiUrl = environment.apiUrl;
  username: any
  personid: any

  constructor(private http: HttpClient, private apiService: ApiService,
     private authservice: AuthService,private pre:PreferenceService) {

    this.username = this.apiService.getUserName()
    this.personid = this.authservice.getPersonId()

    console.log(this.username)
  }

  postTag(data: any) {
    return this.http.post<any>(this.apiUrl + '/generic/save', { tagdata: data })
      .pipe(map(data => {
        return data;
      }));
  }

  postAttribute(data: any) {
    return this.http.post<any>(this.apiUrl + '/generic/save', { attributedata: data })
      .pipe(map(data => {
        return data;
      }));
  }

  postBatchData(data: any) {
    return this.http.post<any>(this.apiUrl + '/generic/save', { batchdata: data })
      .pipe(map(data => {
        return data;
      }));
  }
  postEsigDoc(data: any, docData, parent) {
    console.log(this.username)
    return this.http.post<any>(this.apiUrl + '/generic/save',
      {
        "esigdoc": [
          {
            "esigdocid": null,
            "targetobjname": parent,
            "objrecid": docData.id,
            "doc_json": docData,
            "event": "",
            "createdby": this.personid,
            "status": "inprogress",
            // "username":this.username


          }
        ]
      }
    )
      .pipe(map(data => {
        return data;
      }));
  }


  postEsigSigner(docId: any, formData) {
    var d = Date(); 
    let a = d.toString() 
    return this.http.post<any>(this.apiUrl + '/generic/save',
      {
        
        "esigsigner": [
          {
            "esigdocid": docId,
            "meaning": formData.meaning,
            "status": "",
            "createdby": this.personid,
            "username": this.username,
            "personid": this.personid,
            "seqno": 1,
            "lastupdatedby": this.personid,
            "roleid": formData.role,
            "annotation": formData.comment,
            "signeddate": this.pre.setDateFormate(a)
          }
        ]
      }
    )
      .pipe(map(data => {
        return data;
      }));
  }


  updateEsigDoc(docId) {
    return this.http.post<any>(this.apiUrl + '/generic/save',
      {
        "esigdoc": [
          {
            "esigdocid": docId,
            "status": "complete",
          }
        ]
      }
    )
      .pipe(map(data => {
        return data;
      }));
  }

}
