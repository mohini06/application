import { PreferenceService } from './preference.service';
import { SideBarState } from './../store/side-bar.actions';
import { BatchesService } from './batches.service';
import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { HttpClient, HttpParams, HttpResponse } from '@angular/common/http';
import { environment } from './../../../environments/environment';
import { DataStateChangeEventArgs, Sorts, DataResult } from '@syncfusion/ej2-angular-grids'
import { Observable } from 'rxjs';
import { Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { DatePipe } from '@angular/common';
import { Store } from '@ngrx/store';
@Injectable({
  providedIn: 'root'
})
export class ItemmasterService extends Subject<DataStateChangeEventArgs> {
  apiUrl = environment.apiUrl;
  username: any
  //Array for Filter and search
  startwith = []
  endswith = []
  contains = []
  equal = []
  notequal = []
  greaterthan = []
  greaterthanorequal = []
  lessthanorequal = []
  lessthan = []
  dateequal = []
  datenotequal = []
  commonsearch = []
  sideBarState$
  user$;
  httpClient: any;


  constructor(private preference: PreferenceService, private store: Store<SideBarState>, private http: HttpClient, private batchesService: BatchesService, private datePipe: DatePipe) {
    super();
    this.sideBarState$ = this.store.select('sideBar');
    this.user$ = this.sideBarState$
      .map(state => state.user);
    // this.username = this.batchesService.getUserName();

    this.user$.subscribe(user => this.username = user)

  }

  transformDate(date) {
    return this.datePipe.transform(date, 'yyyy/MM/dd');
  }
  //get view item details
  getViewItemDetail(itemid: any = 0) {
    return this.http.get<any>(this.apiUrl + '/items/view?itemid=' + itemid + '&mastertype=item')
  }

  // save new item details
  saveItemDetails(formData: any) {
    return this.http.post<any>(this.apiUrl + '/items/savenew', formData)
  }
  // Edit new item details
  editItemDetails(formData: any) {
    return this.http.post<any>(this.apiUrl + '/items/update', formData)
  }

  //Check ItemCode Duplicate

  checkItemCode(itemCode: any, id?: any) {
    return this.http.get<any>(this.apiUrl + '/items/check?itemcode=' + itemCode + '&itemid=' + id)
  }
  // atttribute 


  getAttributeItemAllData(grpId: any = "", recId: any = 0, type: any = "", ) {
    return this.http.get<any>(this.apiUrl + '/attribute/attributegroup?objname=' + type + '&recid=' + recId)
  }

  addAttributeGroup(attGrpId: any, username: any, recId: any) {
    return this.http.post<any>(this.apiUrl + '/attribute/save', {
      "objrecid": recId,
      "username": username,
      "attributegroupid": attGrpId
    })
  }

  getAttributeID(atrributeId: any) {
    let params = new HttpParams().set('type', "'item_attribute'");
    return this.http.get<any>(this.apiUrl + '/attribute/attributes?attributeGroupId=' + atrributeId, { params: params })
  }

  // get Item list details
  getAllItemList() {
    return this.http.post<any>(this.apiUrl + '/items/items?username=satish&per=20&page=1&filter=&mastertype=item&orderby=itemcode', {})
  }

  // geting tag groups
  getTaggroups(recId: any, objname) {
    return this.http.get<any>(this.apiUrl + '/tag/view?objname=' + objname + '&recid=' + recId)
  }

  // updating item details
  updateItemDetails(updateData: any) {
    return this.http.post<any>(this.apiUrl + '/items/update', updateData)

  }


  // get comments

  getComments(objName: any, recid: any) {
    return this.http.post<any>(this.apiUrl + '/comment/view?objname=' + objName + '&recid=' + recid, {})

  }

  postComments(id, objrecid, objname, commentid, comment: any, username, context) {
    return this.http.post<any>(this.apiUrl + '/comment/create',
      {
        "id": id,
        "objrecid": objrecid,
        "objname": objname,
        "commentid": commentid,
        "comment": comment.commentMsg,
        "username": username,
        "context": context
      })
  }


  editComments(id, objrecid, objname, commentid, comment: any, username, context) {
    return this.http.post<any>(this.apiUrl + '/comment/create',
      {
        "id": id,
        "objrecid": objrecid,
        "objname": objname,
        "commentid": commentid,
        "comment": comment,
        "username": username,
        "context": context
      })
  }



  //  get recipe 

  getAllRecipeList() {
    return this.http.post<any>(this.apiUrl + "/recipe/recipes?username=satish&per=10&page=1&filter=&mastertype=recipe&orderby=recipename", {})

  }

  //get recipe dropdown values

  getRecipeDropdownDetail(recipeid: any = 0) {
    return this.http.get<any>(this.apiUrl + '/recipe/view?recipeid=' + recipeid + '&mastertype=recipe')
  }
  // save new recipe details
  saveRecipeNewDetails(formData: any) {
    return this.http.post<any>(this.apiUrl + '/recipe/savenew', formData)
  }
  // save new recipe details
  checkRecipeName(recipe: any, id?: any) {
    return this.http.get<any>(this.apiUrl + '/recipe/check?recipename=' + recipe + '&recipeid=' + id)
  }
  // Save data with all tab
  editRecipeDetails(formData: any) {
    return this.http.post<any>(this.apiUrl + '/recipe/update', formData)
  }

  // get recipe section
  getRecipeSection(recipeid: any, mastertype: any) {
    return this.http.get<any>(this.apiUrl + '/recipe/view?recipeid=' + recipeid + '&mastertype=' + mastertype)
  }

  //save Recipe Section Parent/Child

  saveRecipeSection(recipeid?, sectionname?, recipesectionid?, parentrecipesectionid?, sequence?, istable?, description?, type?, username?, isparent?) {
    console.log(recipeid)
    return this.http.post<any>(this.apiUrl + '/recipe/savenewsection', { recipeid, sectionname, recipesectionid, parentrecipesectionid, sequence, istable, description, type, username, isparent })
  }

  // get parameter
  getAllParameterList() {
    return this.http.post<any>(this.apiUrl + "/parameter/parameters?username=satish&per=20&page=1&filter=&mastertype=parameter&orderby=recipename", {})

  }

  //get parameter dropdown values

  getParameterDropdowns(parameterid: any = 0) {
    return this.http.get<any>(this.apiUrl + '/parameter/view?parameterid=' + parameterid + '&mastertype=parameter')
  }
  // save new parameter details
  saveParameterNewDetails(formData: any, username: any) {
    return this.http.post<any>(this.apiUrl + '/parameter/savenew', {
      "parameterid": 0,
      "parametername": formData.parametername,
      "type": formData.parametertype,
      "label": formData.labelparameter,
      "uom": formData.parameteruom,
      "description": formData.description,
      "datatypeid": formData.datatypeid,
      "effectivedate": this.preference.setDateFormate(formData.startdate),
      "inactivedate": this.preference.setDateFormate(formData.enddate),
      "enableversion": formData.enableVersion,
      "status": formData.parameterstatus,
      "username": username
    }
    )
  }


  // Save Parameter data with all tab
  editParameterDetails(formData: any) {
    return this.http.post<any>(this.apiUrl + '/parameter/update', formData)
  }

  checkParameterName(name: any, id) {
    return this.http.get<any>(this.apiUrl + '/parameter/check?parametername=' + name + '&parameterid=' + id)
  }

  //Get data format for version
  getDataFormat(datatypeid) {

    return this.http.get<any>(this.apiUrl + '/parameter/dataformat?datatypeid=' + datatypeid + '&target=parameterformat')
  }

  // getting Parameter recipe
  getParameterRecipe(parameterid) {
    return this.http.get<any>(this.apiUrl + '/parameter/recipes?objname=parameterrecipe&parameterid=' + parameterid)
  }
  // getting Parameter recipe section
  getParameterRecipeSection(parameterId: any = 0, objName) {
    return this.http.get<any>(this.apiUrl + '/parameter/recipesection?objname=' + objName + '&recipeid=' + parameterId)
  }

  // getting Parameter  section
  getParameterSection(parameterId: any = 0, objName) {
    return this.http.get<any>(this.apiUrl + '/parameter/view-section?parameterid=' + parameterId + '&mastertype=' + objName)
  }


  getParameterSPecification(targetobj: any) {
    // return this.http.get<any>(this.apiUrl + '/parameter/view-section?p_targetobjname=' + targetobj)
    return this.http.post<any>(this.apiUrl + '/generic/view',
      {

        // "parametersectionid": formdata.parametersectionid,
        // "parameterid": parameterid,
        // "recipesectionid": formdata.recipesectionid,
        // "username": this.username['username']

        "p_targetobjname": "spec_detail"

      })
  }


  getParameterCurrentSPecData(targetobj: any) {
    return this.http.post<any>(this.apiUrl + '/generic/view',
      {

        // "parametersectionid": formdata.parametersectionid,
        // "parameterid": parameterid,
        // "recipesectionid": formdata.recipesectionid,
        // "username": this.username['username']

        "p_targetobjname": "spec_detail",
        "specid": "16"

      })


  }
  //Save Section
  saveParameterSection(parameterid, formdata) {
    return this.http.post<any>(this.apiUrl + '/parameter/save-section',
      {

        "parametersectionid": formdata.parametersectionid,
        "parameterid": parameterid,
        "recipesectionid": formdata.recipesectionid,
        "username": this.username['username']

      })
  }


  getspecificAnalyticplot() {

    return this.http.post<any>(this.apiUrl + '/generic/view',
      {
        "p_listname": "chart_spchisto",
        "p_where": "parameterid=456"

      })
  }

  //Save Specication
  saveParameterSpecification(parameterid, formdata) {
    return this.http.post<any>(this.apiUrl + '/generic/save',
      {

        // "parametersectionid": formdata.parametersectionid,
        // "parameterid": parameterid,
        // "recipesectionid": formdata.recipesectionid,
        // "username": this.username['username']

        "validateonly": true,
        "spec": [

          {
            "specid": null,
            "specname": formdata.specname,
            "targetobjname": "parameter",
            "targetobjrecid": 123456,
            "createdby": 5,
            "lastupdatedby": 5,
            "versionstart": formdata.versionstart,
            "versionend": formdata.versionend,
            "effectivestartdate": formdata.startdate,
            "effectiveenddate": formdata.enddate
          }

        ]

      })
  }


  ///// save Spec Range 

  saveParameterSpecificationRange(parameterid, formdata, specid: Number) {
    return this.http.post<any>(this.apiUrl + '/generic/save',
      {

        // "parametersectionid": formdata.parametersectionid,
        // "parameterid": parameterid,
        // "recipesectionid": formdata.recipesectionid,
        // "username": this.username['username']

        "validateonly": true,
        "specrange": [

          {
            "specid": specid,
            "rangetype": formdata[0].spec,
            "valuemax": formdata[0].max,

            "valuemin": formdata[0].min,
            "createdby": 5,
            "lastupdatedby": 5,
            // "status":formdata[0].enabled,
            "alertflag": formdata[0].alert
          }

        ]

      })
  }


  /////


  //Get All Existing Version
  getAllVersionData(parameterId = 22815, objName) {
    return this.http.get<any>(this.apiUrl + '/parameter/view?parameterid=' + parameterId + '&mastertype=' + objName)
  }

  //Save Version
  postVersion(formdata: any, username, parameterid) {
    let action
    if (!formdata.parameterversionid) {
      action = 0
      action = 'create'
    }
    else {
      action = 'update'
    }

    if (formdata.limittolist) {
      if (formdata.limittolist.value == "") {
        formdata.limittolist.setValue(false)
      }

    }
    if (formdata.verificationrequired) {
      if (formdata.verificationrequired.value == "") {
        formdata.verificationrequired.setValue(false)
      }

    }
    if (formdata.lockrec) {
      if (formdata.lockrec.value == "") {
        formdata.lockrec.setValue(false)
      }

    }
    if (formdata.lockuom) {
      if (formdata.lockuom.value == "") {
        formdata.lockuom.setValue(false)
      }

    }
    return this.http.post<any>(this.apiUrl + '/parameter/save-version',
      {
        parameterversionid: formdata.parameterversionid,
        caption: formdata.dataentrycaption,
        parameterid: parameterid,
        versionstart: formdata.versionstart,
        versionend: formdata.versionend,
        stepdescription: formdata.stepdescription,
        stepnolabel: formdata.stepnolabel,
        stepno: formdata.stepno,
        sortno: formdata.sortno,
        defaultvalue: formdata.defaultvalue,
        defaultuom: formdata.defaultuom,
        specmin: formdata.specmin,
        specmax: formdata.specmax,
        limittolist: formdata.limittolist,
        dataentryinstructions: formdata.dataentryinstructions,
        verificationrequired: formdata.verificationrequired,
        comments: formdata.comments,
        lockrec: formdata.lockrec,
        lockuom: formdata.lockuom,
        dataformatid: formdata.dataformatid,
        listid: formdata.listid,
        username: username,
        effectivestartdate: formdata.effectivestartdate,
        effectiveenddate: formdata.effectiveenddate,
        action: action
      }
    )
  }
  //Validate version
  valVersion(parameterid, versionstart: number, versionend: number, parameterversionid, action) {
    return this.http.post<any>(this.apiUrl + '/parameter/validate-version-range', {

      parameterid: parameterid,

      versionstart: versionstart,

      versionend: versionend,

      parameterversionid: parameterversionid,

      action: action
    })

  }

  //Get list for parameter version
  getList(parameterid: any) {
    return this.http.get<any>(this.apiUrl + '/parameter/listnames')

  }

  //Get UOM list for parameter version
  getUom(baseuom: any) {
    return this.http.get<any>(this.apiUrl + '/parameter/defaultuom?baseuom=' + baseuom)

  }


  //Attribute group
  // get lookup data for create and edit attribute group

  getAttributeAndGroupLookupData(groupid?: any) {
    return this.http.get<any>(this.apiUrl + '/attribute/group?attributegroupid=' + groupid + '&mastertype=attribute_group')
  }

  // check group availabilty
  checkAttributegroup(groupname?: any, id?: any) {
    return this.http.get<any>(this.apiUrl + '/attribute/validate-attributegroup?attributegroupname=' + groupname + '&attributegroupid=' + id)
  }

  // check Attribute availabilty
  checkAttribute(attribute?: any, id?: any) {
    if (id == null) {
      id = 0
    }
    return this.http.get<any>(this.apiUrl + '/attribute/validate-attribute?attribute=' + attribute + '&attributeid=' + id)
  }

  //Create Attribute group
  saveAttributeGroup(formData: any) {
    return this.http.post<any>(this.apiUrl + '/attribute/saveattributegroup',
      {
        "attributegroupid": formData.attributegroupid,
        "targetobjname": formData.attributetargetobjlist,
        "groupname": formData.attributegroupname,
        "is_table": formData.is_table,
        "caption": formData.attributecaption,
        "effectivedate": this.preference.setDateFormate(formData.startdate),
        "inactivedate": this.preference.setDateFormate(formData.enddate),
        // "effectivedate": this.transformDate(formData.startdate),
        // "inactivedate": this.transformDate(formData.enddate),

        "username": this.username['username'],
        "description": formData.description

      }
    )
  }

  ///Get attribute lookup data
  getAttributLookupData() {
    return this.http.get<any>(this.apiUrl + '/attribute/view?attributeid=0&mastertype=attributemaster')
  }
  //Get Attribute List
  getAttributList(groupId: any) {
    return this.http.get<any>(this.apiUrl + '/attribute/group?attributegroupid=' + groupId + '&mastertype=attribute_group')
  }

  //post Attribute 
  postAttribute(formdata: any, groupid: any) {
    return this.http.post<any>(this.apiUrl + '/attribute/saveAttributeForGroup',
      {
        "attributeid": formdata.attributeid,
        "uniquename": formdata.attributename,
        "caption": formdata.attributeListcaption,
        "attributetype": formdata.attributeListtype,
        "dataformatid": formdata.attributeListDataformat,
        "allowmultiplerecs": formdata.allowmultiplerecs,
        "limittolist": formdata.limitToList,
        "dataentryinstructions": formdata.description,
        "listid": formdata.attributeListName,
        "attributegroupid": groupid,
        "username": this.username['username'],
        "seqno": formdata.seqno,

        "effectivedate": this.preference.setDateFormate(formdata.startdate),
        "inactivedate": this.preference.setDateFormate(formdata.enddate),

        // "effectivedate": this.transformDate(formdata.startdate),
        // "inactivedate": this.transformDate(formdata.enddate),
      }
    )
  }


  //Tags
  //Check Tag group
  // check group availabilty
  checkTaggroup(groupname?: any, id?: any) {
    return this.http.get<any>(this.apiUrl + '/tag/validate-taggroup?taggroupname=' + groupname + '&taggroupid=' + id)
  }

  // check  availabilty
  checkTag(tagname?: any, id?: any) {
    if (id == null) {
      id = 0
    }
    return this.http.get<any>(this.apiUrl + '/tag/validate-tag?tag=' + tagname + '&tagid=' + id)
  }

  // save tag Group

  saveTagGroup(formData: any) {
    // console.log(this.transformDate(formData.enddate))
    return this.http.post<any>(this.apiUrl + '/tag/savetaggroup',
      {
        "taggroupid": formData.taggroupid,
        "targetobjname": formData.tagtargetobjlist,
        "description": formData.description,
        "taggroupname": formData.taggroupname,
        "caption": formData.tagcaption,
        "tagtype": formData.tagtype,
        "hide": formData.hide,
        "allow_multiples": formData.allowmultiple,

        "effectivedate": this.preference.setDateFormate(formData.startdate),
        "inactivedate": this.preference.setDateFormate(formData.enddate),

        // "effectivedate": this.transformDate(formData.startdate),
        // "inactivedate": this.transformDate(formData.enddate),
        "username": this.username['username']

      }
    )
  }

  // get Lookup data for tag group 
  getTagGroupData() {
    return this.http.get<any>(this.apiUrl + '/tag/group?taggroupid=0&mastertype=tag_group')
  }

  // save tag 

  saveTag(formData: any, groupid) {

    if (formData.hidetagList) {
      if (formData.hidetagList.value == "") {
        formData.hidetagList.setValue(false)
      }

    }
    return this.http.post<any>(this.apiUrl + '/tag/saveTag',
      {
        "tagid": formData.tagListid,
        "taggroupid": groupid,
        "tagname": formData.tagListname,
        "caption": formData.tagListcaption,
        "sortno": formData.tagListsortno,
        "hide": formData.hidetagList,
        "description": formData.description,

        "effectivedate": this.preference.setDateFormate(formData.startdate),
        "inactivedate": this.preference.setDateFormate(formData.enddate),

        // "effectivedate": this.transformDate(formData.startdate),
        // "inactivedate": this.transformDate(formData.enddate),
        "username": this.username['username']

      }
    )
  }

  //DashBoard

  getDashBoardCards() {
    return this.http.post<any>(this.apiUrl + '/batches/batches',
      {
        "username": this.username['username'],
        // "username": 'satish',
        "per": 10,
        "page": 1,
        "mastertype": "batchdashboard",
        "orderby": "batch desc",
        "startswith": [],
        "endswith": [],
        "contains": [],
        "equal": [],
        "notequal": [],
        "greaterthan": [],
        "greaterthanorequal": [],
        "lessthanorequal": [],
        "lessthan": [],
        "dateequal": [],
        "datenotequal": []
      }).pipe(map(data => {
        return data;
      }));
  }

  //Get all tag list
  getTagList(tagGroup: any) {
    return this.http.get<any>(this.apiUrl + '/tag/group?taggroupid=' + tagGroup + '&mastertype=tag_group')

  }

  getRecipeDetails(id) {
    return this.http.get<any>(this.apiUrl + '/recipe/view?recipeid=' + id + '&mastertype=recipe')

  }


  //get syncFuison datatable serve side for all
  public execute(state: any, url, parent): void {
    this.getData(state, url, parent).subscribe(x => super.next(x));
  }

  protected getData(state, url, parent): Observable<DataStateChangeEventArgs> {
    // console.log(state)
    let perpage
    let page
    let ordby
    let listname
    let count

    //Array for Filter
    this.startwith = []
    this.endswith = []
    this.contains = []
    this.equal = []
    this.notequal = []
    this.greaterthan = []
    this.greaterthanorequal = []
    this.lessthanorequal = []
    this.lessthan = []
    this.dateequal = []
    this.datenotequal = []
    this.commonsearch = []


    if (state.skip == 0) {
      perpage = state.take;
      page = 1
    } else {
      perpage = state.take;
      page = ((state.skip) / (state.take) + 1)
    }

    if (parent == 'item') {
      ordby = "lastupdatedate desc"
      listname = "item_list"
      count = "item_totalcount"
      // mastertype = "item"
    }

    if (parent == 'parameter') {
      ordby = "lastupdatedate desc"
      listname = "parameter_list"
      count = "parameter_totalcount"
      // mastertype = "parameter"
    }

    if (parent == 'recipe') {
      ordby = "lastupdatedate desc"
      listname = "recipe_list"
      count = "recipe_totalcount"
      // mastertype = "recipe"
    }

    if (parent == 'attributegroup') {
      ordby = "lastupdatedate desc"
      listname = "attributegroup_list"
      count = "attributegroup_totalcount"
      // mastertype = "attributegroup"
    }

    if (parent == 'taggroup') {
      ordby = "lastupdatedate desc"
      listname = "taggroup_list"
      count = "taggroup_totalcount"
      // mastertype = "taggroup"
    }

    if (parent == 'taggroup') {
      ordby = "lastupdatedate desc"
      listname = "taggroup_list"
      count = "taggroup_totalcount"
      // mastertype = "taggroup"
    }

    if (parent == 'batchdashboard') {
      ordby = "lastupdatedate desc"
      listname = "bd_batchtable"
      count = "bd_pagecount"
      // mastertype = "taggroup"
    }

    if (parent == 'role') {
      ordby = "rolename desc"
      listname = "role_list"
      count = "role_totalcount"
    }

    if (parent == 'privilege') {
      ordby = "parentobjname"
      listname = "privilege_list"
      count = "privilege_totalcount"
    }
    // let sortQuery: string =  `&orderby=itemcode`;
    let sortQuery: string = ordby;


    if ((state.sorted || []).length) {
      sortQuery = state.sorted.map((obj: Sorts) => {
        return obj.direction === 'descending' ? `${obj.name} desc` : obj.name;
      }).reverse().join(',');
    }
    if ((state.where || []).length) {
      // where clause

      // Date for equal and not equal
      if (state.where[0]['predicates'][0]['predicates']) {
        // console.log(state)
        for (let i = 0; i < state.where[0]['predicates'][0]['predicates'].length; i++) {
          if (state.where[0]['predicates'][0]['predicates'][i].operator == "lessthan") {
            this.lessthan.push({
              colname: state.where[0]['predicates'][0]['predicates'][i].field, value:
                state.where[0]['predicates'][0]['predicates'][i].value
            })
          }
          if (state.where[0]['predicates'][0]['predicates'][i].operator == "greaterthan") {
            this.greaterthan.push({
              colname: state.where[0]['predicates'][0]['predicates'][i].field, value:
                state.where[0]['predicates'][0]['predicates'][i].value
            })
          }

        }
      }



      for (let i = 0; i < state.where[0]['predicates'].length; i++) {
        if (state.where[0]['predicates'][i].operator == 'startswith') {
          this.startwith.push({ colname: state.where[0]['predicates'][i].field, value: state.where[0]['predicates'][i].value })
        }
        if (state.where[0]['predicates'][i].operator == 'endswith') {
          this.endswith.push({ colname: state.where[0]['predicates'][i].field, value: state.where[0]['predicates'][i].value })
        }

        if (state.where[0]['predicates'][i].operator == 'contains') {
          this.contains.push({ colname: state.where[0]['predicates'][i].field, value: state.where[0]['predicates'][i].value })
        }

        if (state.where[0]['predicates'][i].operator == 'equal') {

          this.equal.push({ colname: state.where[0]['predicates'][i].field, value: state.where[0]['predicates'][i].value })
        }
        if (state.where[0]['predicates'][i].operator == 'notequal') {
          this.notequal.push({ colname: state.where[0]['predicates'][i].field, value: state.where[0]['predicates'][i].value })
        }
        if (state.where[0]['predicates'][i].operator == 'greaterthan') {
          this.greaterthan.push({ colname: state.where[0]['predicates'][i].field, value: state.where[0]['predicates'][i].value })
        }
        if (state.where[0]['predicates'][i].operator == 'greaterthanorequal') {
          this.greaterthanorequal.push({ colname: state.where[0]['predicates'][i].field, value: state.where[0]['predicates'][i].value })
        }
        if (state.where[0]['predicates'][i].operator == 'lessthan') {
          this.lessthan.push({ colname: state.where[0]['predicates'][i].field, value: state.where[0]['predicates'][i].value })
        }

        if (state.where[0]['predicates'][i].operator == 'lessthanorequal') {
          this.lessthanorequal.push({ colname: state.where[0]['predicates'][i].field, value: state.where[0]['predicates'][i].value })
        }
      }

    }
    if ((state.search || []).length) {

      // console.log(state.search[0])
      let field
      for (let i = 0; i < state.search[0].fields.length; i++) {
        // console.log(state.search[0].fields[i])
        field = field + ',' + state.search[0].fields[i]
      }

      this.commonsearch.push({ colname: field.substring(10), value: state.search[0].key })
    }
    return this.http
      .post(this.apiUrl + "/generic/list",
        {
          // 'username': this.username['username'],
          // 'username': 'satish',
          "per": perpage,
          "page": page,
          "mastertype": parent,
          "orderby": sortQuery,
          "startswith": this.startwith,
          "endswith": this.endswith,
          "contains": this.contains,
          "equal": this.equal,
          "notequal": this.notequal,
          "greaterthan": this.greaterthan,
          "greaterthanorequal": this.greaterthanorequal,
          "lessthanorequal": this.lessthanorequal,
          "lessthan": this.lessthan,
          "dateequal": this.dateequal,
          "datenotequal": this.datenotequal,
          "commonsearch": this.commonsearch

        })
      .map((response: any) => response)
      .pipe(map((response: any) => (<DataResult>{
        result: response[listname],
        count: parseInt(response[count][0].count, 10)
      })))
      .pipe((data: any) => data);
  }






//Item
  saveItem(formData: any) {
    return this.http.post<any>(this.apiUrl + '/generic/save',
      {

        "item": [

          {
            "description": formData.description,
            "itemstatus": formData.itemstatus,
            "shorttitle": formData.shorttitle,
            "itemtype": formData.itemtype,
            "itemcode": formData.itemcode,
            "effectivedate": formData.effectivedate,
            "inactivedate": formData.inactivedate,
            "objname": "ITEM",
            "deletionflag": false,

          }

        ]
      }
    )
  }

//Recipe
  saveRecipe(formData: any) {
    if (formData.recipeid == 0) {
      formData.recipeid = null;
    }
    return this.http.post<any>(this.apiUrl + '/generic/save',
      {
        "recipe": [
          {
            "recipeid": formData.recipeid,
            "allowbatch": formData.allowbatch,
            "description": formData.description,
            "itemid": formData.item,
            "status": formData.status,
            "recipename": formData.recipename,
            "processtype": formData.type,
            "effectivedate": formData.effectivedate,
            "inactivedate": formData.inactivedate,
            "objname": "recipe",
            "deletionflag": false,
            "processseqno": 0,
          }
        ]
      }
    )
  }

//parameter
saveParameter(formData: any, username: string) 
  {
   
    if (formData.parameterid == 0) {
      formData.parameterid = null;
    }
    return this.http.post<any>(this.apiUrl + '/generic/save',
      {

        "parameter": [
          {
            "parameterid": formData.parameterid,
            "uniquename": formData.uniquename,
           "type": formData.parametertype,
            "label": formData.label,
            "baseuom": formData.baseuom,
            "description": formData.description,
            "datatypeid": formData.datatypeid,
            "effectivedate": formData.effectivedate,
            "inactivedate": formData.inactivedate,
            "enableversion": formData.enableversion,
            "status": formData.status,
            "objname": "parameter",
            "deletionflag": false
          }
        ]
      }
    )
  }





  saveattributeGroup(formData: any) {

    if (formData.attributegroupid == 0) {
      formData.attributegroupid = null;
    }
    console.log(formData)
    return this.http.post<any>(this.apiUrl + '/generic/save',
      {
        "attributegroup": [
          {
            "attributegroupid": formData.attributegroupid,
            "targetobjname": formData.targetobjname,
            "groupname": formData.groupname,
            "is_table": formData.is_table,
            "caption": formData.caption,
            "effectivedate": formData.effectivedate,
            "inactivedate": formData.inactivedate,
            "description": formData.description,
            "objname": "attributegroup",
            "deletionflag": false
          }
        ]
      }
    )
  }
//save 
  saveTags(formData: any) {
    if (formData.taggroupid == 0) {
      formData.taggroupid = null;
    }
    console.log(formData)
    return this.http.post<any>(this.apiUrl + '/generic/save',
      {

        "taggroup": [

          {
            "taggroupid": formData.taggroupid,
            "targetobjname": formData.targetobjname,
            "taggroupname": formData.taggroupname,
            "tagtype": formData.tagtype,
            "allow_multiples": formData.allow_multiples,
            "caption": formData.caption,
            "hide": formData.hide,
            "effectivedate": formData.effectivedate,
            "inactivedate": formData.inactivedate,
            "description": formData.description,
            "deletionflag": false,
            "objname": "taggroup"
          }

        ]
      }
    )
  }


  SaveparameterTags(tagJson: any) {
    return this.http.post<any>(this.apiUrl + '/generic/save',
      {
        "tagdata": tagJson
      })

  }


  parameterTagdata: any;
  parameterAttributedata: any;
  updateparameter(formData: any) {
    console.log(formData)
    this.parameterTagdata = [];
    this.parameterAttributedata = [];
    if (formData.tags) {
      for (let i = 0; i < formData.tags.length; i++) {
        this.parameterTagdata.push({
          "tagid": formData.tags[i].id,
          "objrecid": formData.parameterid,
          "deletionflag": false,
          "objname": "tagdata"

        })
      }
    }
    if (formData.attributes) {
      for (let i = 0; i < formData.attributes.length; i++) {
        this.parameterAttributedata.push({
          "tagid": formData.attributes[i].attributeid,
          "attributevalue": formData.attributes[i].attributevalue,
          "objrecid": formData.parameterid,
          "deletionflag": false,
          "objname": "tagdata"

        })
      }
    }

    return this.http.post<any>(this.apiUrl + '/generic/save',
      {
        "parameter": [
          {
            "parameterid": formData.parameterid,
            "uniquename": formData.uniquename,
            "type": formData.parametertype,
            "label": formData.label,
            "baseuom": formData.baseuom,
            "description": formData.description,
            "datatypeid": formData.datatypeid,
            "effectivedate": formData.effectivedate,
            "inactivedate": formData.inactivedate,
            "enableversion": formData.enableversion,
            "status": formData.status,
            "objname": "parameter"
          }

        ],
        "tagdata": this.parameterTagdata,
        "attributedata": this.parameterAttributedata
      })

  }



  recipeTagdata: any;
  recipeAttributedata: any;
  updateRecipe(formData: any) {
    this.recipeTagdata = [];
    this.recipeAttributedata = [];
    if (formData.tags) {
      for (let i = 0; i < formData.tags.length; i++) {
        this.recipeTagdata.push({
          "tagid": formData.tags[i].id,
          "objrecid": formData.parameterid,
          "deletionflag": false,
          "objname": "tagdata"

        })
      }
    }
    if (formData.attributes) {
      for (let i = 0; i < formData.attributes.length; i++) {
        this.recipeAttributedata.push({
          "tagid": formData.attributes[i].attributeid,
          "attributevalue": formData.attributes[i].attributevalue,
          "objrecid": formData.parameterid,
          "deletionflag": false,
          "objname": "tagdata"

        })
      }
    }

    return this.http.post<any>(this.apiUrl + '/generic/save',
      {
        "recipe": [
          {
            "recipeid": formData.recipeid,
            "allowbatch": formData.allowbatch,
            "description": formData.description,
            "itemid": formData.item,
            "status": formData.status,
            "recipename": formData.recipename,
            "processtype": formData.recipetype,
            "effectivedate": formData.effectivedate,
            "inactivedate": formData.inactivedate,
            "objname": "recipe",
            "deletionflag": false,
            "processseqno": 0,
          }
        ],
        "tagdata": this.recipeTagdata,
        "attributedata": this.recipeAttributedata
      })

  }


  itemTagdata: any;
  itemAttributedata: any;
  updateItem(formData: any) {
    this.itemTagdata = [];
    this.itemAttributedata = [];
    if (formData.tags) {
      for (let i = 0; i < formData.tags.length; i++) {
        this.itemTagdata.push({
          "tagid": formData.tags[i].id,
          "objrecid": formData.parameterid,
          "deletionflag": false,
          "objname": "tagdata"

        })
      }
    }
    if (formData.attributes) {
      for (let i = 0; i < formData.attributes.length; i++) {
        this.itemAttributedata.push({
          "tagid": formData.attributes[i].attributeid,
          "attributevalue": formData.attributes[i].attributevalue,
          "objrecid": formData.parameterid,
          "deletionflag": false,
          "objname": "tagdata"

        })
      }
    }

    return this.http.post<any>(this.apiUrl + '/generic/save',
      {
        "item": [

          {
            "description": formData.description,
            "itemstatus": formData.itemstatus,
            "shorttitle": formData.shorttitle,
            "itemtype": formData.itemtype,
            "itemcode": formData.itemcode,
            "effectivedate": formData.effectivedate,
            "inactivedate": formData.inactivedate,
            "objname": "ITEM"
          }

        ],
        "tagdata": this.itemTagdata,
        "attributedata": this.itemAttributedata
      })

  }


//
  saveAttribute(formData: any, groupid: any) {
    console.log(formData)
    if (formData.attributeid == 0) {
      formData.attributeid = null;
    }
    return this.http.post<any>(this.apiUrl + '/generic/save',
      {

        "attribute": [
          {
            "attributeid": formData.attributeid,
            "uniquename": formData.attributename,
            "caption": formData.attributeListcaption,

            "attributegroupid": groupid,
            "allowmultiplerecs": formData.allowmultiplerecs,
            "dataformatid": formData.attributeListDataformat,
            "effectivedate": formData.startdate,
            "inactivedate": formData.enddate,
            "deletionflag": false,
            "objname": "attribute",
            "description": formData.description,
            "seqno": formData.seqno,
            "attributetype": formData.attributeListtype,
            "mandatory": formData.mandatory,
            "dataentryinstructions": formData.dataentryinstructions,
            "listid": formData.attributeListName,
            "limittolist": formData.limitToList
          }
        ]
      })

  }

  //Comment
  saveComment(id, objrecid, objname, commentid, comment: any, username, context) {

    if (commentid == 0) {
      commentid = 0;
    }

    return this.http.post<any>(this.apiUrl + '/generic/save',
      {

        "comment": [
          {
            "objrecid": objrecid,
            "comment": comment.commentMsg,
            "targetobjname": objname,
            "context": context

          }
        ]
      })

  }


  saverecipesection(recipeid?, sectionname?, recipesectionid?, parentrecipesectionid?, sequence?, istable?, description?, type?, username?, isparent?) {

    if (recipesectionid == 0) {
      recipesectionid = null
    }
    return this.http.post<any>(this.apiUrl + '/generic/save',
      {
      "recipesection": [
          {
            "recipesectionid": recipesectionid,
            "sectionname": sectionname,
            "recipeid": recipeid,
            "seqno": sequence,
            "is_table": istable,
            "description": description,
            "sectiontype": type,
            "deletionflag": "false",
            "objname": "recipe_section",
            "parentrecipesectionid": parentrecipesectionid

          }
        ]
      })
  }


//parameter->parameter version
  saveParameterVersion(formdata: any, username, parameterid) {
    let action;
    if (!formdata.parameterversionid) {
      action = 0
      action = 'create'
    }
    else {
      action = 'update'
    }
    if (formdata.limittolist) {
      if (formdata.limittolist.value == "") {
        formdata.limittolist.setValue(false)
      }

    }
    if (formdata.verificationrequired) {
      if (formdata.verificationrequired.value == "") {
        formdata.verificationrequired.setValue(false)
      }

    }
    if (formdata.lockrec) {
      if (formdata.lockrec.value == "") {
        formdata.lockrec.setValue(false)
      }

    }
    if (formdata.lockuom) {
      if (formdata.lockuom.value == "") {
        formdata.lockuom.setValue(false)
      }

    }
    return this.http.post<any>(this.apiUrl + '/generic/save',
      {

        "parameterversion": [

          {
            "parameterid": parameterid,
            "parameterversionid": formdata.parameterversionid,
            "dataentrycaption": formdata.dataentrycaption,
            "versionstart": formdata.versionstart,
            "versionend": formdata.versionend,
            "stepdescription": formdata.stepdescription,
            "stepnolabel": formdata.stepnolabel,
            "stepno": formdata.stepno,
            "sortno": formdata.sortno,
            "defaultvalue": formdata.defaultvalue,
            "defaultuom": formdata.defaultuom,
            "specmin": formdata.specmin,
            "specmax": formdata.specmax,
            "limittolist": formdata.limittolist,
            "dataentryinstructions": formdata.dataentryinstructions,
            "verificationrequired": formdata.verificationrequired,
            "comments": formdata.comments,
            "deletionflag": false,
            "deactivate": "taggroup",

            "dropdownvalues": formdata.dropdownvalues,
            "lockrec": formdata.lockrec,
            "lockuom": formdata.lockuom,
            "objname": "parameterversion",
            "dataformatid": formdata.dataformatid,
            "effectivestartdate": formdata.effectivestartdate,
            "effectiveenddate": formdata.effectiveenddate,
            "listid": formdata.listid,
          }
        ]
      }
    )
  }


  saveParameterSections(parameterid, formdata) {
    if (formdata.parametersectionid == 0) {
      formdata.parametersectionid = null;
    }
    return this.http.post<any>(this.apiUrl + '/generic/save',
      {

        "parametersection": [

          {
            "parametersectionid": formdata.parametersectionid,
            "parameterid": parameterid,
            "recipesectionid": formdata.recipesectionid,

            "deletionflag": false,
            "objname": "parametersection",

          }]




      }
    )
  }




  // rolesGetdatajson(objname: any, id: any) {
    rolesGetdatajson() {

    return this.http.post<any>(this.apiUrl + '/generic/getroleaccess',
      {
        "sql":"select core.getdatajson(p_listname:='getRoleAccess', p_json:='{\"targetobjname\" : \"all\"}' )"

      })
    }
    // else
    // {
    //   return this.http.post<any>(this.apiUrl + '/generic/list',
    //   {
    //     "sql":"select core.getdatajson(p_listname:='getRoleAccess', p_json:='{\"targetobjname\" : \"+"+objname+"\",\"item_id\":"+id+"}' )"

    //   })
    // }

  Rolesdata:any;
    roles()
    {
      return this.httpClient.post(this.apiUrl+'/generic/getroleaccess', { "sql":"select core.getdatajson(p_listname:='getRoleAccess', p_json:='{\"targetobjname\" : \"all\"}' )"}, { observe: 'response' }).pipe(
        map((resp: HttpResponse<any>) => {
          //  console.log(resp.body.token)
          this.Rolesdata=resp.body;
          return resp;
        
        }))
    }
    

fieldLevelAcess(parentobjname, targetobjname)
{
if(targetobjname==null)
{
  return this.http.post<any>(this.apiUrl + '/generic/getroleaccess',
  {
    "sql":"select core.rbac_checkaccess('{\"parentobjname\" : \""+parentobjname+"\"}')"

  })
}

}



getRolesList(){
  return this.http.post<any>(this.apiUrl+'/generic/list',{
    
      "per": 10,
      "page": 1,
      "mastertype": "role",
      "orderby": "rolename asc",
      "startswith": [],
      "endswith": [],
      "contains": [],
      "equal": [],
      "notequal": [],
      "greaterthan": [],
      "greaterthanorequal": [],
      "lessthanorequal": [],
      "lessthan": [],
      "dateequal": [],
      "datenotequal": [],
      "commonsearch": []
  }
  )
  .pipe(map(data => {
      return data;
  }));
}
getprivilegList(){
  return this.http.post<any>(this.apiUrl+'/generic/list',{
    
    "per": 10,
    "page": 1,
    "mastertype": "privilege",
    "orderby": "objname asc",
    "startswith": [],
    "endswith": [],
    "contains": [],
    "equal": [],
    "notequal": [],
    "greaterthan": [],
    "greaterthanorequal": [],
    "lessthanorequal": [],
    "lessthan": [],
    "dateequal": [],
    "datenotequal": [],
    "commonsearch": []
}
)
.pipe(map(data => {
    return data;
}));
}

saveRole(formData: any) 
{
  if (formData.roleid == 0) {
    formData.roleid = null;
  }
  return this.http.post<any>(this.apiUrl + '/generic/save',
    {
      "role": [
        {
          "roleid" : formData.roleid ,
          "rolename": formData.rolename,
          "createdby": -1,
          "effectivedate": this.transformDate(formData.startdate),
          "inactivedate":this.transformDate(formData.enddate),
          "objname": "role",
          "deletionflag": false
        }
    ]
    }
  )
}
//get 
savePrivilege(formData:any,rolelist:any){
console.log(rolelist)
console.log(formData)
// console.log(this.username)
// return
  if (formData.privilegeid == 0) {
    formData.privilegeid = null;
 
    // formData.privilegeid = null;
    return this.http.post<any>(this.apiUrl + '/generic/save',
    {
      "privilege" : [
        {
         "privilegeid" :formData.privilegeid, 
         "type" : formData.typeobj,
         "description" : formData.description,
         "createdby" : this.username.personid,
         "objname" : "privilege",
         "targetobjname" : formData.targetobjname ,
         "enabledflag" : formData.enabledflag,
         "default_allow_read" :formData.default_allow_read,
         "default_allow_update" : formData.default_allow_update,
         "default_allow_execute" : formData.default_allow_execute,
         "default_allow_deletionflag" : formData.default_allow_deletionflag,
         "default_allow_create" : formData.default_allow_create,
         "parentobjname" :formData.parentobjname,
         "targetobjsource" : "sysobject",
         "targetobjsourcerecid" : 2,
         "isparent":false,
         "effectivedate":formData.effectivedate,
         "inactivedate":formData.inactivedate
        
        }
        ] 
    }
  )
  
}
else{
  
  return this.http.post<any>(this.apiUrl + '/generic/save',
  {

   "privilege" : [
       {
        "privilegeid" :formData.privilegeid, 
        "type" : formData.typeobj,
        "description" : formData.description,
        "createdby" : this.username.personid,
        "objname" : "privilege",
        "targetobjname" : formData.targetobjname ,
        "enabledflag" : formData.enabledflag,
        "default_allow_read" :formData.default_allow_read,
        "default_allow_update" : formData.default_allow_update,
        "default_allow_execute" : formData.default_allow_execute,
        "default_allow_deletionflag" : formData.default_allow_deletionflag,
        "default_allow_create" : formData.default_allow_create,
        "parentobjname" :formData.parentobjname,
        "targetobjsource" : "sysobject",
        "targetobjsourcerecid" : 2,
        "isparent":false,
        "effectivedate":formData.effectivedate,
        "inactivedate":formData.inactivedate
        
       
       } 
       ],
       "roleprivilege" :rolelist
   
    
    
   }
  )
}
}
viewPrivilege(privilege_id){
  return this.http.post<any>(this.apiUrl + "/generic/view",
    {
      "p_targetobjname" : "privilege",
      "p_objrecid" : ""+privilege_id+""
    }) .pipe(map(data => {
      return data;
  }));
}

getTargetobjlist(isparent,type,parentobjname)
{

  return this.http.post<any>(this.apiUrl + "/generic/view",
    {
      "p_listname" : "privilege_targetobj",
      "p_json" :   "{\"isparent\": \""+isparent+"\", \"type\": \""+type+"\",\"parentobjname\":\""+parentobjname+"\"}"
    }) .pipe(map(data => {
      return data;
  }));
  
}

getParentList(isparent,type){
  return this.http.post<any>(this.apiUrl + "/generic/view",
    {
      "p_listname" : "privilege_parentobj",
      "p_json" :   "{\"isparent\": \""+isparent+"\", \"type\": \""+type+"\"}"
    }) .pipe(map(data => {
      return data;
  }));
}
updatePrivilege(formData:any){
 
  return this.http.post<any>(this.apiUrl + '/generic/save',
  {

    "privilege" : [
       {
        "privilegeid" :formData.privilegeid, 
        "type" : "field",
        "description" : "set privilege for item status",
        "createdby" : -1 ,
        "objname" : "privilege",
        "targetobjname" : "Item Status",
        "enabledflag" : true,
        "default_allow_read" : true,
        "default_allow_update" : false,
        "default_allow_execute" : false,
        "default_allow_deletionflag" : false,
        "parentobjname" : "item",
        "targetobjsource" : "sysobject",
        "targetobjsourcerecid" : 2
        
       
       }
       ],
        "roleprivilege" : [
     {
         "roleprivilegeid" : null,
         "roleid" : 5 ,
         "privilegeid" : 56,
         "description" : "set Item Status privilege for roleid 5 (SYSADMIN)",
         "createdby" : 5 ,
         "lastupdatedby" : 5 ,
         "deletionflag" : false ,
         "objname" : "roleprivilege" ,
         "enabledflag" : true ,
         "allow_read" : true ,
         "allow_update" : false ,
         "allow_execute" : false ,
         "allow_deletionflag" : false,
         "allow_create" : true
     }
   
      ]
    
    
   }
  )
}

}
