import { Injectable } from '@angular/core';
import { environment } from './../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class FilterQueryBuilderService {
  apiUrl = environment.apiUrl;
  constructor(private http: HttpClient) { }

  saveQuery(filtername:any,ispublic:any,sqlcriteria:any,jsoncriteria:any,objname:any){

    // console.log(jsoncriteria)
    // return;
    return this.http.post<any>(this.apiUrl +'/generic/save',{
      "listsavedfilter": [
          {
          "listsavedfilterid" :  null ,
           "createdby": 5,
          "objname": "listsavedfilter",
              "filtername": filtername,
              "ispublic": ispublic,
              "listid": 70,
              "sqlcriteria": sqlcriteria,
              "jsoncriteria": jsoncriteria,
              "applydefault": true
              
               
          }
      ]
  })
    .pipe(map(saveQuery => {
    return saveQuery;
    }));
  }

  getListSavedFilter()
  {
    return this.http.post<any>(this.apiUrl+'/generic/view',{"p_targetobjname":"listsavedfilter"})
    .pipe(map(data => {
        return data;
    }));
  }

  updateQuery(filtername:any,ispublic:any,sqlcriteria:any,jsoncriteria:any,objname:any,listsavedfilterid:any){

    // console.log(jsoncriteria)
    // return;
    return this.http.post<any>(this.apiUrl +'/generic/save',{
      "listsavedfilter": [
          {
          "listsavedfilterid" :  listsavedfilterid ,
           "createdby": 5,
          "objname": "listsavedfilter",
              "filtername": filtername,
              "ispublic": ispublic,
              "listid": 70,
              "sqlcriteria": sqlcriteria,
              "jsoncriteria": jsoncriteria,
              "applydefault": true
              
               
          }
      ]
  })
    .pipe(map(updateQuery => {
    return updateQuery;
    }));
  }

}
