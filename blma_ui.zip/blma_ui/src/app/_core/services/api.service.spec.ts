import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClient, HttpClientModule, HttpParams, HttpRequest } from '@angular/common/http';
import { TestBed, inject, async } from '@angular/core/testing';

import { User, Picture } from '../../../testing/mockdata';

import { ApiService } from './api.service';

describe('ApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientModule,
        HttpClientTestingModule
      ],
      providers: [ApiService]
    });
  });

  it('should be created', inject([ApiService], (api: ApiService) => {
    expect(api).toBeTruthy();
  }));

  it('should make the correct call when signing in', async(inject([ApiService, HttpClient, HttpTestingController],
    (api: ApiService, http: HttpClient, backend: HttpTestingController) => {
      api.register(User.username, User.password, {name: User.name}).subscribe();
      backend.expectOne((req: HttpRequest<any>) => {
        return req.url.includes('register')
               && req.method === 'POST'
               && req.body['username'] === User.username
               && req.body['password'] === User.password;
      });
  })));

  it('should emit true if the signup is succesful', async(inject([ApiService, HttpClient, HttpTestingController],
    (api: ApiService, http: HttpClient, backend: HttpTestingController) => {
      api.register(User.username, User.password, {name: User.name}).subscribe((resp) => {
        expect(resp).toBeTruthy();
      });
      backend.expectOne((req: HttpRequest<any>) => {
        return req.url.includes('register');
      }).flush(null, { status: 201, statusText: 'Created' });
  })));

  it('should make the correct call when logging in', async(inject([ApiService, HttpClient, HttpTestingController],
    (api: ApiService, http: HttpClient, backend: HttpTestingController) => {
      api.login(User.username, User.password).subscribe();
      backend.expectOne((req: HttpRequest<any>) => {
        return req.url.includes('session')
               && req.method === 'POST'
               && req.body['email'] === User.username
               && req.body['password'] === User.password;
      });
  })));

  it('should emit true if the signin is succesful', async(inject([ApiService, HttpClient, HttpTestingController],
    (api: ApiService, http: HttpClient, backend: HttpTestingController) => {
      api.login(User.username, User.password).subscribe((resp) => {
        expect(resp).toBeTruthy();
      });
      backend.expectOne((req: HttpRequest<any>) => {
        return req.url.includes('session');
      }).flush({token: '123'}, { status: 200, statusText: 'OK'});
  })));

  it('should emit false if the signin is unsuccesful', async(inject([ApiService, HttpClient, HttpTestingController],
    (api: ApiService, http: HttpClient, backend: HttpTestingController) => {
      api.login(User.username, User.password).subscribe((resp) => {
        expect(resp.token).toBeFalsy();
      });
      backend.expectOne((req: HttpRequest<any>) => {
        return req.url.includes('session');
      }).flush(null, { status: 401, statusText: 'Unauthorized'});
  })));

  it('should make the correct call when uploading a picture', async(inject([ApiService, HttpClient, HttpTestingController],
    (api: ApiService, http: HttpClient, backend: HttpTestingController) => {
      api.upload(Picture.name, Picture.file).subscribe();
      backend.expectOne((req: HttpRequest<any>) => {
        return req.url.includes('picture');
      });
  })));

  it('should not be able to upload a picture if unauthorized', async(inject([ApiService, HttpClient, HttpTestingController],
    (api: ApiService, http: HttpClient, backend: HttpTestingController) => {
      api.upload(Picture.name, Picture.file).subscribe((resp) => {
        expect(resp).toBeFalsy();
      });
      backend.expectOne((req: HttpRequest<any>) => {
        return req.url.includes('picture');
      }).flush(null, { status: 401, statusText: 'Unauthorized'});
  })));

  it('should emit true if the picture is uploaded', async(inject([ApiService, HttpClient, HttpTestingController],
    (api: ApiService, http: HttpClient, backend: HttpTestingController) => {
      api.login(User.username, User.password).subscribe((resp) => {
        expect(resp).toBeTruthy();
        api.upload(Picture.name, Picture.file).subscribe((resp2) => {
          expect(resp2).toBeTruthy();
        });
      });
      backend.expectOne((req: HttpRequest<any>) => {
        return req.url.includes('session');
      }).flush({token: '123'}, { status: 200, statusText: 'Ok'});
      backend.expectOne((req: HttpRequest<any>) => {
        return req.url.includes('picture');
      }).flush(null, { status: 201, statusText: 'Created'});
    })));

  it('should make the correct call when requesting the pictures', async(inject([ApiService, HttpClient, HttpTestingController],
    (api: ApiService, http: HttpClient, backend: HttpTestingController) => {
      api.login(User.username, User.password).subscribe((resp) => {
        expect(resp).toBeTruthy();
        api.getAll().subscribe((resp2) => {
          expect(resp2).toContain({name: 'img1', url: 'img/img1.png'});
        });
      });

    backend.expectOne((req: HttpRequest<any>) => {
      return req.url.includes('session');
    }).flush({token: '123'}, { status: 200, statusText: 'Ok'});

    backend.expectOne((req: HttpRequest<any>) => {
      return req.url.includes('picture') && req.method === 'GET';
    }).flush([{name: 'img1', url: 'img/img1.png'}]);
  })));

  it('should destroy the tokens when logging out', async(inject([ApiService, HttpClient, HttpTestingController],
    (api: ApiService, http: HttpClient, backend: HttpTestingController) => {
      api.logout().subscribe((resp) => {
        expect(resp).toBeTruthy();
      });
  })));

});
