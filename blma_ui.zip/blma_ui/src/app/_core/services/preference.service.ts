import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators'
import { Observable, of } from 'rxjs';
import { DatePipe } from '@angular/common';
import * as moment from 'moment-timezone';
@Injectable({
  providedIn: 'root'
})
export class PreferenceService {

  constructor(private http: HttpClient,private datePipe: DatePipe) { }

  getDateFormate()
  {
    return "dd-MMM-yyyy"
  }

  getDateTimeFormate()
  {
    return 'dd-MMM-yyyy hh:mm a';
  }

  setDateFormate(date)
  {
    return this.datePipe.transform(date, 'dd-MMM-yyyy');
  }

  setDate(date)
  {
    return this.datePipe.transform(date, 'dd-MMM-yyyy');
  }

}
