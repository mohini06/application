import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ChartdataService {

  constructor() { }
  histogram:any;
  pvalues = [];
  labelsrequired=[];
  lineBoxPlot:any;
  Boxplot:any;
  ControlChart:any;
  Charts=[];
  getspecificchart(graphlist:any)
  {
if(graphlist)
{

  for(let i=0;i<graphlist.labels.length;i++)
  {
    this.labelsrequired.push(graphlist.labels[i].substring(0, 7));
  }
    this.pvalues=graphlist.values;
    this.histogram = {
      data: [
      {
      //  x:this.labels,
      y: this.pvalues,
      mode: 'lines+markers',
      marker: { color: 'blue' }, type: 'histogram', name: '', boxpoints: 'all',
      jitter: 0.3,
      pointpos: -1.8,
      },
      {
      displayModeBar: false,
      }
      
      ],
      
      layout: {
      title:"histogram chart",
       autosize: true, height: 400, width: 400, margin: {
      //   l: 20,
      //   r: 20,
      //   b: 70,
      //   t: 5,
      //   pad: 2
       }
      },
      config: {
      displayModeBar: false
      }
      
      }

      this.lineBoxPlot = {
        data: [
        {
        x:this.labelsrequired,
        y: this.pvalues,
        mode: 'lines+markers',
        marker: { color: 'blue' }, type: 'scatter', name: '', boxpoints: 'all',
        jitter: 0.3,
        pointpos: -1.8,
        },
        {
        displayModeBar: false,
        }
        
        ],
        
        layout: {
        title:"Line chart",
         autosize: true, height: 400, width: 400, margin: {
        //   l: 20,
        //   r: 20,
        //   b: 70,
        //   t: 5,
        //   pad: 2
         }
        },
        config: {
        displayModeBar: false
        }
        
        }
        this.Boxplot = {
          data: [
          {
          //  x:this.labels,
          y: this.pvalues,
          mode: 'lines+markers',
          
          marker: { color: 'blue' },
          type: 'box', name: '', boxpoints: 'all',
          jitter: 0.3,
          pointpos: -1.8,
          },
          {
          displayModeBar: false,
          }
          
          ],
          
          layout: {
          title:"Box chart",
           autosize: true,  height: 400, width: 400, margin: {
          //   l: 20,
          //   r: 20,
          //   b: 70,
          //   t: 5,
          //   pad: 2
           }
          },
          config: {
          displayModeBar: false
          }
          
          }

          this.ControlChart = {
            data: [
              {
               
                   x:this.labelsrequired,
                  y: this.pvalues,
                 mode: 'lines+markers',
               
                marker: { color: 'blue' }, 
                
                type: 'scatter', name: '', boxpoints: 'all',
                jitter: 0.3,
                pointpos: -1.8,
              },
          {
          
          type: 'scatter',
          x: [0,20, null,0,20],
          y: [7.5, 7.5, null, 8.3, 8.3],
          mode: 'lines',
          name: 'LCL/UCL',
          showlegend: true,
          line: {
          color: 'red',
          width: 2,
          dash: 'dash'
          }
          },
          {
          type: 'scatter',
          x: [0, 20],
          y: [8, 8],
          mode: 'lines',
          name: 'Centre',
          showlegend: true,
          line: {
          color: 'grey',
          width: 2
          }
          },
          
              {
                type: 'scatter',
                x: [17],
                y: [8.4],
                mode: 'markers',
                name: 'Violation',
                showlegend: true,
                marker: {
                  color: 'rgb(255,65,54)',
                  line: {width: 3},
                  opacity: 0.5,
                  size: 12,
                  symbol: 'circle-open'
                }
                
          
          
              },
          
          
              {
                displayModeBar: false,
              }
          
            ],
          
            layout: {
              title:"Control chart",
              yaxis: {
                range: [7,9],
                zeroline: false
              },
                         autosize: true, height: 400, width: 400, 
                        // margin: {
                        //   l: 20,
                        //   r: 20,
                        //   b: 100,
                        //   t:30,
                        //   pad: 2
                        // }
                      },
                      config: {
                        displayModeBar: true
                      }
          
          }


          return [this.lineBoxPlot,this.histogram,this.Boxplot,this.ControlChart];
    }
else
{
  return;
}
      
  }


  Inlinechart:any;
getinlinechart(graphlist:any)
{

  for(let i=0;i<graphlist.labels.length;i++)
  {
    this.labelsrequired.push(graphlist.labels[i].substring(0, 7));
  }
  this.pvalues=graphlist.values;
  this.Inlinechart = {
    data: [
    {
    // x:this.labelsrequired,
    y: this.pvalues,
    mode: 'lines+markers',
    marker: { color: 'blue' }, type: 'scatter', name: '', boxpoints: 'all',
    jitter: 0.3,
    pointpos: -1.8,
    },
    {
    displayModeBar: false,
    }
    
    ],
    
    layout: {
    title:"Line chart",
     autosize: true, height: 400, width: 400, margin: {
    //   l: 20,
    //   r: 20,
    //   b: 70,
    //   t: 5,
    //   pad: 2
     }
    },
    config: {
    displayModeBar: false
    }
    
    }
    return this.Inlinechart;
}

}
