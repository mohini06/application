import { TestBed } from '@angular/core/testing';

import { GetGenericService } from './get-generic.service';

describe('GetGenericService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GetGenericService = TestBed.get(GetGenericService);
    expect(service).toBeTruthy();
  });
});
