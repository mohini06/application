export interface Details {
    name: string,
    specMin: number,
    specMax: number,
    batchDataId: number,
    stepLabel: number,
    description: string,
    stepDescription: string,
    specialInstruction: string,
    note: string,
    tags: string [],
    tagList: string []
}

export interface Analysis {
    labels: string [],
    data: number []
}

export interface Params {
    title: string,
    input: string,
    combox: string [],
    messageIcon: string,
    lockIcon: string,
    active: boolean,
    name: string,
    details: {},
    anlysis: {},
    audit: {}
}

export interface Batch {
    [key: string]: any
}

export interface ItemSideBar {
    title: string,
    active: boolean,
    advance: number
}
