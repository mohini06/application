export interface Image {
  name: string;
  url: string;
}
