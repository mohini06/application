import { animate, state, style, transition, trigger, query } from '@angular/animations';


export const contentAnimation = trigger('contentAnimation', [
      transition('* <=> *', [
        // Initial state of new route
        query(':enter',
          style({
            position: 'fixed',
            width:'100%',
            transform: 'translateX(-100%)',
            opacity: 0,
            
          }),
          {optional:true}),
        // move page off screen right on leave
        query(':leave',
          animate('500ms linear',
            style({
              position: 'fixed',
              width:'100%',
              transform: 'translateX(100%)'
            })
          ),
        {optional:true}),
        // move page in screen from left to right
        query(':enter',
          animate('500ms linear',
            style({
              opacity: 1,
              transform: 'translateX(0%)'
            })
          ),
        {optional:true}),
      ])
    ])

export const dataEntryAnimation = trigger('dataEntryAnimation', [
      transition('* <=> *', [
        // Initial state of new route
        query(':enter',
          style({
            position: 'fixed',
            // width:'100%',
            transform: 'translateY(100%)',
            opacity: 0,
            
          }),
          {optional:true}),
        // move page off screen right on leave
        query(':leave',
          animate('300ms linear',
            style({
              position: 'fixed',
              // width:'100%',
              transform: 'translateY(-100%)',
              opacity: 0,
            })
          ),
        {optional:true}),
        // move page in screen from left to right
        query(':enter',
          animate('500ms linear',
            style({
              opacity: 1,
              transform: 'translateY(0%)'
            })
          ),
        {optional:true}),
      ])
    ])

  export const slideInOut = trigger('slideInOut',[
        state('true', style({
           height: '0px',
           overflow: 'hidden',
           display:'none'
           })),
        state('false', style({
           height: '*',
           overflow: 'visible',
           display:'visible'
           })),
        transition('1 => 0', animate('300ms linear')),
        transition('0 => 1', animate('300ms linear'))
    ]);


  
  
  