import { Store, ActionReducer, Action } from '@ngrx/store';

// Actions Types
export const setUser = 'setUser';
export const setElements = 'setElements';

export const sideBarStateActions = {
    setUser,
    setElements
}

export interface ActionWithPayloadInterface extends Action {
    payload: any;
  }
// Interface declaration
export interface SideBarState {
    user: any;
    elements: {
               title: string,
               recipeid: number,
               batchid: number, 
               active: boolean, 
               itemcode: string,
               recipeName: string,
               recipeDescription: string
            } [];
}

export const sideBarInitialState: SideBarState = {
    user: {
        username: '',
        email: ''
    },
    elements: [{
        title: '',
        recipeid: 0,
        batchid: 0,
        active: false,
        itemcode: '',
        recipeName: '',
        recipeDescription: ''
    }]
}

// Reducer
export function sideBarReducer(state: SideBarState = sideBarInitialState, action: ActionWithPayloadInterface): SideBarState {
    switch(action.type){
        case sideBarStateActions.setUser:
            return Object.assign({}, state, { user: action.payload }) as SideBarState;
        case sideBarStateActions.setElements:
            return Object.assign({}, state, { elements: action.payload }) as SideBarState;
        default:
            return Object.assign({}, state)
    }
}