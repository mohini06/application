import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';

/*
  Load here the actions
*/
import { dataEntryReducer } from './data-entry.actions';
import { sideBarReducer } from './side-bar.actions';

/*
    Module Declaration
*/
@NgModule({
  imports: [
    StoreModule.forRoot({
      dataEntry: dataEntryReducer,
      sideBar: sideBarReducer
    })
  ],
  exports: [
    StoreModule
  ],
  declarations: [],
})
export class StateStoreModule { }
