import { Store, ActionReducer, Action } from '@ngrx/store';
// Actions Types
export const setGraph = 'setGraph';
export const setBatches = 'setBatches';
export const setBatch = 'setBatch';
export const setParameters = 'setParameters';
export const setFiltersParam = 'setFiltersParam';
export const setAllParam = 'setAllParam';
export const setAllcomment = 'setAllcomment';
export const setTableData = 'setTableData';
export const setNewTableData = 'setNewTableData';
export const setSelectedParamIndex = 'setSelectedParamIndex';
export const setSelectedCommIndex = 'setSelectedcommIndex';
export const setParamsSelect = 'setParamsSelect';
export const setTopFormInfo = 'setTopFormInfo';
export const setBatchData = 'setBatchData';
export const setRecipeName = 'setRecipeName';
export const setRecipeDescription = 'setRecipeDescription';
export const setItemCode = 'setItemCode';
export const setErrorParams = 'setErrorParams';
export const setParameterIdSelected = 'setParameterIdSelected';
export const setFilters = 'setFilters';
export const setNewBatchesData = 'setNewBatchesData';
export const setUpdateBatchesData = 'setUpdateBatchesData';
export const setCurrentStatus = 'setCurrentStatus';
export const setCurrentStatusDropDown = 'setCurrentStatusDropDown';
export const setBatchNumber = 'setBatchNumber';
export const setCurrentRole = 'setCurrentRole';
export const setAllowedRole = 'setAllowedRole';
export const setUserSig = 'setUserSig';
export const setDataEntryPagination = 'setDataEntryPagination';
export const setToken = 'setDataEntryPagination';

export interface ActionWithPayloadInterface extends Action {
    payload: any;
}

export const dataEntryStateActions = {
    setGraph,
    setBatches,
    setBatch,
    setParamsSelect,
    setFiltersParam,
    setAllParam,
    setAllcomment,
    setTableData,
    setNewTableData,
    setParameters,
    setSelectedParamIndex,
    setSelectedCommIndex,
    setTopFormInfo,
    setBatchData,
    setRecipeName,
    setRecipeDescription,
    setItemCode,
    setErrorParams,
    setParameterIdSelected,
    setFilters,
    setNewBatchesData,
    setUpdateBatchesData,
    setCurrentStatus,
    setCurrentStatusDropDown,
    setBatchNumber,
    setCurrentRole,
    setAllowedRole,
    setUserSig,
    setDataEntryPagination,
    setToken
};

// Interface declaration
export interface DataEntryState {
    graph
    batches: any[];
    batch: any[];
    parameters: any[];
    filterParam: any[];
    AllParam: any[];
    allComment
    tableData: any[];
    tableNewData: any[];
    selectedParamIndex: any[];
    selectedCommIndex: any[];
    paramsSelect: number;
    topFormInfo: number;
    batchData: number;
    recipeName: string;
    itemCode: string;
    recipeDescription: string;
    errorParams: any[];
    parameteridSelected: number;
    filters: string[];
    newBatchesData: {},
    updateBatchesData: {},
    currentStatus: string,
    currentStatusDropDown: any,
    batchNumber: string,
    currentRole: string[],
    allowedRole: boolean,
    userSig: string,
    token:string
}

export const dataEntryInitialState: DataEntryState = {
    graph:[],
    batches: [],
    batch: [
        {
            title: '',
            active: false,
            parameters: []
        }
    ],
    parameters: [],
    filterParam: [],
    AllParam: [],
    allComment:[],
    tableData: [],
    tableNewData: [],
    selectedParamIndex: [
        {
            firstIndex: '',
            secondIndex: '',
            type: ''
        }
    ],
    selectedCommIndex: [{
        firstIndex: '',
        secondIndex: '',
        type: ''
    }],
    paramsSelect: 0,
    topFormInfo: 0,
    batchData: 0,
    recipeName: '',
    recipeDescription: '',
    itemCode: '',
    errorParams: [],
    parameteridSelected: 0,
    filters: [],
    newBatchesData: {},
    updateBatchesData: {},
    currentStatus: '',
    currentStatusDropDown: [],
    batchNumber: '',
    currentRole: [],
    allowedRole: false,
    userSig: '',
    token:''
};





// Reducer
export function dataEntryReducer(state: DataEntryState = dataEntryInitialState, action: ActionWithPayloadInterface): DataEntryState {
    switch (action.type) {
        case dataEntryStateActions.setGraph:
            return Object.assign({}, state, { graph: action.payload }) as DataEntryState; 
        case dataEntryStateActions.setBatches:
            return Object.assign({}, state, { batches: action.payload }) as DataEntryState;
        case dataEntryStateActions.setParameters:
            return Object.assign({}, state, { parameters: action.payload }) as DataEntryState;
        case dataEntryStateActions.setFiltersParam:
            return Object.assign({}, state, { filterParam: action.payload }) as DataEntryState;
        case dataEntryStateActions.setAllParam:
            return Object.assign({}, state, { AllParam: action.payload }) as DataEntryState;
            case dataEntryStateActions.setAllcomment:
                return Object.assign({}, state, { allComment: action.payload }) as DataEntryState;
        case dataEntryStateActions.setTableData:
            return Object.assign({}, state, { tableData: action.payload }) as DataEntryState;

        case dataEntryStateActions.setNewTableData:
            return Object.assign({}, state, { tableNewData: action.payload }) as DataEntryState;
        //    
        case dataEntryStateActions.setSelectedParamIndex:
            return Object.assign({}, state, { selectedParamIndex: action.payload }) as DataEntryState;
        case dataEntryStateActions.setSelectedCommIndex:
            return Object.assign({}, state, { selectedCommIndex: action.payload }) as DataEntryState;
        case dataEntryStateActions.setBatch:
            return Object.assign({}, state, { batch: action.payload }) as DataEntryState;
        case dataEntryStateActions.setParamsSelect:
            return Object.assign({}, state, { paramsSelect: action.payload }) as DataEntryState;
        case dataEntryStateActions.setTopFormInfo:
            return Object.assign({}, state, { topFormInfo: action.payload }) as DataEntryState;
        case dataEntryStateActions.setBatchData:
            return Object.assign({}, state, { batchData: action.payload }) as DataEntryState;
        case dataEntryStateActions.setItemCode:
            return Object.assign({}, state, { itemCode: action.payload }) as DataEntryState;
        case dataEntryStateActions.setRecipeName:
            return Object.assign({}, state, { recipeName: action.payload }) as DataEntryState;
        case dataEntryStateActions.setRecipeDescription:
            return Object.assign({}, state, { recipeDescription: action.payload }) as DataEntryState;
        case dataEntryStateActions.setErrorParams:
            return Object.assign({}, state, { errorParams: action.payload }) as DataEntryState;
        case dataEntryStateActions.setParameterIdSelected:
            return Object.assign({}, state, { parameteridSelected: action.payload }) as DataEntryState;
        case dataEntryStateActions.setFilters:
            return Object.assign({}, state, { filters: action.payload }) as DataEntryState;
        case dataEntryStateActions.setNewBatchesData:
            return Object.assign({}, state, { newBatchesData: action.payload }) as DataEntryState;
        case dataEntryStateActions.setUpdateBatchesData:
            return Object.assign({}, state, { updateBatchesData: action.payload }) as DataEntryState;
        case dataEntryStateActions.setCurrentStatus:
            return Object.assign({}, state, { currentStatus: action.payload }) as DataEntryState;
        case dataEntryStateActions.setCurrentStatusDropDown:
            return Object.assign({}, state, { currentStatusDropDown: action.payload }) as DataEntryState;
        case dataEntryStateActions.setBatchNumber:
            return Object.assign({}, state, { batchNumber: action.payload }) as DataEntryState;
        case dataEntryStateActions.setCurrentRole:
            return Object.assign({}, state, { currentRole: action.payload }) as DataEntryState;
        case dataEntryStateActions.setAllowedRole:
            return Object.assign({}, state, { allowedRole: action.payload }) as DataEntryState;
        case dataEntryStateActions.setUserSig:
            return Object.assign({}, state, { userSig: action.payload }) as DataEntryState;
            case dataEntryStateActions.setToken:
            return Object.assign({}, state, { token: action.payload }) as DataEntryState;
        default:
            return Object.assign({}, state);
    }

}
