import { data } from './../../exp/sync-fusion/alldata';
import { DataService } from './../../_core/services/data.service';
import { PostgenericService } from './../../_core/services/postgeneric.service';
import { ItemmasterService } from './../../_core/services/itemmaster.service';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs';
import {ViewEncapsulation, Inject, ViewChild } from '@angular/core';
import { ProgressButton, SpinSettingsModel, AnimationSettingsModel } from '@syncfusion/ej2-angular-splitbuttons';
import { th_TH } from 'ng-zorro-antd';

@Component({
  selector: 'app-tags',
  templateUrl: './tags.component.html',
  styleUrls: ['./tags.component.scss']
})
export class TagsComponent implements OnInit {

 
  public contractBtn: ProgressButton;

  public spinRight: SpinSettingsModel = { position: 'Right' };
    public spinTop: SpinSettingsModel = { position: 'Top' };
    public spinBottom: SpinSettingsModel = { position: 'Bottom' };
    public spinCenter: SpinSettingsModel = { position: 'Center' };
    public zoomOut: AnimationSettingsModel = { effect: 'ZoomOut' };
    public slideLeft: AnimationSettingsModel = { effect: 'SlideLeft' };
    public slideRight: AnimationSettingsModel = { effect: 'SlideRight' };
    public zoomIn: AnimationSettingsModel = { effect: 'ZoomIn' };

    public contractBegin() {
        this.contractBtn.element.classList.add('e-round');
    }

    public contractEnd() {
        this.contractBtn.element.classList.remove('e-round');
    }

  tagGroupName: any;
  taggroups: [];
  tagNames: any[] = [];
  tagDeselectedData = [];
  tempSelectedValue = []
  tagData = []

  selectedValues = []
  private eventsSubscription: any
  @Input() parentData: any;
  @Input() parent: any;
  @Output() TagChildData: EventEmitter<string[]> = new EventEmitter<string[]>();
  @Input() formData: Observable<void>;
  recId: any
  constructor(private tagGroups: ItemmasterService, private postGeneric: PostgenericService, private dataSubject: DataService) {
  }

  CheckAccessData:any;
  saveTags:boolean=true;
  ngOnInit() {
//Service for Field level Role Access
    this.tagGroups.fieldLevelAcess(this.parent, null).subscribe(data => {
      if(data.item.child)
      {
      this.CheckAccessData = data.item.child;
      for (let obj of this.CheckAccessData) {
        for (let keyname in obj) {
          if(keyname=='tag')
          {
          if (obj[keyname].read == true)
          {
                  
                  if(obj[keyname].create==false)
                  {
                    this.saveTags=false;
                  }

          }
        }
      }}}

    });

    this.recId = this.parentData
    if (this.parent == 'batchdata') {

      this.eventsSubscription = this.formData.subscribe(data => {
        // console.log(data)
        this.recId = data
        this.getAllTagGroups(data);

      })

    }
    else {
      this.getAllTagGroups(this.parentData);

    }

    this.getSelectedParam()
  }



  getAllTagGroups(recId) {
    if (!recId) {
      return;
    }
    this.tagGroupName = []
    this.tagNames = []
    this.tagDeselectedData = []
    this.selectedValues = []
    this.tempSelectedValue = []
    this.tagGroups.getTaggroups(recId, this.parent).
      subscribe(resp => {
        this.tagGroupName = resp['tag_taglist']
        this.tagNames = resp['tag_data']
      
        this.tagvalues=this.tagNames;
   
        if (this.tagNames) {
          for (let i = 0; i < this.tagNames.length; i++) {
            this.searchText=true;
            this.tempSelectedValue.push(this.tagNames[i].tagid)
           
          }
          this.selectedValues = this.tempSelectedValue

        
        } else {
          this.selectedValues = []
        }

        // console.log(this.tagGroupName)
        // if (this.tagNames) {
        //   this.removeDuplicate(this.tagGroupName, this.tagNames)
        // } else {
        //   this.tagDeselectedData = this.tagGroupName
        // }
        this.tagDeselectedData = this.tagGroupName;
       
    

               // this.selectedValues=this.tagNames.filter(d=>d.tagid)
        // console.log(this.selectedValues)
   })
      

  }
  searchText:boolean=false;
  selectedtag=[];
  getTaggroups($event) {
    
 if ($event) {

      // if (this.tagNames) {
      //   for (let i = 0; i < $event.length; i++) {
      //     if (this.tagNames.some(tag => tag.tagid === $event[i].tagid)) {
      //       // console.log("data")
      //     } else {

      //       this.tagNames.push($event[i])
      //       this.removeDuplicate(this.tagGroupName, this.tagNames)

      //       // console.log("No Data")
        //     }
      //   }
      // }
      // else {
      //   this.tagNames = $event
      // }
      if (this.parent == 'batchdata') {
        console.log($event)
        this.tagNames = $event
        
      } else {
        this.tagNames = $event

      }

    }

    this.TagChildData.emit(this.tagNames);
    if(this.selectedValues.length>0)
    {
this.searchText=true;
this.loadbtn=false;
    }
    else
    {
      this.searchText=false;
      this.loadbtn=false;
    }
    // console.log(this.tagNames)
  }



  removeDuplicate(selectedRows, deSelectedRows) {
    selectedRows = selectedRows.filter(function (cv) {
      return !deSelectedRows.find(function (e) {
        return e.tagname == cv.tagname;
      });
    });
    this.tagDeselectedData = selectedRows

  }

  // test(event: MouseEvent): void {
  //   event.preventDefault();
  //   event.stopPropagation();

  // }

  chipsDisplay() {

  }

  ngOnDestroy() {
    // prevent memory leak when component destroyed
    if (this.eventsSubscription) {
      this.eventsSubscription.unsubscribe();

    }
  }

  loadbtn:boolean= false;
  tagvalues:any;
  
  removetag: any[] = [];





  dataSelected=[];
  newDropdowndata=[]
  flag:boolean=false;
  flag1:boolean=false;
  childData=[];
  newAddedTagData=[];
  
 saveTag() {
this.tagData=[];
if(this.tagNames.length==0)
{
  for(let k=0;k<this.tagvalues.length;k++)
{
  this.tagData.push(
    {
      "tagid": this.tagvalues[k].tagid,
       "tagdataid": this.tagvalues[k].tagdataid,
      "objrecid": this.recId,
      "targetobjname": this.parent,
           "deletionflag":true
    }) 
}

}
else if(this.tagvalues!=undefined || this.tagvalues!=null) {
 for(let i=0;i<this.tagvalues.length;i++)
{
this.flag=false;
for(let j=0;j<this.tagNames.length;j++)
{ 
if(this.tagvalues[i].tagid==this.tagNames[j].tagid)
{
  this.flag=true;
  this.newDropdowndata.push(this.tagNames[j].tagid)
  if(this.tagvalues[i].tagdataid!=null)
{
  
   this.tagData.push(
                          {
                            "tagid": this.tagvalues[i].tagid,
                             "tagdataid": this.tagvalues[i].tagdataid,
                            "objrecid": this.recId,
                            "targetobjname": this.parent,
                                 "deletionflag":false
                          })
  }
  else
  {
    
  }
  }

}
if(this.flag==false)
{
  this.tagData.push(
    {
      "tagid": this.tagvalues[i].tagid,
       "tagdataid": this.tagvalues[i].tagdataid,
      "objrecid": this.recId,
      "targetobjname": this.parent,
           "deletionflag":true
    })
}

}

 }
 else if(this.tagvalues!=undefined && this.tagNames.length!=0)
 {
   for(let i=0;i<this.tagNames.length;i++)
   {
  
  this.tagData.push(
    {
      "tagid": this.tagNames[i].tagid,
       "tagdataid": null,
      "objrecid": this.recId,
      "targetobjname": this.parent,
           "deletionflag":true
    })
  }
 }
 else
 {

 }
 
 console.log(this.newDropdowndata)
 
for(let i=0;i<this.tagNames.length;i++)
{
  this.flag1=false;
for(let j=0;j<this.newDropdowndata.length;j++)
{
if(this.tagNames[i].tagid==this.newDropdowndata[j])
{
  
this.flag1=true;
}

}
if(this.flag1==false)
{

  this.newAddedTagData.push(this.tagNames[i].tagid);
  console.log(this.tagNames[i].tagid)
  this.tagvalues.push({
    "tagid": this.tagNames[i].tagid,
     "tagdataid": null,
    "objrecid": this.recId,
    "targetobjname": this.parent,
          // "deletionflag":false
  })
  this.tagData.push(
    {
      "tagid": this.tagNames[i].tagid,
       "tagdataid": null,
      "objrecid": this.recId,
      "targetobjname": this.parent,
           "deletionflag":false
    })
    
}

}

    this.tagGroups.SaveparameterTags(this.tagData).subscribe(data => {

      if(data!=null)
      {
      this.childData = data['tagdata']['rows'];
      
      for(let i=0;i<this.childData.length;i++)
      {
if(this.childData[i]['TXN_TYPE']=="INSERT")
{


  for(let j=0;j<this.newAddedTagData.length;j++)   
  {
  for(let k=0;k<this.tagvalues.length;k++)
  {
 if(this.newAddedTagData[j]==this.tagvalues[k].tagid)
  {
    
  this.tagvalues[k].tagdataid=this.childData[i]['Inserted Row ID'];
  console.log("New INserted data"+this.childData[i]['Inserted Row ID'])
  }
  }

  }   
      }
    }
    }
      

             this.loadbtn=true;
         this.pushNewCommnet()
       },
         error => {
           this.loadbtn=true;
           console.log(error.error)
         })

 }


// for(let i=0;i<this.tagNames.length;i++)
// {
// for(let j=0;j<this.tagvalues.length;j++)
// {
//   if(this.tagNames[i].tagid==this.tagvalues[j].tagid)
//   {
//     alert(this.tagNames[i].tagid)
//     this.tagData.push(
//                       {
//                         "tagid": this.tagNames[i].tagid,
//                          "tagdataid": this.tagvalues[j].tagdataid,
//                         "objrecid": this.recId,
//                         "targetobjname": this.parent,
//                              "deletionflag":false
//                       })
    
//   }
//   else{
//     this.tagData.push(
//       {
//         "tagid": this.tagNames[i].tagid,
//          "tagdataid": this.tagvalues[j].tagdataid,
//         "objrecid": this.recId,
//         "targetobjname": this.parent,
//              "deletionflag":true
//       })

//   }
// }
// }
//    this.postGeneric.postTag(this.tagData).
//       subscribe(data => {
//         // console.log(data)
//             this.loadbtn=true;
//         this.pushNewCommnet()
//       },
//         error => {
//           this.loadbtn=true;
//           console.log(error.error)
//         })
     
    





//  let tagdataid;

//  console.log(this.selectedValues)
//  console.log(this.tagNames )
//  if(this.tagvalues!=undefined) 
//  {
// for (let i = 0; i < this.tagvalues.length; i++) {
//      for(let j=0;j<this.selectedValues.length;j++)
//         {
//         if(this.tagNames[i].tagid==this.selectedValues[j])
//         {    
//             tagdataid = this.tagNames[i].tagdataid;
//           this.tagData.push(
//             {
//               "tagid": this.tagNames[i].tagid,
//               "tagdataid": tagdataid,
//               "objrecid": this.recId,
//               "targetobjname": this.parent,
//                   // "deletionflag":true
//             })
//             this.loadbtn=true;
//  }}
//  this.tagData.push(
// {
//     "tagid": this.tagvalues[i].tagid,
//     "tagdataid": this.tagvalues[i].tagdataid,
//     "objrecid": this.recId,
//     "targetobjname": this.parent,
//      "deletionflag":true
//   })
//  }
// }
// else
// {
//   for (let i = 0; i < this.tagNames.length; i++) {
//     for(let j=0;j<this.selectedValues.length;j++)
//        {
//        if(this.tagNames[i].tagid==this.selectedValues[j])
//        {    
//            tagdataid = this.tagNames[i].tagdataid;
//          this.tagData.push(
//            {
//              "tagid": this.tagNames[i].tagid,
//              "tagdataid": tagdataid,
//              "objrecid": this.recId,
//              "targetobjname": this.parent,
//                  // "deletionflag":true
//            })
//            this.loadbtn=true;
// }}
// this.tagData.push(
// {
//    "tagid": this.tagNames[i].tagid,
//    "tagdataid": this.tagNames[i].tagdataid,
//    "objrecid": this.recId,
//    "targetobjname": this.parent,
//     "deletionflag":true
//  })
// }
// }
//    this.postGeneric.postTag(this.tagData).
//       subscribe(data => {
//         // console.log(data)
//             this.loadbtn=true;
//         this.pushNewCommnet()
//       },
//         error => {
//           this.loadbtn=true;
//           console.log(error.error)
//         })
    
  

pushNewCommnet() {
    this.dataSubject.pushCommentFlag({ type: 'tag' })
  }

  getSelectedParam = () => {

    this.dataSubject.currentParam.subscribe(data => {

      // console.log(data)
      if (data.message) {
        this.recId = data.message
        this.getAllTagGroups(data.message)
      }
    },
      error => {

        // console.log(error)
      })

  }

}


