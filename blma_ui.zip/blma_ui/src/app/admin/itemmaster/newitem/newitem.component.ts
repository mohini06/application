import { PreferenceService } from './../../../_core/services/preference.service';
import { map } from 'rxjs/operators';
import { AlertService } from './../../../_core/services/alert.service';
import { BatchesService } from './../../../_core/services/batches.service';
import { AttributesComponent } from './../../attributes/attributes.component';
import { itemAllData } from './item-all-data';
import { Newitemlist } from './newitemlist';
import { ItemmasterService } from './../../../_core/services/itemmaster.service';

import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';

import { Component, OnInit, TemplateRef, ViewChild, AfterViewInit,Output,EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { of } from 'rxjs';
import { LoginService } from './../../../_core/services/login.service';


@Component({
  selector: 'app-newitem',
  templateUrl: './newitem.component.html',
  styleUrls: ['./newitem.component.scss']
})
export class NewitemComponent implements OnInit, AfterViewInit {

  @ViewChild(AttributesComponent, { static: true }) child: AttributesComponent;
  @Output() getGroupList = new EventEmitter<string>();
  @Output() createNew = new EventEmitter<string>();
  itemstatusData: any;
  itemtypeData: any;
  itemMasterNewForm: FormGroup;
  itemGroupattributes: any;
  attribute = [];
  attributeGroupnames: any;
  formatedAttributeId = [];
  formatedTagId = [];
  newItemSaveData: Newitemlist = {};
  modalRef: BsModalRef;
  itemAllData: itemAllData = {};
  username: string;
  childData = "";
  attributeData: any;
  formatedAttributeData = [];
  formatedAttributeTable=[]
  tagData = [];
  tableData = [];

  isSubmitted: boolean = false;
  duplicateItemCode: boolean = false;
  dateFormate=""
  sucess: string;
  error: string;
  parent = "item";
  detailsFlag: Boolean = false;
  public defaultDate = new Date()

  itemRoles:any;
  showEsig:boolean=false

  constructor(private roleData:LoginService,private formBuilder: FormBuilder, private modalService: BsModalService,
    private masteservice: ItemmasterService, private batchesService: BatchesService,
     private alert: AlertService,private preference:PreferenceService) { 

     
     }
  // target: string = document.querySelector('.e-toolbar-item.e-active .e-tab-text').innerHTML;
  // @Vi
  
  itemCheckAccessData:any;
  ngOnInit() {

    this.itemMasterNewForm = this.formBuilder.group({
      itemcode: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(500), Validators.pattern(".*\\S.*[a-zA-z0-9 ]")],[this.checkName.bind(this)]],
      itemtype: ['', [Validators.required]],
      shorttitle: ['', [Validators.minLength(2), Validators.maxLength(500)]],
      itemstatus: ['', [Validators.required]],
      description: ['', [Validators.minLength(2), Validators.maxLength(500)]],
      effectivedate: [''],
      id: [''],
      inactivedate: ['']
    });

//Service for Field level Role Access
this.masteservice.fieldLevelAcess("item", null).subscribe(data => {
  this.itemCheckAccessData = data.item.child;
  if(this.itemCheckAccessData!=null)
  {
  for (let obj of this.itemCheckAccessData) {
    for (let keyname in obj) {
      if (obj[keyname].type == "Column") {
        if (obj[keyname].read == false) {
          for (const field in this.itemMasterNewForm.controls) { // 'field' is a string
            if (field == keyname) {
              this.itemMasterNewForm.controls[field].disable();
            }}}
        else {
          if (obj[keyname].update == false) {
            for (const field in this.itemMasterNewForm.controls) { if (field == keyname) {
                this.itemMasterNewForm.controls[field].disable();
              }} }}
      }
      else {  
        //  if (keyname == "comment") {if (obj[keyname].read == false) {this.itemcommentTab = false; }}
        // else if (keyname == "tag") {if (obj[keyname].read == false) { this.itemtagTab = false; }}
        // else if(keyname=="attribute"){if (obj[keyname].read==false){this.itemAttributeTab=false}}
        // else if(keyname=="recipe"){if (obj[keyname].read==false){this.itemRecipeTab=false}} 
      }
    }
  }}
})

    this.getViewItemMasterDetails();
    this.username = this.batchesService.getUserName();
    this.dateFormate=this.preference.getDateFormate()
    //  this.getAttribute('1')

    this.effectivedate.setValue(this.defaultDate)
  }

  ngAfterViewInit() {

  }

  get itemcode() { return this.itemMasterNewForm.get('itemcode'); }
  get itemtype() { return this.itemMasterNewForm.get('itemtype'); }
  get shorttitle() { return this.itemMasterNewForm.get('shorttitle'); }
  get itemstatus() { return this.itemMasterNewForm.get('itemstatus'); }
  get description() { return this.itemMasterNewForm.get('description'); }
  get effectivedate() { return this.itemMasterNewForm.get('effectivedate'); }
  get inactivedate() { return this.itemMasterNewForm.get('inactivedate'); }
  get id() { return this.itemMasterNewForm.get('id'); }

  getViewItemMasterDetails() {
    this.masteservice.getViewItemDetail().
      subscribe(data => {
        // console.log('data', data);
        this.itemstatusData = data.item_status;
        this.itemtypeData = data.item_type;
      })
  }
  saveNewItemDetails() {
    this.isSubmitted = true;
 
    if (!this.itemMasterNewForm.valid) {
      return;
    }
    // return

    this.newItemSaveData.username = this.username
    this.newItemSaveData.description = this.description.value
    this.newItemSaveData.itemstatus = this.itemstatus.value
    this.newItemSaveData.shorttitle = this.shorttitle.value
   
    this.newItemSaveData.itemtype = this.itemtype.value
    this.newItemSaveData.itemcode = this.itemcode.value
    console.log(this.newItemSaveData.itemcode)
    this.newItemSaveData.effectivedate =this.preference.setDateFormate(this.effectivedate.value)
    this.newItemSaveData.inactivedate = this.preference.setDateFormate(this.inactivedate.value)

    


    this.masteservice.saveItem(this.newItemSaveData).
    subscribe(data => {
      // console.log(data);
      this.childData =   data['item'].rows[0]['Inserted Row ID'];
      this.id.setValue( data['INSERTED ROW IDs'])
      this.detailsFlag = true;
      this.alert.success("Successfully saved")
      this.getGroupList.emit(null)
      this.showEsig=true

      //  this.itemMasterForm.reset();
      setTimeout(() => {
        this.alert.removeAlert();
      }, 1500);
    },
      error => {
        if (error.status == 409) {

          this.alert.error("Itemcode already exists")
        } else {

          this.alert.error("Something Went wrong")
        }
      })




    // this.masteservice.saveItemDetails(this.newItemSaveData).
    //   subscribe(data => {
    //     // console.log(data);
    //     this.childData = data['id'];
    //     this.id.setValue(data['id'])
    //     this.detailsFlag = true;
    //     this.alert.success("Successfully saved")
    //     this.getGroupList.emit(null)
    //     this.showEsig=true

    //     //  this.itemMasterForm.reset();
    //     setTimeout(() => {
    //       this.alert.removeAlert();
    //     }, 1500);
    //   },
    //     error => {
    //       if (error.status == 409) {

    //         this.alert.error("Itemcode already exists")
    //       } else {

    //         this.alert.error("Something Went wrong")
    //       }
    //     })
  }


  editNewItemDetails(data: any) {
    // this.showEsig=false

    this.masteservice.updateItem(data).
      subscribe(data => {
        // console.log(data);
        this.alert.success("Successfully saved")
        this.getGroupList.emit(null)
        // this.showEsig=true

        //  this.itemMasterForm.reset();
        setTimeout(() => {
          this.alert.removeAlert();
        }, 1500);
      },
        error => {
          if (error.status == 409) {

            this.alert.error("Itemcode already exists")
          } else {

            this.alert.error("Something Went wrong")
          }
        })
  }

  // onSubmit(){
  //   console.log('value',this.itemMasterForm.value); 
  // }
  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }

  operationEditSave() {
    if (this.childData) {
      // console.log("edit")
      if (this.attributeData) {
        for (let i = 0; i < this.attributeData.attribute_data.length; i++) {
          this.formatedAttributeData.push({ 'attributeid': this.attributeData.attribute_data[i].attributeid, 'attributevalue': this.attributeData.attribute_data[i].attributevalue })

        }

        for (let i = 0; i < this.attributeData['attribute_grpsections'].length; i++) {

          if (this.attributeData['attribute_grpsections'][i].is_table) {
            // console.log(this.attributeData['attribute_datatables']['ag_'+this.attributeData['attribute_grpsections'][i].attributegroupid])
            for (let j = 0; j < this.attributeData['attribute_datatables']['ag_' + this.attributeData['attribute_grpsections'][i].attributegroupid].rows.length; j++) {
              // console.log( this.attributeData['attribute_datatables']['ag_'+this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j])
  
              for (let k = 0; k < this.attributeData['attribute_datatables']['ag_' + this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j].length; k++) {
                // console.log(this.attributeData['attribute_datatables']['ag_'+this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j][k])
                this.formatedAttributeTable.push(this.attributeData['attribute_datatables']['ag_' + this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j][k])
              }
            }
          }
  
  
        }

      }
      else {
        this.formatedAttributeData = [];
      }
      this.itemAllData.itemid = this.childData
      this.itemAllData.itemcode = this.itemcode.value
      this.itemAllData.itemtype = this.itemtype.value
      this.itemAllData.shorttitle = this.shorttitle.value
      this.itemAllData.itemstatus = this.itemstatus.value
      this.itemAllData.description = this.description.value
      this.itemAllData.attributes = this.formatedAttributeData;
      this.itemAllData.username = this.username;
      this.itemAllData.inactivedate=this.preference.setDateFormate(this.inactivedate.value)
      this.itemAllData.effectivedate=this.preference.setDateFormate(this.effectivedate.value)
      this.itemAllData.attributetable =  this.formatedAttributeTable

      if (this.tagData) {
        for (let i = 0; i < this.tagData.length; i++) {
          this.formatedTagId.push({ 'id': this.tagData[i].tagid })
        }
      } else {
        this.formatedTagId = []
      }

      this.itemAllData.tags = this.formatedTagId;
      // console.log(this.formatedAttributeData)
      this.editNewItemDetails(this.itemAllData)

    }
    else {
      // console.log("save")
      this.saveNewItemDetails()
    }
  }


  checkItemCode() {
    const itemcode = this.itemMasterNewForm.get('itemcode');
    this.masteservice.checkItemCode(this.itemcode.value,this.childData).
      subscribe(data => {
        // console.log(data);
        this.alert.removeAlert()
      },
        error => {
          // console.log(error.error)
          this.alert.error("Itemcode already exists")
        })
  }

  checkName(control: AbstractControl) {
    if (control.value) {
      return this.masteservice.checkItemCode(control.value,this.childData).pipe(
        map(response => {
          // console.log(response)
          return response ?   null:{ forbiddenName: {value: control.value}};
         }) // use observables, don't convert to promises
       );
    }
    return of(null); // gotta return an observable for async
  }


  updOne(data): void {
    // console.log(data)
    this.attributeData = data
  }

  getTagData(tagdata): void {
    this.tagData = tagdata
    // console.log(data)
  }

  createNewTab(){
    this.createNew.emit(null)
    // console.log("new clicked")

  }

  removeAlert()
  {
    this.alert.removeAlert();
    
  }
}
