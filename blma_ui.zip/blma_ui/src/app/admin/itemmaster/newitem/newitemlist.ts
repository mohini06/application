export interface Newitemlist {
    itemcode?: string;
    itemtype?: string;
    shorttitle?: string;
    description?: string;
    username?: string;
    itemstatus?: string;
    attributes?: (AttributesEntity)[] | null;
    inactivedate?:string;
    effectivedate?:string;
  }
  export interface AttributesEntity {
    attributeid: number;
  }
  