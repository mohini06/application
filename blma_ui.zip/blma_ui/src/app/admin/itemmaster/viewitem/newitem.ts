export interface Newitem {
    itemcode?: string;
    itemtype?: string;
    shorttitle?: string;
    description?: string;
    username?: string;
    itemid?:string;
    itemstatus?: string;
    attributes?: (AttributesEntity)[] | null;
    effectivedate?:string;
    inactivedate?:string;
  }
  export interface AttributesEntity {
    attributeid: number;
  }
  