import { PreferenceService } from './../../../_core/services/preference.service';
import { BatchesService } from './../../../_core/services/batches.service';
import { itemAllData } from './../newitem/item-all-data';
import { DataService } from './../../../_core/services/data.service';
import { ItemmasterService } from './../../../_core/services/itemmaster.service';
import { AlertService } from './../../../_core/services/alert.service';

import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Newitem } from './newitem';
import { Component, OnInit, TemplateRef, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LoginService } from './../../../_core/services/login.service';
// import { Input } from '@syncfusion/ej2-inputs';
// export let ddlObject: ViewitemComponent;

@Component({
  selector: 'app-viewitem',
  templateUrl: './viewitem.component.html',
  styleUrls: ['./viewitem.component.scss']
})
export class ViewitemComponent implements OnInit {
  @Input() itemlistRowData: Newitem;
  @Output() getGroupList = new EventEmitter<string>();
  @Output() createNew = new EventEmitter<string>();

  showEsig: boolean = false
  itemstatusData: any;
  itemtypeData: any;
  itemMasterForm: FormGroup;
  itemGroupattributes: any;
  attribute = [];
  attributeGroupnames: any;
  formatedAttributeId = [];
  formatedAttributeTable = [];
  formatedTagId = [];
  parent = "item";


  attributeData: any = [];
  childData = [];

  itemAllData: itemAllData = {};
  formatedAttributeData = [];
  updateItemSaveData: Newitem = {};
  modalRef: BsModalRef;
  username: string;
  sucess: string;
  error: string;

  tagData = [];
  dateFormate = ""

  esigData = { status: false }

  detailsFlag: Boolean = false;
  
  constructor(private roleData: LoginService, private formBuilder: FormBuilder, private modalService: BsModalService,
    private masterservice: ItemmasterService, private data: DataService,
    private batchesService: BatchesService, private alert: AlertService, private preference: PreferenceService) {

  }
  // target: string = document.querySelector('.e-toolbar-item.e-active .e-tab-text').innerHTML;
  // @ViewChild('samples',{static:false}) ddlObj: ViewitemComponent;

  itemCheckAccessData: any;
  itemcommentTab: boolean = true;
  itemtagTab: boolean = true;
  itemRecipeTab:boolean=true;
  itemAttributeTab:boolean=true;
  ngOnInit() {
    this.itemMasterForm = this.formBuilder.group({
      itemcode: [this.itemlistRowData.itemcode, Validators.required],
      itemtype: [this.itemlistRowData.itemtype, Validators.required],
      shorttitle: [this.itemlistRowData.shorttitle],
      itemstatus: [this.itemlistRowData.itemstatus, Validators.required],
      description: [this.itemlistRowData.description],
      effectivedate: [this.preference.setDate(this.itemlistRowData.effectivedate)],
      inactivedate: [this.preference.setDate(this.itemlistRowData.inactivedate)],
      id: [this.itemlistRowData.itemid],

    });


    //Service for Field level Role Access
    this.masterservice.fieldLevelAcess("item", null).subscribe(data => {
      this.itemCheckAccessData = data.item.child;
      if(this.itemCheckAccessData!=null)
      {
      for (let obj of this.itemCheckAccessData) {
        for (let keyname in obj) {
          if (obj[keyname].type == "Column") {
            if (obj[keyname].read == false) {
              for (const field in this.itemMasterForm.controls) { // 'field' is a string
                if (field == keyname) {
                  this.itemMasterForm.controls[field].disable();
                }}}
            else {
              if (obj[keyname].update == false) {
                for (const field in this.itemMasterForm.controls) { if (field == keyname) {
                    this.itemMasterForm.controls[field].disable();
                  }} }}
          }
          else {  
             if (keyname == "comment") {if (obj[keyname].read == false) {this.itemcommentTab = false; }}
            else if (keyname == "tag") {if (obj[keyname].read == false) { this.itemtagTab = false; }}
            else if(keyname=="attribute"){if (obj[keyname].read==false){this.itemAttributeTab=false}}
            else if(keyname=="recipe"){if (obj[keyname].read==false){this.itemRecipeTab=false}} }
        }
      }}
    })


    this.getViewItemMasterDetails();
    this.username = this.batchesService.getUserName();
    this.dateFormate = this.preference.getDateFormate()
    //  console.log(this,this.dateFormate)


  }

  get itemcode() { return this.itemMasterForm.get('itemcode'); }
  get itemtype() { return this.itemMasterForm.get('itemtype'); }
  get shorttitle() { return this.itemMasterForm.get('shorttitle'); }
  get itemstatus() { return this.itemMasterForm.get('itemstatus'); }
  get description() { return this.itemMasterForm.get('description'); }
  get effectivedate() { return this.itemMasterForm.get('effectivedate'); }
  get inactivedate() { return this.itemMasterForm.get('inactivedate'); }
  get id() { return this.itemMasterForm.get('id'); }


  getViewItemMasterDetails() {
    this.masterservice.getViewItemDetail().
      subscribe(data => {
        // console.log('data', data);
        this.itemstatusData = data.item_status;
        this.itemtypeData = data.item_type;
      })
  }


  editNewItemDetails(data: any) {

    this.masterservice.editItemDetails(data).
      subscribe(data => {
        // console.log(data);

        //  this.itemMasterForm.reset();
        this.getGroupList.emit(null)
        this.alert.success("Successfully saved")

        //  this.itemMasterForm.reset();
        setTimeout(() => {
          this.alert.removeAlert();
        }, 1500);
      },
        error => {
          if (error.status == 409) {

            this.alert.error("Itemcode already exists")
          } else {

            this.alert.error("Something Went wrong")
          }

        })
  }

  effectivestartdate: any;
  onChangeeffective(args) {

    this.effectivestartdate = args.value;
  }

  effectiveenddate: any;
  onChangeeffectiveend(args) {

    this.effectiveenddate = args.value;
  }

  operationEditSave() {

    this.showEsig = true

    if (this.esigData.status) {
      console.log(true)


      if (this.attributeData) {
        for (let i = 0; i < this.attributeData.attribute_data.length; i++) {
          this.formatedAttributeData.push({ 'attributeid': this.attributeData.attribute_data[i].attributeid, 'attributevalue': this.attributeData.attribute_data[i].attributevalue })

        }
        // console.log(this.attributeData['attribute_datatables']['ag_'+'8'])

        for (let i = 0; i < this.attributeData['attribute_grpsections'].length; i++) {

          if (this.attributeData['attribute_grpsections'][i].is_table) {
            // console.log(this.attributeData['attribute_datatables']['ag_'+this.attributeData['attribute_grpsections'][i].attributegroupid])
            for (let j = 0; j < this.attributeData['attribute_datatables']['ag_' + this.attributeData['attribute_grpsections'][i].attributegroupid].rows.length; j++) {
              // console.log( this.attributeData['attribute_datatables']['ag_'+this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j])

              for (let k = 0; k < this.attributeData['attribute_datatables']['ag_' + this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j].length; k++) {
                // console.log(this.attributeData['attribute_datatables']['ag_'+this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j][k])
                this.formatedAttributeTable.push(this.attributeData['attribute_datatables']['ag_' + this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j][k])
              }
            }
          }


        }

        // console.log(this.formatedAttributeTable)

      } else {
        this.formatedAttributeData = []
      }
      this.itemAllData.itemid = this.itemlistRowData.itemid
      this.itemAllData.itemcode = this.itemcode.value
      this.itemAllData.itemtype = this.itemtype.value
      this.itemAllData.shorttitle = this.shorttitle.value
      this.itemAllData.itemstatus = this.itemstatus.value
      this.itemAllData.description = this.description.value
      this.itemAllData.attributes = this.formatedAttributeData;
      this.itemAllData.username = this.username;
      this.itemAllData.effectivedate = this.preference.setDateFormate(this.effectivestartdate)
      // this.itemAllData.inactivedate = this.effectiveenddate

      this.itemAllData.inactivedate = this.preference.setDateFormate(this.inactivedate.value)
      this.itemAllData.attributetable = this.formatedAttributeTable
      if (this.tagData) {
        for (let i = 0; i < this.tagData.length; i++) {
          this.formatedTagId.push({ 'id': this.tagData[i].tagid })
        }
      } else {
        this.formatedTagId = []
      }

      this.itemAllData.tags = this.formatedTagId;
      // console.log(this.itemAllData)
      this.editNewItemDetails(this.itemAllData)

      // this.editNewItemDetails()

    }
    else {
      console.log(false)
      // this.alert.error("Some thing went wrong in Esig!")
      return;
    }

  }


  config = {
    backdrop: true,
    ignoreBackdropClick: true
  };
  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);

  }
  openModalAudit(audithistory: TemplateRef<any>) {
    this.newParam(this.itemlistRowData.itemid, 'item')
    this.modalRef = this.modalService.show(audithistory, Object.assign({}, this.config, { class: 'gray modal-lg' }));

  }

  newParam(param: any, table: any) {
    this.data.changeParam({ message: param, table: table })
  }


  eventHandler(event: string[]) {
    // console.log(event)
    this.childData = event;
  }


  updOne(data): void {
    // console.log(data)
    this.attributeData = data
  }

  getTagData(tagdata): void {
    this.tagData = tagdata
    // console.log(tagdata)
  }

  getEsigData(esigData): void {
    this.esigData = esigData
    this.showEsig = false

    console.log(esigData)
    this.operationEditSave();

  }

  createNewTab() {
    this.createNew.emit(null)
    // console.log("new clicked")

  }

}
