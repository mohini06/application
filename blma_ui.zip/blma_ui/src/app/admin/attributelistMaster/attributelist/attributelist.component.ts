import { map } from 'rxjs/operators';
import { AlertService } from './../../../_core/services/alert.service';
import { DataService } from './../../../_core/services/data.service';
import { TabDirective } from 'ngx-bootstrap/tabs';
import { ItemmasterService } from "./../../../_core/services/itemmaster.service";
import { Component, OnInit, ViewChild, Input } from "@angular/core";
import { ClickEventArgs } from "@syncfusion/ej2-navigations";
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { DataManager, ODataAdaptor, WebApiAdaptor } from "@syncfusion/ej2-data";
import { LoginService } from './../../../_core/services/login.service';
import {
  GridComponent,
  ToolbarItems,
  EditService,
  PageService,
  CommandColumnService,
  CommandModel,
  PageSettingsModel,
  ColumnMenuService,
  RowSelectEventArgs
} from "@syncfusion/ej2-angular-grids";
import { of } from 'rxjs';


@Component({
  selector: 'app-attributelist',
  templateUrl: './attributelist.component.html',
  styleUrls: ['./attributelist.component.scss'],
  providers: [EditService, PageService, CommandColumnService, ColumnMenuService]
})
export class AttributelistComponent implements OnInit {
  @Input() parentData: any;
  public data: DataManager;
  public filterSettings: Object;
  public editSettings: Object;
  public toolbarOptions: ToolbarItems[];
  public dTdata: any;
  public editparams: Object;
  public commands: CommandModel[];
  public initialPage: PageSettingsModel;
  attributeListtypeData: any;
  attributeGroupData: any;
  attributeListDataformatData: any;
  attributeListNameData: any;
  attributeListMasterNewForm: FormGroup;
  public formatOptions: any;
  @ViewChild("grid", { static: false })
  public grid: GridComponent;

  isSubmitte: boolean = false
  //DropDown data
  type = [];
  dataFormate = [];
  listName = [];
  isSubmitted: boolean = false;

  public pageSizes: number[] = [10, 20, 100, 500, 1000];
  public pageSettings: Object;

  attributeRoles:any
  constructor(private alert: AlertService, private formBuilder: FormBuilder, 
    private masterservice: ItemmasterService, private dataservice: DataService,private role:LoginService) {
      this.attributeRoles=this.role.Rolesdata['attribute']
     }

  toolbarClick(args: ClickEventArgs): void {
    if (args.item.id === "Grid_excelexport") {
      // 'Grid_excelexport' -> Grid component id + _ + toolbar item name
      this.grid.excelExport();
    }
  }
  ngOnInit() {

    this.pageSettings = { pageCount: 10, pageSize: this.pageSizes[0], pageSizes: this.pageSizes };

    this.filterSettings = { type: "Menu" };
    this.toolbarOptions = ["ExcelExport", "Search", 'Add', 'Edit', 'Update', 'Cancel'];
    this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Dialog' };
    this.formatOptions = { type: 'date', format: "MM/dd/yyyy hh:mm a" };

    this.attributeListMasterNewForm = this.formBuilder.group({
      attributename: ['', [Validators.required, Validators.pattern(".*\\S.*[a-zA-z0-9 ]")],[this.checkName.bind(this)]],
      attributeListcaption: ['', [Validators.required, Validators.pattern(".*\\S.*[a-zA-z0-9 ]")]],
      attributeListtype: ['', ],
      attributeListDataformat: ['', [Validators.required]],
      startdate: [''],
      enddate: [''],
      attributeid: [0],
      // allowBatch: [''],
      description: [''],
      // attributeGroup: [''],
      attributeListName: [''],
      limitToList: [''],
      allowmultiplerecs: [''],
      seqno: [null]
    });

    this.getLookupdata()
    this.getList()

  }
  get attributeid() { return this.attributeListMasterNewForm.get('attributeid'); }
  get attributename() { return this.attributeListMasterNewForm.get('attributename'); }
  get attributeListName() { return this.attributeListMasterNewForm.get('attributeListName'); }
  get attributeListcaption() { return this.attributeListMasterNewForm.get('attributeListcaption'); }
  get attributeListtype() { return this.attributeListMasterNewForm.get('attributeListtype'); }
  get attributeListDataformat() { return this.attributeListMasterNewForm.get('attributeListDataformat'); }
  get startdate() { return this.attributeListMasterNewForm.get('startdate'); }
  get enddate() { return this.attributeListMasterNewForm.get('enddate'); }
  // get attributeGroup() { return this.attributeListMasterNewForm.get('attributeGroup'); }
  // get allowBatch() { return this.attributeListMasterNewForm.get('allowBatch'); }
  get limitToList() { return this.attributeListMasterNewForm.get('limitToList'); }
  get description() { return this.attributeListMasterNewForm.get('description'); }
  get allowmultiplerecs() { return this.attributeListMasterNewForm.get('allowmultiplerecs'); }
  get seqno() { return this.attributeListMasterNewForm.get('seqno'); }


  setFormdata(data) {
    // console.log(this.listName.find(rec => rec.displayvalue == data.listid).savedvalue)
    // console.log(this.dataFormate.find( rec => rec.displayvalue == data.formatname).displayvalue)
    // console.log(data.listid)
    // return;
    this.attributeid.setValue(data.attributeid)
    this.attributename.setValue(data.uniquename)
    this.attributeListName.setValue(data.listid)
    this.attributeListcaption.setValue(data.caption)
    if (data.attributetype) {
      this.attributeListtype.setValue(this.type.find(rec => rec.displayvalue == data.attributetype).savedvalue)

    } else {
      this.attributeListtype.setValue(null)
    }
    if (data.formatname) {
      this.attributeListDataformat.setValue(this.dataFormate.find(rec => rec.displayvalue == data.formatname).savedvalue)

    } else {
      this.attributeListDataformat.setValue(null)
    }
    this.startdate.setValue(data.effectivedate)
    this.enddate.setValue(data.inactivedate)
    this.limitToList.setValue(data.limittolist)
    this.description.setValue(data.dataentryinstructions)
    this.allowmultiplerecs.setValue(data.allowmultiplerecs)
    this.seqno.setValue(data.seqno)
  }


  public columns: object[] = [
    {
      field: 'caption', headerText: 'Caption'
    },
    {
      field: 'uniquename', headerText: 'Name'
    },

    {
      field: 'seqno', headerText: 'Sequence'
    },
    {
      field: 'attributetype', headerText: 'Attribute Type'
    },
    {
      field: 'formatname', headerText: 'Data Format'
    }
    // {
    //   headerText: 'Action', template: '<ng-template #template let-dTdata><i class="fa fa-edit" (click)= "getRowData($event)"></i> </ng-template>'
    // }
  ];

  getList() {
    this.masterservice.getList(this.parentData).
      subscribe(data => {
        this.listName = data['parameter_listnames']
        // console.log(this.listDropDown)
      },
        error => {
          // this.alert.error(error.error.message)
          console.log(error.error)
        })
  }

  getLookupdata() {
    this.masterservice.getAttributLookupData().
      subscribe(data => {
        // console.log(data); 
        this.type = data['attribute_type']
        this.dataFormate = data['attribute_format']

      },
        error => {

          //  console.log(error.error)
        })
  }

  getAtttributeList() {
    this.masterservice.getAttributList(this.parentData).
      subscribe(data => {
        // console.log(data);
        this.dTdata = data['ag_attributes']
      },
        error => {

          //  console.log(error.error)
        })
  }

  saveAttribute(data: any) {
    this.masterservice.saveAttribute(data, this.parentData).
      subscribe(data => {
        console.log(data);
        this.getAtttributeList()
      },
        error => {

          //  console.log(error.error)
        })
  }

  limitolistChange(event) {
    if (event) {
      this.limitToList.setValue(true)
    } else {
      this.limitToList.setValue(false)
    }
  }

  //data table operation

  actionBegin(args): void {
    // console.log(args)

    if (args.requestType === 'beginEdit' || args.requestType === 'add') {
      this.isSubmitted = false;

      if (args.requestType === 'beginEdit') {
        this.setFormdata(args.rowData)

      } else {
        this.resetForm(this.attributeListMasterNewForm)
      }

      if (args.requestType === 'add') {
        this.resetForm(this.attributeListMasterNewForm)

      }


    }
    if (args.requestType === 'save') {
      this.isSubmitted = true;
      // if (!this.valVer()) {
      //   return;
      // }
      if (this.attributeListMasterNewForm.valid) {

        if (args.action === 'edit') {
          this.saveAttribute(this.attributeListMasterNewForm.value)
          this.resetForm(this.attributeListDataformatData)

        }
        if (args.action === 'add') {
          this.saveAttribute(this.attributeListMasterNewForm.value)
          this.resetForm(this.attributeListDataformatData)

        }

        // args.data = this.versionForm.value;
      } else {
        args.cancel = true;
      }
    }

  }


  actionComplete(args) {
    if ((args.requestType === 'beginEdit' || args.requestType === 'add')) {
      const dialog = args.dialog;

      // console.log(args)
      // change the header of the dialog
      dialog.header = args.requestType === 'beginEdit' ?  args.rowData['caption'] : 'New Attribute';
    }
  }

  checkAttribute() {
    let status
    this.masterservice.checkAttribute(this.attributename.value,this.attributeid.value).
      subscribe(data => {
        this.alert.removeAlertChild()
        status = true;
      },
        error => {
          this.alert.errorChild("Attribute Name Already exists");
          status = false;
          //  console.log(error.error)
        })
    return status
  }

  checkName(control: AbstractControl) {
    if (control.value) {
      return this.masterservice.checkAttribute(this.attributename.value,this.attributeid.value).pipe(
        map(response => {
          // console.log(response)
          return response ?   null:{ forbiddenName: {value: control.value}};
         }) // use observables, don't convert to promises
       );
    }
    return of(null); // gotta return an observable for async
  }


  onlyFloat(event) {
    let charCode = (event.which) ? event.which : event.keyCode;
    if (charCode != 46 && charCode > 31
      && (charCode < 48 || charCode > 57))
      return false;
    return true;
  }

  resetForm(form: FormGroup) {

    form.reset();

    Object.keys(form.controls).forEach(key => {
      form.get(key).setErrors(null);
    });
  }

}



