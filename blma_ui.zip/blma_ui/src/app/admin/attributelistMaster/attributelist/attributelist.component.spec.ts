import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AttributelistComponent } from './attributelist.component';

describe('AttributelistComponent', () => {
  let component: AttributelistComponent;
  let fixture: ComponentFixture<AttributelistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AttributelistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AttributelistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
