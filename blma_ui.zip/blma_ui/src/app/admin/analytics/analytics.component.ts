import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';


@Component({
  selector: 'app-analytics',
  templateUrl: './analytics.component.html',
  styleUrls: ['./analytics.component.scss']
})
export class AnalyticsComponent implements OnInit {

   myTemplate: any = "";
    constructor(private http: HttpClient,public sanitizer: DomSanitizer) {
    }

  ngOnInit() {


    // this.http.get("https://modeanalytics.com/blma/reports/9fd9966bc34c/", { responseType: 'text' })
    // .subscribe(
    //   (data: any) => {
    //     this.myTemplate = data;
    //   }
    // );

    
}
  

}
