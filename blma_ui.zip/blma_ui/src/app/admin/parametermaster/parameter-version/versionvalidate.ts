import {AbstractControl} from '@angular/forms';
export class Versionvalidate {
// constructor(private masterService:ItemmasterService)
// {}
// static versionValidate(signupService: ItemmasterService) {
//     return (control: AbstractControl) => {
//       return signupService.valVersion(control.value).map(res => {
//         return res ? null : { emailTaken: true };
//       });
//     };
//   }
}
