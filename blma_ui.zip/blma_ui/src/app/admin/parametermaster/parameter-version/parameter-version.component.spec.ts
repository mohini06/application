import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParameterVersionComponent } from './parameter-version.component';

describe('ParameterVersionComponent', () => {
  let component: ParameterVersionComponent;
  let fixture: ComponentFixture<ParameterVersionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParameterVersionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParameterVersionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
