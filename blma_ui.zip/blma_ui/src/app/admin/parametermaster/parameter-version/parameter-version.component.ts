import { Observable } from 'rxjs/Observable';
import { AlertService } from './../../../_core/services/alert.service';
import { BatchesService } from './../../../_core/services/batches.service';
import { ItemmasterService } from './../../../_core/services/itemmaster.service';

import { Component, OnInit, ViewChild, Input } from "@angular/core";
import { ClickEventArgs } from "@syncfusion/ej2-navigations";
import { FormGroup, AbstractControl, FormControl, Validators } from '@angular/forms';
import {
  GridComponent,
  ToolbarItems,
  EditService,
  PageService,
  ToolbarService,
  CommandColumnService,
  CommandModel,
  PageSettingsModel,
  ColumnMenuService,
  RowSelectEventArgs, DialogEditEventArgs, SaveEventArgs
} from "@syncfusion/ej2-angular-grids";
import { Browser } from '@syncfusion/ej2-base';
import { Dialog } from '@syncfusion/ej2-angular-popups';
import { DataUtil } from '@syncfusion/ej2-data';
import { DialogComponent } from 'ej-angular2';

@Component({
  selector: 'app-parameter-version',
  templateUrl: './parameter-version.component.html',
  styleUrls: ['./parameter-version.component.scss'],
  providers: [EditService, PageService, CommandColumnService, ColumnMenuService]
})
export class ParameterVersionComponent implements OnInit {
  // public data: DataManager;
  private eventsSubscription: any

  @Input() parentData: any;
  @Input() parent: any;
  @Input() formData: Observable<void>;

  public filterSettings: Object;
  public editSettings: Object;
  public toolbarOptions: ToolbarItems[];
  public data: Object[];
  public editparams: Object;
  public toolbar: string[];
  public commands: CommandModel[];
  public initialPage: PageSettingsModel;
  @ViewChild("grid", { static: false })
  public grid: GridComponent;
  public versionForm: FormGroup;
  public submitClicked: boolean = false;
  dataFormateDropDown = [];
  limittolistDropDown = [];
  versionData = [];
  listDropDown = [];
  uomDropDown = [];
  username: any;
  firstchk: boolean = true
  secondchk: boolean = false
  thirdchk: boolean = false
  fourthchk: boolean = false
  Expandcollapse: string = 'Expand All'
  public pageSettings: Object;
  closeDialog: boolean = false;

  allowVersion: any;
  constructor(private masterservice: ItemmasterService, private batchesService: BatchesService, private alert: AlertService) { }
  toolbarClick(args: ClickEventArgs): void {
    // console.log(args.item.id)
    if (args.item.id === "VersionGrid_excelexport") {
      // 'Grid_excelexport' -> Grid component id + _ + toolbar item name
      this.grid.excelExport();
    }
  }
  ngOnInit() {

    this.eventsSubscription = this.formData.subscribe(data => {
      this.getUOMList(data)
      this.getDataFormate(data)
      
      // console.log(data)
      this.allowVersion = data
      if (!this.allowVersion.enableVersion) {
        this.editSettings = { allowAdding: false };
        return;
      } else {
        this.editSettings = { allowAdding: true };
      }
      this.getAllVersion()
    }

    );

    this.initialPage = { pageSizes: true, pageSize: 10 };
    this.filterSettings = { type: "Menu" };
    this.toolbarOptions = ["ExcelExport", "Search", 'Add', 'Edit', 'Update', 'Cancel'];
    this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Dialog' };

    this.getList()

    this.limittolistDropDown = [true, false]
    // this.parameterversionid.patchValue(0)
    this.username = this.batchesService.getUserName();
    this.Expandcollapse = 'Expand All'



  }
  createFormGroup(data: IOrderModel): FormGroup {
    return new FormGroup({
      dataentrycaption: new FormControl(data.dataentrycaption, Validators.required),
      parameterversionid: new FormControl(data.parameterversionid),
      stepnolabel: new FormControl(data.stepnolabel),
      stepno: new FormControl(data.stepno),
      sortno: new FormControl(data.sortno),
      stepdescription: new FormControl(data.stepdescription),
      defaultvalue: new FormControl(data.defaultvalue),
      // defaultuom: new FormControl(this.uomDropDown.find(rec => rec.displayvalue == data.defaultuom).savedvalue),
      defaultuom: new FormControl(data.defaultuom, Validators.required),
      dataentryinstructions: new FormControl(data.dataentryinstructions),
      limittolist: new FormControl(data.limittolist),
      listid: new FormControl(data.listid),
      // listid: new FormControl((this.listDropDown.find(rec => rec.displayvalue == data.listid).savedvalue)),
      versionstart: new FormControl(data.versionstart, Validators.required),
      versionend: new FormControl(data.versionend),
      specmin: new FormControl(data.specmin),
      specmax: new FormControl(data.specmax),
      effectivestartdate: new FormControl(data.effectivestartdate),
      effectiveenddate: new FormControl(data.effectiveenddate),
      // dataformatid: new FormControl(this.dataFormateDropDown.find(rec => rec.displayvalue == data.dataformatid).savedvalue, Validators.required),
      dataformatid: new FormControl(data.dataformatid, Validators.required),
      lockrec: new FormControl(data.lockrec),
      lockuom: new FormControl(data.lockuom),
      verificationrequired: new FormControl(data.verificationrequired),
      comments: new FormControl(data.comments)
    });

  }

  actionBegin(args): void {
    // console.log(args)

    if (args.requestType === 'beginEdit' || args.requestType === 'add') {
      this.submitClicked = false;
      this.versionForm = this.createFormGroup(args.rowData);
    }
    if (args.requestType === 'save') {
      // args.cancel = true;
      // console.log(args)
      this.submitClicked = true;

      if (this.versionForm.valid) {

        if (args.action === 'edit') {
          // this.saveVersion(this.versionForm.value)
          // console.log("Edited")
          args.cancel = true;
          this.masterservice.saveParameterVersion(this.versionForm.value, this.username, this.parentData).
            subscribe(data => {
              // console.log(data)
              // this.getAllVersion()

              if (data.statusCode == 409) {
                this.alert.errorChild(data.statusMsg)
                // this.versionstart.setValue("");

              } else if (data.statusCode == "400") {


                this.alert.errorChild(data.statusMsg)
                return;

              }

              else {
                this.alert.removeAlertChild();
                // console.log("success")
                // document.getElementById("versionPopUp").style.display = "none";
                const dialog = args.dialog;
                dialog.hide()
                this.getAllVersion()

              }

            },
              error => {
                // this.alert.error(error.error.message)
                // this.getAllVersion()
                console.log(error.error)
              })


        }
        if (args.action === 'add') {

          // this.saveVersion(this.versionForm.value)
          // console.log(this.versionForm.value)
          this.masterservice.saveParameterVersion(this.versionForm.value, this.username, this.parentData).
            subscribe(data => {
              // console.log(data)
              // this.getAllVersion()
              if (data.statusCode == 409) {
                this.alert.errorChild(data.statusMsg)
                // this.versionstart.setValue("");
                args.cancel = true;
              } else if (data.statusCode == "400") {
                this.alert.errorChild(data.statusMsg)
                args.cancel = true;
              }
              else {
                this.alert.removeAlertChild()
                const dialog = args.dialog;
                dialog.hide()
                this.getAllVersion()
              }
            },
              error => {
                // this.alert.error(error.error.message)
                // this.getAllVersion()
                console.log(error.error)
              })

          args.cancel = true;

        }

        // args.data = this.versionForm.value;

      } else {
        args.cancel = true;
      }

    }

  }


  actionComplete(args) {

    // console.log(this.versionData)
    if ((args.requestType === 'beginEdit' || args.requestType === 'add')) {
      const dialog = args.dialog;
      if (args.requestType == "beginEdit") {
        // (document.getElementsByClassName("e-tbar-btn")[4] as any).click();       //Get the toolbar add button and perform click 
        dialog.element.querySelectorAll(".e-primary")[0].innerHTML = "Save Version";  //Customize the default “save” button text 

      }
      if (args.requestType === 'add') {
        let dialog = args.dialog;
        dialog.element.querySelectorAll(".e-primary")[0].innerHTML = "Save Version";  //Customize the default “save” button text 

      }
      // console.log(args)
      // change the header of the dialog
      dialog.header = args.requestType === 'beginEdit' ? args.rowData['dataentrycaption'] : 'New Version';
    }
  }

  get dataentrycaption() { return this.versionForm.get('dataentrycaption'); }
  get parameterversionid() { return this.versionForm.get('parameterversionid'); }
  get stepno() { return this.versionForm.get('stepno'); }
  get stepnolabel() { return this.versionForm.get('stepnolabel'); }
  get sortno() { return this.versionForm.get('sortno'); }
  get stepdescription() { return this.versionForm.get('stepdescription'); }
  get defaultvalue() { return this.versionForm.get('defaultvalue'); }
  get defaultuom() { return this.versionForm.get('defaultuom'); }
  get dataentryinstructions() { return this.versionForm.get('dataentryinstructions'); }
  get limittolist() { return this.versionForm.get('limittolist'); }
  get dropdownvalues() { return this.versionForm.get('dropdownvalues'); }
  get listid() { return this.versionForm.get('listid'); }
  get versionstart() { return this.versionForm.get('versionstart'); }
  get versionend() { return this.versionForm.get('versionend'); }
  get specmin() { return this.versionForm.get('specmin'); }
  get specmax() { return this.versionForm.get('specmax'); }
  get effectivestartdate() { return this.versionForm.get('effectivestartdate'); }
  get effectiveenddate() { return this.versionForm.get('effectiveenddate'); }
  get dataformatid() { return this.versionForm.get('dataformatid'); }
  get lockrec() { return this.versionForm.get('lockrec'); }
  get lockuom() { return this.versionForm.get('lockuom'); }
  get verificationrequired() { return this.versionForm.get('verificationrequired'); }
  get comments() { return this.versionForm.get('comments'); }


  limitolistChange(event) {
    if (event) {
      this.limittolist.setValue(true)
    } else {
      this.limittolist.setValue(false)
    }
  }


  getDataFormate(data) {
    this.masterservice.getDataFormat(data.datatypeid).
      subscribe(data => {
        this.dataFormateDropDown = data.parameter_dataformat
        // console.log(this.dataFormateDropDown)
      },
        error => {
          // this.alert.error(error.error.message)
          console.log(error.error)
        })
  }


  getList() {
    this.masterservice.getList(this.parentData).
      subscribe(data => {
        this.listDropDown = data['parameter_listnames']
        //  console.log(this.listDropDown)
      },
        error => {
          // this.alert.error(error.error.message)
          console.log(error.error)
        })
  }

  getUOMList(data) {
    // console.log(data.parameteruom)
    let uom = data.parameteruom
    if (uom == '%') {
      uom = '%25'
    }
    this.masterservice.getUom(uom).
      subscribe(data => {
        this.uomDropDown = data.parameter_default_uom
        // console.log(data)
      },
        error => {
          // this.alert.error(error.error.message)
          console.log(error.error)
        })
  }


  getAllVersion() {
    this.masterservice.getAllVersionData(this.parentData, 'parameter').
      subscribe(data => {
        this.versionData = data.parameter_version
        for (let i = 0; i < this.versionData.length; i++) {
          if (this.versionData[i].versionend == null || this.versionData[i].versionend == "") {
            this.editSettings = { allowAdding: false };
            return;
          } else {
            this.editSettings = { allowAdding: true };
          }
        }

        if (!this.allowVersion.enableVersion) {
          this.editSettings = { allowAdding: false };
          return;
        } else {
          this.editSettings = { allowAdding: true };
        }
      },
        error => {
          // this.alert.error(error.error.message)
          console.log(error.error)
        })
  }

  saveVersion(data: any) {


    this.masterservice.saveParameterVersion(data, this.username, this.parentData).
      subscribe(data => {
        // console.log(data)
        this.getAllVersion()
      },
        error => {
          // this.alert.error(error.error.message)
          this.getAllVersion()
          console.log(error.error)
        })

  }


  validateVersion(args?: any) {
    let formdata = this.versionForm.value
    let parameterversionid
    let action
    if (!formdata.parameterversionid) {
      parameterversionid = 0
      action = 'create'
    }
    else {
      parameterversionid = formdata.parameterversionid
      action = 'update'
    }
    this.masterservice.valVersion(this.parentData, this.versionstart.value, this.versionend.value, parameterversionid, action).
      subscribe(data => {
        // console.log(data)
        if (data.statusCode == 409) {
          this.alert.errorChild(data.statusMsg)
          // this.versionstart.setValue("");

        } else if (data.statusCode == 400) {
          this.alert.errorChild(data.statusMsg)
        }

        else {
          this.alert.removeAlertChild()

        }

      },
        error => {
          this.alert.errorChild(error.error.message)
          console.log(error.error)

        })
  }

  valVer() {
    const vEnd = this.versionForm.get('versionend');
    let status = null;
    let formdata = this.versionForm.value
    let parameterversionid
    let action
    if (!formdata.parameterversionid) {
      parameterversionid = 0
      action = 'create'
    }
    else {
      parameterversionid = formdata.parameterversionid
      action = 'update'
    }
    this.masterservice.valVersion(this.parentData, this.versionstart.value, this.versionend.value, parameterversionid, action).
      subscribe(data => {
        if (data.statusCode == 409) {
          this.alert.error(data.statusMsg)

          // vEnd.setValue("")
          // vEnd.setValidators([Validators.required])
          // vEnd.updateValueAndValidity();
          status = false

        } else {
          status = true;
        }

      },
        error => {
          this.alert.error(error.error.message)
          status = false;

        })
    return status;
  }



  expandAccor() {
    if (this.thirdchk == !true) {
      this.Expandcollapse = 'Collapse All'
      this.firstchk = true;
      this.secondchk = true;
      this.thirdchk = true;
      this.fourthchk = true;
    }
    else {
      this.Expandcollapse = 'Expand All'
      this.firstchk = false;
      this.secondchk = false;
      this.thirdchk = false;
      this.fourthchk = false;
    }

  }

  // test()
  // {
  //   console.log(this.formData.parameteruom)
  // }

  ngOnDestroy() {
    this.eventsSubscription.unsubscribe()
  }

  onKeyPress(type: any, event) {
    if (type == 'Float') {
      let charCode = (event.which) ? event.which : event.keyCode;
      if (charCode != 46 && charCode > 31
        && (charCode < 48 || charCode > 57))
        return false;
      return true;
    }
    if (type == 'Number') {

      const charCode = (event.which) ? event.which : event.keyCode;
      if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
      }
      return true;
    }
  }

  removeAlert()
  {
    this.alert.removeAlertChild()
  }

}
export interface IOrderModel {
  parameterversionid?: any;
  dataentrycaption?: any;
  parameterid?: any;
  versionstart?: number;
  versionend?: number;
  stepdescription?: any;
  stepnolabel?: any;
  stepno?: any;
  sortno?: any;
  defaultvalue?: any;
  defaultuom?: any;
  specmin?: any;
  specmax?: any;
  limittolist?: any;
  dataentryinstructions?: any;
  verificationrequired?: any;
  comments?: any;
  dropdownvalues?: any;
  lockrec?: any;
  lockuom?: any;
  dataformatid?: any;
  listid?: any;
  username?: any;
  effectivestartdate?: any;
  effectiveenddate?: any;
}