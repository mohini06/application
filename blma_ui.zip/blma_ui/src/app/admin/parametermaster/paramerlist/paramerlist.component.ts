import { DataService } from './../../../_core/services/data.service';
import { TabDirective } from 'ngx-bootstrap/tabs';
import { ItemmasterService } from "./../../../_core/services/itemmaster.service";
import { Component, OnInit, ViewChild } from "@angular/core";
import { ClickEventArgs } from "@syncfusion/ej2-navigations";
import { DataManager, ODataAdaptor, WebApiAdaptor } from "@syncfusion/ej2-data";

import { DataStateChangeEventArgs } from '@syncfusion/ej2-grids';
import { Observable } from 'rxjs';
import {
  GridComponent,
  ToolbarItems,
  EditService,
  PageService,
  CommandColumnService,
  CommandModel,
  PageSettingsModel,
  ColumnMenuService,
  RowSelectEventArgs
} from "@syncfusion/ej2-angular-grids";
import { LoginService } from './../../../_core/services/login.service';


@Component({
  selector: 'app-paramerlist',
  templateUrl: './paramerlist.component.html',
  styleUrls: ['./paramerlist.component.scss'],
  providers: [EditService, PageService, CommandColumnService, ColumnMenuService]
})
export class ParamerlistComponent implements OnInit {
  public data: Observable<DataStateChangeEventArgs>;
  public pageOptions: Object;
  public state: DataStateChangeEventArgs;
  public filterSettings: Object;
  public editSettings: Object;
  public toolbarOptions: ToolbarItems[];
  public dTdata: any;
  public editparams: Object;
  public commands: CommandModel[];
  public initialPage: PageSettingsModel;
  @ViewChild("grid", { static: false })
  public grid: GridComponent;
  public viewData;
  url: any
  public pageSizes: number[] = [10, 20, 100, 500, 1000];
  public pageSettings: Object;
  parameterRoles:any;
  constructor(private itemList: ItemmasterService, private dataservice: DataService,private role:LoginService) {
    
    this.data = itemList
  }

  toolbarClick(args: ClickEventArgs): void {
    if (args.item.id === "Grid_excelexport") {
      // 'Grid_excelexport' -> Grid component id + _ + toolbar item name
      this.grid.excelExport();
    }
  }
  ngOnInit() {
    this.url = "/parameter/parameters"
    this.pageSettings = { pageCount: 10, pageSize: this.pageSizes[0], pageSizes: this.pageSizes };

    let state = { skip: 0, take: 10 };
    this.itemList.execute(state, this.url, 'parameter');

    this.filterSettings = { type: "Menu" };
    this.toolbarOptions = ["ExcelExport", "Search"];

    //   this.editSettings = { allowEditing: false, allowAdding: true,  mode: 'Dialog', allowEditOnDblClick: true };
    // this.commands = [{ type: 'Edit', buttonOption: { iconCss: ' e-icons e-edit', cssClass: 'e-flat' } },

    //       { type: 'Save', buttonOption: { iconCss: 'e-icons e-update', cssClass: 'e-flat' } },
    //       { type: 'Cancel', buttonOption: { iconCss: 'e-icons e-cancel-icon', cssClass: 'e-flat' } }];
    //       this.editparams = { params: { popupHeight: '300px' }};
  }

  // getparameterList($event) {
  //   this.itemList
  //     .getAllParameterList()
  //     .subscribe(resp => (this.dTdata = resp.parameter_list));

  // }

  public dataStateChange(state: DataStateChangeEventArgs): void {
    this.itemList.execute(state, this.url, "parameter");

  }

  refreshList() {
    let state = { skip: 0, take: 10 };
    this.itemList.execute(state, this.url, 'parameter');
  }


  getRowData(args: any): void {
    let data = this.grid.getRowInfo(args.target);
    this.viewData = data.rowData;
    this.addNewTab(data["rowData"], "edit");
  }

  // tabs
  tabs: any[] = [];

  addNewTab(rowdata: any, type: any): void {
    if (type == "new") {
      this.tabs.push({
        title: `Add New Parameter`,
        content: type,
        disabled: false,
        removable: true,
        active: true
      });
    } else if (type == "edit") {
      if (this.tabs.some(title => title.title === rowdata.uniquename)) {
        for (let i = 0; i < this.tabs.length; i++) {
          if (this.tabs[i].title == rowdata.uniquename) {
            this.tabs[i].active = true;
          }
        }
      } else {
        this.tabs.push({
          title: rowdata.uniquename,
          content: type,
          disabled: false,
          removable: true,
          active: true
        });
      }
    }
  }
  removeTabHandler(tab: any): void {
    this.tabs.splice(this.tabs.indexOf(tab), 1);
    // console.log('Remove Tab handler');
  }


  onSelect(data: TabDirective): void {
    console.log(data.heading);
    console.log("calling")
  }


  actionBegin(args): void {
    // console.log(args)
    args.pageNo == 6
    if (args.requestType === 'beginEdit') {


    }


  }


  actionComplete(args) {
    if ((args.requestType === 'beginEdit' || args.requestType === 'add')) {
      const dialog = args.dialog;

      //  console.log(args)
      // change the header of the dialog
      dialog.header = args.requestType === 'beginEdit' ? 'Record of ' + args.rowData['dataentrycaption'] : 'New Version';
    }
  }


}
