import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParamerlistComponent } from './paramerlist.component';

describe('ParamerlistComponent', () => {
  let component: ParamerlistComponent;
  let fixture: ComponentFixture<ParamerlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParamerlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParamerlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
