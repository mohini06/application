import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditParmaeterComponent } from './add-edit-parmaeter.component';

describe('AddEditParmaeterComponent', () => {
  let component: AddEditParmaeterComponent;
  let fixture: ComponentFixture<AddEditParmaeterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddEditParmaeterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditParmaeterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
