export interface Editparameterlist {
  parameterid?: string;
  uniquename?: string;
  type?: string;
  label?: string;
  baseuom?: string;
  description?: string;
  datatypeid?: number;
  enableversion?: string;
  effectivedate?: string;
  inactivedate?: string;
  status?: string;
  username?: string;
  attributes?: (AttributesEntity)[] | null;
  attributetable?: (AttributetableEntity)[] | null;
  tags?: (null)[] | null;
}
export interface AttributesEntity {
  attributeid: number;
  attributevalue: string;
}
export interface AttributetableEntity {
  attributedataid: number;
  attributeid: number;
  attributevalue: string;
  rowno: number;
}
