
import { GetGenericService } from './../../../_core/services/get-generic.service';
import { PreferenceService } from './../../../_core/services/preference.service';
import { map } from 'rxjs/operators';
import { Subject, of } from 'rxjs';
import { AlertService } from './../../../_core/services/alert.service';
import { DataService } from './../../../_core/services/data.service';

import { Editparameterlist } from './parameter-interface';
import { ItemmasterService } from '../../../_core/services/itemmaster.service';
import { Component, OnInit, TemplateRef, Input, ViewChild, Output, EventEmitter, AfterViewInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { DateTimePickerComponent } from '@syncfusion/ej2-angular-calendars';
import { BatchesService } from './../../../_core/services/batches.service';
import { ChartdataService } from './../../../_core/services/chartdata.service';
import { LoginService } from './../../../_core/services/login.service';
@Component({
  selector: 'app-add-edit-parmaeter',
  templateUrl: './add-edit-parmaeter.component.html',
  styleUrls: ['./add-edit-parmaeter.component.scss']
})
export class AddEditParmaeterComponent implements OnInit, AfterViewInit {
  private eventsSubject: Subject<void> = new Subject<void>();
  @Input() type: any;
  @Input() rowData: any;
  @Output() getGroupList = new EventEmitter<string>();
  @Output() createNew = new EventEmitter<string>();


  Charttype=["lineBoxPlot","Boxplot","Control chart","histogram"];
  parametertypeData: any;
  parameterstatusData: any;
  parameteruomData: any;
  parameterDatatype: any
  parameterMasterNewForm: FormGroup;
  sucess: string;
  error: string;
  parent = "parameter";
  detailsFlag: Boolean = false;
  editParameterSaveData: Editparameterlist = {};
  username: string;
  childData = "";
  formData = [];
  attributeData: any;
  formatedAttributeData = [];
  formatedAttributeTable = []
  tagData = [];
  formatedTagId = [];
  tableData = [];
  modalRef: BsModalRef;
  isSubmitted: boolean = false;
  dateFormate = ''
  public defaultDate = new Date()
  public dateTime = new Date()

  //Plotly Graph
  analysis: any;
  graphdata: any;
  
parameterRoles:any;
parameterCheckAccessData: any;
  parametercommentTab: boolean = true;
  parametertagTab: boolean = true;
  parametersectionTab:boolean=true;
  parameterversionTab:boolean=true;
  parameterattributeTab:boolean=true;
  parameterspecTab:boolean=true;
  parameterAnalyticTab:boolean=true;
  Updatetab:boolean=false;
  Createtab:boolean=false;
  constructor(private formBuilder: FormBuilder, private modalService: BsModalService,
    private parametermaster: ItemmasterService, private data: DataService,
    private batchesService: BatchesService, private alert: AlertService,
    private preference: PreferenceService, private getgeneric: GetGenericService,
    private Chartdata:ChartdataService) {
     
     }

     
  ngOnInit() {
    this.parameterMasterNewForm = this.formBuilder.group({
      uniquename: ['', [Validators.required, Validators.pattern(".*\\S.*[a-zA-z0-9 ]")], [this.checkName.bind(this)]],
      parametertype: [''],
      status: ['', [Validators.required,]],
      baseuom: ['', [Validators.required,]],
      effectivedate: [this.defaultDate],
      inactivedate: [null],
      // parameterDatatype: [''],
      parameterid: ['0'],
      label: ['', Validators.required],
      datatypeid: ['', [Validators.required,]],
      description: [''],
      enableversion: ['']
    });

     //Service for Field level Role Access
     this.parametermaster.fieldLevelAcess("item", null).subscribe(data => {
     
      if(data.item.child)
      {
        this.parameterCheckAccessData = data.item.child;
      for (let obj of this.parameterCheckAccessData) {
        for (let keyname in obj) {
          if (obj[keyname].type == "Column") {
            if (obj[keyname].read == false) {
              for (const field in this.parameterMasterNewForm.controls) {
                if(keyname=='type')
                   { this.parameterMasterNewForm.controls['parametertype'].disable(); }
                if (field == keyname) {  
                  this.parameterMasterNewForm.controls[field].disable();
                }
              }
            }
            else {
              if (obj[keyname].update == false) {
                for (const field in this.parameterMasterNewForm.controls) { // 'field' is a string
                  if (field == keyname) {
                    this.parameterMasterNewForm.controls[field].disable();
                  }
                }
              }
            }
          }
          else {
            if (keyname == "comment") { if (obj[keyname].read == false) {this.parametercommentTab = false;} }
            else if (keyname == "tag") {if (obj[keyname].read == false) { this.parametertagTab = false;}   }
            else if (keyname == "parametersection") {if (obj[keyname].read == false) { this.parametersectionTab = false;}   }
            else if (keyname == "parameterversion") {if (obj[keyname].read == false) { this.parameterversionTab = false;}   }
            else if (keyname == "attribute") {if (obj[keyname].read == false) { this.parameterattributeTab = false;}   }
            else if (keyname == "spec") {if (obj[keyname].read == false) { this.parameterspecTab = false;}   }
            else if (keyname == "analytics") {if (obj[keyname].read == false) { this.parameterAnalyticTab = false;}   }
      
          }
        }
      }}
    })

    this.enableversion.value == true
    this.getAllDropdowns();
    this.username = this.batchesService.getUserName();
    if (this.type == "edit") {
      this.Updatetab=true;
      this.Createtab=false;
      this.setFormValue()
      this.childData = this.rowData.parameterid
      this.formData = this.parameterMasterNewForm.value
      this.detailsFlag = true;
      // console.log(this.rowData)
      this.getAnalyticsData(this.rowData.parameterid)
    }
    else
    {
      this.Createtab=true;
      this.Updatetab=false;
    }


    this.dateFormate = this.preference.getDateFormate()
    
  }

  get uniquename() { return this.parameterMasterNewForm.get('uniquename'); }
  get baseuom() { return this.parameterMasterNewForm.get('baseuom'); }
  get status() { return this.parameterMasterNewForm.get('status'); }
  get parametertype() { return this.parameterMasterNewForm.get('parametertype'); }
  get description() { return this.parameterMasterNewForm.get('description'); }
  get effectivedate() { return this.parameterMasterNewForm.get('effectivedate'); }

  get inactivedate() {  return this.parameterMasterNewForm.get('inactivedate'); }
  get parameterid() { return this.parameterMasterNewForm.get('parameterid'); }
  get label() { return this.parameterMasterNewForm.get('label'); }
  get datatypeid() { return this.parameterMasterNewForm.get('datatypeid'); }
  get enableversion() {
     return this.parameterMasterNewForm.get('enableversion');
     }


  emitEventToChild() {
    this.eventsSubject.next(this.parameterMasterNewForm.value)
  }



  
  setFormValue() {
    this.uniquename.setValue(this.rowData.uniquename)
    this.baseuom.setValue(this.rowData.baseuom)
    this.status.setValue(this.rowData.status)
    this.parametertype.setValue(this.rowData.type)
    this.description.setValue(this.rowData.description)
    this.effectivedate.setValue(this.rowData.effectivedate)
    this.inactivedate.setValue(this.rowData.inactivedate)
    
   
    this.parameterid.setValue(this.rowData.parameterid)
    this.label.setValue(this.rowData.label)
    this.datatypeid.setValue(this.rowData.datatypeid)
    this.enableversion.setValue(this.rowData.enableversion)

  }

  getAllDropdowns() {
    this.parametermaster.getParameterDropdowns().subscribe(data => {
      this.parametertypeData = data.parameter_type;
      this.parameterstatusData = data.parameter_status;
      this.parameteruomData = data.parameter_uom;
      this.parameterDatatype = data.parameter_datatype;
    })
  }



  effectivestartdate:any;
  onChangeeffective(args)
  {
    
    this.effectivestartdate=args.value;
  }

  effectiveenddate:any;
  onChangeeffectiveend(args)
  {
    
    this.effectiveenddate=args.value;
  }


  operationEditSave() {
    if (this.childData) {


      // console.log("edit")
      if (this.attributeData) {
        for (let i = 0; i < this.attributeData.attribute_data.length; i++) {
          this.formatedAttributeData.push({ 'attributeid': this.attributeData.attribute_data[i].attributeid, 'attributevalue': this.attributeData.attribute_data[i].attributevalue })

        }

        for (let i = 0; i < this.attributeData['attribute_grpsections'].length; i++) {

          if (this.attributeData['attribute_grpsections'][i].is_table) {
            // console.log(this.attributeData['attribute_datatables']['ag_'+this.attributeData['attribute_grpsections'][i].attributegroupid])
            for (let j = 0; j < this.attributeData['attribute_datatables']['ag_' + this.attributeData['attribute_grpsections'][i].attributegroupid].rows.length; j++) {
              // console.log( this.attributeData['attribute_datatables']['ag_'+this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j])

              for (let k = 0; k < this.attributeData['attribute_datatables']['ag_' + this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j].length; k++) {
                // console.log(this.attributeData['attribute_datatables']['ag_'+this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j][k])
                this.formatedAttributeTable.push(this.attributeData['attribute_datatables']['ag_' + this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j][k])
              }
            }
          }
        }

      }
      else {
        this.formatedAttributeData = [];
      }
      //  all data
      this.editParameterSaveData.parameterid = this.childData
      this.editParameterSaveData.uniquename = this.uniquename.value
      this.editParameterSaveData.type = this.parametertype.value
      this.editParameterSaveData.label = this.label.value
      this.editParameterSaveData.baseuom = this.baseuom.value
      this.editParameterSaveData.datatypeid = this.datatypeid.value
      this.editParameterSaveData.username = this.username;
      this.editParameterSaveData.description = this.description.value
      this.editParameterSaveData.enableversion = this.enableversion.value
      this.editParameterSaveData.effectivedate =  this.preference.setDateFormate(this.effectivestartdate)
      this.editParameterSaveData.inactivedate = this.preference.setDateFormate(this.inactivedate.value)
        // this.editParameterSaveData.inactivedate = this.effectiveenddate
  this.editParameterSaveData.status = this.status.value
      this.editParameterSaveData.attributes = this.formatedAttributeData;
      this.editParameterSaveData.attributetable = this.formatedAttributeTable


      if (this.tagData) {
        for (let i = 0; i < this.tagData.length; i++) {
          this.formatedTagId.push({ 'id': this.tagData[i].tagid })
        }
      } else {
        this.formatedTagId = []
      }

      this.editParameterSaveData.tags = this.formatedTagId;
      // console.log(this.formatedAttributeData)
      this.editParameterDetails(this.editParameterSaveData)

    }
    else {
      // console.log("save")
     
      this.saveNewParameterDetails()
    }
  }



  saveNewParameterDetails() {
    this.alert.removeAlert(); 
    if (this.enableversion.value == "") {
      this.enableversion.setValue(false)
    }

    this.parametermaster.saveParameter(this.parameterMasterNewForm.value, this.username).
    subscribe(data => {
      console.log(data)
      this.detailsFlag = true;
      this.childData = data['parameter'].rows[0]['Inserted Row ID'];
      console.log(this.childData)
      // this.formData = this.parameterMasterNewForm.value
      this.getGroupList.emit(null)
      this.alert.success("Successfully saved")
      this.getAnalyticsData(data['item'].rows[0]['Inserted Row ID'])

      setTimeout(() => {
        this.alert.removeAlert();
        this.emitEventToChild()
      }, 1500);


    },
      error => {
        if (error.status == 409) {
          this.alert.error("Parameter name already exist")
        }
        this.alert.error(error.error.message)
      })



    // this.parametermaster.saveParameterNewDetails(this.parameterMasterNewForm.value, this.username).
    //   subscribe(data => {
    //     this.detailsFlag = true;
    //     this.childData = data.id
    //     // this.formData = this.parameterMasterNewForm.value
    //     this.getGroupList.emit(null)
    //     this.alert.success("Successfully saved")
    //     this.getAnalyticsData(data.id)

    //     setTimeout(() => {
    //       this.alert.removeAlert();
    //       this.emitEventToChild()
    //     }, 1500);


    //   },
    //     error => {
    //       if (error.status == 409) {
    //         this.alert.error("Parameter name already exist")
    //       }
    //       this.alert.error(error.error.message)
    //     })
  }

  editParameterDetails(data: any) {
    console.log(this.parameterMasterNewForm.value)
    console.log(data)
    
    // return;
    this.parametermaster.updateparameter(data).
      subscribe(data => {
       
        this.emitEventToChild()
        this.alert.success("Successfully Saved")
        this.getGroupList.emit(null)
        setTimeout(() => {
          this.alert.removeAlert();
        }, 1500);
      },
        error => {
          this.alert.error("Parameter Name Already Exists")


        })
  }

  checkParameter() {

    this.parametermaster.checkParameterName(this.uniquename.value, this.parameterid.value).
      subscribe(data => {
        // console.log(data);
        this.alert.removeAlert()
      },
        error => {
          // console.log(error.error)
          this.alert.error("Parameter already exists")
        })
  }


  checkName(control: AbstractControl) {
    if (control.value) {
      return this.parametermaster.checkParameterName(control.value, this.parameterid.value).pipe(
        map(response => {

          return response ? null : { forbiddenName: { value: control.value } };
        }) // use observables, don't convert to promises
      );
    }
    return of(null); // gotta return an observable for async
  }


  getAttributeDataParameter(data): void {
    // console.log(data)
    this.attributeData = data
  }

  getTagDataParameter(tagdata): void {
    this.tagData = tagdata
    // console.log(tagdata)
  }


  ngAfterViewInit() {
    this.emitEventToChild()
  }

  createNewTab() {
    this.createNew.emit(null)
    // console.log("new clicked")

  }
  config = {
    backdrop: true,
    ignoreBackdropClick: true
  };
  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);

  }
  openModalAudit(audithistory: TemplateRef<any>) {
    this.newParam(this.rowData.parameterid, 'parameter')
    this.modalRef = this.modalService.show(audithistory, Object.assign({}, this.config, { class: 'gray modal-lg' }));

  }

  newParam(param: any, table: any) {
    this.data.changeParam({ message: param, table: table })
  }

  removeAlert() {
    this.alert.removeAlert();

  }

  labelsrequired=[];
  chartvalues=[];
  getAnalyticsData(parameterid) {
    this.getgeneric.getParameterAnalysis(parameterid).
      subscribe(data => {
        //  console.log(data)
        
        this.analysis = data.parameter_analysis;
      // alert(this.analysis[0].json_object_agg.analysis.labels)
  //     for(let i=0;i<this.analysis[0].json_object_agg.analysis.labels.length;i++)
  //       {
  // this.labelsrequired.push(this.analysis[0].json_object_agg.analysis.labels[i].substring(0,7));
  //       }
     
 this.chartvalues=this.Chartdata.getspecificchart(this.analysis[0].json_object_agg.analysis);
        // this.graphdata = [

        //   { x: this.analysis[0].json_object_agg.analysis.labels, y: this.analysis[0].json_object_agg.analysis.values, type: 'scatter', mode: 'lines+points', marker: { color: 'red' } },
        //   { x: this.analysis[0].json_object_agg.analysis.labels, y: this.analysis[0].json_object_agg.analysis.values, type: 'bar' },
        // ]
      },

        error => {
          console.log(error.error)

        })

       
        
        
  }

  getcharttype(value:any)
  {
    for(let i=0;i<this.chartvalues.length;i++)
    {
      if(this.chartvalues[i].layout.title==value)
      {
        alert("found same")
      }
    }

  }



  
}
