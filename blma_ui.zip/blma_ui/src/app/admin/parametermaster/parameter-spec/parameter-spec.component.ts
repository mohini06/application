
import { PreferenceService } from './../../../_core/services/preference.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit, ViewChild, Input, TemplateRef } from "@angular/core";
import { ClickEventArgs } from "@syncfusion/ej2-navigations";
import { DataManager, ODataAdaptor, WebApiAdaptor } from "@syncfusion/ej2-data";
import { ChangeEventArgs, DropDownListComponent } from '@syncfusion/ej2-angular-dropdowns';
import { DropDownList } from '@syncfusion/ej2-dropdowns';
import { Query } from '@syncfusion/ej2-data'
import { ItemmasterService } from './../../../_core/services/itemmaster.service';
import {
  GridComponent,
  ToolbarItems,
  EditService,
  PageService,
  CommandColumnService,
  CommandModel,
  PageSettingsModel,
  ColumnMenuService,
  NewRowPosition,
  RowSelectEventArgs
} from "@syncfusion/ej2-angular-grids";

@Component({
  selector: 'app-parameter-spec',
  templateUrl: './parameter-spec.component.html',
  styleUrls: ['./parameter-spec.component.scss'],
  providers: [EditService, PageService, CommandColumnService, ColumnMenuService]
})
export class ParameterSpecComponent implements OnInit {

 


  @Input() parentData: any;
  @Input() parent: any;
  public data: DataManager;
  public filterSettings: Object;
  public editSettings: Object;
  public toolbarOptions: ToolbarItems[];
  public dTdata: any;
  public editparams: Object;
  public toolbar: string[];
  public commands: CommandModel[];
  public initialPage: PageSettingsModel;
  recipeDropDown = [];
  sectionDropDown = [];
  selectedCalculation = [];
  public gridData: any;
  public pageSizes: number[] = [10, 20, 100, 500, 1000];
  public pageSettings: Object;
  @ViewChild("sectiongrid", { static: false })
  public sectiongrid: GridComponent;
  trigerFlag: boolean = false
  public submitClicked: boolean = false;
  sectionForm: FormGroup
  recipename = []
  config = {
    backdrop: true,
    ignoreBackdropClick: true
  };
  modalRef: BsModalRef;
  dateTimeFormate: any;
  public viewData;
  type="edit"
  toHide=true
  // public columnsParent: object[] = [

  //   {
  //     field: 'recipename', headerText: 'Recipe', foreignKeyField: "savedvalue", foreignKeyValue: "displayvalue", editType: 'dropdownedit', width: '120', edit: {
  //       params: {
  //         query: new Query(),
  //         dataSource: this.recipeDropDown,
  //         fields: { value: "savedvalue", text: "displayvalue" }
  //       }
  //     }
  //   },
  //   {
  //     field: 'sectionname', headerText: 'Section', foreignKeyField: "value", foreignKeyValue: "text", editType: 'dropdownedit', width: '120', edit: {
  //       params: {
  //         query: new Query(),
  //         dataSource: "",
  //         fields: { value: "savedvalue", text: "displayvalue" }
  //       }
  //     }

  //   }
  // ];


  constructor(private preference: PreferenceService, private modalService: BsModalService, private formBuilder: FormBuilder, private masterservice: ItemmasterService) { }
  toolbarClick(args: ClickEventArgs): void {
    console.log(args.item.id)
    if (args.item.id == "sectionParameter_excelexport") {
      // 'Grid_excelexport' -> Grid component id + _ + toolbar item name
      this.sectiongrid.excelExport();
    }
  }
  ngOnInit() {
    this.masterservice.getspecificAnalyticplot().subscribe(data=>{
      console.log(data)
    })
    this.sectionForm = this.formBuilder.group({
      specname: ['', [Validators.required]],
      versionstart: ['', [Validators.required]],
      versionend: ['', [Validators.required]],
      startdate:['', []],
      enddate:['', []]
    });


    this.pageSettings = { pageCount: 10, pageSize: this.pageSizes[0], pageSizes: this.pageSizes };
    this.filterSettings = { type: "Menu" };
    this.toolbarOptions = ["ExcelExport", "Search", 'Add', 'Edit', 'Update', 'Cancel'];
    this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true, newRowPosition: 'Bottom', mode: 'Dialog' };
    this.toolbar = ['Add', 'Save', 'Edit', 'Update', 'Cancel'];
    // console.log(this.parentData)
    this.getAllParameterRecipe()

    this.dateTimeFormate = this.preference.getDateTimeFormate()
  }


  get specname() { return this.sectionForm.get('specname'); }
  get versionstart() { return this.sectionForm.get('versionstart'); }
  get versionend() { return this.sectionForm.get('versionend'); }
get startdate() { return this.sectionForm.get('startdate');}
get enddate() { return this.sectionForm.get('enddate');}


  // getAllParameterRecipeSection(recipeid) {
  //   if (recipeid) {
  //     this.masterservice.getParameterRecipeSection(recipeid.savedvalue, 'parameterrecipesection').subscribe(data => {
  //       // console.log(data);
  //       if (this.trigerFlag) {
  //         this.recipesectionid.setValue(null)
  //       }

  //       this.sectionDropDown = data['parameter_recipesection']
  //     },

  //       error => {
  //         // this.alert.error(error.error.message)
  //         this.sectionDropDown = []
  //         console.log(error.error.message)
  //       })
  //   } else {
  //     this.sectionDropDown = []
  //   }

  // }


  getAllParameterRecipe() {

    this.masterservice.getParameterRecipe(this.parentData).
      subscribe(data => {
        this.recipeDropDown = data['parameter_recipes']
        // console.log(this.recipeDropDown)
      },
        error => {
          // this.alert.error(error.error.message)
          console.log(error.error.message)
        })
  }


  getAllSectionList() {

    this.masterservice.getParameterSection(this.parentData, 'parametersections').
      subscribe(data => {
        // console.log(data)
        // console.log(data.parameter_sections)
        this.dTdata = data.parameter_sections

      },
        error => {
          // this.alert.error(error.error.message)
          console.log(error)
        })
  }


  rangetypes=[];
  Dropdwontype=[]
  
  getAllSpecList()
  {
    this.masterservice.getParameterSPecification(this.parentData).
    subscribe(data => {
       console.log(data)
      // console.log(data.parameter_sections)
      // this.dTdata = data.parameter_sections
      this.dTdata = data.spec_header;
      // alert(this.dTdata)
       this.rangetypes=data.spec_range_types;
      //  alert(this.rangetypes[0].displayvalue)
      for(let i=0;i<this.rangetypes.length;i++)
      {
        this.Dropdwontype[i]=this.rangetypes[i].displayvalue;
      }
      // console.log(this.Dropdwontype)
      // alert(this.Dropdwontype)

    },
      error => {
        // this.alert.error(error.error.message)
        console.log(error)
      })

  }




  onEditClick(args: any) {
    console.log("event triggered");

  }


  AddSpecStatus:number;
  actionBegin(args): void {
    // console.log(args)

    if (args.requestType === 'beginEdit' || args.requestType === 'add') {
      this.submitClicked = false;

      if (args.requestType === 'beginEdit') {
        // this.setFormdata(args.rowData)

      } else {
        this.resetForm(this.sectionForm)
      }

      if (args.requestType === 'add') {
        this.resetForm(this.sectionForm)

      }


    }
    if (args.requestType === 'save') {
      this.submitClicked = true;

       if (this.sectionForm.valid) {

        if (args.action === 'edit') {
          this.saveSection(this.sectionForm.value)
        
          this.resetForm(this.sectionForm)

        }
        if (args.action === 'add') {
          
        
          this.AddSpecStatus= this.saveSection(this.sectionForm.value)
      //  console.log(this.saveSection(this.sectionForm.value))
      //  alert(this.saveSection(this.sectionForm.value))
          
            // this.saveSpecRanges(this.fieldArray,this.AddSpecStatus)
          
          // console.log(this.sectionForm.value)
          this.resetForm(this.sectionForm)

        }

        // args.data = this.versionForm.value;
      } else {
        // console.log("not valid")
        args.cancel = true;
      }
    }

  }


  actionComplete(args) {
    if ((args.requestType === 'beginEdit' || args.requestType === 'add')) {
      const dialog = args.dialog;

      // console.log(args.rowData)
      // change the header of the dialog
      dialog.header = args.requestType === 'beginEdit' ? args.rowData['recipename'] : 'New Section';
    }
  }


  CreatedSpecid:number;
  saveSection(formData: any) {
    this.masterservice.saveParameterSpecification(this.parentData, formData).
      subscribe(data => {
      // alert(data.INSERTED_ROW_ID[0].id)
      // console.log(data.INSERTED_ROW_ID[0].id)
      this.CreatedSpecid=data.INSERTED_ROW_ID[0].id
console.log(this.CreatedSpecid)
this.saveSpecRanges(this.fieldArray,this.CreatedSpecid)
      },  
        error => {
          // this.alert.error(error.error.message)
          this.getAllSectionList()

          // console.log(error)
        })
        return this.CreatedSpecid;
  }


  saveSpecRanges(formData: any,specid:number) {
    this.masterservice.saveParameterSpecificationRange(this.parentData, formData,specid).
      subscribe(data => {
       
      },
        error => {
        
        })
  }



  resetForm(form: FormGroup) {

    form.reset();

    Object.keys(form.controls).forEach(key => {
      form.get(key).setErrors(null);
    });
  }


  // setFormdata(data) {

  //   // console.log(data)
  //   this.trigerFlag = false
  //   this.recipeDropDown.push({
  //     displayvalue: data.recipename,
  //     meaning: null,
  //     savedvalue: data.recipeid
  //   })

  //   this.recipe.patchValue(data.recipeid)

  //   this.getAllParameterRecipeSection({
  //     displayvalue: data.recipename,
  //     meaning: null,
  //     savedvalue: data.recipeid
  //   })
  //   this.parametersectionid.patchValue(data.parametersectionid)
  //   this.recipesectionid.patchValue(data.recipesectionid)
  //   // this.trigerFlag = true
  //   // console.log(this.recipeDropDown)


  // }
  getRowData(args: any, template: TemplateRef<any>): void {
    let data = this.sectiongrid.getRowInfo(args.target);
    // console.log(data['rowData']['recipeid'])
    this.getRecipeDetails(data['rowData']['recipeid'], template)

  }

  getRecipeDetails(id, template) {
    this.masterservice.getRecipeDetails(id).
      subscribe(data => {
        console.log(data['recipe_row'][0])
        this.recipename = data['recipe_row'][0]
        this.viewData= data['recipe_row'][0]
        this.modalRef = this.modalService.show(template, Object.assign({}, this.config, { class: 'modal-lg' }));


      },
        error => {
          // this.alert.error(error.error.message)


          // console.log(error)
        })
  }


 
  tableListOption=["True","False"];
  RangeTypes=["Type","Min","Max","Enabled","Alerts"];
   
  tableListOptionStatus=["Enabled","Disabled"];


displayrangetable:boolean=false;
  Rangetab()
  {
    if(this.displayrangetable==false)
    {
    this.displayrangetable=true;
    }
    else
    {
      this.displayrangetable=false;
    }
  }


  addrow()
  {
    
  }

  public fieldArray: Array<any> = [];
  private newAttribute: any = {};
  
  
  addFieldValue() {
      this.fieldArray.push(this.newAttribute)
      this.newAttribute = {};
    //  console.log(this.fieldArray);
  }



  deleteFieldValue(index) {
      this.fieldArray.splice(index, 1);
  }
}
