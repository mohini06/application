import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParameterSpecComponent } from './parameter-spec.component';

describe('ParameterSpecComponent', () => {
  let component: ParameterSpecComponent;
  let fixture: ComponentFixture<ParameterSpecComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParameterSpecComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParameterSpecComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
