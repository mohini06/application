import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParameterSectionComponent } from './parameter-section.component';

describe('ParameterSectionComponent', () => {
  let component: ParameterSectionComponent;
  let fixture: ComponentFixture<ParameterSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParameterSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParameterSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
