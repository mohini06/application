import { PreferenceService } from './../../../_core/services/preference.service';

import { DataService } from './../../../_core/services/data.service';
import { data } from './../../../data-entry/data.service';
import { AlertService } from './../../../_core/services/alert.service';

import { ItemmasterService } from '../../../_core/services/itemmaster.service';
import { Component, OnInit, TemplateRef, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { DateTimePickerComponent } from '@syncfusion/ej2-angular-calendars';
import { BatchesService } from './../../../_core/services/batches.service';
import { Observable, timer } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';
import { of, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { LoginService } from './../../../_core/services/login.service';

@Component({
  selector: 'app-add-attribute-group',
  templateUrl: './add-attribute-group.component.html',
  styleUrls: ['./add-attribute-group.component.scss']
})
export class AddAttributeGroupComponent implements OnInit {
  @Input() type: any;
  @Input() rowData: any;
  @Output() getGroupList = new EventEmitter<string>();
  @Output() createNew = new EventEmitter<string>();

  attributetargetobjlistData: any;

  attributeGroupMasterNewForm: FormGroup;
  sucess: string;
  error: string;
  parent = "attribute";
  detailsFlag: Boolean = false;

  username: string;
  childData = "";
  isSubmitted: boolean = false
  targetObjectDropDown = []
  modalRef: BsModalRef;
  dateFormate=''
  public defaultDate = new Date()
  dateTime = new Date()
  Updatetab:boolean=false;
  Createtab:boolean=false;
  attributeRoles:any;
  attributeCheckAccessData: any;
  attributeTab: boolean = true;

  constructor(private preference: PreferenceService,private formBuilder: FormBuilder, private modalService: BsModalService,
    private masterservice: ItemmasterService, private data: DataService, private batchesService: BatchesService, private alert: AlertService,private role:LoginService) { 
      // this.attributeRoles=this.role.Rolesdata['attribute']
    }

  ngOnInit() {

    this.attributeGroupMasterNewForm = this.formBuilder.group({
      caption: ['', [Validators.required, Validators.pattern(".*\\S.*[a-zA-z0-9 ]")]],
      groupname: ['', [Validators.required, Validators.pattern(".*\\S.*[a-zA-z0-9 ]")],[this.checkName.bind(this)]],
       targetobjname: ['', [Validators.required]],
     // targetobjname: [''],
      effectivedate: [this.defaultDate],
      inactivedate: [''],
      attributegroupid: [0],
      is_table: [''],
      description: [''],

    });


 //Service for Field level Role Access
 this.masterservice.fieldLevelAcess("attribute", null).subscribe(data => {
   
  this.attributeCheckAccessData = data.item.child;
  if(this.attributeCheckAccessData!=null)
  {
  for (let obj of this.attributeCheckAccessData) {
    for (let keyname in obj) {
      if (obj[keyname].type == "Column") {
        if (obj[keyname].read == false) {
          for (const field in this.attributeGroupMasterNewForm.controls) { // 'field' is a string
            if (field == keyname) {
              this.attributeGroupMasterNewForm.controls[field].disable();
            }
          }
        }
        else {
          if (obj[keyname].update == false) {
            for (const field in this.attributeGroupMasterNewForm.controls) { // 'field' is a string
              if (field == keyname) {
                this.attributeGroupMasterNewForm.controls[field].disable();
              }
            }
          }
        }
      }
      else {
        if (keyname == "attribute") {
          if (obj[keyname].read == false) {
            this.attributeTab = false; }
        } 
        
      }
    }
  }
}
})


    this.getAttributeAndGroupData()
    if (this.type == "edit") {
      this.Createtab=false;
      this.Updatetab=true;
	  
      this.setFormValue()
      this.childData = this.rowData.attributegroupid
      this.detailsFlag = true;
      // console.log(this.rowData)
    }

    else
    {
      this.Createtab=true;
      this.Updatetab=false;
	  
    }

    this.dateFormate=this.preference.getDateFormate()
  }
  get caption() { return this.attributeGroupMasterNewForm.get('caption'); }
  get groupname() { return this.attributeGroupMasterNewForm.get('groupname'); }
  get targetobjname() { return this.attributeGroupMasterNewForm.get('targetobjname'); }
  get attributegroupid() { return this.attributeGroupMasterNewForm.get('attributegroupid'); }
  get effectivedate() { return this.attributeGroupMasterNewForm.get('effectivedate'); }
  get inactivedate() { return this.attributeGroupMasterNewForm.get('inactivedate'); }
  get is_table() { return this.attributeGroupMasterNewForm.get('is_table'); }
  get description() { return this.attributeGroupMasterNewForm.get('description'); }




  setFormValue() {
    this.caption.setValue(this.rowData.caption)
    this.groupname.setValue(this.rowData.groupname)
    this.targetobjname.setValue(this.rowData.targetobjname)
    this.attributegroupid.setValue(this.rowData.attributegroupid)
    this.effectivedate.setValue(this.rowData.effectivedate)
    this.inactivedate.setValue(this.rowData.inactivedate)
    this.is_table.setValue(this.rowData.is_table)
    this.description.setValue(this.rowData.description)
  }


  saveAttributeGroup() {

    if (!this.attributeGroupMasterNewForm.valid) {
      return;
    }

    if (this.is_table.value == "") {
      this.is_table.setValue(false)
    }
    console.log(this.attributeGroupMasterNewForm.value)
    this.masterservice.saveattributeGroup(this.attributeGroupMasterNewForm.value).
      subscribe(data => {
        
        this.childData = data['attributegroup'].rows[0]['Inserted Row ID'];
        
        // console.log(data['attributegroup'].rows[0]);
        this.attributegroupid.setValue(data.id)
        this.getGroupList.emit(null)
        this.alert.success("Successfully saved")
        setTimeout(() => {
          this.alert.removeAlert();
        }, 1500);
        this.detailsFlag = true;
        //  this.itemMasterForm.reset();
      },
        error => {
          if (error.status == 409) {
            this.alert.error("Parameter name already exist")
          } else {
            this.alert.error(error.error.message)
          }
        })
  }

  getAttributeAndGroupData() {

    this.masterservice.getAttributeAndGroupLookupData(0).
      subscribe(data => {
        // console.log(data); 
        this.targetObjectDropDown = data.attribute_targetobjlist

      },
        error => {

          //  console.log(error.error)
        })
  }

  checkAttributeGroup() {
    let status
    this.masterservice.checkAttributegroup(this.groupname.value,this.attributegroupid.value).
      subscribe(data => {
        this.alert.removeAlert()
        status = true;
      },
        error => {
          this.alert.error("Attribute Group Name Already exists");
          status = false;
          //  console.log(error.error)
        })
    return status
  }


  checkName(control: AbstractControl) {
    if (control.value) {
      return this.masterservice.checkAttributegroup(control.value,this.attributegroupid.value).pipe(
        map(response => {
          // console.log(response)
          return response ?   null:{ forbiddenName: {value: control.value}};
         }) // use observables, don't convert to promises
       );
    }
    return of(null); // gotta return an observable for async
  }


  createNewTab() {
    this.createNew.emit(null)
    // console.log("new clicked")

  }
  config = {
    backdrop: true,
    ignoreBackdropClick: true
  };
  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);

  }
  openModalAudit(audithistory: TemplateRef<any>) {
    this.newParam(this.rowData.attributegroupid, 'attributegroup')
    this.modalRef = this.modalService.show(audithistory, Object.assign({}, this.config, { class: 'gray modal-lg' }));

  }

  newParam(param: any, table: any) {
    this.data.changeParam({ message: param, table: table })
  }

  removeAlert()
  {
    this.alert.removeAlert();
    
  }
}

