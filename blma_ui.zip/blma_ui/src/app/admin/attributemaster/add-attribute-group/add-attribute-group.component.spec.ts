import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAttributeGroupComponent } from './add-attribute-group.component';

describe('AddAttributeGroupComponent', () => {
  let component: AddAttributeGroupComponent;
  let fixture: ComponentFixture<AddAttributeGroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddAttributeGroupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddAttributeGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
