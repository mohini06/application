import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AttributegrouplistComponent } from './attributegrouplist.component';

describe('AttributegrouplistComponent', () => {
  let component: AttributegrouplistComponent;
  let fixture: ComponentFixture<AttributegrouplistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AttributegrouplistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AttributegrouplistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
