import { DataService } from './../../../_core/services/data.service';
import { TabDirective } from 'ngx-bootstrap/tabs';
import { ItemmasterService } from "./../../../_core/services/itemmaster.service";
import { Component, OnInit, ViewChild } from "@angular/core";
import { ClickEventArgs } from "@syncfusion/ej2-navigations";
import { DataManager, ODataAdaptor, WebApiAdaptor } from "@syncfusion/ej2-data";
import { DataStateChangeEventArgs } from '@syncfusion/ej2-grids';
import { Observable } from 'rxjs';
import {
  GridComponent,
  ToolbarItems,
  EditService,
  PageService,
  CommandColumnService,
  CommandModel,
  PageSettingsModel,
  ColumnMenuService,
  RowSelectEventArgs
} from "@syncfusion/ej2-angular-grids";
import { LoginService } from './../../../_core/services/login.service';


@Component({
  selector: 'app-attributegrouplist',
  templateUrl: './attributegrouplist.component.html',
  styleUrls: ['./attributegrouplist.component.scss'],
  providers: [EditService, PageService, CommandColumnService, ColumnMenuService]
})
export class AttributegrouplistComponent implements OnInit {
  public data: Observable<DataStateChangeEventArgs>;
  public pageOptions: Object;
  public state: DataStateChangeEventArgs;
  public filterSettings: Object;
  public editSettings: Object;
  public toolbarOptions: ToolbarItems[];
  public dTdata: any;
  public editparams: Object;
  public commands: CommandModel[];
  public pageSizes: number[] = [10,20,100,500,1000]; 
  public pageSettings: Object;

public formatOptions:any;
  @ViewChild("grid", { static: false })
  public grid: GridComponent;
  public viewData;
  url:any


  attributeRoles:any
  constructor(private masterservice: ItemmasterService,private dataservice:DataService,private role:LoginService) {
    // this.attributeRoles=this.role.Rolesdata['attribute']
    this.data = masterservice;
  }

  toolbarClick(args: ClickEventArgs): void {
    if (args.item.id === "Grid_excelexport") {
      // 'Grid_excelexport' -> Grid component id + _ + toolbar item name
      this.grid.excelExport();
    }
  }
  ngOnInit() {
    this.url="/attribute/attributegrouplist"
    this.pageSettings = { pageCount: 10, pageSize: this.pageSizes[0], pageSizes: this.pageSizes }; 
    let state = { skip: 0, take: 10 };
    this.masterservice.execute(state,this.url,'attributegroup');
    this.filterSettings = { type: "Menu" };
    this.toolbarOptions = ["ExcelExport", "Search"];
    this.formatOptions={type:'date',format:"MM/dd/yyyy hh:mm a"}; 
  }
  
 
refreshList()
{
  console.log("called")
  let state = { skip: 0, take: 10 };
    this.masterservice.execute(state,this.url,'attributegroup'); 
}

  // public columns: object[] = [
  //   {
  //     field: 'caption', headerText: 'Caption'
  //   },
   
  //   {
  //     field: 'targetobjname', headerText: 'Target objname'
  //   },
  //   {
  //     field: 'groupname', headerText: 'Attribute Group'
  //   },
  //   {
  //     field: 'is_table', headerText: 'Is Table'
  //   },
  //   {
  //     headerText: 'Action', template:'<ng-template #template let-dTdata><i class="fa fa-edit" (click)="getRowData($event)"></i> </ng-template>'
  //   }
  // ];

  public dataStateChange(state: DataStateChangeEventArgs): void {
    console.log(state)
    this.masterservice.execute(state,this.url,"attributegroup");

  }

  // tabs

  getRowData(args: any): void {
    // console.log(args)
    let data = this.grid.getRowInfo(args.target);
    this.viewData = data.rowData;
   
    // console.log(this.viewData)
    this.addNewTab(data["rowData"], "edit");
  }

  tabs: any[] = [];

  addNewTab(rowdata: any, type: any): void {
    if (type == "new") {
      this.tabs.push({
        title: `Add New Attribute Group`,
        content: type,
        disabled: false,
        removable: true,
        active: true
      });
    } else if (type == "edit") {
      if (this.tabs.some(title => title.title === rowdata.itemcode)) {
        for (let i = 0; i < this.tabs.length; i++) {
          if (this.tabs[i].title == rowdata.itemcode) {
            this.tabs[i].active = true;
          }
        }
      } else {
        this.tabs.push({
          title: rowdata.caption,
          content: type,
          disabled: false,
          removable: true,
          active: true
        });
      }
    }
  }
  removeTabHandler(tab: any): void {
    this.tabs.splice(this.tabs.indexOf(tab), 1);
    // console.log('Remove Tab handler');
  }



  
}
