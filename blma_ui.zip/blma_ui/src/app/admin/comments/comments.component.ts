import { DataService } from './../../_core/services/data.service';
import { Location } from '@angular/common';
import { BatchesService } from './../../_core/services/batches.service';
import { Component, OnInit, Input } from '@angular/core';
import { ItemmasterService } from './../../_core/services/itemmaster.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms'
import { Router, ActivatedRoute, RoutesRecognized } from '@angular/router';
import { distanceInWords } from 'date-fns';
import { filter, pairwise } from 'rxjs/operators';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.scss']
})
export class CommentsComponent implements OnInit {
  @Input() parentData: any;
  @Input() parent: any;
  
  time = distanceInWords(new Date(), new Date());
  commentData = [];
  spec = [];
  enablebutton: any = -1;
  username: any;
  commentForm: FormGroup;
  isSubmitted: boolean = false;
  parameterid: number
  dataentyCom: boolean = false
  data: any[] = [];
  submitting = false;
  returnUrl = "";
  user = {
    // author: 'Han Solo',
    // avatar: 'https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png'
  };
  inputValue = '';
  handleSubmit(): void {
    this.submitting = true;
    const content = this.inputValue;
    this.inputValue = '';
    // setTimeout(() => {
    //   this.submitting = false;
    //   this.data = [
    //     ...this.data,
    //     {
    //       ...this.user,
    //       content,
    //       datetime: new Date(),
    //       displayTime: distanceInWords(new Date(), new Date())
    //     }
    //   ].map(e => {
    //     return {
    //       ...e,
    //       displayTime: distanceInWords(new Date(), e.datetime)
    //     };
    //   });
    // }, 800);
  }
  constructor(private route: ActivatedRoute, private router: Router,
    private frmBuilder: FormBuilder, private masterService: ItemmasterService,
    private batchesService: BatchesService, private location: Location,private dataSubject:DataService) {

    this.route.queryParams.subscribe((params) => {
      // Object.assign(this.parameterid, params['parameterid'] );
      if (params['parameterid']) {
        this.parameterid = params['parameterid']
        this.getAllComments('batch', this.parameterid)
        this.dataentyCom = true
      }
    })
  }
  CheckAccessData:any;
  addComment:boolean=true;
  ngOnInit() {
  
//Service for Field level Role Access
    this.masterService.fieldLevelAcess(this.parent, null).subscribe(data => {
      if(data.item.child){
      this.CheckAccessData = data.item.child;
      for (let obj of this.CheckAccessData) {
        for (let keyname in obj) {
          if(keyname=='comment')
          {
          if (obj[keyname].read == true)
          {
                  this.addComment=true;
                  if(obj[keyname].create==false)
                  {
                   this.addComment=false;
                  }

          }
        }
      }}}

    });
    this.router.events
      .pipe(filter((e: any) => e instanceof RoutesRecognized),
        pairwise()
      ).subscribe((e: any) => {
        // console.log(e[0].urlAfterRedirects); // previous url

      });


    this.commentForm = this.frmBuilder.group({

      commentMsg: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(500)]],

    });
    // console.log(this.router.url);
    console.log(this.parentData)
    console.log(this.parent)

    if (!this.dataentyCom) {

      this.getAllComments(this.parent, this.parentData)

    }

    this.username = this.batchesService.getUserName();

    this.getSelectedParam()

  }


  get commentMsg() { return this.commentForm.get('commentMsg'); }

  getAllComments(objname, recid) {
    this.masterService.getComments(objname, recid).
      subscribe(data => {
        // console.log(data);
        if (data['comment_data']) {
          this.commentData = data['comment_data']
        } else {
          this.commentData = []
        }

        this.spec = data['comment_spec']
      },
        error => {

          //  console.log(error.error)
        })
  }


  createComment() {
    this.isSubmitted = true;
    if (!this.commentForm.valid)
      return;

    if (this.dataentyCom) {
      this.parentData = this.parameterid;
      this.parent = "batch"

    }
    this.masterService.saveComment(this.parentData, this.parentData, this.parent, 0, this.commentForm.value, this.username, 'master').
      subscribe(data => {
         console.log(data);
        this.resetForm(this.commentForm)
        this.pushNewCommnet()
        if (data['comment_data']) {
          this.commentData = data['comment_data'];
          // this.pushNewCommnet(
          //   {
          //     "hastags": true,
          //   "hascomment": true,
          //   "batchdataid": this.parentData,
          //   "recipesectionid": 522,
          //   "parentrecipesectionid": 522
          // }
          //   ,'comment')
        }

        this.spec = data['comment_spec']
        this.resetForm(this.commentForm)

      },
        error => {

          //  console.log(error.error)
        })
  }


  editComment(commentid: any, comment: any) {
    if (this.dataentyCom) {
      this.parentData = this.parameterid;
      this.parent = "batch"

    }
    this.masterService.editComments(this.parentData, this.parentData, this.parent, commentid, comment, this.username, 'master').
      subscribe(data => {
        console.log(data);
        if (data['comment_data']) {
          this.commentData = data['comment_data']
        }

        this.spec = data['comment_spec']
        alert("Comment Updated")
      },
        error => {

          //  console.log(error.error)
        })
  }


  enableBtn(i) {
    this.enablebutton = i

  }

  resetForm(form: FormGroup) {

    form.reset();

    Object.keys(form.controls).forEach(key => {
      form.get(key).setErrors(null);
    });
  }

  backClicked() {
    this.location.back();
  }


  test() {
    this.getAllComments(this.parent, this.parentData)
  }


  pushNewCommnet() {
    this.dataSubject.pushCommentFlag({ type: 'comment' })
  }

  getSelectedParam = () => {

    this.dataSubject.currentParam.subscribe(data => {

      // console.log(data)
      if(data.message)
      {
        this.parentData=data.message
        this.getAllComments(this.parent, data.message)
      }
   
   
    },
      error => {

        // console.log(error)
      })

  }


}
