import { environment } from '../../../environments/environment';
import { AfterViewInit, Component, OnInit, ViewChild,Renderer,ChangeDetectionStrategy } from '@angular/core';
import { Router } from '@angular/router';
// import { DataTableDirective } from 'angular-datatables';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-datatable',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './datatable.component.html',
  styleUrls: ['./datatable.component.scss']
})

export class DatatableComponent implements OnInit, AfterViewInit {

  apiUrl=environment.apiUrl;
  // @ViewChild(DataTableDirective, {static: false})
  // datatableElement: DataTableDirective;

  // dtOptions: DataTables.Settings = {};
  // persons: Person[];

  constructor(private http: HttpClient,private renderer: Renderer, private router: Router) {}

  ngOnInit(): void {
    const that = this;

  }


  ngAfterViewInit(): void {
    // this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
    //   dtInstance.columns().every(function () {
    //     const that = this;
    //     $('input', this.footer()).on('keyup change', function () {
    //       if (that.search() !== this['value']) {
    //         that
    //           .search(this['value'])
    //           .draw();
    //       }
    //     });
    //   });
    // });

    this.renderer.listenGlobal('document', 'click', (event) => {
      // event.target.getAttribute("view-person-id")
      if (event.target.hasAttribute("view-person-id")) {
        this.addNewTab()
      }
    });
  

  }
// tabs
  tabs: any[] = [

    // { title: 'Dynamic Title 1', content: 'Dynamic content 1', removable: true }
  ];
 
  addNewTab(): void {
    const newTabIndex = this.tabs.length + 1;
    this.tabs.push({
      title: `Item code ${newTabIndex}`,
      content: ``,
      disabled: false,
      removable: true,
     active:true
    });
  }
  removeTabHandler(tab: any): void {
    this.tabs.splice(this.tabs.indexOf(tab), 1);
    // console.log('Remove Tab handler');
  }

  
}
class Person {
 itemcode:number
       
 itemtype:string
  shorttitle:string
  itemstatus:string

}

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}