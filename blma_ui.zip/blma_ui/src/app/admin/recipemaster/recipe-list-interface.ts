export interface Newrecipelist {
  recipename?: string;
  type?: string;
  status?: string;
  description?: string;
  username?: string;
  item?: string;
  effectivedate?: string;
  inactivedate?: string;
  allowbatch?: boolean;
  recipeid?: number;
}