import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecipesectionComponent } from './recipesection.component';

describe('RecipesectionComponent', () => {
  let component: RecipesectionComponent;
  let fixture: ComponentFixture<RecipesectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecipesectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecipesectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
