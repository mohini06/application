import { AlertService } from './../../../_core/services/alert.service';
import { BatchesService } from './../../../_core/services/batches.service';
import { ItemmasterService } from './../../../_core/services/itemmaster.service';
import { Component, OnInit, ViewChild, Input } from "@angular/core";
import { ClickEventArgs } from "@syncfusion/ej2-navigations";
import { DataManager, ODataAdaptor, WebApiAdaptor } from "@syncfusion/ej2-data";
import { ChangeEventArgs, DropDownListComponent } from '@syncfusion/ej2-angular-dropdowns';
import { DropDownList } from '@syncfusion/ej2-dropdowns';
import { Query } from '@syncfusion/ej2-data'

import {
  GridComponent,
  ToolbarItems,
  EditService,
  PageService,
  CommandColumnService,
  CommandModel,
  PageSettingsModel,
  ColumnMenuService,
  NewRowPosition,
  RowSelectEventArgs
} from "@syncfusion/ej2-angular-grids";


@Component({
  selector: 'app-recipesection',
  templateUrl: './recipesection.component.html',
  styleUrls: ['./recipesection.component.scss'],
  providers: [EditService, PageService, CommandColumnService, ColumnMenuService]

})
export class RecipesectionComponent implements OnInit {
  @Input() parentData: any;
  @Input() parent: any;

  public numEditParams: Object;
  public data: DataManager;
  public filterSettings: Object;
  public editSettings: Object;
  public toolbarOptions: ToolbarItems[];
  public dTdata: any;
  public dTdataChild: Object[] = [];
  allData: any
  parentdataList: any
  childAllData = []
  public editparams: Object;
  public toolbar: string[];
  public commands: CommandModel[];
  public initialPage: PageSettingsModel;
  @ViewChild("grid", { static: false })
  public grid: GridComponent;

  public sectionrules: Object;
  username: any


  public dropdown: object[] = [{ is_table: true }, { is_table: false }];
  public dropdownChildParent: object[] = [];

  public columnsParent: object[] = [
    { field: 'sectionname', headerText: 'Section name <span style="color:red";"padding:4px;">*</span>', width: '120', validationRules: { required: true } },
    {
      field: 'seqno', headerText: 'Seq no', width: '100', type: "number", validationRules: { number: true }
    },
  
    {
      field: 'is_table', headerText: 'Is table  <span style="color:red";"padding:4px;">*</span>', validationRules: { required: true }, editType: 'dropdownedit', width: '120', edit: {
        params: {
          query: new Query(),
          dataSource: this.dropdown,
          fields: { value: "is_table", text: "is_table" }
        }
      }
    },
    {
      field: 'description', headerText: 'Description', width: '120'
    },
    {
      field: 'sectiontype', headerText: 'Section type', width: '120'
    }
  ];



  public columnsChild: object[] = [
    { field: 'sectionname', headerText: 'Section name  <span style="color:red";"padding:4px;">*</span>', width: '120', validationRules: { required: true } },
    {
      field: 'seqno', edit: { params: { decimals: 0, format: 'n' } }, headerText: 'Seq no', width: '100', type: "number", validationRules: { number: true }
    },
    {
      field: 'is_table', headerText: 'Is table  <span style="color:red";"padding:4px;">*</span>', validationRules: { required: true }, editType: 'dropdownedit', width: '120', edit: {
        params: {
          query: new Query(),
          dataSource: this.dropdown,
          fields: { value: "is_table", text: "is_table" }
        }
      }
    },
    {
      field: 'description', headerText: 'Description', width: '120'
    },
    {
      field: 'sectiontype', headerText: 'Section type', width: '120'
    }
    ,
    {
      field: 'parentrecipesectioname', headerText: 'Parent  <span style="color:red";"padding:4px;">*</span>', validationRules: { required: true }, editType: 'dropdownedit', width: '120', edit: {
        params: {
          query: new Query(),
          dataSource: this.dropdownChildParent,
          fields: { value: "parentrecipesectionid", text: "sectionname" }
        }
      }
    }
  ];



  constructor(private masterservice: ItemmasterService, private batchesService: BatchesService, private alert: AlertService) { }
  toolbarClick(args: ClickEventArgs): void {
    console.log(args.item.id)
    if (args.item.id === "ParentGrid_excelexport") {
      // 'Grid_excelexport' -> Grid component id + _ + toolbar item name
      this.grid.excelExport();
    }
  }
  ngOnInit() {

    this.numEditParams = { params: { decimals: 0, format: 'n' } };

    this.sectionrules = { required: true };
    this.initialPage = { pageSizes: true, pageSize: 10 };
    this.filterSettings = { type: "Menu" };
    this.toolbarOptions = ["ExcelExport", "Search", 'Add', 'Edit', 'Update', 'Cancel'];
    this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true, newRowPosition: 'Bottom' };
    this.toolbar = ['Add', 'Save', 'Edit', 'Update', 'Cancel'];
    // console.log(this.parentData)
    this.username = this.batchesService.getUserName();
    this.columnsChild[5]['edit'].params.dataSource = this.dTdata
  }



  getrecipeList() {

    this.masterservice.getRecipeSection(this.parentData, this.parent).
      subscribe(data => {
        if (data.recipe_secion_list) {
          //  console.log(data.recipe_secion_list)

          this.dTdata = data.recipe_secion_list.filter(a => a.recipesectionid == a.parentrecipesectionid)
          this.dTdataChild = data.recipe_secion_list.filter(a => a.recipesectionid !== a.parentrecipesectionid)
          this.parentdataList = this.dTdata
          this.allData = this.dTdataChild
          this.childAllData = []
          for (let i = 0; i < this.allData.length; i++) {
            this.childAllData.push({
              description: this.allData[i].description,
              is_table: this.allData[i].is_table,
              parentrecipesectionid: this.allData[i].parentrecipesectionid,
              recipesectionid: this.allData[i].recipesectionid,
              sectionname: this.allData[i].sectionname,
              sectiontype: this.allData[i].sectiontype,
              seqno: this.allData[i].seqno,
              parentrecipesectioname: this.parentdataList.find(x => x.parentrecipesectionid == this.allData[i].parentrecipesectionid).sectionname
            })
          }

          // console.log(this.childAllData)
          // this.columnsChild[5]['edit'].params.dataSource = this.dTdata
          this.dropdownChildParent = this.allData
        }
        else {
          this.dTdata = [];
          this.dTdataChild = []
          // this.columnsChild[5]['edit'].params.dataSource = this.dTdata
        }
      },
        error => {
          // this.alert.error(error.error.message)

          console.log(error.error.message)
        })
  }



  public newRowPosition: { [key: string]: Object }[] = [
    { id: 'Top', newRowPosition: 'Top' },
    { id: 'Bottom', newRowPosition: 'Bottom' }
  ];
  public localFields: Object = { text: 'newRowPosition', value: 'id' };


  actionBeginParent(args: any): void {
    let gridInstance: any = (<any>document.getElementById('ParentGrid')).ej2_instances[0];
    this.columnsParent[2]['edit'].params.dataSource = [{ is_table: true }, { is_table: false }];

    // console.log(gridInstance)

    if (args.requestType === 'save') {
      console.log(args.data.sectionname)

    

      if (args.action == 'edit') {
        // console.log(args.data)

        // console.log(this.dTdata.find( rec => rec.displayvalue ==args.data.sectionname))
    // console.log(this.dTdata.find( rec => rec.sectionname == args.data.sectionname))

        if (this.dTdata.find( rec => rec.sectionname = args.data.sectionname)) {
           args.cancel
           this.grid.editModule.startEdit(); 
           this.alert.errorChild("Duplicate Section Name")
           return;
        }
        this.masterservice.saveRecipeSection(this.parentData, args.data.sectionname, args.data.recipesectionid, args.data.parentrecipesectionid, args.data.seqno, args.data.is_table, args.data.description, args.data.sectiontype, this.username, true).
          subscribe(data => {

            this.getrecipeList()
            this.alert.successChild("Saved Sucessfully")
            setTimeout(() => {
              this.alert.removeAlertChild();
            }, 1500);
          },
            error => {
              this.alert.errorChild("Parent Section Already Exists for " + this.parent)
              this.getrecipeList()
              setTimeout(() => {
                this.alert.removeAlertChild();
              }, 1500);
              console.log(error.error.message)
            })
      }

      if (args.action == 'add') {
        // console.log(args)
        // if (this.dTdata.find( rec => rec.sectionname = args.data.sectionname)) {
        //   // args.cancel
        //   this.alert.errorChild("Duplicate Section Name")
        //   return ;
        // }
        this.masterservice.saverecipesection(this.parentData, args.data.sectionname, 0, 0, args.data.seqno, args.data.is_table, args.data.description, args.data.sectiontype, this.username, true).
          subscribe(data => {
            alert("data passed")
            this.getrecipeList()
            console.log(data)
            this.alert.successChild("Saved Sucessfully")
            setTimeout(() => {
              this.alert.removeAlertChild();
            }, 1500);
          },
            error => {

              this.alert.errorChild("Parent Section Already Exists for " + this.parent)
              this.getrecipeList()
              setTimeout(() => {
                this.alert.removeAlertChild();
              }, 2500);
              console.log(error.error)
            })
      }



      if (gridInstance.pageSettings.currentPage !== 1 && gridInstance.editSettings.newRowPosition === 'Top') {
        args.index = (gridInstance.pageSettings.currentPage * gridInstance.pageSettings.pageSize) - gridInstance.pageSettings.pageSize;
      } else if (gridInstance.editSettings.newRowPosition === 'Bottom') {
        args.index = (gridInstance.pageSettings.currentPage * gridInstance.pageSettings.pageSize) - 1;
      }
    }
  }

  actionBeginChild(args: any): void {
    let gridInstance: any = (<any>document.getElementById('ChildGrid')).ej2_instances[0];
    // console.log(args.data)
    this.columnsChild[5]['edit'].params.dataSource = this.parentdataList
    this.columnsChild[2]['edit'].params.dataSource = [{ is_table: true }, { is_table: false }];

    if (args.requestType === 'save') {
      console.log(args.data)
      if (typeof args.data.parentrecipesectioname === 'string') {
        // console.log("string")
        this.alert.errorChild("Select Parent Section")
        args.cancel
        return;
      }
      else {
        // console.log("number")

      }

      if (args.action == 'edit') {
        // console.log(args.data)
        this.masterservice.saveRecipeSection(this.parentData, args.data.sectionname, args.data.recipesectionid, args.data.parentrecipesectioname, args.data.seqno, args.data.is_table, args.data.description, args.data.sectiontype, this.username, false).
          subscribe(data => {
            this.alert.successChild("Saved Sucessfully")
            this.getrecipeList()
            setTimeout(() => {
              this.alert.removeAlertChild();
            }, 1500);
          },
            error => {
              this.alert.errorChild("Child Section Not saved")
              this.getrecipeList()
              setTimeout(() => {
                this.alert.removeAlertChild();
              }, 3000);
              console.log(error.error.message)
            })
      }

      if (args.action == 'add') {
        console.log(args.data)
        this.masterservice.saveRecipeSection(this.parentData, args.data.sectionname, 0, args.data.parentrecipesectioname, args.data.seqno, args.data.is_table, args.data.description, args.data.sectiontype, this.username, false).
          subscribe(data => {
            this.getrecipeList()
            console.log(data)
            this.alert.successChild("Saved Sucessfully")
            setTimeout(() => {
              this.alert.removeAlertChild();
            }, 1500);
          },
            error => {
              this.alert.errorChild("Child Section Not Saved")
              this.getrecipeList()
              setTimeout(() => {
                this.alert.removeAlertChild();
              }, 3000);
              console.log(error.error.message)
            })
      }



      if (gridInstance.pageSettings.currentPage !== 1 && gridInstance.editSettings.newRowPosition === 'Top') {
        args.index = (gridInstance.pageSettings.currentPage * gridInstance.pageSettings.pageSize) - gridInstance.pageSettings.pageSize;
      } else if (gridInstance.editSettings.newRowPosition === 'Bottom') {
        args.index = (gridInstance.pageSettings.currentPage * gridInstance.pageSettings.pageSize) - 1;
      }
    }
  }



  actionCompleteChild(args) {
    this.columnsChild[5]['edit'].params.dataSource = this.dTdata
  }
  public cellSave(args: any): void { 
 
   console.log(args) 
} 

}
