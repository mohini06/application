import { LoginService } from './../../../_core/services/login.service';
import { Newitem } from './../../itemmaster/viewitem/newitem';
import { DataService } from './../../../_core/services/data.service';
import { TabDirective } from 'ngx-bootstrap/tabs';
import { ItemmasterService } from "./../../../_core/services/itemmaster.service";
import { Component, OnInit, ViewChild } from "@angular/core";
import { ClickEventArgs } from "@syncfusion/ej2-navigations";
import { DataManager, ODataAdaptor, WebApiAdaptor } from "@syncfusion/ej2-data";
import { DataStateChangeEventArgs } from '@syncfusion/ej2-grids';
import { Observable } from 'rxjs';
import {
  GridComponent,
  ToolbarItems,
  EditService,
  PageService,
  CommandColumnService,
  CommandModel,
  PageSettingsModel,
  ColumnMenuService,
  RowSelectEventArgs
} from "@syncfusion/ej2-angular-grids";


@Component({
  selector: 'app-recipelist',
  templateUrl: './recipelist.component.html',
  styleUrls: ['./recipelist.component.scss'],
  providers: [EditService, PageService, CommandColumnService, ColumnMenuService]
})
export class RecipelistComponent implements OnInit {
  public data: Observable<DataStateChangeEventArgs>;
  public pageOptions: Object;
  public state: DataStateChangeEventArgs;
  public filterSettings: Object;
  public editSettings: Object;
  public toolbarOptions: ToolbarItems[];
  public dTdata: any;
  public editparams: Object;
  public viewData;

  public commands: CommandModel[];
  public pageSizes: number[] = [10,20,100,500,1000]; 
  public pageSettings: Object; 
  @ViewChild("grid", { static: false })
  public grid: GridComponent;
  url:any;
  recipeRoles:any;
  constructor(private itemList: ItemmasterService,private dataservice:DataService) {

    this.data = itemList;
   
  }

  toolbarClick(args: ClickEventArgs): void {
    if (args.item.id === "Grid_excelexport") {
   
      // 'Grid_excelexport' -> Grid component id + _ + toolbar item name
      this.grid.excelExport();
    }
  }
  ngOnInit() {

    this.url="/recipe/recipes"
    this.pageSettings = { pageCount: 10, pageSize: this.pageSizes[0], pageSizes: this.pageSizes }; 
    let state = { skip: 0, take: 10 };
    this.itemList.execute(state,this.url,'recipe');
    this.filterSettings = { type: "Menu" };
    this.toolbarOptions = ["ExcelExport", "Search"];

    //   this.editSettings = { allowEditing: false, allowAdding: true,  mode: 'Dialog', allowEditOnDblClick: true };
    // this.commands = [{ type: 'Edit', buttonOption: { iconCss: ' e-icons e-edit', cssClass: 'e-flat' } },

    //       { type: 'Save', buttonOption: { iconCss: 'e-icons e-update', cssClass: 'e-flat' } },
    //       { type: 'Cancel', buttonOption: { iconCss: 'e-icons e-cancel-icon', cssClass: 'e-flat' } }];
    //       this.editparams = { params: { popupHeight: '300px' }};
  }


  public dataStateChange(state: DataStateChangeEventArgs): void {
    console.log(state)
    this.itemList.execute(state,this.url,"recipe");

  }

  refreshList()
  {
    let state = { skip: 0, take: 10 };
      this.itemList.execute(state,this.url,'recipe');
  }

  // getrecipeList($event) {
  //   this.itemList
  //     .getAllRecipeList()
  //     .subscribe(resp => (this.dTdata = resp.recipe_list));
  // }
 

  // tabs
  tabs: any[] = [];

  addNewTab(rowdata: any, type: any): void {
    // console.log(this.tabs)
    if (type == "new") {
      this.tabs.push({
        title: `Add New Recipe`,
        content: type,
        disabled: false,
        removable: true,
        active: true
      });
    } else if (type == "edit") {
      if (this.tabs.some(title => title.title === rowdata.recipename)) {
        for (let i = 0; i < this.tabs.length; i++) {
          if (this.tabs[i].title == rowdata.recipename) {
            this.tabs[i].active = true;
          }
        }
      } else {
        this.tabs.push({
          title: rowdata.recipename,
          content: type,
          disabled: false,
          removable: true,
          active: true
        });
      }
    }
  }
  removeTabHandler(tab: any): void {
    this.tabs.splice(this.tabs.indexOf(tab), 1);
     console.log(tab);
  }

  getRowData(args: any): void {
    let data = this.grid.getRowInfo(args.target);
    this.viewData = data.rowData;
 
    this.addNewTab(data["rowData"], "edit");
  }




  onSelect(data: TabDirective): void {
    console.log(data.heading);
    console.log("calling")
  }


}

