export interface RecipeAllData {
    recipeid?: string;
    recipename?: string;
    status?: string;
    description?: string;
    inactivedate?:string;
    effectivedate?:string;
    item?: string;
    recipetype?: string;
    allowbatch?: boolean;
    username?: string;
    attributes?: (AttributesEntity)[] | null;
    attributetable?: (AttributetableEntity)[] | null;
    tags?: (null)[] | null;
  }
  export interface AttributesEntity {
    attributeid: number;
    attributevalue: string;
  }
  export interface AttributetableEntity {
    attributedataid: number;
    attributeid: number;
    attributevalue: string;
    rowno: number;
  }