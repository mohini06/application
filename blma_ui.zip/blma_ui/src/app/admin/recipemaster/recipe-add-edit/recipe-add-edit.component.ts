import { LoginService } from './../../../_core/services/login.service';
import { PreferenceService } from './../../../_core/services/preference.service';
import { map } from 'rxjs/operators';
import { AlertService } from './../../../_core/services/alert.service';
import { DataService } from './../../../_core/services/data.service';

import { Newrecipelist } from '../recipe-list-interface';
import { ItemmasterService } from '../../../_core/services/itemmaster.service';
import { Component, OnInit, TemplateRef, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { DateTimePickerComponent } from '@syncfusion/ej2-angular-calendars';
import { BatchesService } from './../../../_core/services/batches.service';
import { RecipeAllData } from './recipe-all-data';
import { of } from 'rxjs';
@Component({
  selector: 'app-recipe-add-edit',
  templateUrl: './recipe-add-edit.component.html',
  styleUrls: ['./recipe-add-edit.component.scss']
})
export class RecipeAddEditComponent implements OnInit {
  @Input() type: any;
  @Input() rowData: any;
  @Input() hidecontrol: any;

  @Output() getGroupList = new EventEmitter<string>();
  @Output() createNew = new EventEmitter<string>();
  recipetypeData: any;
  recipestatusData: any;
  recipeitemData: any;
  recipeMasterNewForm: FormGroup;
  sucess: string;
  error: string;
  parent = "recipe";
  detailsFlag: Boolean = false;
  newRecipeSaveData: Newrecipelist = {};
  recipeAllData: RecipeAllData = {}
  username: string;
  childData = "";
  attributeData: any;
  formatedAttributeData = [];
  formatedAttributeTable = []
  tagData = [];
  formatedTagId = [];
  tableData = [];
  modalRef: BsModalRef;
  isSubmitted: boolean = false
  dateFormate = ''
  Recipestatus:any
  public defaultDate = new Date()
  public dateTime = new Date()
  recipeRoles:any;

  Updatetab:boolean=false;
  Createtab:boolean=false;
  constructor(private formBuilder: FormBuilder, private modalService: BsModalService,
    private recipemaster: ItemmasterService, private data: DataService,
    private batchesService: BatchesService, private alert: AlertService,
    private preference: PreferenceService) {
   
      
    }
    recipeCheckAccessData:any;
    recipecommentTab: boolean = true;
  recipetagTab: boolean = true;
  recipeAttributeTab:boolean=true;
  recipesectionTab:boolean=true;
  ngOnInit() {
    // console.log(this.dateTime)
    this.recipeMasterNewForm = this.formBuilder.group({
      recipename: ['', [Validators.required, Validators.pattern(".*\\S.*[a-zA-z0-9 ]")], [this.checkName.bind(this)]],
      recipetype: ['', Validators.required],
      recipestatus: ['', Validators.required],
      recipeitem: ['', Validators.required],
      effectivedate: [this.defaultDate,],
      inactivedate: ['',],
      yes: [''],
      recipeid: [0],
      allowBatch: [''],
      description: ['']
    });

    this.recipemaster.fieldLevelAcess("recipe", null).subscribe(data => {
      this.recipeCheckAccessData = data.item.child;
      if(this.recipeCheckAccessData!=null){
      for (let obj of this.recipeCheckAccessData) {
        for (let keyname in obj) {
          if (obj[keyname].type == "Column") {
            if (obj[keyname].read == false) {
              for (const field in this.recipeMasterNewForm.controls) { // 'field' is a string
                if (field == keyname) {
                  this.recipeMasterNewForm.controls[field].disable();
                }
              }
            }
            else {
              if (obj[keyname].update == false) {
                for (const field in this.recipeMasterNewForm.controls) { // 'field' is a string
                  if (field == keyname) {
                    this.recipeMasterNewForm.controls[field].disable();
                  }
                }
              }
            }
          }
          else {
           
            if (keyname == "comment") {
              alert("comment")
              if (obj[keyname].read == false) {
                this.recipecommentTab = false;
              }
            }
            else if (keyname == "tag") 
            { if (obj[keyname].read == false) 
              {
                this.recipetagTab = false; 
               }
             }
            else if (keyname == "recipesection") {if (obj[keyname].read == false) { this.recipesectionTab = false; }}
            else if(keyname=="attribute"){if (obj[keyname].read==false){this.recipeAttributeTab=false}}
          }
        }
      }}
    })


    this.allowBatch.setValue(true)
    this.getAllDropdowns();
    this.username = this.batchesService.getUserName();
    // console.log(this.type)
    if (this.type == "edit") {
      // console.log(this.rowData)
      this.Createtab=false;
      this.Updatetab=true;
      this.setFormValue()
      this.detailsFlag = true;
      this.childData = this.rowData.recipeid;
     this.Recipestatus  =this.rowData.status;
    }
    else{
      this.Createtab=true;
      this.Updatetab=false;
    }

    this.dateFormate = this.preference.getDateFormate()
    // console.log(this.hidecontrol)
  }

  get recipename() { return this.recipeMasterNewForm.get('recipename'); }
  get recipeitem() { return this.recipeMasterNewForm.get('recipeitem'); }
  get recipestatus() { return this.recipeMasterNewForm.get('recipestatus'); }
  get recipetype() { return this.recipeMasterNewForm.get('recipetype'); }
  get description() { return this.recipeMasterNewForm.get('description'); }
  get effectivedate() {
    
    return this.recipeMasterNewForm.get('effectivedate');
  
  }
  get inactivedate() { return this.recipeMasterNewForm.get('inactivedate'); }
  get recipeid() { return this.recipeMasterNewForm.get('recipeid'); }
  get allowBatch() { return this.recipeMasterNewForm.get('allowBatch'); }

  

  setFormValue() {
   
    this.recipename.setValue(this.rowData.recipename)
    this.recipeitem.setValue(this.rowData.itemid)
    this.recipestatus.setValue(this.rowData.status)
    this.recipetype.setValue(this.rowData.processtype)
    this.description.setValue(this.rowData.description)
    this.effectivedate.setValue(this.preference.setDate(this.rowData.effectivedate))
    this.inactivedate.setValue(this.preference.setDate(this.rowData.inactivedate))
    this.recipeid.setValue(this.rowData.recipeid)
    this.allowBatch.setValue(this.rowData.allowbatch)
  }

  getAllDropdowns() {
   
    this.recipemaster.getRecipeDropdownDetail().subscribe(data => {
  
    
      // console.log("values")
      if(this.Recipestatus=="NEW")
      {
        this.recipetypeData = data.recipe_type;
         this.recipestatusData = data.recipe_status;
        this.recipestatusData[4]="NEW";
        this.recipeitemData = data['recipe_item'][0].dj;
       
      }
     
      this.recipetypeData = data.recipe_type;
      this.recipestatusData = data.recipe_status;
      this.recipeitemData = data['recipe_item'][0].dj;
      

    }
    )
  }

  effectivestartdate:any;
  onChangeeffective(args)
  {
    
    this.effectivestartdate=args.value;
  }

  effectiveenddate:any;
  onChangeeffectiveend(args)
  {
    
    this.effectiveenddate=args.value;
  }

  operationEditSave() {
    if (this.childData) {
      // console.log("edit")
      if (this.attributeData) {
        for (let i = 0; i < this.attributeData.attribute_data.length; i++) {
          this.formatedAttributeData.push({ 'attributeid': this.attributeData.attribute_data[i].attributeid, 'attributevalue': this.attributeData.attribute_data[i].attributevalue })

        }

        for (let i = 0; i < this.attributeData['attribute_grpsections'].length; i++) {

          if (this.attributeData['attribute_grpsections'][i].is_table) {
            // console.log(this.attributeData['attribute_datatables']['ag_'+this.attributeData['attribute_grpsections'][i].attributegroupid])
            for (let j = 0; j < this.attributeData['attribute_datatables']['ag_' + this.attributeData['attribute_grpsections'][i].attributegroupid].rows.length; j++) {
              // console.log( this.attributeData['attribute_datatables']['ag_'+this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j])

              for (let k = 0; k < this.attributeData['attribute_datatables']['ag_' + this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j].length; k++) {
                // console.log(this.attributeData['attribute_datatables']['ag_'+this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j][k])
                this.formatedAttributeTable.push(this.attributeData['attribute_datatables']['ag_' + this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j][k])
              }
            }
          }
        }

      
      }
      else {
        this.formatedAttributeData = [];
      }
      //  all data
      this.recipeAllData.recipeid = this.childData
      this.recipeAllData.recipename = this.recipename.value
      this.recipeAllData.status = this.recipestatus.value
      this.recipeAllData.item = this.recipeitem.value
      this.recipeAllData.recipetype = this.recipetype.value
      this.recipeAllData.allowbatch = this.allowBatch.value
      this.recipeAllData.username = this.username;
      this.recipeAllData.description = this.description.value
      this.recipeAllData.attributes = this.formatedAttributeData;
      this.recipeAllData.effectivedate = this.preference.setDateFormate(this.effectivestartdate)
      // this.recipeAllData.inactivedate = this.effectiveenddate
      this.recipeAllData.inactivedate = this.preference.setDateFormate(this.effectiveenddate)

      this.recipeAllData.attributetable = this.formatedAttributeTable


      if (this.tagData) {
        for (let i = 0; i < this.tagData.length; i++) {
          this.formatedTagId.push({ 'id': this.tagData[i].tagid })
        }
      } else {
        this.formatedTagId = []
      }

      this.recipeAllData.tags = this.formatedTagId;
      // console.log(this.formatedAttributeData)
      this.editRecipeDetails(this.recipeAllData)
      

    }
    else {
      // console.log("save")
      this.saveNewRecipeDetails()
    }
  }

  saveNewRecipeDetails() {
    this.alert.removeAlert();
    if (this.allowBatch.value == "") {
      this.newRecipeSaveData.allowbatch = false
    } else {
      this.newRecipeSaveData.allowbatch = this.allowBatch.value
    }

    this.newRecipeSaveData.username = this.username
    this.newRecipeSaveData.description = this.description.value
    this.newRecipeSaveData.item = this.recipeitem.value
    this.newRecipeSaveData.status = this.recipestatus.value
    this.newRecipeSaveData.recipename = this.recipename.value
    this.newRecipeSaveData.type = this.recipetype.value
    this.newRecipeSaveData.effectivedate = this.preference.setDateFormate(this.effectivedate.value)
    this.newRecipeSaveData.inactivedate = this.preference.setDateFormate(this.inactivedate.value)

    this.newRecipeSaveData.recipeid = this.recipeid.value


    this.recipemaster.saveRecipe(this.newRecipeSaveData).subscribe(data=>{
       this.childData =  data['recipe'].rows[0]['Inserted Row ID'];
       console.log(this.childData)
      this.alert.success("Successfully saved")
      this.getGroupList.emit(null)
      this.detailsFlag = true;
      setTimeout(() => {
        this.alert.removeAlert();
      }, 1500);
    },
    error => {
      if (error.status == 409) {
        this.alert.error("Recipe already exists")
      } else {
        this.alert.error(error.error.message)
      }
      console.log(error.error)
    
    }
    )

    // this.recipemaster.saveRecipeNewDetails(this.newRecipeSaveData).
    //   subscribe(data => {
    //     //  console.log(data);
    //     this.childData = data['id'];
    //     this.alert.success("Successfully saved")
    //     this.getGroupList.emit(null)
    //     this.detailsFlag = true;
    //     setTimeout(() => {
    //       this.alert.removeAlert();
    //     }, 1500);

    //   },
    //     error => {
    //       if (error.status == 409) {
    //         this.alert.error("Recipe already exists")
    //       } else {
    //         this.alert.error(error.error.message)
    //       }
    //       console.log(error.error)

    //     })

  }


  editRecipeDetails(data: any) {

    this.recipemaster.updateRecipe(data).
      subscribe(data => {
  // console.log(data);
        this.getGroupList.emit(null)
        this.alert.success("Successfully Saved")
        setTimeout(() => {
          this.alert.removeAlert();
        }, 1500);
      },
        error => {
          if (error.status == 409) {
            this.alert.error("Recipe already exists")
          } else {
            this.alert.error(error.error.message)
          }
        })
  }


  checkRecipeName() {

    this.recipemaster.checkRecipeName(this.recipename.value, this.recipeid.value).
      subscribe(data => {
        // console.log(data);

        this.alert.removeAlert();

      },
        error => {
          if (error.status == 409) {
            this.alert.error("Recipe already exists")
          } else {
            this.alert.error(error.error.message)
          }


        })
  }

  checkName(control: AbstractControl) {
    if (control.value) {
      return this.recipemaster.checkRecipeName(control.value, this.recipeid.value).pipe(
        map(response => {
          // console.log(response)
          return response ? null : { forbiddenName: { value: control.value } };
        }) // use observables, don't convert to promises
      );
    }
    return of(null); // gotta return an observable for async
  }


  getAttributeDataRecipe(data): void {
    console.log(data)
    this.attributeData = data
  }

  getTagDataRecipe(tagdata): void {
    this.tagData = tagdata
    // console.log(data)
  }

  config = {
    backdrop: true,
    ignoreBackdropClick: true
  };
  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);

  }
  openModalAudit(audithistory: TemplateRef<any>) {
    this.newParam(this.rowData.recipeid, 'recipe')
    this.modalRef = this.modalService.show(audithistory, Object.assign({}, this.config, { class: 'gray modal-lg' }));

  }

  newParam(param: any, table: any) {
    this.data.changeParam({ message: param, table: table })
  }


  createNewTab() {
    this.createNew.emit(null)
    // console.log("new clicked")

  }
  removeAlert() {
    this.alert.removeAlert();

  }

}
