import { map } from 'rxjs/operators';
import { AlertService } from './../../../_core/services/alert.service';
import { DataService } from './../../../_core/services/data.service';
import { TabDirective } from 'ngx-bootstrap/tabs';
import { ItemmasterService } from "./../../../_core/services/itemmaster.service";
import { Component, OnInit, ViewChild, Input } from "@angular/core";
import { ClickEventArgs } from "@syncfusion/ej2-navigations";
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { DataManager, ODataAdaptor, WebApiAdaptor } from "@syncfusion/ej2-data";


import {
  GridComponent,
  ToolbarItems,
  EditService,
  PageService,
  CommandColumnService,
  CommandModel,
  PageSettingsModel,
  ColumnMenuService,
  RowSelectEventArgs
} from "@syncfusion/ej2-angular-grids";
import { of } from 'rxjs';

@Component({
  selector: 'app-taglist',
  templateUrl: './taglist.component.html',
  styleUrls: ['./taglist.component.scss'],
  providers: [EditService, PageService, CommandColumnService, ColumnMenuService]
})
export class TaglistComponent implements OnInit {
  @Input() parentData: any;
  public data: DataManager;
  public filterSettings: Object;
  public editSettings: Object;
  public toolbarOptions: ToolbarItems[];
  public dTdata: any;
  public editparams: Object;
  public commands: CommandModel[];
  public initialPage: PageSettingsModel;
  tagListtypeData: any;
  tagGroupData: any;
  public isSubmitted: boolean = false;
  tagListNameData: any;
  tagListMasterNewForm: FormGroup;
  public formatOptions: any;
  @ViewChild("grid", { static: false })
  public grid: GridComponent;
  isSubmitte: boolean = false
  constructor(private alert: AlertService, private formBuilder: FormBuilder, private masterservice: ItemmasterService, private dataservice: DataService) { }

  toolbarClick(args: ClickEventArgs): void {
    if (args.item.id === "Grid_excelexport") {
      // 'Grid_excelexport' -> Grid component id + _ + toolbar item name
      this.grid.excelExport();
    }
  }
  ngOnInit() {
    this.initialPage = { pageSizes: true, pageSize: 10 };

    this.filterSettings = { type: "Menu" };
    this.toolbarOptions = ["ExcelExport", "Search", 'Add', 'Edit', 'Update', 'Cancel'];
    this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Dialog' };
    this.formatOptions = { type: 'date', format: "MM/dd/yyyy hh:mm a" };

    this.tagListMasterNewForm = this.formBuilder.group({
       tagListname: [''],
      tagListsortno: ['', [Validators.required]],
      tagListcaption: ['', [Validators.required, Validators.pattern(".*\\S.*[a-zA-z0-9 ]")]],
      startdate: [''],
      enddate: [''],

      tagListid: [0],

      description: [''],

      hidetagList: ['']
    });

    this.tagList()
  }
  get tagListid() { return this.tagListMasterNewForm.get('tagListid'); }
  get tagListname() { return this.tagListMasterNewForm.get('tagListname'); }
  get tagListcaption() { return this.tagListMasterNewForm.get('tagListcaption'); }
  get startdate() { return this.tagListMasterNewForm.get('startdate'); }
  get enddate() { return this.tagListMasterNewForm.get('enddate'); }
  get description() { return this.tagListMasterNewForm.get('description'); }
  get hidetagList() { return this.tagListMasterNewForm.get('hidetagList'); }
  get tagListsortno() { return this.tagListMasterNewForm.get('tagListsortno'); }




  public columns: object[] = [
    {
      field: 'caption', headerText: 'Caption'
    },
    {
      field: 'tagname', headerText: 'Tag Name'
    },
    {
      field: 'sortno', headerText: 'Sort No'
    },
    {
      field: 'hide', headerText: 'Hide'
    }
  ];

  setFormdata(data) {
    this.tagListname.setValue(data.tagname)
    this.tagListcaption.setValue(data.caption)
    this.startdate.setValue(data.effectivedate)
    this.enddate.setValue(data.inactivedate)
    this.tagListid.setValue(data.tagid)
    this.description.setValue(data.description)
    this.hidetagList.setValue(data.hide)
    this.tagListsortno.setValue(data.sortno)
  }

  checkTag() {
   
    
    let status
    this.masterservice.checkTag(this.tagListname.value, this.tagListid.value).
      subscribe(data => {
        this.alert.removeAlertChild()
        status = true;
      },
        error => {
          this.alert.errorChild("Tag Name Already exists");
          status = false;
          //  console.log(error.error)
        })
    return status
  }

  checkName(control: AbstractControl) {
    if (control.value) {
      return this.masterservice.checkTag(this.tagListname.value, this.tagListid.value).pipe(
        map(response => {
          // console.log(response)
          return response ? null : { forbiddenName: { value: control.value } };
        }) // use observables, don't convert to promises
      );
    }
    return of(null); // gotta return an observable for async
  }

  saveTag(data: any) {
    this.masterservice.saveTag(data, this.parentData).
      subscribe(data => {
        this.tagList()
        this.alert.success("Successfully Saved")
        setTimeout(() => {
          this.alert.removeAlert();
        }, 1500);

      },
        error => {
          this.alert.error(error.error.message);

          //  console.log(error.error)
        })
  }


  //Get All taglist
  tagList() {
    this.masterservice.getTagList(this.parentData).
      subscribe(data => {
        this.dTdata = data.tags
      },
        error => {
          this.alert.error(error.error.message);

          //  console.log(error.error)
        })

  }


  //data table operation

  actionBegin(args): void {
    // console.log(args)
    if (args.requestType === 'beginEdit' || args.requestType === 'add') {
      this.isSubmitted = false;

      if (args.requestType === 'beginEdit') {
        this.setFormdata(args.rowData)

      } else {
        this.resetForm(this.tagListMasterNewForm)
      }

      if (args.requestType === 'add') {
        this.resetForm(this.tagListMasterNewForm)

      }


    }
    if (args.requestType === 'save') {
      this.isSubmitted = true;
      // if (!this.valVer()) {
      //   return;
      // }
      if (this.tagListMasterNewForm.valid) {

        if (args.action === 'edit') {
          this.saveTag(this.tagListMasterNewForm.value)
          console.log(args.data)
        }
        if (args.action === 'add') {
          this.saveTag(this.tagListMasterNewForm.value)

        }

        // args.data = this.versionForm.value;
      } else {
        args.cancel = true;
      }
    }

  }


  actionComplete(args) {
    if ((args.requestType === 'beginEdit' || args.requestType === 'add')) {
      const dialog = args.dialog;

      // console.log(args)
      // change the header of the dialog
      dialog.header = args.requestType === 'beginEdit' ?  args.rowData['caption'] : 'New Tag';
    }
  }
  resetForm(form: FormGroup) {

    form.reset();

    Object.keys(form.controls).forEach(key => {
      form.get(key).setErrors(null);
    });
  }

  onlyNumber(event) {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }


}
