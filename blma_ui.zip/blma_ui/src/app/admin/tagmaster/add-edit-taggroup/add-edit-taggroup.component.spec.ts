import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditTaggroupComponent } from './add-edit-taggroup.component';

describe('AddEditTaggroupComponent', () => {
  let component: AddEditTaggroupComponent;
  let fixture: ComponentFixture<AddEditTaggroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddEditTaggroupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditTaggroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
