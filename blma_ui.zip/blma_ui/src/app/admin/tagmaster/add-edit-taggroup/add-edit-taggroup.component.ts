import { PreferenceService } from './../../../_core/services/preference.service';
import { DataService } from './../../../_core/services/data.service';
import { data } from './../../../data-entry/data.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { AlertService } from './../../../_core/services/alert.service';
import { ItemmasterService } from '../../../_core/services/itemmaster.service';
import { Component, OnInit, TemplateRef, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl, AsyncValidatorFn } from '@angular/forms';
import { BatchesService } from './../../../_core/services/batches.service';
import { Observable, timer } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';
import { of, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { LoginService } from './../../../_core/services/login.service';

@Component({
  selector: 'app-add-edit-taggroup',
  templateUrl: './add-edit-taggroup.component.html',
  styleUrls: ['./add-edit-taggroup.component.scss']
})
export class AddEditTaggroupComponent implements OnInit {
  @Input() type: any;
  @Input() rowData: any;
  @Output() getGroupList = new EventEmitter<string>();
  @Output() createNew = new EventEmitter<string>();

  tagtargetobjlistData: any;
  tagtypeData: any;
  tagGroupMasterNewForm: FormGroup;
  detailsFlag: Boolean = false;s
  username: string;
  childData = "";
  targetObjectDropDown = []
  tagType = []
  isSubmitted: boolean = false
  modalRef: BsModalRef;
  parent = "taggroup"
  dateFormate = ''
  public defaultDate = new Date()
  public dateTime = new Date()
  idToggle
  disableTargetObj: boolean = false

  attributeRoles:any;
  tagCheckAccessData: any;
  tagTab: boolean = true;


  Updatetab:boolean=false;
  Createtab:boolean=false;
  constructor(private preference: PreferenceService, private formBuilder: FormBuilder, private modalService: BsModalService, private data: DataService,
    private batchesService: BatchesService, private alert: AlertService, private masterservice: ItemmasterService) {
      
    this.idToggle = this.dateTime.getTime();
  
  }

  
  ngOnInit() {
    this.tagGroupMasterNewForm = this.formBuilder.group({
      caption: ['', [Validators.required, Validators.pattern(".*\\S.*[a-zA-z0-9 ]")]],
      // taggroupname: ['',
      //   Validators.compose(
      //     [Validators.required, Validators.minLength(2), Validators.pattern(".*\\S.*[a-zA-z0-9 ]")]
      //   )

      //   , [this.checkName.bind(this)], 


      // ],
      taggroupname: [null, {
        validators: [Validators.required, Validators.minLength(2),
        Validators.pattern(".*\\S.*[a-zA-z0-9 ]")], asyncValidators: this.checkName.bind(this),
        updateOn: 'blur'
      }],
       targetobjname: ['', [Validators.required]],
      //targetobjname: [''],
      effectivedate: [this.defaultDate],
      inactivedate: [''],
      taggroupid: [0],
      tagtype: [''],
      allow_multiples: [''],
      hide: [''],
      description: ['']
    });


//Service for Field level Role Access
this.masterservice.fieldLevelAcess("tag", null).subscribe(data => {
  this.tagCheckAccessData = data.item.child;
  if(this.tagCheckAccessData)
  {
  for (let obj of this.tagCheckAccessData) {
    for (let keyname in obj) {
      if (obj[keyname].type == "Column") {
        if (obj[keyname].read == false) {
          for (const field in this.tagGroupMasterNewForm.controls) { // 'field' is a string
            if (field == keyname) {
              this.tagGroupMasterNewForm.controls[field].disable();
            }
          }
        }
        else {
          if (obj[keyname].update == false) {
            for (const field in this.tagGroupMasterNewForm.controls) { // 'field' is a string
              if (field == keyname) {
                this.tagGroupMasterNewForm.controls[field].disable();
              }
            }
          }
        }
      }
      else {
        if (keyname == "tag") {
          if (obj[keyname].read == false) {
            this.tagTab = false;
          }
        }
        
      }
    }
  }}
})


    this.getTagData()

    if (this.type == "edit") {
      this.Createtab=false;
      this.Updatetab=true;
      this.setFormValue()
      this.childData = this.rowData.taggroupid
      this.detailsFlag = true;
      // console.log(this.rowData)
    }

    else
    {
      this.Createtab=true;
      this.Updatetab=false;
    }
    this.dateFormate = this.preference.getDateFormate()
  }
  get caption() { return this.tagGroupMasterNewForm.get('caption'); }
  get taggroupname() { return this.tagGroupMasterNewForm.get('taggroupname'); }
  get targetobjname() { return this.tagGroupMasterNewForm.get('targetobjname'); }
  get taggroupid() { return this.tagGroupMasterNewForm.get('taggroupid'); }
  get effectivedate() { return this.tagGroupMasterNewForm.get('effectivedate'); }
  get inactivedate() { return this.tagGroupMasterNewForm.get('inactivedate'); }
  get tagtype() { return this.tagGroupMasterNewForm.get('tagtype'); }
  get allow_multiples() { return this.tagGroupMasterNewForm.get('allow_multiples'); }
  get hide() { return this.tagGroupMasterNewForm.get('hide'); }
  get description() { return this.tagGroupMasterNewForm.get('description'); }


  setFormValue() {
    this.caption.setValue(this.rowData.caption)
    this.taggroupname.setValue(this.rowData.taggroupname)
    this.targetobjname.setValue(this.rowData.targetobjname)
    this.tagtype.setValue(this.rowData.tagtype)
    this.taggroupid.setValue(this.rowData.taggroupid)
    this.effectivedate.setValue(this.rowData.effectivedate)
    this.inactivedate.setValue(this.rowData.inactivedate)
    this.hide.setValue(this.rowData.hide)
    this.allow_multiples.setValue(this.rowData.allow_multiples)
    this.description.setValue(this.rowData.description)
    // this.tagtargetobjlist.disable()
    this.disableTargetObj = true

  }

  saveTagGroup() {
    if (!this.tagGroupMasterNewForm.valid) {
      return;
    }

    if (this.allow_multiples.value == "") {
      this.allow_multiples.setValue(false)
    }
    if (this.hide.value == "") {
      this.hide.setValue(false)
    }
console.log(this.tagGroupMasterNewForm.value)
    this.masterservice.saveTags(this.tagGroupMasterNewForm.value).
      subscribe(data => {
        this.childData =  data['taggroup'].rows[0]['Inserted Row ID'];
        this.taggroupid.setValue(data.id)

        this.getGroupList.emit(null)
        this.alert.success("Successfully saved")
        setTimeout(() => {
          this.alert.removeAlert();
        }, 1500);
        this.detailsFlag = true;
        this.disableTargetObj = true
        //  this.itemMasterForm.reset();
      },
        error => {
          if (error.status == 409) {
            this.alert.error("tag Group name already exist")
          } else {
            this.alert.error(error.error.message)
          }
        })
  }


  getTagData() {

    this.masterservice.getTagGroupData().
      subscribe(data => {
        // console.log(data); 
        this.targetObjectDropDown = data['tag_targetobjlist'];
        this.tagType = data['tag_type']

      },
        error => {

          //  console.log(error.error)
        })
  }

  checkTagGroup() {
    let status
    this.masterservice.checkTaggroup(this.taggroupname.value, this.taggroupid.value).
      subscribe(data => {
        this.alert.removeAlert()
        status = true;
      },
        error => {
          this.alert.error("Tag Group Name Already exists");
          status = false;
          //  console.log(error.error)
        })
    return status
  }

  validateTagGroup(control: AbstractControl) {
    return this.masterservice.checkTaggroup(control.value).map(res => {
      console.log(res)
      // return res ? { groupTaken: false } : { groupTaken: true };
    });
  }

  userValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Observable<{ [key: string]: any } | null> => {
      return this.masterservice.checkTaggroup(control.value)
        .pipe(
          map(response => response),
          catchError((e: any) => {
            //do your processing here
            console.log(e)
            return throwError({ groupTaken: true });
          }),
        );
    };

  }

  checkName(control: AbstractControl) {
    let id = this.taggroupid.value
    if (control.value) {
      return this.masterservice.checkTaggroup(control.value, id).pipe(
        map(response => {

          return response ? null : { forbiddenName: true };
        }) // use observables, don't convert to promises
      );
    }
    return of(null); // gotta return an observable for async
  }


  createNewTab() {
    this.createNew.emit(null)
    // console.log("new clicked")
  }
  config = {
    backdrop: true,
    ignoreBackdropClick: true
  };
  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);

  }
  openModalAudit(audithistory: TemplateRef<any>) {
    this.newParam(this.rowData.taggroupid, 'taggroup')
    this.modalRef = this.modalService.show(audithistory, Object.assign({}, this.config, { class: 'gray modal-lg' }));

  }

  newParam(param: any, table: any) {
    this.data.changeParam({ message: param, table: table })
  }


  test() {
    console.log(this.taggroupname.errors)

  }
  removeAlert() {
    this.alert.removeAlert();

  }

}
