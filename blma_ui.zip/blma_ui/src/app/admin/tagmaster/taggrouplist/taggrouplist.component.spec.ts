import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaggrouplistComponent } from './taggrouplist.component';

describe('TaggrouplistComponent', () => {
  let component: TaggrouplistComponent;
  let fixture: ComponentFixture<TaggrouplistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaggrouplistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaggrouplistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
