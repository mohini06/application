import { DataService } from './../../../_core/services/data.service';
import { TabDirective } from 'ngx-bootstrap/tabs';
import { ItemmasterService } from "./../../../_core/services/itemmaster.service";
import { Component, OnInit, ViewChild } from "@angular/core";
import { ClickEventArgs } from "@syncfusion/ej2-navigations";
import { DataManager, ODataAdaptor, WebApiAdaptor } from "@syncfusion/ej2-data";
import { DataStateChangeEventArgs } from '@syncfusion/ej2-grids';
import { Observable } from 'rxjs';
import {
  GridComponent,
  ToolbarItems,
  EditService,
  PageService,
  CommandColumnService,
  CommandModel,
  PageSettingsModel,
  ColumnMenuService,
  RowSelectEventArgs
} from "@syncfusion/ej2-angular-grids";
import { LoginService } from './../../../_core/services/login.service';


@Component({
  selector: 'app-taggrouplist',
  templateUrl: './taggrouplist.component.html',
  styleUrls: ['./taggrouplist.component.scss'],
  providers: [EditService, PageService, CommandColumnService, ColumnMenuService]

})
export class TaggrouplistComponent implements OnInit {
  public data: Observable<DataStateChangeEventArgs>;
  public filterSettings: Object;
  public editSettings: Object;
  public toolbarOptions: ToolbarItems[];
  public dTdata: any;
  public editparams: Object;
  public commands: CommandModel[];
  public pageSizes: number[] = [10, 20, 100, 500, 1000];
  public pageSettings: Object;
  public formatOptions: any;
  @ViewChild("grid", { static: false })
  public grid: GridComponent;
  url: any
  public viewData;

  tagRoles:any;
  constructor(private masterservice: ItemmasterService, private dataservice: DataService,private role:LoginService) {
    // this.tagRoles=this.role.Rolesdata['tag']
    this.data = masterservice;
  }

  toolbarClick(args: ClickEventArgs): void {
    if (args.item.id === "Grid_excelexport") {
      // 'Grid_excelexport' -> Grid component id + _ + toolbar item name
      this.grid.excelExport();
    }
  }
  ngOnInit() {
    this.url = "/tag/taggrouplist"
    this.pageSettings = { pageCount: 10, pageSize: this.pageSizes[0], pageSizes: this.pageSizes };
    let state = { skip: 0, take: 10 };
    this.masterservice.execute(state, this.url, 'taggroup');
    this.filterSettings = { type: "Menu" };
    this.toolbarOptions = ["ExcelExport", "Search"];
    this.formatOptions = { type: 'date', format: "MM/dd/yyyy hh:mm a" };
  }


  public columns: object[] = [
    {
      field: 'caption', headerText: 'Caption'
    },

    {
      field: 'taggroupname', headerText: 'Tag Group'
    },
    {
      field: 'targetobjname', headerText: 'Target Obj Name'
    },
    {
      field: 'tagtype', headerText: 'Tag Type'
    },
    {
      headerText: 'Action', template: '<ng-template #template let-dTdata><i class="fa fa-edit" (click)= "getRowData($event)"></i> </ng-template>'
    }
  ];

  // tabs

  getRowData(args: any): void {
    // console.log(args)
    let data = this.grid.getRowInfo(args.target);
    this.viewData = data.rowData;

    // console.log(this.viewData)
    this.addNewTab(data["rowData"], "edit");
  }

  tabs: any[] = [];

  addNewTab(rowdata: any, type: any): void {
    if (type == "new") {
      this.tabs.push({
        title: `Add New Tag Group`,
        content: type,
        disabled: false,
        removable: true,
        active: true
      });
    } else if (type == "edit") {
      if (this.tabs.some(title => title.title === rowdata.caption)) {
        for (let i = 0; i < this.tabs.length; i++) {
          if (this.tabs[i].title == rowdata.caption) {
            this.tabs[i].active = true;
          }
        }
      } else {
        this.tabs.push({
          title: rowdata.caption,
          content: type,
          disabled: false,
          removable: true,
          active: true
        });
      }
    }
  }
  removeTabHandler(tab: any): void {
    this.tabs.splice(this.tabs.indexOf(tab), 1);
    // console.log('Remove Tab handler');
  }

  public dataStateChange(state: DataStateChangeEventArgs): void {
    console.log(state)
    this.masterservice.execute(state, this.url, "taggroup");

  }

  refreshList() {
    let state = { skip: 0, take: 10 };
    this.masterservice.execute(state, this.url, 'taggroup');
  }


}
