import { PostgenericService } from './../../_core/services/postgeneric.service';
import { BatchesService } from './../../_core/services/batches.service';
import { Newitem } from '../itemmaster/viewitem/newitem';

import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ItemmasterService } from './../../_core/services/itemmaster.service';
import { Directive, ElementRef, HostListener, Component, ViewChild, OnInit, OnChanges, TemplateRef, Input, Output, EventEmitter, IterableDiffers, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgControl } from '@angular/forms';
import { NgSelectComponent } from '@ng-select/ng-select';
import { NzResizeEvent } from 'ng-zorro-antd/resizable';

@Component({
  selector: 'app-attributes',
  templateUrl: './attributes.component.html',
  styleUrls: ['./attributes.component.scss']
})
export class AttributesComponent implements OnInit {
  @Input() parentData: any;
  @Input() parent: any;
  // @ViewChild(NgSelectComponent,{static:false}) ngSelectComponent: NgSelectComponent;
  @Output() ChildData: EventEmitter<string[]> = new EventEmitter<string[]>();

  itemstatusData: any;
  itemtypeData: any;
  itemMasterForm: FormGroup;
  itemGroupattributes: any;
  attribute: any;
  selectedAtrribute = [];
  selectedAttributeGrpID = "";
  attributeGroupnames: any;
  formatedAttributeId = [];
  newItemSaveData: Newitem = {};
  edit: boolean = false;
  errorMsg = "";
  username: any;
  attributeGroupData: any;
  sectiondata = [];
  tableData = [];
  dataTopush = []
  modalRef: BsModalRef;
  selectedCalculation = [];
  listOption: any;
  tableListOption: any;
  attributeData = []
  savebutton=false;
  config = {
    backdrop: true,
    ignoreBackdropClick: true
  };

  constructor(private formBuilder: FormBuilder,
    private modalService: BsModalService,
    private itemAtrributes: ItemmasterService
    , private batchesService: BatchesService,
    private postGeneric: PostgenericService) {

  }

  ngOnInit() {
    this.operationType(this.parentData);
    // console.log(this.parentData)
    this.ChildData.emit(this.itemGroupattributes)
    this.username = this.batchesService.getUserName();
  }

  // ngDoCheck() {
  //   let changes = this.itemGroupattributes.diff(this.itemGroupattributes);
  //   if (changes) {
  //       console.log('Changes detected!');
  //   }

  //   }


  operationType($itemid) {
    if (this.edit) {
      this.itemAttributesGroup('', $itemid)

    } else {
      this.itemAttributesGroup('', $itemid)
    }
  }

  itemAttributesGroup(grpId: any = "", itemid: any) {
    this.itemAtrributes.getAttributeItemAllData('', itemid, this.parent)
      .subscribe(data => {
        console.log(data)
        
        this.itemGroupattributes = data
        this.attributeGroupData = data['attribute_grplist'];
        this.sectiondata = data['attribute_grpsections'];
        if(this.sectiondata.length>0)
        {
          this.savebutton=true;
        }
        this.tableData = data['attribute_datatables'];
        this.attribute = data['attribute_data']

      })
  }


  filterAttribute(attributegroupid: any) {
    // console.log(this.attribute.filter(param => param.attributegroupid === attributegroupid))
    this.selectedAtrribute = this.attribute.filter(param => param.attributegroupid === attributegroupid)
    return this.attribute.filter(param => param.attributegroupid === attributegroupid)
  }


  addAttribute() {

    this.itemAtrributes.addAttributeGroup(this.selectedAttributeGrpID, this.username, this.parentData)
      .subscribe(data => {
        // console.log(data)
        this.itemAttributesGroup('', this.parentData)
        this.selectedAttributeGrpID = ""
        this.selectedCalculation = [];

      },
        error => {
          if (error.status == 404) {
            alert("No Attribute found !")
          }
          // console.log(error.status)
        })
  }



  // getAttribute($event) {
  //   console.log($event)
  //   this.attributeGroupnames = $event.caption
  //   this.getAtrributesGroupId.getAttributeID($event.attributegroupid).
  //     subscribe(data => {
  //       this.attribute = data['item_attribute']

  //       console.log(this.attribute)
  //       for (let i = 0; i < this.attribute.length; i++) {
  //         this.formatedAttributeId.push(this.attribute['i'])
  //       }
  //       this.newItemSaveData.attributes = this.formatedAttributeId;
  //       console.log(this.newItemSaveData);
  //     })
  // }

  selectedGroupFn($event) {
    // console.log($event)
    if ($event) {
      if ($event.attributegroupid == "") {
        this.selectedAttributeGrpID = "";
      } else {
        this.errorMsg = "";
        this.selectedAttributeGrpID = "";
        this.selectedAttributeGrpID = $event.attributegroupid
        // console.log(this.selectedAttributeGrpID)
      }
    } else {
      this.selectedAttributeGrpID = "";

    }



  }

  checkTypeOfElement = (input: string, index: number) => {
    const parameter = this.selectedAtrribute[index]

    if (parameter.listname) {
      this.listOption = this.itemGroupattributes.attribute_lov[parameter.listname]
    }

    switch (input) {
      case 'text':
        return parameter.typename.toUpperCase() !== 'DATE' && parameter.typename.toUpperCase() !== 'TIME' && parameter.typename !== 'Date/Time' && !parameter.listname;
      case 'date':
        return parameter.typename.toUpperCase() == 'DATE'
      case 'datetime':
        return parameter.typename == 'Date/Time';
      case 'time':
        return parameter.typename == 'Time';
      case 'dropdown':
        return parameter.listname;
      // default:
      //   return !parameterVersion.dropdownlimittolist
    }
  }

  // Tabular data Control
  checkTypeOfElementTable = (input: string, firstIndex: number, secondIndex: number, table: any) => {


    if (this.tableData[table]) {
      // console.log(this.tableData[table][firstIndex])
      // const parameter = this.tableData[table][firstIndex]
      const parameter = this.tableData[table].headers[secondIndex]
      // console.log(parameter)
      if (parameter.listname) {
        this.tableListOption = this.itemGroupattributes.attribute_lov[parameter.listname]
      }

      switch (input) {
        case 'text':
          return parameter.formattype.toUpperCase() !== 'DATE' && parameter.formattype.toUpperCase() !== 'TIME' && parameter.formattype !== 'Date/Time' && !parameter.listname;
        case 'date':
          return parameter.formattype.toUpperCase() == 'DATE'
        case 'datetime':
          return parameter.formattype == 'Date/Time';
        case 'time':
          return parameter.formattype == 'Time';
        case 'dropdown':
          return parameter.listname;

      }

    }

    // if (parameter.limittolist) {
    //   this.listOption = this.allParam.batchdata_paramlov[parameter.listname]
    // }


    // console.log(this.option)
  }



  openModal(template: TemplateRef<any>) {
    if (this.selectedAttributeGrpID == "") {
      this.errorMsg = "Please select Attribute Group"

    } else {
      this.modalRef = this.modalService.show(template, Object.assign({}, this.config, { class: 'modal-sm custom-modal' }));
    }

  }

  confirm(): void {

    this.addAttribute();
    this.modalRef.hide();
  }

  decline(): void {

    this.modalRef.hide();
  }


  sendDataToParent() {
    
    this.ChildData.emit(this.itemGroupattributes)
    console.log(this.itemGroupattributes)
  }


  addRow(data) {
    // console.log(data)
    let last: any = this.itemGroupattributes['attribute_datatables']['ag_' + data].rows[this.itemGroupattributes['attribute_datatables']['ag_' + data].rows.length - 1];
    // console.log(last)
    // console.log(this.itemGroupattributes['attribute_datatables']['ag_' + data].rows)
    for (let j = 0; j < last.length; j++) {
      // console.log(last[j].rowno + 1)
      this.dataTopush.push({
        "rowno": last[j].rowno + 1,
        "rid": last[j].rid,
        "header_name": last[j].header_name,
        "attributeid": last[j].attributeid,
        "attributedataid": null,
        "attributevalue": '',
        "lastupdatedby": 1,
        "lastupdatedate": '',
        "creationdate": '',
        "createdby": '',
      })
    }
    this.itemGroupattributes['attribute_datatables']['ag_' + data].rows.push(this.dataTopush)
    // console.log(this.itemGroupattributes['attribute_datatables']['ag_' + data])
  }

  trackByFn(index, item) {
    return item.caption;
  }

  onKeyPress(type: any, event) {
    // console.log(type)
    if (type == 'Float') {
      let charCode = (event.which) ? event.which : event.keyCode;
      if (charCode != 46 && charCode > 31
        && (charCode < 48 || charCode > 57))
        return false;
      return true;
    }
    if (type == 'Number' || type == 'Integer') {

      const charCode = (event.which) ? event.which : event.keyCode;
      if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
      }
      return true;
    }
  }

  updateAttributeValue() {
    // console.log(this.itemGroupattributes)
    // return
    this.attributeData=[]

    for (let i = 0; i < this.itemGroupattributes['attribute_grpsections'].length; i++) {

      if (this.itemGroupattributes['attribute_grpsections'][i].is_table) {
        // console.log(this.attributeData['attribute_datatables']['ag_'+this.attributeData['attribute_grpsections'][i].attributegroupid])
        for (let j = 0; j < this.itemGroupattributes['attribute_datatables']['ag_' + this.itemGroupattributes['attribute_grpsections'][i].attributegroupid].rows.length; j++) {
          // console.log( this.attributeData['attribute_datatables']['ag_'+this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j])

          for (let k = 0; k < this.itemGroupattributes['attribute_datatables']['ag_' + this.itemGroupattributes['attribute_grpsections'][i].attributegroupid].rows[j].length; k++) {
             console.log(this.itemGroupattributes['attribute_datatables']['ag_' + this.itemGroupattributes['attribute_grpsections'][i].attributegroupid].rows[j][k].attributevalue)
            this.attributeData.push(
              {
                attributedataid:this.itemGroupattributes['attribute_datatables']['ag_' + this.itemGroupattributes['attribute_grpsections'][i].attributegroupid].rows[j][k].attributedataid,
                attributeid:this.itemGroupattributes['attribute_datatables']['ag_' + this.itemGroupattributes['attribute_grpsections'][i].attributegroupid].rows[j][k].attributeid,
                objrecid: this.parentData,
                attributevalue: this.itemGroupattributes['attribute_datatables']['ag_' + this.itemGroupattributes['attribute_grpsections'][i].attributegroupid].rows[j][k].attributevalue,
                rowno:this.itemGroupattributes['attribute_datatables']['ag_' + this.itemGroupattributes['attribute_grpsections'][i].attributegroupid].rows[j][k].rowno 
              
              })
          }
        }
      }

    }
// console.log(this.attributeData)
// return

    for (let i = 0; i < this.itemGroupattributes.attribute_data.length; i++) {
      {
        console.log(this.itemGroupattributes.attribute_data[i])
        this.attributeData.push(
          {
            attributedataid: this.itemGroupattributes.attribute_data[i].attributedataid,
            attributeid: this.itemGroupattributes.attribute_data[i].attributeid,
            objrecid: this.parentData,
            attributevalue: this.itemGroupattributes.attribute_data[i].attributevalue,
            rowno: this.itemGroupattributes.attribute_data[i].rowno
          }
        )
      }
    }
    // console.log(this.attributeData)
    this.postGeneric.postAttribute(this.attributeData).
      subscribe(data => {
        console.log(data)
        this.operationType(this.parentData);
      },
        error => {
          console.log(error.error)
        })
  }




}