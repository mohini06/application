import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemrecipeComponent } from './itemrecipe.component';

describe('ItemrecipeComponent', () => {
  let component: ItemrecipeComponent;
  let fixture: ComponentFixture<ItemrecipeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ItemrecipeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemrecipeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
