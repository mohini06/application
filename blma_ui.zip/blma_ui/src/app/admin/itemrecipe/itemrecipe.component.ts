import { PreferenceService } from './../../_core/services/preference.service';
import { DataService } from './../../_core/services/data.service';
import { Newitem } from './../itemmaster/viewitem/newitem';

import { ItemmasterService } from './../../_core/services/itemmaster.service';
import { HttpClient } from '@angular/common/http';
import { ItemRecipeService } from './../../_core/services/itemrecipe.service';
import { environment } from '../../../environments/environment.prod';
import {  Component,OnDestroy, OnInit,TemplateRef,ViewChild ,Input} from '@angular/core';
// import { Router } from '@angular/router';
// import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ClickEventArgs } from "@syncfusion/ej2-navigations";
import { DataManager, ODataAdaptor, WebApiAdaptor } from "@syncfusion/ej2-data";
import {
  GridComponent,
  ToolbarItems,
  EditService,
  PageService,
  CommandColumnService,
  CommandModel,
  PageSettingsModel,
  ColumnMenuService,
  RowSelectEventArgs
} from "@syncfusion/ej2-angular-grids";


@Component({
  selector: 'app-itemrecipe',
  templateUrl: './itemrecipe.component.html',
  styleUrls: ['./itemrecipe.component.scss']
})
export class ItemrecipeComponent implements  OnInit {
  public data: DataManager;
  public filterSettings: Object;
  public editSettings: Object;
  public toolbarOptions: ToolbarItems[];
  public dTdata: any;
  public editparams: Object;
  public commands: CommandModel[];
  public initialPage: PageSettingsModel;
  recipename=[]
  itemid:any;
  dateTimeFormate:any;
  public viewData;
  type="edit"
  toHide=true
  @Input() parentData:any;
  constructor(private preference:PreferenceService ,private modalService: BsModalService,private masterservice:ItemmasterService,private dataservice:DataService)
   {
    // this.dataservice.itemid.subscribe(data => {
    //   this.itemid=data
    // },
    //   error => {
  
    //     // console.log(error)
    //   })

  
   }


  @ViewChild("grid", { static: false })
  public grid: GridComponent;
  toolbarClick(args: ClickEventArgs): void {
    if (args.item.id === "Grid_excelexport") {
      // 'Grid_excelexport' -> Grid component id + _ + toolbar item name
      this.grid.excelExport();
    }
  }
  ngOnInit(): void {
    this.initialPage = { pageSizes: true, pageSize: 10 };
    this.filterSettings = { type: "Menu" };
    this.toolbarOptions = ["ExcelExport", "Search"];
    this.itemid=this.parentData;
  // console.log(this.itemlistRowData)
  this.dateTimeFormate=this.preference.getDateTimeFormate()

  }
  getitemRecipeList($event,itemid:any) {
    this.masterservice.getViewItemDetail(itemid)
      .subscribe(data => (this.dTdata = data['item_recipelist']));
  }



  modalRef: BsModalRef;
  config = {
    backdrop: true,
    ignoreBackdropClick: true
  };
 
  // openModal(template: TemplateRef<any>) {
  //   this.modalRef = this.modalService.show(template,Object.assign({},this.config, { class: 'gray modal-lg' })
  //   );
  
  // }


  getRowData(args: any, template: TemplateRef<any>): void {
    let data = this.grid.getRowInfo(args.target);
    // console.log(data['rowData']['recipeid'])
    this.getRecipeDetails(data['rowData']['recipeid'], template)

  }

  getRecipeDetails(id, template) {
    this.masterservice.getRecipeDetails(id).
      subscribe(data => {
        console.log(data['recipe_row'][0])
        this.viewData= data['recipe_row'][0]
        this.modalRef = this.modalService.show(template, Object.assign({}, this.config, { class: 'modal-lg' }));


      },
        error => {
          // this.alert.error(error.error.message)


          // console.log(error)
        })
  }
  
}
