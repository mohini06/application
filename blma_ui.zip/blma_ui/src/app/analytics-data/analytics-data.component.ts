import { Component, OnInit, Inject, ViewChild } from '@angular/core';

// import 'moment/locale/pt-br';

import { AnalyticsService } from '../_core/services/analytics.service';
import { NzFormatEmitEvent } from 'ng-zorro-antd/core';
import { RuleModel, QueryBuilderComponent } from '@syncfusion/ej2-angular-querybuilder';
import { DialogComponent } from '@syncfusion/ej2-angular-popups';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { FilterQueryBuilderService } from '../_core/services/filter-query-builder.service';

@Component({
  selector: 'app-analytics-data',
  templateUrl: './analytics-data.component.html',
  styleUrls: ['./analytics-data.component.scss']
})
export class AnalyticsDataComponent implements OnInit {
  searchValue = '';

  // nzEvent(event: NzFormatEmitEvent): void {
  //   console.log(event);
  // }
  tagQueryData = [];
  @ViewChild('querybuilder', { static: false })
  @ViewChild('dialogfilter', { static: false })
  public Dialog: DialogComponent;
  public animationSettings: Object = { effect: 'Zoom', duration: 400 };
  public showCloseIcon: Boolean = true;
  public hidden: Boolean = false;
  public width: string = '70%';
  public height: string = '80%';
  public SavedFilter: any;

  constructor(private Analytics:AnalyticsService,private filterQueryBuilder: FilterQueryBuilderService)
  {

  }

  Nodedata=[];
  ngOnInit(): void {
   this.Analytics.getNodeAnalyticplot().subscribe(data=>{
 console.log(data)
    this.Nodedata=data;
   
      })
      this.getSavedQuery();
  }

  
  getSavedQuery() {
    this.filterQueryBuilder.getListSavedFilter()
      .subscribe(data => {
        this.SavedFilter = data.listsavedfilter;
        console.log(this.SavedFilter)
      })
  }
  getFilterdialog() {
    this.Dialog.show();
  }


  getQueryData(tagquerydata) {
    this.tagQueryData = tagquerydata
    this.SavedFilter = tagquerydata.filtername;
    console.log(this.tagQueryData)
    this.Dialog.close();
    // console.log(data)
  }

  onChangeFilter(SavedFilter) {
    // this.SavedFilter = SavedFilter.filtername;
    this.tagQueryData = SavedFilter.sqlcriteria;
  }
  
  BoxplotData=[];
  Plotdata:any;
  RecipeJsondata:any;
  displayrecipe:boolean=false;
  parameterjsontabs:any;
  displayparameter:boolean=false;
  parametertab:boolean=false;
  recipetab:boolean=false;
  nzEvent(event: NzFormatEmitEvent): void {
    console.log(event)
    // if( (event.eventName == "expand")||(event.eventName == "click")) {
 if(event.selectedKeys[0].origin.node=='recipesection')
 {
  this.displayparameter=false;
  this.displayrecipechart=false;
  this.displayrecipespcchartspc=false;
  this.displayrecipe=true;
this.Analytics.getrecipetab(event.selectedKeys[0].key).subscribe(data=>{
       this.RecipeJsondata=data;
      
 this.getrecipedata(this.RecipeJsondata.tabs[0].panels)
 
 })
}
else if(event.selectedKeys[0].origin.node=='parameter')
{
  this.displayparameter=true;
  this.displayrecipe=false;
  this.displayrecipespcchartspc=false;
    this.displayrecipechart=false;
  this.Analytics.getparametertab(event.selectedKeys[0].key).subscribe(data=>{
    this.parameterjsontabs=data;
    
    console.log(this.parameterjsontabs.tabs[0].panels)
    this.getparametercharts(this.parameterjsontabs.tabs[0])
  })
  this.parametertab=true;
 
}
else {

}

  // }   


  }



controlchart:any;
getrecipedata(data:any)
{
  
 if(data[0].multiplot==false)
 {
   this.displayparameterspcchartspc=false;
this.recipeplot(data[0].chartdata.data,data[0].chartdata.layout)

 }
 else 
 {
this.displayrecipespcchartspc=false;
this.recipecontrolcharts(data[0].chartdata,0)
console.log(data[0].chartdata)
  }
}



reciperechart:any;
displayrecipechart:boolean=false;
recipeplot(parameterdata1:any,layout:any)
{
  this.displayrecipechart=true;
  this.displayrecipespcchartspc=false;
  
this.reciperechart={
data:parameterdata1,
layout:layout
}

}

config: any;
collection = [];

// pageChanged(event){
//   this.config.currentPage = event;
// }

recipecontrolspcchart=[];
displayrecipespcchartspc:boolean=false;
recipespcchart:any;
loopcount:number;
recipecontrolcharts(chartdata:any,index:number)
{
 
  this.recipecontrolspcchart=[];
  this.loopcount=index;
   for (let obj of chartdata) {
    for (let key in obj) {
       this.displayrecipechart=false;
  this.displayrecipespcchartspc=true;
 
this.recipespcchart={
data:obj[key].data,
layout:obj[key].layout
  }
}
this.recipecontrolspcchart.push(this.recipespcchart)


for (let i = 1; i <= 100; i++) {
  this.collection.push(this.recipecontrolspcchart);
}
 }
 
}




parametercharts:any;

getparametercharts(parameterdata)
{
  this.parametertab=false;
  if(parameterdata.tabname=='boxplot')
  {
    this.parameterboxchart(parameterdata.panels.data,parameterdata.panels.data)
  }
  else
  {
    this.displayparameterspcchartspc=true;
     this.parametercontrolcharts(parameterdata.panels,0)
  }
  
//   for(let i=0;i<parameterdata.length;i++)
//   {
//     if(parameterdata[i].tabname=="boxplot")
//     {
     
// this.parameterboxchart(parameterdata[i].chartdata.data,parameterdata[i].chartdata.layout)
//     }
//     else if(parameterdata[i].tabname=="controlchart"){
//     this.displayparameterspcchartspc=true;
// this.parametercontrolcharts(parameterdata[i].chartdata,0)

//     }
//     else
//     {

//     }
    
//   }

}


parameterchart:any;
displayparameterchart:boolean=false;
parameterboxchart(parameterdata1:any,layout:any)
{
console.log(parameterdata1)
this.parameterchart={
data:parameterdata1,
layout:layout
}
console.log(this.parameterchart)
}


parametercontrolspcchart=[];
displayparameterspcchartspc:boolean=false;
parameterspcchart:any;
loopcount1:number;
parametercontrolcharts(parameterdata:any,index:number)
{
  console.log(parameterdata)
  this.parametercontrolspcchart=[]
  this.displayrecipechart=false;
 
  for(let i=0;i<parameterdata.length;i++)
  {
if(parameterdata[i].charttype=='boxplot')
{
  this.parameterspcchart={
    data:parameterdata[i].chartdata.data,
    layout:parameterdata[i].chartdata.layout
  }
  this.parametercontrolspcchart.push(this.parameterspcchart)
}
else {
 
this.parameterspcchart={
  data:parameterdata[i].chartdata[0].data,
  layout:parameterdata[i].chartdata[0].layout
}
   this.parametercontrolspcchart.push(this.parameterspcchart)
} 
  }

}


}