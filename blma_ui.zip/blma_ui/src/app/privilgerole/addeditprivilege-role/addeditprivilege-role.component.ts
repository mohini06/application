import { Component, OnInit, TemplateRef, ViewChild, AfterViewInit, Output, Input, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs';
import { DataStateChangeEventArgs, CommandModel, PageSettingsModel } from '@syncfusion/ej2-grids';
import { ToolbarItems } from '@syncfusion/ej2-grids/src/grid/common';
import { GridComponent } from '@syncfusion/ej2-angular-grids';
import { ItemmasterService } from './../../_core/services/itemmaster.service';
import { ClickEventArgs } from "@syncfusion/ej2-navigations";
import { CheckBoxModule, ButtonModule } from '@syncfusion/ej2-angular-buttons';
import { DropDownList } from '@syncfusion/ej2-dropdowns';
import { Query, DataManager } from '@syncfusion/ej2-data';
import { EditSettingsModel, IEditCell } from '@syncfusion/ej2-angular-grids';
@Component({
  selector: 'app-addeditprivilege-role',
  templateUrl: './addeditprivilege-role.component.html',
  styleUrls: ['./addeditprivilege-role.component.scss']
})
export class AddeditprivilegeRoleComponent implements OnInit {
  @Output() ChildData: EventEmitter<string[]> = new EventEmitter<string[]>();
  @Input() parentData: any;
  @Input() parent: any;
  // @ViewChild(NgSelectComponent,{static:false}) ngSelectComponent: NgSelectComponent;

  @Input() rolePrivilegeList: any;
  public rolelist: Observable<DataStateChangeEventArgs>;
  public pageOptions: Object;
  public state: DataStateChangeEventArgs;
  url: any
  public toolbar: string[];
  public pageSizes: number[] = [10, 20, 100, 500, 1000];
  public pageSettings: Object;
  public filterSettings: Object;
  public editSettings: Object;
  public toolbarOptions: ToolbarItems[];
  public dTdata: any;
  public editparams: Object;
  public commands: CommandModel[];
  public initialPage: PageSettingsModel;
  public privilegeRolePermission = [];
  @ViewChild("grid", { static: false })
  public grid: GridComponent;
  public data2;
  public eventreadvalue ;
  public eventcreatevalue;
  public eventupdatevalue;
  public viewData;
  public countryParams: IEditCell;
  public country: object[] = [
    { displayvalue: 'United States', savedvalue: '1' },
    { displayvalue: 'Australia', savedvalue: '2' },
    { displayvalue: 'India', savedvalue: '3' }
];
  constructor(private masteservice: ItemmasterService) {
    this.rolePrivilegeList = masteservice;
  }

  toolbarClick(args: ClickEventArgs): void {
    if (args.item.id === "Grid_excelexport") {
      // 'Grid_excelexport' -> Grid component id + _ + toolbar item name
      this.grid.excelExport();
    }
  }
 
  ngOnInit() {
    // console.log(this.rolePrivilegeList[0])

    this.filterSettings = { type: "Menu" };
    this.toolbarOptions = ["ExcelExport", "Search","Add"];
    this.editSettings = {  allowAdding: true};
    this.countryParams = {
      params: {
          allowFiltering: true,
          dataSource: new DataManager(this.country),
          fields: { text: 'displayvalue', value: 'savedvalue' },
          query: new Query(),
          actionComplete: () => false
      }
  };
    // this.sendDataToParent()
  }


  getRowData(args: any): void {
    alert('okdata67')

    let data = this.grid.getRowInfo(args.target);
    //  alert(data.rowData['privilegeid'])
    this.viewData = data["rowData"];
    // this.addNewTab(data["rowData"], "edit");
  }
  count: number = 0
  valueChange(event: any, type, id): void {
    // console.log(event)
    // return
    if (type === "read") {
      // console.log(id)

        this.rolePrivilegeList.find(v => v.savedvalue == id.savedvalue).allow_read = event.checked;

    }
    if (type === "create") {
      //  console.log(id)
     
      this.rolePrivilegeList.find(v => v.savedvalue == id.savedvalue).allow_create = event.checked;
      
    }
    if (type === "update") {
      // console.log(id)
    
      this.rolePrivilegeList.find(v => v.savedvalue == id.savedvalue).allow_update = event.checked;
      
    }
    //  if(type="delete"){
    //   this.rolePrivilegeList.find(v => v.savedvalue == id.savedvalue).allow_deletionflag = event.checked;

    //  }

    console.log(this.rolePrivilegeList)

  }
  sendDataToParent() {
    this.ChildData.emit(this.privilegeRolePermission)
    // this.ChildData.emit(this.rolePrivilegeList)
    console.log(this.privilegeRolePermission)
  }

  test() {
    console.log(this.rolePrivilegeList)
  }

}
