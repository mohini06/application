import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddeditprivilegeRoleComponent } from './addeditprivilege-role.component';

describe('AddeditprivilegeRoleComponent', () => {
  let component: AddeditprivilegeRoleComponent;
  let fixture: ComponentFixture<AddeditprivilegeRoleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddeditprivilegeRoleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddeditprivilegeRoleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
