
import { Component, OnInit, Inject, ViewChild, EventEmitter, Output } from '@angular/core';

import 'moment/locale/pt-br';

import { AnalyticsService } from '../_core/services/analytics.service';
import { NzFormatEmitEvent } from 'ng-zorro-antd/core';
import { RuleModel, QueryBuilderComponent } from '@syncfusion/ej2-angular-querybuilder';
import { DialogComponent } from '@syncfusion/ej2-angular-popups';
import { FilterSettingsModel } from '@syncfusion/ej2-angular-grids';
import { FormControl, Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { FilterQueryBuilderService } from '../_core/services/filter-query-builder.service';
/**
 * QueryBuilder datasource
 */
export let employeeData: Object[] =
  [
    {
      'title': 'Emeryville',
      'key': '65',
      'node': 'org'

    },
    {
      'title': 'Düsseldorf',
      'key': '67',
      'node': 'org'
    },
    {
      'title': 'HLSAV-B (DP)',
      'key': '194',
      'node': 'item'
    },
    {
      'title': 'HLSAV-B Purification',
      'key': '9',
      'node': 'recipe'
    },
    {
      'title': 'WASH 1',
      'key': '776',
      'node': 'recipesection'
    },
    {
      'title': 'WASH 2',
      'key': '779',
      'node': 'recipesection'
    },
    {
      'title': 'WASH 3',
      'key': '778',
      'node': 'recipesection'
    },
    {
      'title': 'CENTRIFUGE SPEED',
      'key': '1695',
      'node': 'parameter'
    }
  ]
export let employeeData2: Object[] =
  [{
    'EmployeeID': 1,
    'LastName': 'Davolio',
    'FirstName': 'Nancy',
    'Title': 'Sales Representative',
    'TitleOfCourtesy': 'Ms.',
    'Date': '12/10/2018',
    'Address': '507 - 20th Ave. E.\r\nApt. 2A',
    'City': 'Seattle',
    'Region': 'WA',
    'PostalCode': '98122',
    'Country': 'USA'
  },
  {
    'EmployeeID': 2,
    'LastName': 'Fuller',
    'FirstName': 'Andrew',
    'Title': 'Vice President',
    'TitleOfCourtesy': 'Dr.',
    'Date': '22/06/2018',
    'Address': '908 W. Capital Way',
    'City': 'Tacoma',
    'Region': 'WA',
    'PostalCode': '98401',
    'Country': 'USA'
  },
  {
    'EmployeeID': 3,
    'LastName': 'Leverling',
    'FirstName': 'Janet',
    'Title': 'Sales Representative',
    'TitleOfCourtesy': 'Ms.',
    'Date': '12/10/2011',
    'Address': '722 Moss Bay Blvd.',
    'City': 'Kirkland',
    'Region': 'WA',
    'PostalCode': '98033',
    'Country': 'USA'
  },
  {
    'EmployeeID': 4,
    'LastName': 'Peacock',
    'FirstName': 'Margaret',
    'Title': 'Sales Representative',
    'TitleOfCourtesy': 'Mrs.',
    'Date': '01/11/2014',
    'Address': '4110 Old Redmond Rd.',
    'City': 'Redmond',
    'Region': 'WA',
    'PostalCode': '98052',
    'Country': 'USA'
  },
  {
    'EmployeeID': 5,
    'LastName': 'Buchanan',
    'FirstName': 'Steven',
    'Title': 'Sales Manager',
    'TitleOfCourtesy': 'Mr.',
    'Date': '12/10/2018',
    'Address': '14 Garrett Hill',
    'City': 'London',
    'Region': null,
    'PostalCode':
      'SW1 8JR',
    'Country': 'UK'
  },
  {
    'EmployeeID': 6,
    'LastName': 'Suyama',
    'FirstName': 'Michael',
    'Title': 'Sales Representative',
    'TitleOfCourtesy': 'Mr.',
    'Date': '01/12/2018',
    'Address': 'Coventry House\r\nMiner Rd.',
    'City': 'London',
    'Region': null,
    'PostalCode': 'EC2 7JR',
    'Country': 'UK'
  },
  {
    'EmployeeID': 7,
    'LastName': 'King',
    'FirstName': 'Robert',
    'Title': 'Sales Representative',
    'TitleOfCourtesy': 'Mr.',
    'Date': '12/12/2011',
    'Address': 'Edgeham Hollow\r\nWinchester Way',
    'City': 'London',
    'Region': null,
    'PostalCode': 'RG1 9SP',
    'Country': 'UK'
  },
  {
    'EmployeeID': 8,
    'LastName': 'Callahan',
    'FirstName': 'Laura',
    'Title': 'Inside Sales Coordinator',
    'Date': '12/10/2012',
    'TitleOfCourtesy': 'Ms.',
    'Address': '4726 - 11th Ave. N.E.',
    'City': 'Seattle',
    'Region': 'WA',
    'PostalCode': '98105',
    'Country': 'USA'
  },
  {
    'EmployeeID': 9,
    'LastName': 'Dodsworth',
    'FirstName': 'Anne',
    'Title': 'Sales Representative',
    'TitleOfCourtesy': 'Ms.',
    'Date': '12/03/2018',
    'Address': '7 Houndstooth Rd.',
    'City': 'London',
    'Region': null,
    'PostalCode': 'WG2 7LT',
    'Country': 'UK'
  }];
export let expenseData: Object[] = [{
  'UniqueId': 'T100001',
  'Category': 'Food',
  'PaymentMode': 'Credit Card',
  'TransactionType': 'Expense',
  'Description': 'Boiled peanuts',
  'Amount': '7',
  'MonthShort': 'Jun',
  'MonthFull': 'June, 2017',
  'FormattedDate': '06/01/2017 09:12 AM'
}, {
  'UniqueId': 'T100024',
  'Category': 'Food',
  'PaymentMode': 'Cash',
  'TransactionType': 'Expense',
  'Description': 'Peanuts in Coke',
  'Amount': '8',
  'MonthShort': 'Jun',
  'MonthFull': 'June, 2017',
  'FormattedDate': '06/04/2017 02:43 PM'
}, {
  'UniqueId': 'T100025',
  'Category': 'Food',
  'PaymentMode': 'Cash',
  'TransactionType': 'Expense',
  'Description': 'Palmetto Cheese, Mint julep',
  'Amount': '11',
  'MonthShort': 'Jun',
  'MonthFull': 'June, 2017',
  'FormattedDate': '06/04/2017 08:35 PM'
}, {
  'UniqueId': 'T100026',
  'Category': 'Transportation',
  'PaymentMode': 'Debit Card',
  'TransactionType': 'Expense',
  'Description': 'Cars and trucks, used',
  'Amount': '9',
  'MonthShort': 'Jun',
  'MonthFull': 'June, 2017',
  'FormattedDate': '06/04/2017 10:25 AM'
}, {
  'UniqueId': 'T100027',
  'Category': 'Transportation',
  'PaymentMode': 'Debit Card',
  'TransactionType': 'Expense',
  'Description': 'Public and other transportation',
  'Amount': '8',
  'MonthShort': 'Jun',
  'MonthFull': 'June, 2017',
  'FormattedDate': '06/04/2017 03:55 PM'
}, {
  'UniqueId': 'T100028',
  'Category': 'Shopping',
  'PaymentMode': 'Cash',
  'TransactionType': 'Expense',
  'Description': 'Household things \u0026 Utilities',
  'Amount': '160',
  'MonthShort': 'Jun',
  'MonthFull': 'June, 2017',
  'FormattedDate': '06/04/2017 10:22 AM'
},
{
  'UniqueId': 'T101284',
  'Category': 'Extra income',
  'PaymentMode': 'Cash',
  'TransactionType': 'Income',
  'Description': 'Income from Sale',
  'Amount': '110',
  'MonthShort': 'Nov',
  'MonthFull': 'November, 2017',
  'FormattedDate': '11/30/2017 02:42 PM'
}];
export let hardwareData: Object[] = [
  {
    'TaskID': 1,
    'Name': 'Lenovo Yoga',
    'Category': 'Laptop',
    'SerialNo': 'CB27932009',
    'InvoiceNo': 'INV-2878',
    'DOP': '04/10/2018',
    'WEO': '05/01/2021',
    'Status': 'Assigned',
    'AssignedTo': 'John Doe',
    'Note': 'Remarks are noted'
  },
  {
    'TaskID': 2,
    'Name': 'Acer Aspire',
    'Category': 'Others',
    'SerialNo': 'CB35728290',
    'InvoiceNo': 'INV-3456',
    'DOP': '02/12/2018',
    'WEO': '03/01/2023',
    'Status': 'In-repair',
    'AssignedTo': '',
    'Note': 'Remarks are noted'
  },
  {
    'TaskID': 3,
    'Name': 'Apple MacBook',
    'Category': 'Laptop',
    'SerialNo': 'CB35628728',
    'InvoiceNo': 'INV-2763',
    'DOP': '04/10/2018',
    'WEO': '04/03/2021',
    'Status': 'In-repair',
    'AssignedTo': '',
    'Note': 'Remarks are noted'
  },
  {
    'TaskID': 4,
    'Name': 'Lenovo ThinkPad',
    'Category': 'Laptop',
    'SerialNo': 'CB56209872',
    'InvoiceNo': 'INV-2980',
    'DOP': '03/09/2018',
    'WEO': '05/12/2021',
    'Status': 'Pending',
    'AssignedTo': '',
    'Note': 'Remarks are noted'
  },
  {
    'TaskID': 5,
    'Name': 'Dell Inspiron',
    'Category': 'Laptop',
    'SerialNo': 'CB56289036',
    'InvoiceNo': 'INV-3782',
    'DOP': '01/10/2018',
    'WEO': '04/01/2021',
    'Status': 'Assigned',
    'AssignedTo': 'David Anto',
    'Note': 'Remarks are noted'
  },
  {
    'TaskID': 6,
    'Name': 'HP Pavilion',
    'Category': 'Laptop',
    'SerialNo': 'CB56289305',
    'InvoiceNo': 'INV-2712',
    'DOP': '04/10/2018',
    'WEO': '05/01/2021',
    'Status': 'Assigned',
    'AssignedTo': 'Mary Saveley',
    'Note': 'Remarks are noted'
  },
  {
    'TaskID': 7,
    'Name': 'Asus ZenBook',
    'Category': 'Laptop',
    'SerialNo': 'CB25637891',
    'InvoiceNo': 'INV-0984',
    'DOP': '06/16/2018',
    'WEO': '09/01/2021',
    'Status': 'Pending',
    'AssignedTo': '',
    'Note': 'Remarks are noted'
  },
  {
    'TaskID': 8,
    'Name': 'HP EliteBook',
    'Category': 'Laptop',
    'SerialNo': 'CB27819726',
    'InvoiceNo': 'INV-2561',
    'DOP': '02/19/2018',
    'WEO': '05/21/2021',
    'Status': 'Ordered',
    'AssignedTo': '',
    'Note': 'Remarks are noted'
  },
  {
    'TaskID': 9,
    'Name': 'Apple MacBook Air',
    'Category': 'Laptop',
    'SerialNo': 'CB05262880',
    'InvoiceNo': 'INV-8970',
    'DOP': '02/12/2018',
    'WEO': '03/01/2023',
    'Status': 'Pending',
    'AssignedTo': '',
    'Note': 'Remarks are noted'
  },
  {
    'TaskID': 10,
    'Name': 'Apple iPad Air',
    'Category': 'Tablet',
    'SerialNo': 'CB45262777',
    'InvoiceNo': 'INV-4555',
    'DOP': '04/10/2018',
    'WEO': '05/01/2021',
    'Status': 'Pending',
    'AssignedTo': '',
    'Note': 'Remarks are noted'
  }
];
// export let completedata:Object[]=Object.assign({},employeeData, employeeData2)

@Component({
  selector: 'app-filter-analytics-data',
  templateUrl: './filter-analytics-data.component.html',
  styleUrls: ['./filter-analytics-data.component.scss']
})
export class FilterAnalyticsDataComponent implements OnInit {
  saveBuildQuery: FormGroup;
  public columnfield: any;
  public data: any;
  public importRules: RuleModel;
  public titleOperators: Object[];
  public nodeOperators: Object[];
  @ViewChild('querybuilder', { static: false })
  public qryBldrObj: QueryBuilderComponent;
  @ViewChild('dialog', { static: false })
  public Dialog: DialogComponent;
  public animationSettings: Object = { effect: 'Zoom', duration: 400 };
  public showCloseIcon: Boolean = true;
  public hidden: Boolean = false;
  public width: string = '50%';
  public height: string = '50%';
  public promptHeader: string = 'Save Query builder';
  public saveQueryField = false;
  public query: any;
  public json: any;
  public objname: any;
  public listSavedFilter: any;
  public listsavedfilterid: any;
  tagquerydata = [];
  @Output() TagQueryData: EventEmitter<string[]> = new EventEmitter<string[]>();
  constructor(private Analytics: AnalyticsService, private formBuilder: FormBuilder, private filterQueryBuilder: FilterQueryBuilderService) {

  }
  ngOnInit(): void {
    this.getSavedQuery();
    this.saveBuildQuery = this.formBuilder.group({

      filtername: [''],
      ispublic: [''],

    })

    this.columnfield = [{
      'label': 'Title',
      'field': 'title',
      'type': 'string',

    }, {
      'label': 'Node',
      'field': 'node',
      'type': 'string',

    }];
    this.data = employeeData.concat(employeeData2).concat(expenseData)
    console.log(this.data)

    this.importRules = {
      'condition': 'or',
      'rules': [{
        'label': 'title',
        'field': 'title',
        'type': 'string',
        'operator': 'equal',
        'value': 'Emeryville'
      },
      {
        'label': 'node',
        'field': 'node',
        'type': 'string',
        'operator': 'equal',
        'value': 'org'

      }]


    };

    this.titleOperators = [
      { value: 'equal', key: 'Equal' },
      { value: 'notequal', key: 'Not Equal' },
      { value: 'in', key: 'In' },
      { value: 'notin', key: 'Not In' },
      { value: 'contains', key: '@' }
    ];
    this.nodeOperators = [
      { value: 'equal', key: 'Equal' },
      { value: 'in', key: 'In' },
      { value: 'isnull', key: 'Is Null' }
    ];
    console.log(this.data)

  }

  getSavedQuery() {
    this.filterQueryBuilder.getListSavedFilter()
      .subscribe(data => {
        this.listSavedFilter = data.listsavedfilter;
        console.log(this.listSavedFilter)
        // this.importRules=data.jsoncriteria;
      })
  }


  setRules(): void {
    this.qryBldrObj.setRules(this.importRules);
  }
  get filtername() { return this.saveBuildQuery.get('filtername'); }
  get ispublic() { return this.saveBuildQuery.get('ispublic'); }

  onSubmit(): void {
    // alert('ok');
    // this.qryBldrObj.setRules(this.importRules);
    // this.qryBldrObj.setRules(this.importRules);
    this.query = this.qryBldrObj.getSqlFromRules(this.qryBldrObj.getRules());
    this.json = { condition: this.qryBldrObj.rule.condition, rules: this.qryBldrObj.rule.rules }, null, 4
    this.objname = "LISTFILTER";
    this.filterQueryBuilder.saveQuery(this.filtername.value, this.ispublic.value, this.query, this.json, this.objname)
      .subscribe(data => {
        alert("new query added")

      })
  }
  onChangeFilter(listSavedFilter) {
    // console.log(listsavedfilter.jsoncriteria)
    this.saveQueryField = true;
    // console.log(listsavedfilter.jsoncriteria);
    this.filtername.setValue(listSavedFilter.filtername);
    this.ispublic.setValue(listSavedFilter.ispublic);
    this.importRules = listSavedFilter.jsoncriteria;
    this.listsavedfilterid = listSavedFilter.listsavedfilterid;
    this.qryBldrObj.setRules(this.importRules);
  }
  addNew(): void {
    this.saveQueryField = true;
    this.listsavedfilterid = 0;
    this.filtername.setValue("");
    this.ispublic.setValue("");
  }
  saveQuery(selectedfilter): void {
    // this.Dialog.content =  '<pre>' + JSON.stringify({ condition: this.qryBldrObj.rule.condition, rules: this.qryBldrObj.rule.rules }, null, 4) + '</pre>';
    // this.Dialog.show();


    this.query = this.qryBldrObj.getSqlFromRules(this.qryBldrObj.getRules());
    this.json = { condition: this.qryBldrObj.rule.condition, rules: this.qryBldrObj.rule.rules }, null, 4
    this.objname = "LISTFILTER";


    if (this.listsavedfilterid == 0) {
      this.filterQueryBuilder.saveQuery(this.filtername.value, this.ispublic.value, this.query, this.json, this.objname)
        .subscribe(data => {
          alert("new query added")

        })
    }
    else {

      // this.filtername.setValue(selectedfilter.filtername);
      // this.ispublic.setValue(selectedfilter.ispublic);
      this.listsavedfilterid = selectedfilter.listsavedfilterid;
      this.filterQueryBuilder.updateQuery(this.filtername.value, this.ispublic.value, this.query, this.json, this.objname, this.listsavedfilterid)
        .subscribe(data => {
          alert("Updated  query")

        })

    }




    // this.Dialog.show();
  }


  // getSql(): void {
  //   this.Dialog.content = this.qryBldrObj.getSqlFromRules(this.qryBldrObj.getRules());
  //   this.Dialog.show();
  // }
  getJson(): void {
    this.Dialog.content = '<pre>' + JSON.stringify({ condition: this.qryBldrObj.rule.condition, rules: this.qryBldrObj.rule.rules }, null, 4) + '</pre>';
    this.Dialog.show();

  }

  applyQuery() {
    this.query = this.qryBldrObj.getSqlFromRules(this.qryBldrObj.getRules());
    this.TagQueryData.emit(this.query);

  }
}
