import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FilterAnalyticsDataComponent } from './filter-analytics-data.component';

describe('FilterAnalyticsDataComponent', () => {
  let component: FilterAnalyticsDataComponent;
  let fixture: ComponentFixture<FilterAnalyticsDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FilterAnalyticsDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilterAnalyticsDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
