
import { AlertService } from './../_core/services/alert.service';
import { Component, OnInit, OnDestroy,ViewChild } from '@angular/core';
import { Subscription } from 'rxjs';

@Component({
    selector: 'alert',
    templateUrl: 'alert.component.html'
})

export class AlertComponent implements OnInit, OnDestroy {
    private subscription: Subscription;
    message: any;


    @ViewChild('element',{static:false}) element;
    public position = { X: 'Center', Y: 'Top' };
  
    onCreate() {
      this.element.show();
    }
    btnClick() {
      this.element.show();
    }

    constructor(private alertService: AlertService) { }

    ngOnInit() {
        this.subscription = this.alertService.getMessage().subscribe(message => { 
            this.message = message;
            
            // if(this.message)
            // {
            //    this.element.show();  
            // }
           
        });
    }

closeAlert()
{
    this.alertService.removeAlert()
}

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }


    onBeforeOpen(e) {
        e.cancel = this.preventDuplicate(e);
      }
  
      preventDuplicate(e) {
        let toastEle: HTMLElement = e.element;
        let toasts: NodeList = e.toastObj.element.children;
         for (let i: number = 0; i < toasts.length; i++) {
          if ((toasts[i] as HTMLElement).querySelector('.e-toast-title').isEqualNode(toastEle.querySelector('.e-toast-title'))) {
              return true;
          }
      }
      return false;
      }

      onClick(e) {
        e.clickToClose = true;
      }
}