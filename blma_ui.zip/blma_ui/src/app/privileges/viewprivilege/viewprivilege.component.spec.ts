import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewprivilegeComponent } from './viewprivilege.component';

describe('ViewprivilegeComponent', () => {
  let component: ViewprivilegeComponent;
  let fixture: ComponentFixture<ViewprivilegeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewprivilegeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewprivilegeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
