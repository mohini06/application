import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewprivilege',
  templateUrl: './viewprivilege.component.html',
  styleUrls: ['./viewprivilege.component.scss']
})
export class ViewprivilegeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
