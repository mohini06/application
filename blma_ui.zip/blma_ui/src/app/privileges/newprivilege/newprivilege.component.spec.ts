import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewprivilegeComponent } from './newprivilege.component';

describe('NewprivilegeComponent', () => {
  let component: NewprivilegeComponent;
  let fixture: ComponentFixture<NewprivilegeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewprivilegeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewprivilegeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
