import { itemAllData } from './allprivilegelist';
import { NewPrivilegelist } from './newprivilegelist';
import { ItemmasterService } from './../../_core/services/itemmaster.service';

import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Component, OnInit, TemplateRef, ViewChild, Output, Input, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { LoginService } from './../../_core/services/login.service';
import { AlertService } from './../../_core/services/alert.service';
import { BatchesService } from './../../_core/services/batches.service';
import { PreferenceService } from './../../_core/services/preference.service';
import {
  GridComponent,
  ToolbarItems,
  EditService,
  PageService,
  CommandColumnService,
  CommandModel,
  PageSettingsModel,
  ColumnMenuService,
  RowSelectEventArgs
} from "@syncfusion/ej2-angular-grids";
import { DataStateChangeEventArgs } from '@syncfusion/ej2-grids';
import * as cloneDeep from 'lodash/cloneDeep';

@Component({
  selector: 'app-newprivilege',
  templateUrl: './newprivilege.component.html',
  styleUrls: ['./newprivilege.component.scss'],
  providers: [EditService, PageService, CommandColumnService, ColumnMenuService]
})
export class NewprivilegeComponent implements OnInit {

  @Output() getGroupList = new EventEmitter<string>();
  @Output() createNew = new EventEmitter<string>();
  @Input() type: any;
  @Input() rowData: any;
  // public rolelist: Observable<DataStateChangeEventArgs>;
  itemstatusData: any;
  itemtypeData: any; ViewChild
  parent = "privilege";
  privilegeForm: FormGroup;
  itemGroupattributes: any;
  attribute = [];
  attributeGroupnames: any;
  formatedAttributeId = [];
  formatedTagId = [];
  newItemSaveData: NewPrivilegelist = {};
  modalRef: BsModalRef;
  itemAllData: itemAllData = {};
  childData = "";
  attributeData: any;
  formatedAttributeData = [];
  formatedAttributeTable = []
  tagData = [];
  tableData = [];
  // rolelist:any;
  isSubmitted: boolean = false;
  duplicateItemCode: boolean = false;
  dateFormate = ""
  sucess: string;
  error: string;
  detailsFlag: Boolean = false;
  public defaultDate = new Date()

  itemRoles: any;
  showEsig: boolean = false
  typelist: any;
  targetObjlist: any;
  parentlist: any;
  public privilege_row: any;
  public privilege_rolelist: any;
  public privilege_typelist: any;
  public alldata: any;
  public pageOptions: Object;
  public state: DataStateChangeEventArgs;
  url: any
  public pageSizes: number[] = [10, 20, 100, 500, 1000];
  public pageSettings: Object;
  public filterSettings: Object;
  public editSettings: Object;
  public toolbarOptions: ToolbarItems[];
  public dTdata: any;
  public childDataRP: any;
  public editparams: Object;
  public commands: CommandModel[];
  public initialPage: PageSettingsModel;
  public roleprivilegelist;
  public roleprivilegelist1;
  public parentdata;
  // public roleprivilegelistdata ;
  public rolelist;
  public roleprivilegelistchild = [];
  public roleprivilegelistarray;
  @ViewChild("grid", { static: false })
  public grid: GridComponent;
  constructor(private formBuilder: FormBuilder, private modalService: BsModalService,
    private masteservice: ItemmasterService,
    private alert: AlertService, private preference: PreferenceService

  ) {

    // this.rolelist = masteservice;
  }


  ngOnInit() {

    this.privilegeForm = this.formBuilder.group({
      typeobj: ['', [Validators.required]],
      parentobjname: ['', [Validators.required]],
      targetobjname: ['', [Validators.required]],
      description: ['', [Validators.minLength(2), Validators.maxLength(500)]],
      effectivedate: [''],
      inactivedate: [''],
      enabledflag: [''],

      privilegeid: [0],
    });

    // this.getParentList();
    this.getTypelist();

    this.dateFormate = this.preference.getDateFormate()

    if (this.type == "edit") {
      // console.log(this.rowData)
      this.setFormValue()
      this.detailsFlag = true;
      this.childData = this.rowData.privilegeid;
      // 9 this.Recipestatus  =this.rowData.status;
      this.getRoleList(this.childData);
      // this.getTargetobjlist();
      // this.getParentList(event);
    }
    this.effectivedate.setValue(this.defaultDate)
  }



  getRoleList(id) {
    this.rolelist = []
    this.masteservice.viewPrivilege(id).
      subscribe(data => {
        console.log('data', data);
        this.rolelist = data.privilege_rolelist;
        this.roleprivilegelist1 = data.privilege_selectedrolelist;
        let roleprivilegelistdata = [];
        if (this.roleprivilegelist1 != null) {
          for (let i = 0; i < this.roleprivilegelist1.length; i++) {
            roleprivilegelistdata.push({
              
              ...(this.roleprivilegelist1[i]),
              ...this.rolelist.find((itmInner) => itmInner.savedvalue === this.roleprivilegelist1[i].roleid)
            });


          }
        }
        else {
          this.rolelist.map((roles)=>{
            roles.roleprivilegeid=null
          })
          roleprivilegelistdata = [];
          // roleprivilegelistdata = this.rolelist;
        }
        if(this.type=="edit")
        {
        roleprivilegelistdata.unshift({ displayvalue: "All Roles", meaning: null, savedvalue: "DefaultAllRoles", allow_read: this.rowData.default_allow_read, allow_update: this.rowData.default_allow_update, allow_create: this.rowData.default_allow_create, allow_execute: this.rowData.default_allow_execute, allow_deletionflag: this.rowData.default_allow_deletionflag })
          
        }else 
        {
          roleprivilegelistdata.unshift({ displayvalue: "All Roles", meaning: null, savedvalue: "DefaultAllRoles", allow_read: false, allow_update: false, allow_create:false, allow_execute: false, allow_deletionflag: false })

        }

        this.roleprivilegelist = roleprivilegelistdata;
        // this.roleprivilegelist={this.rolelist, ...data.privilege_selectedrolelist};
        // this.roleprivilegelist1 = {...this.rolelist, ...this.roleprivilegelist};
        // this.roleprivilegelist=data.privilege_rolelist.concat(data.privilege_selectedrolelist);
        console.log(this.roleprivilegelist)
        // console.log(this.rolelist)
      })

  }

  setRolePrivilege(data): void {
    this.roleprivilegelistchild=[]
    let read
    let create
    let update
    let roleprivilegeid
    let dataTomap = data.filter(role => role.savedvalue !== "DefaultAllRoles")
    dataTomap.map((rolelist) => {

      read = null
      create == null
      update = null
      roleprivilegeid = null


      if (!rolelist.roleprivilegeid) {
        roleprivilegeid = null
      } else {
        roleprivilegeid = rolelist.roleprivilegeid

      }
      if (!rolelist.allow_update) {
        update = false
      } else {
        update = true

      }
      if (!rolelist.allow_read) {
        read = false
        // console.log(read)

      } else {
        read = true

      }
      if (!rolelist.allow_create) {
        create = false
      } else {
        create = true
      }

      this.roleprivilegelistchild.push({
        "roleprivilegeid": roleprivilegeid,
        "privilegeid": this.childData? this.childData : this.rowData.privilegeid,
        "description": "",
        "createdby": 5,
        "lastupdatedby": 5,
        "objname": "roleprivilege",
        "allow_read": read,
        "allow_create": create,
        "allow_update": update,
        "roleid": rolelist.savedvalue
      })

    })

    // console.log(this.roleprivilegelistchild)
  }


  get typeobj() { return this.privilegeForm.get('typeobj'); }
  get parentobjname() { return this.privilegeForm.get('parentobjname'); }
  get targetobjname() { return this.privilegeForm.get('targetobjname'); }
  get itemstatus() { return this.privilegeForm.get('itemstatus'); }
  get description() { return this.privilegeForm.get('description'); }
  get effectivedate() { return this.privilegeForm.get('effectivedate'); }
  get inactivedate() { return this.privilegeForm.get('inactivedate'); }
  get enabledflag() { return this.privilegeForm.get('enabledflag'); }
  get privilegeid() { return this.privilegeForm.get('privilegeid'); }


  getTypelist() {
    let privilegeid
    if (this.rowData) {

      privilegeid = this.rowData.privilegeid
    }
    else {
      privilegeid = 0

    }
    this.masteservice.viewPrivilege(privilegeid).
      subscribe(data => {
        // console.log('data', data);
        this.typelist = data.privilege_typelist;

        if (this.rowData) {

        }
      })

  }

  getParentList(event) {
    let type

    // console.log(type)

    if (this.rowData) {
      // console.log(this.rowData.parentobjname)
      type = event
      // console.log(event)
    }
    else {

      type = event.savedvalue
      console.log(event.savedvalue)
    }
    this.masteservice.getParentList(false, type).
      subscribe(data => {
        this.parentlist = data.privilege_parentobj;
        if (this.rowData) {
          this.parentlist.push({ displayvalue: this.rowData.parentobjname, meaning: null, savedvalue: this.rowData.parentobjname });
          // console.log(this.parentlist)
        }
      })
  }
  getTargetobjlist(event) {

    let parent
    if (this.rowData) {
      // console.log(this.rowData.targetobjname)
      parent = event
    } else {
      parent = event.savedvalue
    }
    // console.log(this.typeobj.value)
    this.masteservice.getTargetobjlist(false, this.typeobj.value, parent).
      subscribe(data => {
        // console.log('target object list', data);
        this.targetObjlist = data.privilege_targetobj;
        if (this.rowData) {
          this.targetObjlist.push({ displayvalue: this.rowData.targetobjname, meaning: null, savedvalue: this.rowData.targetobjname });
        }

      })
  }
  saveNewItemDetails() {

    this.isSubmitted = true;

    if (!this.privilegeForm.valid) {
      return;
    }
    // return
    this.newItemSaveData.privilegeid = this.privilegeid.value
    this.newItemSaveData.description = this.description.value
    this.newItemSaveData.typeobj = this.typeobj.value
    this.newItemSaveData.parentobjname = this.parentobjname.value
    this.newItemSaveData.targetobjname = this.targetobjname.value
    this.newItemSaveData.effectivedate = this.effectivedate.value
    this.newItemSaveData.inactivedate = this.inactivedate.value

    // if (this.isparent.value == "") {
    //   this.newItemSaveData.isparent = false
    // } else {
    //   this.newItemSaveData.isparent = this.isparent.value
    // }
    if (this.enabledflag.value == "") {
      this.newItemSaveData.enabledflag = false
    } else {
      this.newItemSaveData.enabledflag = this.enabledflag.value

    }
    // if (this.default_allow_read.value == "") {
    //   this.newItemSaveData.default_allow_read = false
    // } else {
    //   this.newItemSaveData.default_allow_read = this.default_allow_read.value
    // }
    // if (this.default_allow_update.value == "") {
    //   this.newItemSaveData.default_allow_update = false
    // } else {
    //   this.newItemSaveData.default_allow_update = this.default_allow_update.value
    // }
    // if (this.default_allow_execute.value == "") {
    //   this.newItemSaveData.default_allow_execute = false
    // } else {
    //   this.newItemSaveData.default_allow_execute = this.default_allow_execute.value
    // }

    // if (this.default_allow_deletionflag.value == "") {
    //   this.newItemSaveData.default_allow_deletionflag = false
    // } else {
    //   this.newItemSaveData.default_allow_deletionflag = this.default_allow_deletionflag.value
    // }

    if (this.type == "edit") {
      this.setRolePrivilege(this.roleprivilegelist)
      let privilegeData =this.roleprivilegelist.filter(privilege=>privilege.savedvalue == "DefaultAllRoles")
      // console.log(privilegeData)
      this.newItemSaveData.default_allow_execute=privilegeData[0].allow_execute
      this.newItemSaveData.default_allow_update=privilegeData[0].allow_update
      this.newItemSaveData.default_allow_read =privilegeData[0].allow_read
      this.newItemSaveData.default_allow_deletionflag =privilegeData[0].allow_deletionflag
      this.newItemSaveData.default_allow_create =privilegeData[0].allow_create

    }
    if(this.childData)
    {
      this.setRolePrivilege(this.roleprivilegelist)
      let privilegeData =this.roleprivilegelist.filter(privilege=>privilege.savedvalue == "DefaultAllRoles")
      // console.log(privilegeData)
      this.newItemSaveData.default_allow_execute=privilegeData[0].allow_execute
      this.newItemSaveData.default_allow_update=privilegeData[0].allow_update
      this.newItemSaveData.default_allow_read =privilegeData[0].allow_read
      this.newItemSaveData.default_allow_deletionflag =privilegeData[0].allow_deletionflag
      this.newItemSaveData.default_allow_create =privilegeData[0].allow_create
      this.newItemSaveData.effectivedate =this.preference.setDateFormate(this.effectivedate.value)
      this.newItemSaveData.inactivedate = this.preference.setDateFormate(this.inactivedate.value)
    }
    console.log(this.roleprivilegelistchild)
    // return;
    this.masteservice.savePrivilege(this.newItemSaveData, this.roleprivilegelistchild).
      subscribe(data => {
        // console.log(data);
        if (data.privilege.STATUS == "SUCCESS") {
          console.log(data)
          this.alert.success("Data Successfully Saved")
          this.childData = data.privilege.rows[0]['Inserted Row ID'];
          this.getRoleList(this.childData)
          this.privilegeid.setValue(this.childData)
          this.detailsFlag = true;
          this.getGroupList.emit(null)
          this.showEsig = true
        } else {
          this.alert.error(data.privilege.rows[0].MESSAGE)
        }


        setTimeout(() => {
          this.alert.removeAlert();
        }, 1500);
      },
        error => {
          this.alert.error("Something Went wrong")
        })

  }

  setFormValue() {

    this.masteservice.viewPrivilege(this.rowData.privilegeid).
      subscribe(data => {
        // console.log(data.privilege_row);
        // return 
        // this.alldata = data;
        this.privilege_row = data.privilege_row;
        // console.log(this.privilege_row[0].parentobjname)


        this.typeobj.setValue(this.privilege_row[0].type)
        this.getParentList(this.privilege_row[0].type)


        // console.log(this.privilege_row[0].parentobjname)
        this.getTargetobjlist(this.privilege_row[0].parentobjname)

        this.targetobjname.setValue(this.privilege_row[0].targetobjname)
        this.enabledflag.setValue(this.privilege_row[0].enabledflag)

        this.enabledflag.setValue(this.privilege_row[0].enabledflag)
        this.description.setValue(this.privilege_row[0].description)
        this.parentobjname.setValue(this.privilege_row[0].parentobjname)
        this.effectivedate.setValue(this.preference.setDate(this.privilege_row[0].effectivedate))
        this.inactivedate.setValue(this.preference.setDate(this.privilege_row[0].inactivedate))
        this.privilegeid.setValue(this.privilege_row[0].privilegeid)
      })
  }


  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }

  operationEditSave() {
    this.saveNewItemDetails();

  }
  updOne(data): void {
    // console.log(data)
    this.attributeData = data
  }

  getTagData(tagdata): void {
    this.tagData = tagdata
    // console.log(data)
  }

  createNewTab() {
    this.createNew.emit(null)
    // console.log("new clicked")

  }

  removeAlert() {
    this.alert.removeAlert();

  }
}

