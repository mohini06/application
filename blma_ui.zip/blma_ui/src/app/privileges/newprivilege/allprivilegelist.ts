export interface itemAllData {
    itemid?: string;
    itemcode?: string;
    itemtype?: string;
    shorttitle?: string;
    itemstatus?: string;
    description?: string;
    attributes?: (AttributesEntity)[] | null;
    attributetable?: (AttributetableEntity)[] | null;
    username?: string;
    tags?: (null)[] | null;
    inactivedate?:string;
    effectivedate?:string;
  }
  export interface AttributesEntity {
    attributeid: number;
    attributevalue: string;
  }
  export interface AttributetableEntity {
    attributedataid: number;
    attributeid: number;
    attributevalue: string;
    rowno: number;
  }
  