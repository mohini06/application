export interface NewPrivilegelist {
      typeobj?:string ,
      parentobjname?:string ,
      targetobjname?:string,
      description?:string ,
      effectivedate?:string,
      privilegeid?:string,
      inactivedate?:string,
      isparent?:boolean,
      enabledflag?:boolean,
      default_allow_read?:boolean,
      default_allow_update?:boolean,
      default_allow_execute?:boolean,
      default_allow_deletionflag?:boolean
      default_allow_create?:boolean
  }
  export interface AttributesEntity {
    attributeid: number;
  }
  