
import { ItemmasterService } from "./../../_core/services/itemmaster.service";
import { Component, OnInit, ViewChild } from "@angular/core";
import { ClickEventArgs } from "@syncfusion/ej2-navigations";
import { DataStateChangeEventArgs } from '@syncfusion/ej2-grids';
import { Observable } from 'rxjs';
import {
  GridComponent,
  ToolbarItems,
  EditService,
  PageService,
  CommandColumnService,
  CommandModel,
  PageSettingsModel,
  ColumnMenuService,
  RowSelectEventArgs
} from "@syncfusion/ej2-angular-grids";


@Component({
  selector: 'app-privilegelist',
  templateUrl: './privilegelist.component.html',
  styleUrls: ['./privilegelist.component.scss'],
  providers: [EditService, PageService, CommandColumnService, ColumnMenuService]
})
export class PrivilegelistComponent implements OnInit {

  public data: Observable<DataStateChangeEventArgs>;
  public pageOptions: Object;
  public state: DataStateChangeEventArgs;
  public filterSettings: Object;
  public toolbarOptions: ToolbarItems[];
   public initialPage: PageSettingsModel;
  @ViewChild("grid", { static: false }) 
  public grid: GridComponent;
  public viewData;
  url: any
  public editSettings: Object;
  public pageSizes: number[] = [10, 20, 100, 500, 1000];
  public pageSettings: Object;
  public alldata: any;
  constructor(private itemList: ItemmasterService) {

    this.data = itemList
    // console.log(this.data)
  }
  toolbarClick(args: ClickEventArgs): void {
    if (args.item.id === "Grid_excelexport") {
      // 'Grid_excelexport' -> Grid component id + _ + toolbar item name
      this.grid.excelExport();
    }
  }
  ngOnInit() {
    this.url = "/generic/list"
    this.pageSettings = { pageCount: 10, pageSize: this.pageSizes[0], pageSizes: this.pageSizes };
    let state = { skip: 0, take: 10 };
    this.itemList.execute(state, this.url, 'privilege');
    this.filterSettings = { type: "Menu" };
    this.toolbarOptions = ["ExcelExport", "Search"];


  }


  public dataStateChange(state: DataStateChangeEventArgs): void {
    // console.log(state)
    this.itemList.execute(state, this.url, "privilege");

  }

  refreshList() {
    let state = { skip: 0, take: 10 };
    this.itemList.execute(state, this.url, 'privilege');
  }

  getRowData(args: any): void {
    let data = this.grid.getRowInfo(args.target);
    //  alert(data.rowData['privilegeid'])
    this.viewData = data["rowData"];
     console.log(this.viewData.privilegeid)
    this.addNewTab(data["rowData"], "edit");
  }
  // tabs
  tabs: any[] = [];

  addNewTab(rowdata: any, type: any): void {

    if (type == "new") {
      this.tabs.push({
        title: `Add New Pr`,
        content: type,
        disabled: false,
        removable: true,
        active: true
      });
    } else if (type == "edit") {
      if (this.tabs.some(title => title.title === rowdata.parentobjname)) {
        for (let i = 0; i < this.tabs.length; i++) {
          if (this.tabs[i].title == rowdata.parentobjname) {
            this.tabs[i].active = true;
          }
        }
      } else {
        this.tabs.push({
          title: rowdata.parentobjname,
          content: type,
          disabled: false,
          removable: true,
          active: true
        });
      }
    }
  }
  removeTabHandler(tab: any): void {
    this.tabs.splice(this.tabs.indexOf(tab), 1);
    // console.log('Remove Tab handler');
  }


}

