import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrivilegelistComponent } from './privilegelist.component';

describe('PrivilegelistComponent', () => {
  let component: PrivilegelistComponent;
  let fixture: ComponentFixture<PrivilegelistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrivilegelistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrivilegelistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
