import { LoginService } from './_core/services/login.service';
import { AddEditTaggroupComponent } from './admin/tagmaster/add-edit-taggroup/add-edit-taggroup.component';
import { TaglistComponent } from './admin/tagmaster/taglist/taglist.component';
import { TaggrouplistComponent } from './admin/tagmaster/taggrouplist/taggrouplist.component';
import { AddAttributeGroupComponent } from './admin/attributemaster/add-attribute-group/add-attribute-group.component';
import { AttributelistComponent } from './admin/attributelistMaster/attributelist/attributelist.component';
import { AttributegrouplistComponent } from './admin/attributemaster/attributegrouplist/attributegrouplist.component';
import { ParameterVersionComponent } from './admin/parametermaster/parameter-version/parameter-version.component';
import { RecipeAddEditComponent } from './admin/recipemaster/recipe-add-edit/recipe-add-edit.component';
import { AddEditParmaeterComponent } from './admin/parametermaster/add-edit-parmaeter/add-edit-parmaeter.component';
import { RecipesectionComponent } from './admin/recipemaster/recipesection/recipesection.component';
import { ParamerlistComponent } from './admin/parametermaster/paramerlist/paramerlist.component';
import { RecipelistComponent } from './admin/recipemaster/recipelist/recipelist.component';
import { ViewitemComponent } from './admin/itemmaster/viewitem/viewitem.component';
import { NewitemComponent } from './admin/itemmaster/newitem/newitem.component';

// import { AttributesComponent } from './admin/attributes/attributes.component';
import { LoadingModule } from 'ngx-loading';
import { Subject } from 'rxjs';
import { NgSelectModule } from '@ng-select/ng-select';
import { LaddaModule } from 'angular2-ladda';

import { TabsModule } from 'ngx-bootstrap/tabs';
import { ChartsModule } from 'ng2-charts';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import * as PlotlyJS from 'plotly.js/dist/plotly.js';
import { PlotlyModule } from 'angular-plotly.js';

import { AutosizeModule } from 'ngx-autosize';
//Modules
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { SharedModule } from './_shared/share.module'


import { DataEntryModule } from './data-entry/data.entry.module';
import { StateStoreModule } from './_core/store/state.store.module';
import { BatchesModule } from './batches/batches.module'

import {NgxPaginationModule} from 'ngx-pagination';

//Components
import { AppComponent } from './app.component';
import { LoginComponent } from './session/login/login.component';
import { RegisterComponent } from './session/register/register.component';

//Services
import { AuthService } from './_core/services/auth.service';
import { AuthInterceptor } from './_core/services/auth.interceptor';
import { ApiService } from './_core/services/api.service';
// Routes
import { AppRoutesModule } from './app.routes';

//Location Strategy
import { APP_BASE_HREF, LocationStrategy, HashLocationStrategy, DatePipe, TitleCasePipe } from '@angular/common';
import { DatatableComponent } from './admin/datatable/datatable.component';


import { ItemrecipeComponent } from './admin/itemrecipe/itemrecipe.component';
import { ModalModule } from 'ngx-bootstrap';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { ItemRecipeService } from './_core/services/itemrecipe.service';
//SyncFusion
import { EJAngular2Module } from 'ej-angular2';
//  import { SyncFusionComponent } from './exp/sync-fusion/sync-fusion.component';
import { GridModule, ToolbarService, ExcelExportService, EditService } from '@syncfusion/ej2-angular-grids';
import { PageService, SortService, FilterService, GroupService } from '@syncfusion/ej2-angular-grids';
import { DropDownListModule } from '@syncfusion/ej2-angular-dropdowns';
import { DateTimePickerModule,DatePickerModule,TimePickerModule } from '@syncfusion/ej2-angular-calendars';
import { ItemlistComponent } from './admin/itemmaster/itemlist/itemlist.component';

import { AccordionModule } from '@syncfusion/ej2-angular-navigations';
import { ParameterSectionComponent } from './admin/parametermaster/parameter-section/parameter-section.component';
import { OrdersserviceService } from './exp/sync-fusion/ordersservice.service';
import { DateAgoPipe } from './pipes/date-ago.pipe';
import { AnalyticsComponent } from './admin/analytics/analytics.component';
import { ProgressButtonModule } from '@syncfusion/ej2-angular-splitbuttons';

import {MatStepperModule, MatInputModule, MatButtonModule} from '@angular/material';
import { ParameterSpecComponent } from './admin/parametermaster/parameter-spec/parameter-spec.component';
import { AnalyticsDataComponent } from './analytics-data/analytics-data.component';

import { QueryBuilderModule } from '@syncfusion/ej2-angular-querybuilder';
import { enableRipple } from '@syncfusion/ej2-base';
import { DialogModule } from '@syncfusion/ej2-angular-popups';
import { FilterAnalyticsDataComponent } from './filter-analytics-data/filter-analytics-data.component';
import { CheckBoxModule, ButtonModule } from '@syncfusion/ej2-angular-buttons';
//  import { ResizableDirective } from './exp/sync-fusion/resizable.directive';

import { ResizableDirective } from './analytics-data/resizable.directive';
import { RolesDirective } from './roles.directive';


// import { RoleControlDirective } from './exp/role-control.directive';


import { ListAllrolesComponent } from './roles/list-allroles/list-allroles.component';
import { AddNewRoleComponent } from './roles/add-new-role/add-new-role.component';
import { ViewRoleDetailComponent } from './roles/view-role-detail/view-role-detail.component';
import { PrivilegelistComponent } from './privileges/privilegelist/privilegelist.component';
import { NewprivilegeComponent } from './privileges/newprivilege/newprivilege.component';
import { ViewprivilegeComponent } from './privileges/viewprivilege/viewprivilege.component';
import { AddeditprivilegeRoleComponent } from './privilgerole/addeditprivilege-role/addeditprivilege-role.component';
// import { SyncFusionComponent } from './exp/sync-fusion/sync-fusion.component';



PlotlyModule.plotlyjs = PlotlyJS;
enableRipple(true);
@NgModule({
  declarations: [
   
    ResizableDirective,
    AppComponent,
    LoginComponent,
    RegisterComponent,
    DatatableComponent,
  
    ViewitemComponent,
    ItemrecipeComponent,
  
    NewitemComponent,
    ItemlistComponent,
   

    RecipelistComponent,
    ParamerlistComponent,
    RecipesectionComponent,
    AddEditParmaeterComponent,
    RecipeAddEditComponent,
    ParameterVersionComponent,
    ParameterSectionComponent,
    AttributegrouplistComponent,
    AttributelistComponent,
    AddAttributeGroupComponent,
    TaggrouplistComponent,
    TaglistComponent,
    AddEditTaggroupComponent,
    AnalyticsComponent,
    ParameterSpecComponent,
    AnalyticsDataComponent,
  
     RolesDirective,
   
     
     
    
   
    
    FilterAnalyticsDataComponent,
    
    ListAllrolesComponent,
    
    AddNewRoleComponent,
    
    ViewRoleDetailComponent,
    
    PrivilegelistComponent,
    
    NewprivilegeComponent,
    
    ViewprivilegeComponent,
    
    AddeditprivilegeRoleComponent,
      

  ],
  imports: [
    CheckBoxModule, ButtonModule,
  BrowserModule,
    FormsModule,
    AppRoutesModule,
    HttpClientModule,
    BrowserAnimationsModule,
    SharedModule,
    DataEntryModule,
    BatchesModule,
    StateStoreModule,
    LaddaModule,
    ProgressButtonModule,
    BrowserAnimationsModule,
    TabsModule.forRoot(),
    ChartsModule,
    PlotlyModule,
    AutosizeModule,
    NgSelectModule,
    ModalModule.forRoot(),
    NgMultiSelectDropDownModule,
    ReactiveFormsModule,
    LoadingModule,
    GridModule,
    DateTimePickerModule,
    DropDownListModule,
    DatePickerModule,
    TimePickerModule,
    AccordionModule,
    NgxPaginationModule,
    BrowserAnimationsModule,
      MatStepperModule, MatInputModule, MatButtonModule,
      QueryBuilderModule,
      DialogModule
 
  ],
  
  
  providers: [
    ApiService,
    AuthService,
    LoginService,
    DatePipe,
    TitleCasePipe,
    ItemRecipeService,
    OrdersserviceService,
    PageService, SortService, FilterService, GroupService, ExcelExportService, ToolbarService,EditService,

    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },

    { provide: APP_BASE_HREF, useValue: '', }
    , { provide: LocationStrategy, useClass: HashLocationStrategy },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }