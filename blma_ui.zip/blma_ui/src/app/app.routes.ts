
import { AnalyticsComponent } from './admin/analytics/analytics.component';

import { TaggrouplistComponent } from './admin/tagmaster/taggrouplist/taggrouplist.component';
import { AttributegrouplistComponent } from './admin/attributemaster/attributegrouplist/attributegrouplist.component';
import { CommentsComponent } from './admin/comments/comments.component';
import { RecipeAddEditComponent } from './admin/recipemaster/recipe-add-edit/recipe-add-edit.component';
import { ParamerlistComponent } from './admin/parametermaster/paramerlist/paramerlist.component';
import { RecipelistComponent } from './admin/recipemaster/recipelist/recipelist.component';
import { AttributesComponent } from './admin/attributes/attributes.component';
import { ViewitemComponent } from './admin/itemmaster/viewitem/viewitem.component';

import { DatatableComponent } from './admin/datatable/datatable.component';
import { AuthGuard } from './_core/guards/auth.guard';
import { DataEntryComponent } from './data-entry/data-entry.component';
import { FormInfoComponent } from './data-entry/components/form-info/form-info.component';
// import { CommentsComponent } from './data-entry/components/comments/comments.component';

import { FlagsComponent } from './data-entry/components/flags/flags.component';
import { BatchesComponent } from './batches/batches.component'
import { DashboardBatchesComponent } from './batches/dashboard/dashboard.component';
import { NewBatchComponent } from './batches/new/new.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './session/login/login.component';
import { RegisterComponent } from './session/register/register.component';
import { LayoutComponent } from './_shared/layout/layout.component'
import { EditComponent } from './batches/edit/edit.component'
// import { SyncFusionComponent } from './exp/sync-fusion/sync-fusion.component';
import { ItemlistComponent } from './admin/itemmaster/itemlist/itemlist.component';
import { HeaderlayoutComponent } from './_shared/headerlayout/headerlayout.component';
import { AnalyticsDataComponent } from './analytics-data/analytics-data.component';
import { ListAllrolesComponent } from './roles/list-allroles/list-allroles.component';
import { PrivilegelistComponent } from './privileges/privilegelist/privilegelist.component';

export const routes: Routes = [
    { path: '', redirectTo: '/login', pathMatch: 'full' },
    { path: 'login', component: LoginComponent },
    { path: 'datatable', component: DatatableComponent },
    // { path: 'syncFusion', component: SyncFusionComponent },
    { path: 'attribute', component:AttributesComponent },
  

    { path: 'header', component: HeaderlayoutComponent },

    { path: 'register', component: RegisterComponent },
    
    {
        path: '',
        component: HeaderlayoutComponent, 
        children: [
            // { path: 'in', component: ImagesComponent, canActivate: [AuthGuard] },
            { path: 'batches', component: BatchesComponent,data: {animation: 'batches'}, children: [
                { path: '',      component: DashboardBatchesComponent, data: { animation: 'batches' }, canActivate: [AuthGuard] },
                { path: 'new',   component: NewBatchComponent, data: {animation: 'batches/new' }, canActivate: [AuthGuard]},
                { path: 'edit',   component: EditComponent, data: {animation: 'batches/edit' }, canActivate: [AuthGuard] }
            ] },
            { path: 'data-entry', component: DataEntryComponent, data: {animation: 'data-entry' }, canActivate: [AuthGuard] , children: [
                { path: '',   redirectTo: '/data-entry/info', pathMatch: 'full', canActivate: [AuthGuard] },
                { path: 'info', component: FormInfoComponent, data: {animation: 'data-entry/info' }, canActivate: [AuthGuard]},
                { path: 'comments', component: CommentsComponent, data: {animation: 'data-entry/comments' }, canActivate: [AuthGuard]},
                { path: 'flags', component: FlagsComponent, data: {animation: 'data-entry/flags' }, canActivate: [AuthGuard]}
              ] },
             { path: 'analytics-data', component: AnalyticsDataComponent,canActivate: [AuthGuard]},

            //   { path: 'batches', component: BatchesComponent,data: {animation: 'batches'}, children: [
            //     { path: '',      component: DashboardBatchesComponent, data: { animation: 'batches' } },
            //     { path: 'new',   component: NewBatchComponent, data: {animation: 'batches/new' }},
            //     { path: 'edit',   component: EditComponent, data: {animation: 'batches/edit' } }
            // ] },
            // { path: 'data-entry', component: DataEntryComponent, data: {animation: 'data-entry' } , children: [
            //     { path: '',   redirectTo: '/data-entry/info', pathMatch: 'full' },
            //     { path: 'info', component: FormInfoComponent, data: {animation: 'data-entry/info' },},
            //     { path: 'comments', component: CommentsComponent, data: {animation: 'data-entry/comments' }},
            //     { path: 'flags', component: FlagsComponent, data: {animation: 'data-entry/flags' }}
            //   ] },

            // {path: 'itemlist', component: ItemlistComponent },
            {path: 'itemlist', component: ItemlistComponent, canActivate: [AuthGuard] },
            {path:'recipelist',component:RecipelistComponent, canActivate: [AuthGuard]},
            {path:'parameterlist',component:ParamerlistComponent, canActivate: [AuthGuard]},
            {path:'addrecipe',component:RecipeAddEditComponent, canActivate: [AuthGuard]},
            {path:'attributelist',component:AttributegrouplistComponent, canActivate: [AuthGuard]},
            {path:'taglist',component:TaggrouplistComponent, canActivate: [AuthGuard]},
            {path:'Analytics',component:AnalyticsComponent, canActivate: [AuthGuard]},
            {path:'Roles',component:ListAllrolesComponent, canActivate: [AuthGuard]},
            {path:'Privileges',component:PrivilegelistComponent, canActivate: [AuthGuard]},
       
        ]
    }
];

@NgModule({
    imports: [
        RouterModule.forRoot(routes),
    ],
    exports: [
        RouterModule
    ],
    providers: [
        AuthGuard
    ]
})
export class AppRoutesModule {
}
