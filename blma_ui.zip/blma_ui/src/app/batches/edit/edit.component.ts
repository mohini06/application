import { map, catchError } from 'rxjs/operators';
import { AlertService } from './../../_core/services/alert.service';
import { ApiService } from './../../_core/services/api.service';
import { FormGroup, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { Component, OnInit, OnChanges, Input, Output, EventEmitter } from '@angular/core';
import { BatchesService } from '../../_core/services/batches.service'
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';

import { Router, ActivatedRoute } from '@angular/router';

import { DatePipe, TitleCasePipe } from '@angular/common';
import { of, Observable } from 'rxjs';
import { ItemmasterService } from '../../_core/services/itemmaster.service';



@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss']
})
export class EditComponent implements OnInit {
  @Input() parentData: any;
  @Output() getGroupList = new EventEmitter<string>();
  editBatchForm: FormGroup
  recipes: any[];
  templates: any[];
  users: any[];
  batchType: any[];
  username: string;
  Status: string

  configLoading = {
    backdropBackgroundColour: 'rgba(255,255,255,0.2)', backdropBorderRadius: '10px',
    primaryColour: '#f96332', secondaryColour: '#f27b25', tertiaryColour: '#f49123', fullScreenBackdrop: true
  };

  constructor(
    private batchesService: BatchesService, private api: ApiService, private alert: AlertService
    , private router: Router, private formBuilder: FormBuilder,private masterservice:ItemmasterService ) {
  }

batchCheckAccessData:any;
  ngOnInit() {

    this.editBatchForm = this.formBuilder.group({
      batchid: [''],
      recipeid: ['', [Validators.required]],
      batch: [null, { validators: [Validators.required], asyncValidators:this.checkName.bind(this), 
        updateOn: 'blur' }],
      parentbatch: [''],
      bpdversionno: ['', [Validators.required]],
      batchtype: ['', [Validators.required]],
      assignedto: ['', [Validators.required]],
      planstartdate: [''],
      planenddate: [''],
      batchstartdate: [''],
      batchenddate: [''],
      templatetagid: ['', [Validators.required]],
      currentstatus: ['', []],
      recipeidHidden: ['', []],
      templatetagidHidden: ['', []]
    });

    
     //Service for Field level Role Access
     this.masterservice.fieldLevelAcess("batch", null).subscribe(data => {
      this.batchCheckAccessData = data.item.child;
      if(this.batchCheckAccessData!=null)
      {
      for (let obj of this.batchCheckAccessData) {
        for (let keyname in obj) {
          if (obj[keyname].type == "Column") {
            if (obj[keyname].read == false) {
              for (const field in this.editBatchForm.controls) { // 'field' is a string
                if (field == keyname) {
                  this.editBatchForm.controls[field].disable();
                }}}
            else {
              if (obj[keyname].update == false) {
                for (const field in this.editBatchForm.controls) { if (field == keyname) {
                    this.editBatchForm.controls[field].disable();
                  }} }}
          }
          else {  
              }
        }
      }}
    })


    this.username = this.batchesService.getUserName();
    this.lookupData(this.parentData)
    this.getBatch(this.parentData)

  }

  get batchid() { return this.editBatchForm.get('batchid'); }
  get recipeid() { return this.editBatchForm.get('recipeid'); }
  get batch() { return this.editBatchForm.get('batch'); }
  get parentbatch() { return this.editBatchForm.get('parentbatch'); }
  get bpdversionno() { return this.editBatchForm.get('bpdversionno'); }
  get batchtype() { return this.editBatchForm.get('batchtype'); }
  get assignedto() { return this.editBatchForm.get('assignedto'); }
  get currentstatus() { return this.editBatchForm.get('currentstatus'); }
  get planstartdate() { return this.editBatchForm.get('planstartdate'); }
  get planenddate() { return this.editBatchForm.get('planenddate'); }
  get batchstartdate() { return this.editBatchForm.get('batchstartdate'); }
  get batchenddate() { return this.editBatchForm.get('batchenddate'); }
  get templatetagid() { return this.editBatchForm.get('templatetagid'); }
  get recipeidHidden() { return this.editBatchForm.get('recipeidHidden'); }
  get templatetagidHidden() { return this.editBatchForm.get('templatetagidHidden'); }


  getBatch = (batchid) => this.batchesService.editBatch(batchid).subscribe((resp) => {
    // console.log(resp)
    this.batchid.patchValue(resp.batchid)
    this.recipeid.patchValue(resp.recipeid)
    this.recipeidHidden.patchValue(resp.recipeid)
    this.batch.patchValue(resp.batch)
    this.parentbatch.patchValue(resp.parentbatch)
    this.bpdversionno.patchValue(resp.bpdversionno)
    this.batchtype.patchValue(resp.batchtype)
    this.assignedto.patchValue(resp.assignedto)
    this.planstartdate.patchValue(resp.planstartdate)
    this.planenddate.patchValue(resp.planenddate)
    this.batchstartdate.patchValue(resp.batchstartdate)
    this.batchenddate.patchValue(resp.batchenddate)
    this.templatetagid.patchValue(resp.templatetagid)
    this.templatetagidHidden.patchValue(resp.templatetagid)
    this.currentstatus.patchValue(resp.currentstatus)
    this.Status = resp.currentstatus
    this.editBatchForm.controls.recipeid.disable()
    this.editBatchForm.controls.templatetagid.disable()
  })

  lookupData(batchid) {
    this.batchesService.getRecipes(batchid).subscribe(data => {
      // console.log(data)
      this.recipes = data.batch_recipeid;
      this.templates = data.batch_templatetagid;
      this.batchType = data.batch_batchtype;
      this.users = data.batch_assignedto;

    })
  }

  checkBatch() {

    this.batchesService.checkRecipeBatchNumber({recipeid:this.recipeidHidden.value,batchnumber: this.batch.value,batchid:this.batchid.value}).
      subscribe(data => {
        this.alert.removeAlert()
      
      },
        error => {
          this.alert.error("Combination of Recipe & Batch already exists!");
      
          //  console.log(error.error)
        })
  
  }


  checkName(control: AbstractControl) {
 
    if (control.value) {
      return  this.batchesService.checkRecipeBatchNumber({recipeid:this.recipeidHidden.value,batchnumber: control.value,batchid:this.batchid.value}).pipe(
        map(response => {
    
          return response ?   null:{ forbiddenName: {value: control.value}};
         })
        //   ,
        //  catchError(error => {
       
        //    console.log(error);
        //    return of(true);
        //  })// use observables, don't convert to promises
       );
    }
    return of(null); // gotta return an observable for async
  }




  updateBatch(type) {
    // console.log(this.editBatchForm.value)
    this.api.putBatch(this.editBatchForm.value, type).subscribe(data => {
      this.alert.success("Batch Updated Successfully")
      this.getGroupList.emit(null)
      // console.log(data)
    },
      error => {
        // console.log(error)
        this.alert.error("Something went wrong")
      })

  }

  onlyFloat(event) {
    let charCode = (event.which) ? event.which : event.keyCode;
    if (charCode != 46 && charCode > 31
      && (charCode < 48 || charCode > 57))
      return false;
    return true;
  }

  onlyNumber(event) {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

}
