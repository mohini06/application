import { Directive, ElementRef, HostListener, Input, Renderer } from '@angular/core';
import { LoginService } from '../_core/services/login.service';

@Directive({
  selector: '[appRolePermission]'
})
export class RolePermissionDirective {

  

  @Input() name: string;
  @Input() action: string;
  @Input() type: string;
  constructor(private el: ElementRef,private render:Renderer, private login: LoginService) { }


  Roledata: any;
  ngOnInit() {
    this.login.roles().subscribe(data => {

      this.Roledata = data.body;
      if (this.action != "read") {
        if (this.Roledata[this.name]) {
          if (this.Roledata[this.name][this.action]) {
            this.show()
          }
          else {
            this.hide()
          }
        }
      }

      else {
        if (this.Roledata[this.name]) {
          if (this.Roledata[this.name][this.action]) {
this.show()
          }
          else {
            this.render.setElementStyle(this.el.nativeElement, "pointer-events", "none")
          }
        }


      }
    })
  }


  show() {
    this.el.nativeElement.style.display = 'block'
  }


  hide() {
    

    this.el.nativeElement.disabled = true;

    // this.el.nativeElement.style.visibility = "hidden";
  }
}
