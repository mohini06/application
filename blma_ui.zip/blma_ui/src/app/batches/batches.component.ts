import { Component } from '@angular/core';
import { contentAnimation } from '../_core/animations/page.animations'
import { trigger, state, style, animate, transition, query} from '@angular/animations';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-batches',
  template:`
   <div  >
        <router-outlet #batchRoute="outlet" ></router-outlet>
   </div>
  `,
  styles: [],
  animations: [ contentAnimation ]
})
export class BatchesComponent {
  
   constructor(
    private router: Router,
    private route: ActivatedRoute
    ){}

   getRouteAnimation(outlet) {
    return outlet.activatedRouteData.animation
  }
 }
