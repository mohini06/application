import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardBatchesComponent } from './dashboard.component';

describe('BatchesComponent', () => {
  let component: DashboardBatchesComponent;
  let fixture: ComponentFixture<DashboardBatchesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardBatchesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardBatchesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
