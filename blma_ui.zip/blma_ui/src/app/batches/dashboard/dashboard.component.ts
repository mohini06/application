import { BatchesService } from './../../_core/services/batches.service';
import { FlagsComponent } from './../../data-entry/components/flags/flags.component';
import { ItemmasterService } from './../../_core/services/itemmaster.service';
import { TabDirective } from 'ngx-bootstrap/tabs';

import { Component, OnInit, ViewChild } from "@angular/core";
import { ClickEventArgs } from "@syncfusion/ej2-navigations";
import { Observable } from 'rxjs';
import { isNullOrUndefined } from '@syncfusion/ej2-base';
import {
  GridComponent,
  ToolbarItems,
  EditService,
  PageService,
  CommandColumnService,
  CommandModel,
  PageSettingsModel,
  ColumnMenuService,
  RowSelectEventArgs, FilterSettingsModel,
  DataStateChangeEventArgs, IFilterUI, Column,
  parentsUntil

} from "@syncfusion/ej2-angular-grids";
import { Router } from '@angular/router';


@Component({
  selector: 'batches-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardBatchesComponent implements OnInit {
  newBatch: number;
  openBatch: number;
  reviewBatch: number;
  closedBatch: number;
  username:string=""

  public data: Observable<DataStateChangeEventArgs>;
  public pageOptions: Object;
  public state: DataStateChangeEventArgs;
  public filterSettings: FilterSettingsModel;
  public editSettings: Object;
  public toolbarOptions: ToolbarItems[] | object;
  public dTdata: any;
  public editparams: Object;
  public commands: CommandModel[];
  public initialPage: PageSettingsModel;
  childData = "";
  new: boolean = false;
  open: boolean = false;
  close: boolean = false;
  review: boolean = false;
  UncheckedBatch: boolean=false;
  // public inputValue = (<HTMLInputElement>document.getElementById('clearBatch')).value;

  public formatOptions: any;
  @ViewChild("grid", { static: false })
  public grid: GridComponent;
  url: any

  public pageSizes: number[] = [10, 20, 100, 500, 1000];
  public pageSettings: Object;
  public templateOptions: IFilterUI;
  public button: HTMLElement;

  constructor(private batchesService: BatchesService,private masterservice: ItemmasterService, private router: Router) {
    this.data = masterservice;
    this.username = this.batchesService.getUserName();
  }

  toolbarClick(args: ClickEventArgs): void {
    if (args.item.id === "Grid_excelexport") {
      console.log(args.item.id)
      // 'Grid_excelexport' -> Grid component id + _ + toolbar item name
      this.grid.excelExport();
    }
    if (args.item.id === 'reset') {

      this.grid.refresh(); // to refresh the content 
      this.grid.refreshColumns(); // to refresh the refreshColumns 
      this.grid.refreshHeader(); // to refresh the header content  

    }
  }
  ngOnInit() {
    this.url = "/batches/batches"
    this.pageSettings = { pageCount: 10, pageSize: this.pageSizes[0], pageSizes: this.pageSizes };
    let state = { skip: 0, take: 10 };
    this.masterservice.execute(state, this.url, 'batchdashboard');
    this.filterSettings = {
      type: 'Menu'
      // ,
      // operators: {
      //     stringOperator: [
      //       { value: 'contains', text: 'Contains' },
      //         { value: 'startsWith', text: 'Starts with' },
      //         { value: 'endsWith', text: 'Ends with' }

      //      ],
      //  }




    };

    this.toolbarOptions = ["ExcelExport", "Search"];

    this.formatOptions = { type: 'date', format: "MM/dd/yyyy" };

    this.getCards();

    ///SyncFusion Custom filter UI

    //   this.templateOptions = {
    //     create: (args: { element: Element, column: Column }) => {
    //         const dd = document.createElement('select');
    //         dd.id = 'currentstatus';
    //         const dataSource: string[] = ['All', '1', '3', '4', '5', '6', '8', '9'];
    //         for (const value of  dataSource) {
    //             const option: HTMLOptionElement = document.createElement('option');
    //             option.value = value;
    //             option.innerHTML = value;
    //             dd.appendChild(option);
    //         }
    //         return dd;
    //     },
    //     write: (args: { element: Element, column: Column }) => {
    //         args.element.addEventListener('input', (args1: Event): void => {
    //             const target: HTMLInputElement = args1.currentTarget as HTMLInputElement;
    //             if (target.value !== 'All') {
    //                 const value = + +target.value;
    //                 this.grid.filterByColumn(target.id, 'equal', value);
    //             } else {
    //                 this.grid.removeFilteredColsByField(target.id);
    //             }
    //         });
    //     },
    // };

    /// Edit Button in grid
    let btn = document.createElement("input");
    btn.type = "button";
    btn.id = "btn";
    btn.classList.add("e-btn");
    btn.value = "Edit";
    btn.style.marginLeft = "10px";
    btn.onclick = function (e) {
      console.log("Button clicked");
    };
    this.button = btn;


  }


  load(args) {
    this.grid.element.addEventListener("mouseover", function (e) {
      if ((e.target as HTMLElement).classList.contains("e-rowcell")) {
        let ele: Element = e.target as Element;
        let row = parentsUntil(ele, "e-row");
        let previousButton = document.getElementById("btn");
        if (!isNullOrUndefined(previousButton)) {
          previousButton.remove();
        }
        row.lastChild.appendChild(this.button);
      }
    }.bind(this))
  }


  public dataStateChange(state: DataStateChangeEventArgs): void {
    this.masterservice.execute(state, this.url, "batchdashboard");

  }
  refreshList() {
    let state = { skip: 0, take: 10 };
    this.masterservice.execute(state, this.url, 'batchdashboard');
  }


  clear(): void {   // clears the filtering of Grid 
    this.grid.clearFiltering();
    this.UncheckedBatch=false;
    this.close=false;
      this.review=false;
      this.open=false;
      this.new=false
  };

  filterCard(status) {

if(status=='NEW')
{
    if (this.new) {
 
      this.clear()
      this.new = false
    } else {
      this.new = true
      this.grid.filterByColumn('currentstatus', 'equal', status);
   
      this.close=false;
      this.review=false;
      this.open=false;
    }
  }

  if(status=='OPEN')
  {
    if (this.open) {
      this.clear()
      this.open = false
    
    } else {
      this.open = true
      this.grid.filterByColumn('currentstatus', 'equal', status);
      this.new=false;
      this.close=false;
      this.review=false;
    }
    }

    if(status=='REVIEW'){
    if (this.review) {
      this.review = false
      this.clear()
    } else {
      this.review = true
      this.grid.filterByColumn('currentstatus', 'equal', status);
      this.new=false;
      this.close=false;
      this.open=false;
    }
  }
  if(status=='CLOSED-DONE'){
    if (this.close) {
      this.close = false
      this.clear()
    } else {
      this.close = true
      this.grid.filterByColumn('currentstatus', 'equal', status);
      this.new=false;
      this.review=false;
      this.open=false;
    }
  }
    // let state = {skip: 0, take: 10, where:[
    //   {
    //     "isComplex": true,
    //     "ignoreAccent": false,
    //     "condition": "and",
    //     "predicates": [
    //       {
    //         "isComplex": false,
    //         "field": "currentstatus",
    //         "operator": "equal",
    //         "value": status,
    //         "ignoreCase": true,
    //         "ignoreAccent": false
    //       }
    //     ]
    //   }
    // ] };
    // this.masterservice.execute(state, this.url, 'batchdashboard');
  }

onlyMyBatches()
{
 
  if(!this.UncheckedBatch)
  {
   this.grid.filterByColumn('username', 'equal', this.username); 
  }else
  {

    this.clear()
  //  if(this.open)
  //  {
  //  this.grid.filterByColumn('username', 'equal', this.username); 

  //   this.grid.filterByColumn('currentstatus', 'equal', 'OPEN');
     
  //  }
  //  if(this.new)
  //  {
  //   this.grid.filterByColumn('currentstatus', 'equal', 'NEW');
     
  //  }
  //  if(this.close)
  //  {
  //   this.grid.filterByColumn('currentstatus', 'equal', 'CLOSED-DONE');
     
  //  }
  //  if(this.review)
  //  {
  //   this.grid.filterByColumn('currentstatus', 'equal', 'REVIEW');
     
  //  }
   
  }

  // this.new=false;
  // this.close=false;
  // this.review=false;
  // this.open=false;
}

  showBatch(args: any): void {
    let data = this.grid.getRowInfo(args.target);
    this.router.navigate(['/data-entry/info'], { queryParams: { batchid: data.rowData['batchid'], recipeid: data.rowData['recipeid'], batch: data.rowData['batch'], assignedto: data.rowData['username'] } })
    // console.log(data.rowData['batch'])
  }

  editBatch(args: any): void {
    let data = this.grid.getRowInfo(args.target);

    this.childData=data.rowData['batchid']

    // this.router.navigate(['/batches/edit'], { queryParams: { batchid: data.rowData['batchid'] } })
  }

  checkCompleteDataEntry = (currentStatus: string) => (currentStatus !== 'new');
  // showBatch = (batchid: number, recipeid: number, batch: number, recipeName: string, recipeDescription: string, itemCode: string, currentstatus: string, assignedto: any) => {


  //   this.router.navigate(['/data-entry/info'], { queryParams: {batchid: batchid, recipeid: recipeid, batch: batch, assignedto: assignedto }})
  // }

  // editBatch = (batchid) => this.router.navigate(['/batches/edit'], { queryParams: {batchid: batchid }})
  checkValue(event: any){
    console.log(event);
 }

  getCards() {
    this.masterservice.getDashBoardCards().
      subscribe(data => {
        // console.log(data.bd_statuscards)
        this.newBatch = data.bd_statuscards[2].count
        this.openBatch = data.bd_statuscards[0].count
        this.reviewBatch = data.bd_statuscards[1].count
        this.closedBatch = data.bd_statuscards[3].count
      },
        error => {

        })
  }

 // tabs
 tabs: any[] = [];

 addNewTab(rowdata: any, type: any): void {
   if (type == "new") {
     this.tabs.push({
       title: `Add New Batch`,
       content: type,
       disabled: false,
       removable: true,
       active: true
     });
   } else if (type == "edit") {
     if (this.tabs.some(title => title.title === rowdata.batch)) {
       for (let i = 0; i < this.tabs.length; i++) {
         if (this.tabs[i].title == rowdata.batch) {
           this.tabs[i].active = true;
         }
       }
     } else {
       this.tabs.push({
         title: rowdata.batch,
         content: type,
         disabled: false,
         removable: true,
         active: true
       });
     }
   }
 }
 removeTabHandler(tab: any): void {
   this.tabs.splice(this.tabs.indexOf(tab), 1);
   // console.log('Remove Tab handler');
 }

 getRowData(args: any): void {
    let data = this.grid.getRowInfo(args.target);
    this.childData =data.rowData['batchid'];

    // console.log(this.viewData)
    this.addNewTab(data["rowData"], "edit");
  }


 

}
