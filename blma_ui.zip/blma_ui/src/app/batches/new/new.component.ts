import { ItemmasterService } from './../../_core/services/itemmaster.service';
import { LoginService } from './../../_core/services/login.service';
import { isNullOrUndefined } from '@syncfusion/ej2-base';
import { PreferenceService } from './../../_core/services/preference.service';
import { map } from 'rxjs/operators';
import { contentAnimation } from './../../_core/animations/page.animations';
import { ApiService } from './../../_core/services/api.service';
import { AlertService } from './../../_core/services/alert.service';
import { Component, OnInit, Output, Input, EventEmitter, ElementRef, HostListener, ViewChild } from '@angular/core';
import { BatchesService } from '../../_core/services/batches.service'
import { Observable, of } from 'rxjs';
import { slideInOut } from '../../_core/animations/page.animations';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormArray, AbstractControl } from '@angular/forms';

import { NzInputDirective } from 'ng-zorro-antd/input';
import { en_US, NzI18nService } from 'ng-zorro-antd';


@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.scss'],
  animations: [slideInOut]
})
export class NewBatchComponent implements OnInit {

  @Input() parentData: any;
  configLoading = {
    backdropBackgroundColour: 'rgba(255,255,255,0.2)', backdropBorderRadius: '10px',
    primaryColour: '#f96332', secondaryColour: '#f27b25', tertiaryColour: '#f49123', fullScreenBackdrop: true
  };

  //Ng Zorro
  mapOfExpandData: { [key: string]: boolean } = {};
  expand=false;
  isAllDisplayDataChecked = false;
  isIndeterminate = false;
  listOfDisplayData: any[] = [];
  mapOfCheckedId: { [key: string]: boolean } = {};
  editCache: { [key: string]: any } = {};
  listOfData: any[] = [];

  dataToSend: any[];

  currentPageDataChange($event: Array<{
    id: number; recipeid: string; batch: null;
    templatetagid: string, bpdversionno: string, batchtype: string, batchstartdate: string, batchenddate: string
    , planenddate: string, planstartdate: string, assignedto: null, parentbatch: null, currentstatus: null, checked: boolean, batchid: number
  }>): void {
    this.listOfDisplayData = $event;
    this.refreshStatus();
  }


  refreshStatus(): void {
    // const validData = this.listOfDisplayData.filter(value => !value.disabled);
    const allChecked = this.listOfDisplayData.length > 0 && this.listOfDisplayData.every(value => value.checked === true);
    const allUnChecked = this.listOfDisplayData.every(value => !value.checked);
    this.isAllDisplayDataChecked = allChecked;
    this.isIndeterminate = !allChecked && !allUnChecked;

    if(this.isAllDisplayDataChecked==true)
    {
       this.disableSave=true;
    }
    else
    {
       this.disableSave=false;
    }
  }

  checkAll(value: boolean): void {
    this.listOfDisplayData.forEach(data => {

      data.checked = value;

    });
    this.refreshStatus();
  }

  startEdit(id: string): void {
    this.listOfData.forEach(item => {
      this.editCache[item.id] = {
        edit: false,
        data: { ...item }
      };
    });
    this.editCache[id].edit = true;
  }

  cancelEdit(id: string): void {
    const index = this.listOfData.findIndex(item => item.id === id);
    this.editCache[id] = {
      data: { ...this.listOfData[index] },
      edit: false
    };
  }

  saveEdit(id: string): void {
    // console.log(id)
    const index = this.listOfData.findIndex(item => item.id === id);
    Object.assign(this.listOfData[index], this.editCache[id].data);
    // this.editCache[id].edit = false;
  }

  updateEditCache(): void {
    this.listOfData.forEach(item => {
      this.editCache[item.id] = {
        edit: false,
        data: { ...item }
      };
    });
  }

  addRow() {
    let last: any = this.listOfData.length - 1;
    this.listOfData = [
      ...this.listOfData,

      {
        id: `${last + 1}`,
        recipeid: null,
        batch: null,
        templatetagid: null,
        bpdversionno: null,
        batchtype: null,
        batchstartdate: null,
        batchenddate: null,
        planenddate: null,
        planstartdate: null,
        assignedto: null,
        parentbatch: null,
        currentstatus: 'NEW',
        checked: true,
        batchid: 0,
      }
    ];

    this.updateEditCache();
    this.startEdit(last + 1);
  }



  dataConvertion(type, id) {
    if (id !== null) {

      if (type == "recipe") {
        return this.recipes.find(x => x.savedvalue == id).displayvalue
      }
      if (type == "template") {
        return this.templates.find(x => x.savedvalue == id).displayvalue
      }
      if (type == "batchtype") {
        return this.batchType.find(x => x.savedvalue == id).displayvalue
      }
      if (type == "user") {
        return this.users.find(x => x.savedvalue == id).displayvalue
      }
    }
  }
  dateConvertion(data: any) {
    if (data) {
      let firstDate = this.preference.setDate(data[0])
      let secondDate = this.preference.setDate(data[1])
      return firstDate + ', ' + secondDate
    } else {
      return null
    }


  }

  deleteRow(id: string): void {
    this.listOfData = this.listOfData.filter(d => d.id !== id);
  }

  test() {
    console.log(this.listOfDisplayData)
  }
  //End of Ng zorro

  saveError: boolean = false;
  disableControl: boolean = false;
  disableRelease: boolean = false;
  disableSave: boolean = false;
  currentStatus = "";

  loading: boolean = false;
  @Output() getGroupList = new EventEmitter<string>();
  items: FormArray;
  batchesNewForm: FormGroup;
  recipes: any[];
  templates: any[];
  users: any[];
  batchType: any[];
  // currentStatus: any[];
  username: string;
batchrecipe:boolean=false;
batches:boolean=false;
batchAssigne:boolean=false;
Parentbatch:boolean=false;
Batchtype:boolean=false;
Batchtemplatetagid:boolean=false;
Batchbpdversionno:boolean=false;

  constructor(
    private batchesService: BatchesService, private api: ApiService, private alert: AlertService
    , private router: Router, private formBuilder: FormBuilder, private i18n: NzI18nService, private preference: PreferenceService, private login:LoginService,private roleservice:ItemmasterService) {
 
      this.login.roles().subscribe(data => {
        this.Roledata = data.body['batch'];
        console.log(this.Roledata.read)
               })
         
    }



  Roledata:any;
  batchCheckAccessData:any;
 
  ngOnInit() {
    
   
    if (this.parentData) {
      this.lookupData(this.parentData)
      this.getBatch(this.parentData)
    }

    if (!this.parentData) {
      this.addRow()

    }

    this.i18n.setLocale(en_US);

    this.updateEditCache();
    this.batchesService.getRecipes(0).subscribe(resp => {

      this.recipes = resp.batch_recipeid;
      this.templates = resp.batch_templatetagid;
      this.users = resp.batch_assignedto;
      this.batchType = resp.batch_batchtype;
      // this.currentStatus = resp.batch_currentstatus;
    })
    this.username = this.batchesService.getUserName();
    this.batchesNewForm = this.formBuilder.group({
      items: this.formBuilder.array([this.createItem()])
    });

this.startEdit('0');

 //Service for Field level Role Access
 this.roleservice.fieldLevelAcess("batch", null).subscribe(data => {
  this.batchCheckAccessData = data.item.child;
  if(this.batchCheckAccessData!=null)
  {
  for (let obj of this.batchCheckAccessData) {
    for (let keyname in obj) {
      if (obj[keyname].type == "Column") {
        if (obj[keyname].read == false) {

          if(keyname=="recipe"){
            this.batchrecipe=true;
          } else if(keyname=="batch")
          {
            this.batches=true;
          }
        else if(keyname=="assignedto")
          { this.batchAssigne=true}   else if(keyname=="parentbatch")
          { this.Parentbatch=true;}
          else if(keyname=="batchtype")
          {this.Batchtype=true;}
          else if(keyname=="bpdversionno")
          {this.Batchbpdversionno=true;}
          else if(keyname=="templatetagid")
          {this.Batchtemplatetagid=true;}

        //   for (const field in this.batchesNewForm.controls) { // 'field' is a string
        //     if (field == keyname) {

        //       this.batchesNewForm.controls[field].disable();
        //     }
         
        //   }}
        // else {
          
        //   if (obj[keyname].update == false  ) {
        //     for (const field in this.batchesNewForm.controls) { if (field == keyname) {
        //         this.batchesNewForm.controls[field].disable();
        //       }} }}
      }
      else {  
          }
    }
  }}}
})


}






  get batchid() { return this.batchesNewForm.get('batchid'); }
  get recipeid() { return this.batchesNewForm.get('recipeid'); }
  get batch() { return this.batchesNewForm.get('batch'); }
  get parentbatch() { return this.batchesNewForm.get('parentbatch'); }
  get bpdversionno() { return this.batchesNewForm.get('bpdversionno'); }
  get batchtype() { return this.batchesNewForm.get('batchtype'); }
  get assignedto() { return this.batchesNewForm.get('assignedto'); }
  get currentstatus() { return this.batchesNewForm.get('currentstatus'); }
  get planstartdate() { return this.batchesNewForm.get('planstartdate'); }
  get planenddate() { return this.batchesNewForm.get('planenddate'); }
  get batchstartdate() { return this.batchesNewForm.get('batchstartdate'); }
  get batchenddate() { return this.batchesNewForm.get('batchenddate'); }
  get templatetagid() { return this.batchesNewForm.get('templatetagid'); }
  get id() { return this.batchesNewForm.get('id'); }

  createItem() {
    return this.formBuilder.group({
      batchid: [0],
      id: [0],
      recipeid: [null, [Validators.required]],
      batch: ['', [Validators.required]],
      parentbatch: [''],
      bpdversionno: ['', [Validators.required]],
      batchtype: [null, [Validators.required]],
      assignedto: [null, [Validators.required]],
      planstartdate: [''],
      planenddate: [''],
      batchstartdate: [''],
      batchenddate: [''],
      templatetagid: [null, [Validators.required]]
    });

  }

  addItem(): void {
    this.items = this.batchesNewForm.get('items') as FormArray;
    this.items.push(this.createItem());
  }

  //Check Batch
  value:any;
  operationSaveEdit(type) {
    this.dataToSend = []

    this.dataToSend = this.listOfDisplayData.filter(data => data.checked == true)
    // console.log(this.dataToSend)
    if (typeof this.dataToSend != "undefined" && this.dataToSend != null && this.dataToSend.length != null && this.dataToSend.length > 0) {
    } else {
      this.alert.error("Please Select or Add Batch")
      return
    }
    // return
    for (let i = 0; i < this.dataToSend.length; i++) {
     
   
      if (this.dataToSend[i]['recipeid'] == null
          || this.dataToSend[i]['batch'] == null
        || this.dataToSend[i]['batch'].replace(/\s/g, "")==""
        || this.dataToSend[i]['bpdversionno'] == null
        || this.dataToSend[i]['bpdversionno'] == ""
        || this.dataToSend[i]['templatetagid'] == null
        || this.dataToSend[i]['templatetagid'] == ""
        || this.dataToSend[i]['batchtype'] == null
        || this.dataToSend[i]['batchtype'] == ""
        || this.dataToSend[i]['assignedto'] == null
        || this.dataToSend[i]['assignedto'] == ""
        || this.dataToSend[i]['parentbatch'] == null
        || this.dataToSend[i]['parentbatch'].replace(/\s/g, "")==""
        // ||this.dataToSend[i][''] == null
        // ||this.dataToSend[i][''] == ""
        // ||this.dataToSend[i][''] == null
      ) {
        document.getElementById(this.dataToSend[i]['id']).style.backgroundColor = "#F2DEDE";

if(this.dataToSend[i]['batch']!=null && this.dataToSend[i]['parentbatch']!=null  )
{
 if(this.dataToSend[i]['batch'].replace(/\s/g, "")=="" && this.dataToSend[i]['parentbatch'].replace(/\s/g, "")=="")
 {
  this.alert.error("Please Enter the Batch# and ParentBatch")
 }
 this.alert.error("Please Enter the Batch# and ParentBatch")
}

        if(this.dataToSend[i]['batch']==null && this.dataToSend[i]['parentbatch']==null)
        {
          this.alert.error("Please Enter the Batch# and ParentBatch")
        }
        else if(this.dataToSend[i]['batch']==null )
        {
          this.alert.error("Please Enter the Batch#")
        }
        else if(this.dataToSend[i]['parentbatch']==null)
        {
          this.alert.error("Please Enter the ParentBatch#")
        }
        else
        {
        this.alert.error("Please Enter mandatory Field")
        }

        if ((i + 1) == (this.dataToSend.length)) {
          return
        }

      }
    }

    // console.log(this.listOfDisplayData)
    this.loading = true


    if (this.parentData) {
      this.updateBatch(type)
    }
    else {
      this.createBatch(type)
    }
    this.loading = false
  }
  //Save batch

  createBatch(type?: any) {
console.log(this.dataToSend[0]['batchid'])
    this.api.saveBatch({ params: this.dataToSend }, type).
      subscribe(data => {
        // console.log(this.listOfDisplayData)
        console.log(data.body)
        if (data.body.statusCode == 409) {
          this.alert.error(data.body.statusMsg)
        } else {
this.api.CreateBatchData(this.dataToSend[0]['batchid']).subscribe(data => {
  
})

          this.listOfDisplayData=this.listOfDisplayData.filter(data => data.checked !== true)
          this.listOfData=this.listOfDisplayData.filter(data => data.checked !== true)

          this.alert.success("Batch saved succesfully")
          this.getGroupList.emit(null)
          setTimeout(() => {
            this.alert.removeAlert()
          }, 2000);
        }
      },
        error => {

          this.alert.error("Error while saving Data!")
          console.log(error)

        })

  }

  updateBatch(type) {
    // console.log(this.editBatchForm.value)
    this.api.UpdateBatches({ params: this.dataToSend }, type).subscribe(data => {

      this.api.CreateBatchData(this.dataToSend[0].batchid).subscribe(data => {
  
      })
      this.alert.success("Batch Updated Successfully")
      this.getGroupList.emit(null)
      this.listOfData = []
      this.ngOnInit();
      setTimeout(() => {
        this.alert.removeAlert()
      }, 2000);
      // console.log(data)
    },
      error => {
        // console.log(error)
        this.alert.error("Something went wrong")
      })

  }

  // checkBatch() {

  //   this.batchesService.checkRecipeBatchNumber({recipeid:this.recipeidHidden.value,batchnumber: this.batch.value,batchid:this.batchid.value}).
  //     subscribe(data => {
  //       this.alert.removeAlert()

  //     },
  //       error => {
  //         this.alert.error("Combination of Recipe & Batch already exists!");

  //         //  console.log(error.error)
  //       })

  // }


  checkName(control: AbstractControl) {
    if (control.value) {
      return this.batchesService.checkRecipeBatchNumber({ recipeid: this.recipeid.value, batchnumber: control.value, batchid: 0 }).pipe(
        map(response => {
          // console.log(response)
          return response ? null : { forbiddenName: { value: control.value } };
        }) // use observables, don't convert to promises
      );
    }
    return of(null); // gotta return an observable for async
  }





  onlyFloat(event) {
    let charCode = (event.which) ? event.which : event.keyCode;
    if (charCode != 46 && charCode > 31
      && (charCode < 48 || charCode > 57))
      return false;
    return true;
  }


  onlyNumber(event) {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  lookupData(batchid) {
    this.batchesService.getRecipes(batchid).subscribe(data => {
      // console.log(data)
      this.recipes = data.batch_recipeid;
      this.templates = data.batch_templatetagid;
      this.batchType = data.batch_batchtype;
      this.users = data.batch_assignedto;

    })
  }

  getBatch = (batchid) => this.batchesService.editBatch(batchid).subscribe((resp) => {
    // console.log(resp)
    this.currentStatus = "";
    if (resp.currentstatus !== "NEW") {
      this.disableControl = true;
    }
    if (resp.currentstatus == "NEW" || resp.currentstatus == "REVIEW") {
      this.disableSave = true;
    }

    if (resp.currentstatus == "REVIEW" || resp.currentstatus == "CLOSED-DONE") {
      this.disableRelease = true;
    }
    this.currentStatus = resp.currentstatus;

    this.listOfData = [
      ...this.listOfData,

      {
        id: `${0}`,
        recipeid: resp.recipeid,
        batch: resp.batch,
        templatetagid: resp.templatetagid,
        bpdversionno: resp.bpdversionno,
        batchtype: resp.batchtype,
        batchstartdate: (resp.batchstartdate, resp.planenddate),
        batchenddate: resp.batchenddate,
        planenddate: resp.planenddate,
        planstartdate: resp.planstartdate,
        assignedto: resp.assignedto,
        parentbatch: resp.parentbatch,
        currentstatus: resp.currentstatus,
        checked: true,
        batchid: resp.batchid,
      }
    ];
    this.updateEditCache();
    this.startEdit('0');
  })



}