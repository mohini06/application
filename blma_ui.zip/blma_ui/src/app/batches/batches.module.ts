import { RolePermissionDirective } from './role-permission.directive';
import { AlertService } from './../_core/services/alert.service';

//Modules
import { NgModule  } from '@angular/core';
import { CommonModule, TitleCasePipe } from '@angular/common';
import { RouterModule } from '@angular/router';
import { BsDropdownModule, ProgressbarModule, BsDatepickerModule, TypeaheadModule, ButtonsModule, TabsModule } from 'ngx-bootstrap';
import { DatetimePopupModule } from 'ngx-bootstrap-datetime-popup';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

//Components
import { BatchesComponent } from './batches.component';
import { DashboardBatchesComponent } from './dashboard/dashboard.component'
import { NewBatchComponent } from './new/new.component';


//Routes
import { routes } from '../app.routes';

//Services
import { DataEntryService } from "../_core/services/data-entry.service"
import { BatchesService } from "../_core/services/batches.service";
import { EditComponent } from './edit/edit.component'
import { SharedModule } from '../_shared/share.module';


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild([]),
    FormsModule,
    ReactiveFormsModule,
    // bootstrap

    BsDropdownModule.forRoot(),
    BsDatepickerModule.forRoot(),
    DatetimePopupModule.forRoot(),
    ProgressbarModule.forRoot(),
    TypeaheadModule.forRoot(),
    LoadingModule,
    NgxPaginationModule,
    ButtonsModule.forRoot(),
    SharedModule,
    TabsModule,
  ],
  exports: [
    CommonModule,
    RouterModule,
  ],
  declarations: [
    BatchesComponent,
    DashboardBatchesComponent,
    // NewBatchComponent,
    EditComponent,
    RolePermissionDirective
    // AlertComponent,
  
  ],
  providers: [ 
    DataEntryService,
     BatchesService,
    // AlertService
   ]
})
export class BatchesModule {}