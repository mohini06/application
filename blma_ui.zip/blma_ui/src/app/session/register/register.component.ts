import { AuthService } from '../../_core/services/auth.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  email: string;
  password: string;
  password2: string;
  name: string;
  surname: string;
  userName: string;

  constructor(private auth: AuthService, private router: Router) { }

  ngOnInit() {
  }

  register() {
    this.auth.register(this.email, this.password, this.name, this.surname, this.userName)
      .subscribe(resp => {
        if (resp) {
          this.router.navigateByUrl('/login');
        } else {
          console.log('sign up failed');
        }
      });
  }

}
