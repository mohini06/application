import { Observable } from 'rxjs/Rx';
import { FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthService } from '../../services/auth.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClientModule, HttpRequest } from '@angular/common/http';
import { ApiService } from '../../services/api.service';
import { async, ComponentFixture, getTestBed, TestBed, inject } from '@angular/core/testing';

import { LoginComponent } from './login.component';
import { By } from '@angular/platform-browser';
import { User } from '../../../testing/mockdata';
import { Router } from '@angular/router';

class RouterStub {
  navigateByUrl(url: string) { return url; }
}

class AuthStub {
  login(user, pass) {
    return Observable.create(observer => {
      if (user === 'user1') {
        observer.next(true);
      } else {
        observer.next(false);
      }
      observer.complete();
    });
  }
}

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        LoginComponent
      ],
      imports: [
        HttpClientModule,
        HttpClientTestingModule,
        RouterTestingModule,
        FormsModule
      ],
      providers: [
        {provide: AuthService, useClass: AuthStub},
        {provide: Router, useClass: RouterStub}
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have two inputs', () => {
    const inputs = fixture.debugElement.queryAll(By.css('input'));
    expect(inputs.length).toBe(2);
  });

  it('should have a button', () => {
    const button = fixture.debugElement.query(By.css('button'));
    expect(button.nativeElement.textContent).toBe('Log In');
  });

  xit('should make a request when submitted', () => {
    const auth = getTestBed().get(AuthService);
    console.log('authstub', auth)
    const spy = spyOn(auth, 'login');
    component.username = User.username;
    component.password = User.password;
    component.login();
    expect(spy).toHaveBeenCalled();
  });

  xit('should redirect to dashboard if logged in',
    async(inject([Router, HttpTestingController], (router: Router, backend: HttpTestingController) => {
      const spy = spyOn(router, 'navigateByUrl');
      component.username = User.username;
      component.password = User.password;

      component.login();
      fixture.detectChanges();

      backend.expectOne((req: HttpRequest<any>) => {
        return true;
      })
      .flush({token: '123'}, {status: 200, statusText: 'Ok'});
    })));
});
