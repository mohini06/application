import { LoginService } from './../../_core/services/login.service';
import { AlertService } from './../../_core/services/alert.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import 'rxjs/add/operator/do';
import { AuthService } from '../../_core/services/auth.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms'


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  username: string;
  password: string;
  loading: boolean = false;
  loginForm: FormGroup;
  isSubmitted: boolean = false;
  returnUrl: string;
  // errorMessage: string = 'Username or Password invalid';
  // showErrorMessage: boolean = false;

  configLoading = {
    backdropBackgroundColour: 'rgba(255,255,255,0.2)', backdropBorderRadius: '10px',
    primaryColour: '#f96332', secondaryColour: '#f27b25', tertiaryColour: '#f49123', fullScreenBackdrop: true
  };


  constructor(private frmBuilder: FormBuilder, private auth: AuthService,private route: ActivatedRoute, private router: Router, private alert: AlertService,private roles:LoginService) { }

  ngOnInit() {
    this.loginForm = this.frmBuilder.group({
      userName: ["", [Validators.required, Validators.minLength(3), Validators.maxLength(100)]],
      userPassword: ["", [Validators.required, Validators.minLength(3), Validators.maxLength(32)]]
    });


    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/itemlist';
  }

  get userName() { return this.loginForm.get('userName'); }
  get userPassword() { return this.loginForm.get('userPassword'); }

  login() {
    this.alert.removeAlert()
    this.isSubmitted = true;
    if (!this.loginForm.valid)
      return;
    if (this.username == undefined || this.username.length == 0 || this.password.length == 0 || this.password.length == undefined) {

      this.alert.error("Username or Password is Mandatory")
    }
    else {
      this.loading = true;
      this.auth.login(this.username, this.password)
        .subscribe(data => {
          // console.log(data);
          if (data) {
// this.roles.roles(this.username, this.password).subscribe(data=>
//   {
//     console.log(data)
//   })


            this.router.navigate([this.returnUrl]);
          } else {
            this.alert.error("Invalid Username or Password")
          }
          this.loading = false;
        },
          error => {
            this.alert.error("Invalid Username or Password")
            this.loading = false
          })
    }
  }

}

