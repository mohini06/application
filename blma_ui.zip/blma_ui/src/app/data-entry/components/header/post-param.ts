export interface PostParam {
  username?: string;
  batchid?: number;
  status?: string;
  parameters?: (ParametersEntity)[] | null;
  tables?: (TablesEntity)[] | null;
}
export interface ParametersEntity {
  parametername: string;
  parametervalue: string;
  uom: string;
  value_json?: null;
  baseuom?: null;
  dataformatid: number;
  enteredby?: null;
  enteredon: string;
  verifiedby?: null;
  verifiedon?: null;
  tblname?: null;
  rowno: number;
  batchid: number;
  specmax?: null;
  specmin?: null;
  createdby: number;
  creationdate: string;
  lastupdatedby: number;
  lastupdatedate: string;
  parameterid: number;
  parameterversionid: number;
  dataentryinstructions: string;
  verificationrequired: boolean;
  lockrec: boolean;
  lockuom: boolean;
  listid?: null;
  listname?: null;
  limittolist?: null;
  regex_code?: null;
  recipesectionid: number;
  typename: string;
  formattype: string;
  stepdescription: string;
  stepno: number;
  stepnolabel?: string | null;
  sortno: number;
  batchdataid: number;
}
export interface TablesEntity {
  parametername: string;
  parameterid: number;
  tableId: string;
  rows?: (RowsEntity)[] | null;
}
export interface RowsEntity {
  rowno: number;
  rid: string;
  header_name: string;
  batchdataid: number;
  parametervalue?: string | null;
  typename: string;
  formattype: string;
  listname?: null;
  limittolist?: null;
  dataentryinstructions: string;
  regex_code?: null;
  enteredby?: null;
  enteredon?: string | null;
  lastupdatedby: number;
  lastupdatedate: string;
  specmax?: null;
  specmin?: null;
}
