import { PostgenericService } from './../../../_core/services/postgeneric.service';
import { DataService } from './../../../_core/services/data.service';
import { AlertService } from './../../../_core/services/alert.service';
import { ApiService } from './../../../_core/services/api.service';
import { PostParam } from './post-param';
import { Component, OnInit, ViewChild } from '@angular/core';

import { DataEntryState, dataEntryStateActions } from '../../../_core/store/data-entry.actions';

import { SideBarState, sideBarStateActions } from '../../../_core/store/side-bar.actions';

import { DataEntryService } from '../../../_core/services/data-entry.service'

import { Router, ActivatedRoute } from '@angular/router';

import { Store } from '@ngrx/store';

import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

import { TabsetComponent } from 'ngx-bootstrap';

import { Observable } from 'rxjs/Observable';
import { async } from 'q';
@Component({
  selector: 'header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  @ViewChild('staticTabs', { static: false }) staticTabs: TabsetComponent;

  modalRef: BsModalRef;
  config = {
    backdrop: true,
    ignoreBackdropClick: true
  };
  // color = 'primary';
  // mode = 'determinate';
  // value = 50;
  // bufferValue = 75;
  perComp: any = 100
  perRem: any = 0
  totalPercentage: any = 0
  percentagMsg=""
  
  dataEntryState$;
  sideBarState$;
  title$;
  itemCode$;
  description$;
  batch$;
  batch;
  queryParams;
  user$;
  user;
  lockTrigger: boolean;
  commentTrigger: boolean;
  flagTrigger: boolean;

  filters$;
  filters;

  newBatchesData$
  newBatchesData = [];
  updateBatchesData$
  updateBatchesData = [];
  username: string;

  currentStatus$;
  currentStatus;

  currentStatusDropdown$;
  currentStatusDropdown;

  loading: boolean = false;

  allParam$: any = [];;
  allParam: any;
  headerdata: any = [];

  postParamdata: PostParam = {};

  tableData$;
  tableData;

  tableNewData$;
  tableNewData;
  tableDataFormated = [];

  currentStatusChaged: any;
  success: any;
  error: any;

  childData = ""
  parent = "batch"

  configLoading = {
    backdropBackgroundColour: 'rgba(255,255,255,0.2)', backdropBorderRadius: '10px',
    primaryColour: '#f96332', secondaryColour: '#f27b25', tertiaryColour: '#f49123', fullScreenBackdrop: true
  };

  constructor(
    private store: Store<DataEntryState | SideBarState>,
    private dataEntryService: DataEntryService,
    private route: ActivatedRoute,
    private router: Router,
    private api: ApiService, private alert: AlertService,
    private modalService: BsModalService,
    private data: DataService,
    private postGeneric: PostgenericService
  ) {
    this.dataEntryState$ = this.store.select('dataEntry');
    this.sideBarState$ = this.store.select('sideBar');

    //Data Entry State
    this.allParam$ = this.dataEntryState$
      .map(state => state.AllParam);

    this.title$ = this.dataEntryState$
      .map(state => state.recipeName);

    this.itemCode$ = this.dataEntryState$
      .map(state => state.itemCode);

    this.description$ = this.dataEntryState$
      .map(state => state.recipeDescription);

    this.batch$ = this.dataEntryState$
      .map(state => state.batch);

    this.updateBatchesData$ = this.dataEntryState$
      .map(state => state.updateBatchesData)

    this.newBatchesData$ = this.dataEntryState$
      .map(state => state.newBatchesData)

    this.filters$ = this.dataEntryState$
      .map(state => state.filters);

    this.currentStatusDropdown$ = this.dataEntryState$
      .map(state => state.currentStatusDropDown);

    this.currentStatus$ = this.dataEntryState$
      .map(state => state.currentStatus);

    // Side Bar State
    this.user$ = this.sideBarState$
      .map(state => state.user);

    this.tableData$ = this.dataEntryState$
      .map(state => state.tableData);

    this.tableNewData$ = this.dataEntryState$
      .map(state => state.tableNewData);

    this.lockTrigger = false;
    this.commentTrigger = false;
    this.lockTrigger = false;
  }


  ngOnInit() {
    this.allParam$.subscribe(allparam => this.allParam = allparam);
    this.route.queryParams.subscribe(params => this.queryParams = params);
    this.user$.subscribe(user => this.user = user);
    this.batch$.subscribe(batch => this.batch = batch);
    this.filters$.subscribe(filters => this.filters = filters);
    this.updateBatchesData$.subscribe(updateBatchesData => this.updateBatchesData = updateBatchesData);
    this.newBatchesData$.subscribe(newBatchesData => this.newBatchesData = newBatchesData);
    this.currentStatus$.subscribe(currentStatus => this.currentStatus = currentStatus);
    this.currentStatusDropdown$.subscribe(currentStatusDrop => this.currentStatusDropdown = currentStatusDrop);
    this.username = this.dataEntryService.getUserName();
    this.tableData$.subscribe(tabledata => this.tableData = tabledata);
    this.tableNewData$.subscribe(tableNewdata => this.tableNewData = tableNewdata);

    this.childData = this.queryParams['batchid'];
    setTimeout(() => {
      this.percentaCalc()
    }, 500);
  
  
    this.getPercentCalc() 

  }
 


  batchid:number;
  saveBatch = (): any => {
    this.currentStatusChaged = this.currentStatus;
    this.postParamdata.username = this.username;
    // this.postParamdata.username = 'satish';
    this.postParamdata.batchid = this.queryParams['batchid'];

    this.postParamdata.status = this.currentStatusChaged;

 this.batchid= this.queryParams['batchid'];
 console.log("batchid")
 console.log(this.batchid)
if(this.queryParams['batchid']==this.updateBatchesData[0].batchid)
{

for(let g=0;g<this.updateBatchesData.length;g++)
{
  this.tableDataFormated.push({
    batchdataid:this.updateBatchesData[g].batchdataid,
    batchid:this.queryParams['batchid'],
    
    parameterid:this.updateBatchesData[g].parameterid,
    parameterversionid:this.updateBatchesData[g].parameterversionid,
    tblname:this.updateBatchesData[g].tblname,
    rowno:this.updateBatchesData[g].rowno,
    parametername:this.updateBatchesData[g].parametername,
    parametervalue:this.updateBatchesData[g].parametervalue,
    recipesectionid:this.updateBatchesData[g].recipesectionid,
    uom:this.updateBatchesData[g].uom
  })
}
}
       
console.log(this.updateBatchesData)

    if (this.updateBatchesData) {
      this.postParamdata.parameters = this.updateBatchesData;
    
     
    } else {
      console.log("no data")
 }


for (let i = 0; i < this.tableNewData.length; i++) {
     
      for (let j = 0; j < this.tableNewData[i]['rows'].length; j++) {
        // console.log(this.tableNewData[i]['rows'][j])
        // this.tableDataFormated.push(this.tableNewData[i]['rows'][j])
        for (let k = 0; k < this.tableNewData[i]['rows'][j].length; k++) {
          // console.log(this.tableNewData[i]['rows'][j][k].parametername)
          this.tableDataFormated.push({
            batchdataid:this.tableNewData[i]['rows'][j][k].batchdataid,
            batchid:this.queryParams['batchid'],
            parameterid:this.tableNewData[i]['rows'][j][k].parameterid,
            parameterversionid:this.tableNewData[i]['rows'][j][k].parameterversionid,
            tblname:this.tableNewData[i]['rows'][j][k].tblname,
            rowno:this.tableNewData[i]['rows'][j][k].rowno,
            parametername:this.tableNewData[i]['rows'][j][k].parametername,
            parametervalue:this.tableNewData[i]['rows'][j][k].parametervalue,
            recipesectionid:this.tableNewData[i]['rows'][j][k].recipesectionid,
            dataformatid:this.tableNewData[i]['rows'][j][k].dataformatid
          })
      
        }

      }
    }
    // console.log(this.tableDataFormated)
    // return
    this.postParamdata.tables = this.tableDataFormated;
    // console.log(this.postParamdata);
    // return
    
    // this.api.postBatch(this.postParamdata).
    this.postGeneric.postBatchData(this.tableDataFormated).
      subscribe(data => {
        // console.log(data);
        // alert("successfully Saved")
        this.tableDataFormated = []
        // this.success = "Batch saved succesfully"
        this.alert.success("Batch saved succesfully")
        setTimeout(() => {
          // this.router.navigate(["/batches"]);
          this.alert.removeAlert()
        }, 1000);
      },
        error => {
          this.alert.error("Something went wrong!")

        })

        
  }
  


  triggerFilter = (filter: string, trigger: boolean) => {
    this.switchFilterTrigger(filter);
    !trigger ? this.filters.push(filter) : this.filters = this.filters.filter(f => f !== filter);
    this.dataEntryService.setFilters(this.filters);
  }

  updateCurrentStatus = (status: string) => {

    this.currentStatusChaged = status;
    this.currentStatus = status
    console.log(this.currentStatusChaged)
  }

  // updateBatch = (params) => this.dataEntryService.updateBatch(params).subscribe(resp => {
  //   if (resp)
  //     window.alert('update status')
  //   else
  //     window.alert('error')
  // })

  switchFilterTrigger = (filter: string) => {
    switch (filter) {
      case 'lock':
        this.lockTrigger = !this.lockTrigger;
        break;
      case 'comment':
        this.commentTrigger = !this.commentTrigger;
        break;
      case 'flag':
        this.flagTrigger = !this.flagTrigger;
        break;
    }
  }

  percentaCalc() {
    // console.log(this.tagComment.batchdata_tagcomment.filter(data => data.recipesectionid==recipesectionid
    //    && data.hascomment==true));

    //  console.log(this.tagComment.batchdata_tagcomment.some(data => data.recipesectionid==recipesectionid)); // true
    // console.log(this.batchFiltered)
    // console.log(this.allParam.batchdata_parameter)
    if (this.allParam.batchdata_parameter) {
      this.perRem = this.allParam.batchdata_parameter.filter(data => data.parametervalue == '' || data.parametervalue == null).length
      this.perComp = this.allParam.batchdata_parameter.filter(data => data.parametervalue).length

      // console.log(notFillcount)
      // console.log(fillcount)
      let total = this.perRem + this.perComp
      let perc = ((this.perComp / total) * 100).toFixed(0)
      console.log(perc)
      this.totalPercentage = perc

      this.percentagMsg=this.perRem + " of " + (this.perComp + this.perRem)
    }
  }


  test() {
    console.log(this.tableNewData)
  }


  openDialog(template, tab) {
    this.modalRef = this.modalService.show(template, Object.assign({}, this.config, { class: 'modal-lg modal-lock' }));
    this.newParam(this.childData, 'batch')
    // this.selectTab(tab)
  }

  selectTab(tabId: number) {
    this.staticTabs.tabs[tabId].active = true;
  }

  newParam(param: any, table: any) {
    this.data.changeParam({ message: param, table: table })
  }

  getPercentCalc()
  {
  this.data.percentCalc.subscribe(data => {
    console.log(data)
   this.percentaCalc()
  },
    error => {
  
      // console.log(error)
    })
  }
}