import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { DataEntryState, dataEntryStateActions } from '../../../_core/store/data-entry.actions';
import { SideBarState, sideBarStateActions } from '../../../_core/store/side-bar.actions';
import { DataEntryService } from '../../../_core/services/data-entry.service'
import { Location } from '@angular/common';
import { BehaviorSubject, Observable }  from 'rxjs';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'dataentry-flags',
  templateUrl: './flags.component.html',
  styleUrls: ['./flags.component.scss']
})
export class FlagsComponent implements OnInit {
  translateY$;
  dataEntryState$;
  parameterIdSelected$;
  parameterIdSelected;
  queryParams: any;
  paramSelect$;
  paramSelect: string;
  batch$;
  batch;
  batchDataSelect$
  batchDataSelect: number;
  updateBatchesData$;
  updateBatchesData;
  newBatchesData;
  newBatchesData$;

  checkboxes: {label: string, id: string, checked: any, value: boolean} [];
  checkboxesFiltered: any [];
  inputfiltered;
  currentStatus: string = 'open'
  currentStatus$

  constructor(
    private store: Store<DataEntryState>,
    private dataEntryService: DataEntryService,
    private route: ActivatedRoute,
    private location: Location
  ) { 
    
    this.dataEntryState$ = this.store.select('dataEntry');

    this.translateY$ = this.dataEntryState$
                             .map(state => state.topFormInfo );
    
    this.parameterIdSelected$ = this.dataEntryState$
                             .map(state => state.parameteridSelected );
                             
    this.paramSelect$ = this.dataEntryState$
                        .map(state => state.paramsSelect)
    
    this.batch$ = this.dataEntryState$
                  .map(state => state.batch );

    this.batchDataSelect$ = this.dataEntryState$
                             .map(state => state.batchData );

    this.updateBatchesData$ = this.dataEntryState$
                             .map(state => state.updateBatchesData );

    this.newBatchesData$ = this.dataEntryState$
                      .map(state => state.newBatchesData);
    
    this.currentStatus$ = this.dataEntryState$
                    .map(state => state.currentStatus);

  }

  ngOnInit() {
    this.parameterIdSelected$.subscribe(id => this.parameterIdSelected = id );
    this.route.queryParams.subscribe(params => this.queryParams = params);
    this.paramSelect$.subscribe(param => {
      this.paramSelect = param;
      this.getFlags();
    })
    this.batch$.subscribe(batch => {
      this.batch = batch;
      this.getFlags();
    });
    this.batchDataSelect$.subscribe(batchData => {
      if(this.batchDataSelect === batchData) return
      this.batchDataSelect = batchData;
      this.getFlags();
    }); 
    this.newBatchesData$.subscribe(newBatchesData => this.newBatchesData = newBatchesData);
    this.updateBatchesData$.subscribe(updateBatchesData => this.updateBatchesData = updateBatchesData)
    this.currentStatus$.subscribe(currentStatus => this.currentStatus = currentStatus);
  }

  resetValues = () => this.checkboxesFiltered = this.checkboxes ;
  
  
  filterList = (e) => {
      const value = this.inputfiltered;
      this.checkboxesFiltered = this.checkboxes.filter(d => d.label.toLowerCase().indexOf(value) !== -1)
      if(value === '') this.resetValues();
      if (e.key === 'Enter' && this.checkboxesFiltered.length === 1){
        this.setFlag(this.checkboxesFiltered[0].id)
        this.resetValues();
        this.inputfiltered= '';
      }
  }

  getFlags = () => {
    if (this.batch === undefined || this.paramSelect === undefined || this.batchDataSelect === undefined || this.batch[this.paramSelect].parameters[this.batchDataSelect] === undefined) 
    return
    const flags = this.batch[this.paramSelect].parameters[this.batchDataSelect].batch_data.slice(-1).pop().isflag;
    this.setFlags(flags);
  }
  
  setFlags = (flags: string) => {
    this.setDefaultCheckboxes();
    if (flags === null) return 
    const flagsArray = flags.split(',');
    flagsArray.forEach((flag) => {
      const index = this.checkboxes.findIndex(d => d.id === flag);
      if (index !== -1) {
        this.checkboxes[index].checked = "";
        this.checkboxes[index].value = true;
      };
    })
  }

  removeFlag = (id: string) => {
    
    // find Index
    const index = this.checkboxes.findIndex(flag => flag.id === id);
    // Get current flags
    let currentFlags = this.batch[this.paramSelect].parameters[this.batchDataSelect].batch_data.slice(-1).pop().isflag;
    if (currentFlags === null) currentFlags = [];
    else currentFlags = currentFlags.split(',');
    
    currentFlags = currentFlags.filter(flag => flag !== "")
    currentFlags = currentFlags.filter(flag => flag !== id)
    
    // Remove if same values
    currentFlags = currentFlags.filter((v, i, a) => a.indexOf(v) === i);

    // Active icon
    this.setIcon(currentFlags);

    // Save Flag
    this.saveFlag(currentFlags);

    this.checkboxes[index].value = false;

  }


  setFlag = (id: string) => {
    
    // find Index
    const index = this.checkboxes.findIndex(flag => flag.id === id);
    // Get current flags
    let currentFlags = this.batch[this.paramSelect].parameters[this.batchDataSelect].batch_data.slice(-1).pop().isflag;
    if (currentFlags === null) currentFlags = [];
    else currentFlags = currentFlags.split(',');
    
    currentFlags.filter(flag => flag !== "")
    if (!this.checkboxes[index].value) {
      currentFlags.push(id)
    }else{
      currentFlags = currentFlags.filter(flag => flag !== id)  
    }
    // Remove if same values
    currentFlags = currentFlags.filter((v, i, a) => a.indexOf(v) === i);
    
    // Active icon
    this.setIcon(currentFlags);
    
    // Save Flag
    this.saveFlag(currentFlags);
    this.checkboxes[index].value = true;
  }

  setIcon = (currentFlags) => currentFlags.length === 0 ? this.batch[this.paramSelect].parameters[this.batchDataSelect].batch_data.slice(-1).pop().isflag = null : this.batch[this.paramSelect].parameters[this.batchDataSelect].batch_data.slice(-1).pop().isflag = currentFlags.join(',');

  saveFlag = (currentFlags) => {
    if (currentFlags.length === 0) currentFlags = null;
    else currentFlags = currentFlags.join(',');
    const selected = this.batch[this.paramSelect].parameters[this.batchDataSelect];
    const uniquename = selected.parameter.uniquename;
    
    if(this.newBatchesData[uniquename] !== undefined){
    
    // Update new Batch Data
    this.newBatchesData[uniquename].isflag = currentFlags;
    this.dataEntryService.setNewBatchesData(this.newBatchesData);    

    }else if(this.updateBatchesData[selected.batch_data.slice(-1).pop().batchdataid] === undefined){
    
    // Update Batch Data first time
    const batchdataid = selected.batch_data.slice(-1).pop().batchdataid;
    this.updateBatchesData[batchdataid] = selected.batch_data.slice(-1).pop();
    this.updateBatchesData[batchdataid].isflag = currentFlags;
    this.dataEntryService.setUpdateBatchesData(this.updateBatchesData);

    }else if(this.updateBatchesData[selected.batch_data.slice(-1).pop().batchdataid] !== undefined){
    
    // Update Batch Data
    const batchdataid = selected.batch_data.slice(-1).pop().batchdataid;
    this.updateBatchesData[batchdataid].isflag = currentFlags;
    this.dataEntryService.setUpdateBatchesData(this.updateBatchesData);

    }
  }

  // postFlags = () => {
  //   const result = this.dataEntryService.postBatch({username: 'john', batchid: this.queryParams.batchid, recipeid: this.queryParams.recipeid , new_batches_data: this.newBatchesData, update_batches_data: this.updateBatchesData });
    
  //   result.subscribe(resp => {
  //     if (resp.status){ 
  //       // this.dataEntryService.setErrorParams([]);
  //       window.alert('save')
  //     }else{
  //       // this.dataEntryService.setErrorParams(resp.errors)
  //       window.alert('error')  
  //     }
  //   })
  // };

  setDefaultCheckboxes = () => this.checkboxes = [
    {label: 'Bookmark', id: 'BMRK', checked: undefined, value: false},
    {label: 'Deviation Record', id: 'DR', checked: undefined, value: false},
    {label: 'Data Entry Issue', id: 'DEI', checked: undefined, value: false},
    {label: 'Master Data Issue', id: 'MDI', checked: undefined, value: false},
    ]

  backClicked() {
    this.location.back();
  }

}
