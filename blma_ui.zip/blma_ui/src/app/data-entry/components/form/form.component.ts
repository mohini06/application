
import { LayoutComponent } from './../../../_shared/layout/layout.component';
import { GetGenericService } from './../../../_core/services/get-generic.service';
import { state } from '@angular/animations';
import { PreferenceService } from './../../../_core/services/preference.service';

import { DataService } from './../../../_core/services/data.service';
import { Input, Component, OnInit, ChangeDetectorRef, AfterViewChecked, ɵConsole, ViewChild, AfterViewInit, AfterContentChecked, Output, EventEmitter } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { DataEntryService } from '../../../_core/services/data-entry.service'
import { paramsData } from '../../data.service'
import { ScrollToService } from 'ng2-scroll-to-el';
import { ElementRef, TemplateRef } from '@angular/core';

import { Store } from '@ngrx/store';
import { DataEntryState, dataEntryStateActions } from '../../../_core/store/data-entry.actions';

import { Router, ActivatedRoute, Params } from '@angular/router';
import { ViewEncapsulation } from '@angular/core';
import { IPointRenderEventArgs, ITextRenderEventArgs } from '@syncfusion/ej2-angular-charts';


import { loadCldr, L10n } from '@syncfusion/ej2-base';
import { DropDownListComponent } from '@syncfusion/ej2-angular-dropdowns';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { FormInfoComponent } from '../form-info/form-info.component';
import { ChartdataService } from '../../../_core/services/chartdata.service';
import { AnalyticsService } from '../../../_core/services/analytics.service';


@Component({
  selector: 'form-data',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})


export class FormComponent implements OnInit, AfterViewChecked, AfterContentChecked {
  @Input() parentData: any;
  @ViewChild("inputBox", { static: false }) _el: ElementRef;
  

  rowData = []
  items: any;
  topFormInfo: number
  paramSelect$;
  paramSelect: string;
  dataEntryState$;
  batch$;
  batch;
  parameters$;
  parameters: any;
  batchFiltered;
  allParam$;
  allParam: any;
  graph$;
  graph: any;
  tableData$;
  tableData;
  queryParams: any;
  parameterId;
  filters$;
  filters;
  newBatchesData$;
  newBatchesData;
  updBatchesData$;

  updBatchesData;
  values: any = {};
  dates: any = {};
  closeButton: any = { show: true, label: 'Close', cssClass: 'btn btn-sm btn-primary' };
  currentStatus$
  currentStatus: string = 'open';
  allowedRole: boolean;
  allowedRole$;
  bsModalRef: BsModalRef;
  userSig$;
  userSig;
  currentRole$
  currentRole
  sameUser: boolean = false;


  p: number = 1;

  //New var

  uomOption: any;
  listOption: any;
  tableListOption: any;
  selectedParameter: any = -1;
  selectedComm: any = -1;

  //SyncFusion 
  dateFormate: boolean = false;
  dateTimeFormate: boolean = false;
  timeFormate: boolean = false;
  errorIndexDate: string = "";
  errorIndexDateTime: string = "";
  errorIndexTime: string = "";

  errorIndexDateTable: string = "";
  errorIndexDateTableSecond: string = ""
  dateFormateTable: boolean = false;

  errorIndexDateTimeTable: string = "";
  errorIndexDateTimeTableSecond: string = ""
  dateTimeFormateTable: boolean = false;

  errorIndexTimeTable: string = "";
  errorIndexTimeTableSecond: string = ""
  timeFormateTable: boolean = false;

  public dateFormat: string;
  public dateTimeFormat: string;
  @ViewChild('listObj', { 'static': true })
  public listObj: DropDownListComponent;

  dataTopush = []
  updatedParameter = [];
  selectedValue = ""

  tagComment: any

  recipeId: any
  recipeSectionId: any

  showAnalysis: boolean = false

  errorMsg: string;
  modalRef: BsModalRef;


  constructor(private modalService: BsModalService,
   
    private Analytics:AnalyticsService,
    private store: Store<DataEntryState>,
    private dataEntryService: DataEntryService,
    private scrollService: ScrollToService,
    private router: Router,
    private route: ActivatedRoute,
    // private modalService: BsModalService,
    private cdr: ChangeDetectorRef,
    private data: DataService,
    private preference: PreferenceService,
    private getGeneric: GetGenericService,
    private Chartdata: ChartdataService
  ) {


    this.dates;
    this.items = [];
    this.allowedRole = false;
    this.dataEntryState$ = this.store.select('dataEntry')


    this.paramSelect$ = this.dataEntryState$
      .map(state => state.paramsSelect)

    // this.graph$ = this.dataEntryState$
    //   .map(state => state.graph)

    this.parameters$ = this.dataEntryState$
      .map(state => state.filterParam);

    this.allParam$ = this.dataEntryState$
      .map(state => state.AllParam);

    this.tableData$ = this.dataEntryState$
      .map(state => state.tableData);

    this.batch$ = this.dataEntryState$
      .map(state => state.batch);

    this.filters$ = this.dataEntryState$
      .map(state => state.filters);

    this.newBatchesData$ = this.dataEntryState$
      .map(state => state.newBatchesData);

    this.currentStatus$ = this.dataEntryState$
      .map(state => state.currentStatus);

    this.updBatchesData$ = this.dataEntryState$
      .map(state => state.updateBatchesData);

    this.allowedRole$ = this.dataEntryState$
      .map(state => state.allowedRole);

    this.userSig$ = this.dataEntryState$
      .map(state => state.userSig);

    this.currentRole$ = this.dataEntryState$
      .map(state => state.currentRole);
  }

  tittleTrigger = (name: string, parameterid: number) => {

    // Set position   
    this.setPositionFormInfo(name);

    // Active Elements
    this.batch[this.paramSelect].parameters.forEach((d) => d.parameter.uniquename === name ? d.active = true : d.active = false)

    // Set Parameters
    this.setParameters(name, parameterid);

    //Scrol to Element selcted
    this.scrollToEndPage(name);

  }

  trackByFn = (index) => index;



  dropdownToggleValue = (uniquename: string, event: any) => {
    const value = event.currentTarget.innerHTML;
    this.values[uniquename].value = value;

    const indexSelected = this.batch[this.paramSelect].parameters.findIndex((d) => d.parameter.uniquename === uniquename);
    const selected = this.batch[this.paramSelect].parameters[indexSelected];
    if (this.newBatchesData[uniquename] !== undefined) {

      //Update new Batch Data
      this.newBatchesData[uniquename].parametervalue = value;
      this.dataEntryService.setNewBatchesData(this.newBatchesData);
    } else if (this.updBatchesData[selected.batch_data.slice(-1).pop().batchdataid] === undefined) {

      // Update Batch Data First time
      const batchdataid = selected.batch_data.slice(-1).pop().batchdataid;
      this.updBatchesData[batchdataid] = selected.batch_data.slice(-1).pop();
      this.updBatchesData[batchdataid].parametervalue = value;
      this.dataEntryService.setUpdateBatchesData(this.updBatchesData);
    } else if (this.updBatchesData[selected.batch_data.slice(-1).pop().batchdataid] !== undefined) {

      // Update Batch Data
      const batchdataid = selected.batch_data.slice(-1).pop().batchdataid;
      this.updBatchesData[batchdataid].parametervalue = value;
      this.dataEntryService.setUpdateBatchesData(this.updBatchesData);

    }
  }

  dropdownvalue: string;
  scrollToEndPage = (name: string) => setTimeout(() => { this.scrollService.scrollTo(document.getElementById(name), 500, -360) }, 510)

  dropdownToggle = (select: string, uniquename: string, event: any) => {
    this.values[uniquename].uom = select;


    console.log(select)
    event.currentTarget.parentElement.closest('div').firstElementChild.innerHTML = select;

    const indexSelected = this.batch[this.paramSelect].parameters.findIndex((d) => d.parameter.uniquename === uniquename);
    const selected = this.batch[this.paramSelect].parameters[indexSelected];
    if (this.newBatchesData[uniquename] !== undefined) {

      //Update new Batch Data
      this.newBatchesData[uniquename].uomselected = select;
      this.dataEntryService.setNewBatchesData(this.newBatchesData);
    } else if (this.updBatchesData[selected.batch_data.slice(-1).pop().batchdataid] === undefined) {

      // Update Batch Data First time
      const batchdataid = selected.batch_data.slice(-1).pop().batchdataid;
      this.updBatchesData[batchdataid] = selected.batch_data.slice(-1).pop();
      this.updBatchesData[batchdataid].uomselected = select;
      this.dataEntryService.setUpdateBatchesData(this.updBatchesData);
    } else if (this.updBatchesData[selected.batch_data.slice(-1).pop().batchdataid] !== undefined) {

      // Update Batch Data
      const batchdataid = selected.batch_data.slice(-1).pop().batchdataid;
      this.updBatchesData[batchdataid].uomselected = select;
      this.dataEntryService.setUpdateBatchesData(this.updBatchesData);

    }

  };

  goToFlags = () => this.router.navigate(['/data-entry/flags'], { queryParams: this.queryParams })


  goToComments(index, parameterid, type) {
    console.log("graph data")
    // alert(this.graph['pid_1686'].labels)
    // console.log(this.graph)
    this.textInputValue(index, null, type, parameterid)
    this.selectedParameter = (this.p - 1) * 5 + index;
    this.toggleComment(false)

    this.dataEntryService.selecttab(3)
    this.newParam(parameterid, 'batchdata',parameterid);

  }



  onTogglePicker = (name: string) => {
    if (this.dates[name].showPicker === false) this.dates[name].showPicker = true;
  }


  onValueChange = (val: Date, name: string) => {
    this.values[name].value = val.toString()
    this.setNewBatchesData(name);

  };

  Plotgraphdata; any;
  checkTypeOfElement = (input: string, index: number) => {

    const parameter = this.parameters[(this.p - 1) * 5 + index]
    // lert(this.graph["pid_"+parameter.parameterid])
    // console.log("parameterdata"+parameter.parameterid)
    // this.getGeneric.getAnalysisAll(this.recipeSectionId, this.recipeId).subscribe(plotdata => {
    //   this.Plotgraphdata=plotdata;
    //   console.log(plotdata)
    // });
    // this.Plotgraphdata["pid_"+parameter.parameterid]

    //   if(parameter.parameterid==this.Plotgraphdata["pid_"+parameter.parameterid])
    //   {
    //     console.log("plotdata found")
    //     // this.linechart(this.Plotgraphdata["pid_"+parameter.parameterid].labels,this.Plotgraphdata["pid_"+parameter.parameterid].values);



    //   }
    //   else
    //   {
    //     console.log("parameterid not found")
    //   }

    // alert(this.graph["pid_1686"].labels)

    // const parameter = this.parameters[index];
    //   console.log(parameter)\

    // this.horizontalBoxPlot.data=this.graph["pid_"+parameter.parameterid];

    // this.horizontalBoxPlot.data.x=this.graph["pid_1686"].labels;
    // alert(this.horizontalBoxPlot.data.x)
    //  this.horizontalBoxPlot.data.y=this.plotdata["pid_"+parameter.parameterid].values;
    //console.log(this.horizontalBoxPlot.data)
    // this.horizontalBoxPlot.layout;
    // this.horizontalBoxPlot.config;
    if (!parameter.typename) {
      return;
    }

    if (parameter.listname) {
      this.listOption = this.allParam.batchdata_paramlov[parameter.listname]
    }

    if (parameter.baseuom) {

      // console.log(this.allParam.batchdata_uom[parameter.uom])
      this.uomOption = this.allParam.batchdata_uom[parameter.baseuom]

    }

    switch (input) {
      case 'text':
        return parameter.typename.toUpperCase() !== 'DATE' && parameter.typename.toUpperCase() !== 'TIME' && parameter.typename !== 'Date/Time' && !parameter.limittolist;
      case 'date':
        return parameter.typename.toUpperCase() == 'DATE'
      case 'datetime':
        return parameter.typename == 'Date/Time';
      case 'time':
        return parameter.typename == 'Time';
      case 'dropdown':
        return parameter.limittolist;
      // default:
      //   return !parameterVersion.dropdownlimittolist
    }
  }



  checkTypeOfElementTable = (input: string, firstIndex: number, secondIndex: number) => {
    // console.log(FirstIndex);

    // console.log(this.tableData.headers[secondIndex])

    const parameter = this.tableData.headers[secondIndex]
    //  console.log(parameter.typename);
    if (!parameter.typename) {
      return;
    }

    if (parameter.listname) {
      this.tableListOption = this.allParam.batchdata_paramlov[parameter.listname]
    }

    switch (input) {

      case 'text':
        return parameter.typename.toUpperCase() !== 'DATE' && parameter.typename.toUpperCase() !== 'TIME' && parameter.typename !== 'Date/Time' && !parameter.listname;
      case 'date':
        return parameter.typename.toUpperCase() == 'DATE'
      case 'datetime':
        return parameter.typename == 'Date/Time';
      case 'time':
        return parameter.typename == 'Time';
      case 'dropdown':
        return parameter.listname;


    }



    // if (parameter.limittolist) {
    //   this.listOption = this.allParam.batchdata_paramlov[parameter.listname]
    // }


    // console.log(this.option)


  }

  textInputValue(index: number, secondIndex: number = null, type: string = '', batchdataid = '', event?, alldata?) {
    this.displayicon = true;
    this.newParam(batchdataid, 'batchdata',alldata.parameterid);
    
    console.log(this.uomOption)

    // console.log(batchdataid)

    // console.log(alldata)

    // if(event.model.angularValue)
    // {
    //   console.log(event.model.angularValue)

    // }else

    // {
    //   console.log(event.target.value)

    // }

    // this.selectedValue=event.target.value
    if (type == 'normal') {

      this.selectedParameter = (this.p - 1) * 5 + index;
      //  this.selectedParameter=index;
      // console.log(this.selectedParameter)

      this.setSelectedParamIndex({ 'firstIndex': (this.p - 1) * 5 + index, 'secondIndex': secondIndex, 'type': type })

    } else {
      // this.selectedParameter = index;
      this.selectedParameter = index;
      this.setSelectedParamIndex({ 'firstIndex': index, 'secondIndex': secondIndex, 'type': type })
    }



  }

  getDropDownValues = (index: number) => {
    const values = this.batchFiltered[this.paramSelect].parameters[index].parameter_version.dropdownvalues.split(',')
    return values.map(val => val.split(';').join(' - '))
  };
  displaytoggleicon:boolean=false;

  ngOnInit() {
    this.displaytoggleicon=false;
this.getGraph()

    this.getRecipeSectionId()
    this.parameters = "";

    this.getDateFormate()
    this.getDateTimeFormate()
    this.items = paramsData;

    this.batch$.subscribe(batch => this.batch = batch);
    // this.graph$.subscribe(allgraph => this.graph = allgraph);

    this.parameters$.subscribe(parameter => this.parameters = parameter);

    this.allParam$.subscribe(allparam => this.allParam = allparam);
    // console.log("graph data")
    this.tableData$.subscribe(tabledata => this.tableData = tabledata);



    this.paramSelect$.subscribe(param => {
      this.paramSelect = param
      // this.setValues();  
    });

    this.newBatchesData$.subscribe(newBatchesData => this.newBatchesData = newBatchesData);

    this.route.queryParams.subscribe(params => {
      this.queryParams = params
      this.sameUser = params['assignedto'] === this.dataEntryService.getUserName();
      this.recipeId = params.recipeid

    });

    this.allowedRole$.subscribe(allowedRole => this.allowedRole = allowedRole);

    this.userSig$.subscribe(userSig => this.userSig = userSig);

    this.currentRole$.subscribe(currentRole => this.currentRole = currentRole);

    this.filters$.subscribe(filters => {
      (this.batch[0].title !== '' && filters.length > 0) ? this.batchFiltered =
        this.dataEntryService.setFilterBatch(filters, this.batch) : this.batchFiltered = this.batch.map(d => Object.assign({}, d));
    });

    this.updBatchesData$.subscribe(updateBatchesData => this.updBatchesData = updateBatchesData)
    this.currentStatus$.subscribe(currentStatus => this.currentStatus = currentStatus);


    this.getCommentTagCount()

    this.commentFlag()
    this.displaytoggleicon=true;
  }


  
  getGraph = () => {

    this.data.graphData.subscribe(data => {
     
this.graph=data
    },
      error => {

        // console.log(error)
      })

  }

  setParameters = (name: string, parameterid: number) => {
    this.dataEntryService.setBatch(this.batch);
    this.dataEntryService.setBatchData(name, this.batch[this.paramSelect].parameters);
    this.dataEntryService.setParameterIdSelected(parameterid);
    this.parameterId = parameterid;
  }



  setPositionFormInfo = (name: string) => {
    const top = document.getElementById(name).getBoundingClientRect().top;
    const firstElementOfList = this.batch[this.paramSelect].parameters[0].parameter.uniquename
    const elementSelect = document.getElementById(firstElementOfList);
    this.topFormInfo = elementSelect.getBoundingClientRect().top;
    const relativeTop = top - this.topFormInfo;
    this.dataEntryService.setTopFormInfo(relativeTop);
  }

  removeBatchData = (uniquename: string) => {
    delete this.newBatchesData[uniquename];
    const index = this.batch[this.paramSelect].parameters.findIndex(d => d.parameter.uniquename === uniquename);

    // Remove Last Batch Data
    this.batch[this.paramSelect].parameters[index].batch_data.pop();

    // Set Last Value of Batch Data
    this.values[uniquename].value = this.batch[this.paramSelect].parameters[index].batch_data.slice(-1).pop().parametervalue;

    // Remove Last Element of Analysis
    // this.batch[this.paramSelect].parameters[index].analysis.data.pop();
    // this.batch[this.paramSelect].parameters[index].analysis.labels.pop();

    // Set New Batches
    this.dataEntryService.setNewBatchesData(this.newBatchesData)
  }
  setValues = () => {
    if (this.batch[0].title === '') return
    this.batch[this.paramSelect].parameters.forEach((d, i) => {
      if (this.dates[d.parameter.uniquename] === undefined) {
        let obj = {};
        obj[d.parameter.uniquename] = { unique: d.parameter.uniquename, showPicker: false, showDate: true, showTime: true }
        this.dates = Object.assign(this.dates, obj);
      }
      if (this.values[d.parameter.uniquename] === undefined) {
        let obj = {};
        obj[d.parameter.uniquename] = {
          uom: d.batch_data.slice(-1).pop().uomselected,
          value: d.batch_data.slice(-1).pop().parametervalue
        };
        this.values = Object.assign(this.values, obj);
      }
    })
  }

  sig = (item: any) => {
    if (!this.allowedRole) {
      // this.bsModalRef = this.modalService.show(ModalRoleComponent);
      this.bsModalRef.content.item = item;
      this.bsModalRef.content.batchid = this.queryParams.batchid;
    } else {
      const esig = this.dataEntryService.setEsig(this.userSig, ['']);
      const [updateBatch, batchdataid] = this.dataEntryService.changeEsig(this.batch, item.parameter.uniquename, esig)
      this.dataEntryService.postEsig({ batchid: this.queryParams.batchid, esig: esig, batchdataid: batchdataid }).subscribe(resp => {
        const notice = resp.status ? 'update' : 'We have some problems';
        window.alert(notice)
      })
      this.dataEntryService.setBatch(updateBatch);
    }
  }


  checkDisabled = (item: any) => {
    // return (this.currentRole.findIndex(d => d === 'VIEWER') !== -1 || this.currentStatus.toLowerCase() !== "open" || item.batch_data.slice(-1).pop().esig !== null) ? true : null;
  }

  setNewBatchesData = (uniquename: string) => {
    const batchData = this.setParamsNewBatchData(uniquename);
    this.newBatchesData[uniquename] === undefined ? this.newBatchData(uniquename, batchData) : this.updateBatchesData(uniquename, batchData);
    this.dataEntryService.setNewBatchesData(this.newBatchesData);
    console.log("batch data" + this.newBatchesData)
  }
  

  updateBatchesData = (uniquename, batchData) => {
   
    const index = this.batch[this.paramSelect].parameters.findIndex(d => d.parameter.uniquename === uniquename);
    // this.batch[this.paramSelect].parameters[index].analysis.data.pop() 
    // this.batch[this.paramSelect].parameters[index].analysis.labels.pop()
    // this.batch[this.paramSelect].parameters[index].analysis.data.push(this.values[uniquename].value)
    // this.queryParams.batch
    // this.batch[this.paramSelect].parameters[index].analysis.labels.push(this.queryParams.batch); 
    // this.batch[this.paramSelect].parameters[index].analysis.labels.push((new Date()).toUTCString()) 
    this.newBatchesData[uniquename] = batchData
    // Add new Batch to Store
    this.dataEntryService.setBatch(this.batch);
    console.log("batch data" + this.batch)
  };


  newBatchData = (uniquename, batchData) => {

    const index = this.batch[this.paramSelect].parameters.findIndex(d => d.parameter.uniquename === uniquename);
    // Update analyis charts
    // this.batch[this.paramSelect].parameters[index].analysis.data.push(this.values[uniquename].value)
    // this.batch[this.paramSelect].parameters[index].analysis.labels.push(this.queryParams.batch);
    // this.batch[this.paramSelect].parameters[index].analysis.labels.push((new Date()).toUTCString())
    // Update Details
    this.batch[this.paramSelect].parameters[index].batch_data.push(batchData);
    this.newBatchesData[uniquename] = batchData;
    // Add new Batch to Store
    this.dataEntryService.setBatch(this.batch);

  }

  setParamsNewBatchData = (uniquename) => {

    const index = this.batch[this.paramSelect].parameters.findIndex(d => d.parameter.uniquename === uniquename);
    const parameterSelected = this.batch[this.paramSelect].parameters[index];


    return {
      batchdataid: 'new',
      name: parameterSelected.parameter ? parameterSelected.parameter.label : '',
      specMin: parameterSelected.parameter_version ? parameterSelected.parameter_version.specmin : 0,
      specMax: parameterSelected.parameter_version ? parameterSelected.parameter_version.specmax : 0,
      stepLabel: parameterSelected.parameter_version ? parameterSelected.parameter_version.stepno : 0,
      specialInstruction: parameterSelected.parameter_version ? parameterSelected.parameter.dataentryinstructions : '',
      description: parameterSelected.parameter ? parameterSelected.parameter.description : '',
      stepDescription: parameterSelected.parameter_version ? parameterSelected.parameter_version.stepdescription : '',
      usercomment: parameterSelected.parameter_version ? parameterSelected.parameter_version.uom : '',
      parametervalue: this.values[uniquename].value,
      uomselected:this.values[uniquename].uom,
      parameterid: parameterSelected.batch_data.slice(-1).pop().parameterid,
      batchid: parameterSelected.batch_data.slice(-1).pop().batchid,
      parameterversionid: parameterSelected.batch_data.slice(-1).pop().parameterversionid,
      esig: null,
      isflag: null
    }
  }


  ngAfterContentChecked() {
    // console.log(this.allParam)
  }

  ngAfterViewChecked() {

    this.cdr.detectChanges();
  }

  last:any;
  addRow() {
    //  console.log(this.tableData)

    
    if(this.tableData.rows.length<=1)
    {
      this.last = this.tableData.rows[this.tableData.rows.length - 1];
    console.log(this.last)
    for (let j = 0; j < this.last.length; j++) {
      this.dataTopush.push({
        "rowno": this.last[j].rowno+1, "rid": this.last[j].rid, "header_name": this.last[j].header_name, "batchdataid": null, "parametervalue": '', "typename": this.last[j].typename, "formattype": this.last[j].formattype,
        "regex_code": this.last[j].regex_code, "enteredby":this. last[j].enteredby, "enteredon": this.last[j].enteredon, "lastupdatedby": 1, "lastupdatedate": '',
        "parameterid": this.last[j].parameterid, "parametername":this.last[j].parametername, "stepno": this.last[j].stepno, "sortno": this.last[j].sortno, "parameterversionid": this.last[j].parameterversionid
        , "sectionname": this.last[j].sectionname, "tblname": this.last[j].tblname, "recipesectionid": this.last[j].recipesectionid, "dataformatid": this.last[j].dataformatid
      })
    


      // console.log({
      //   "rowno": last[j].rowno + 1, "rid": last[j].rid, "header_name": last[j].header_name, "batchdataid": 0, "parametervalue": '', "typename": last[j].typename, "formattype": last[j].formattype, "listname": last[j].listname,
      //   "limittolist": last[j].limittolist, "dataentryinstructions": last[j].dataentryinstructions, "regex_code": last[j].regex_code, "enteredby": last[j].enteredby, "enteredon": last[j].enteredon, "lastupdatedby": 1, "lastupdatedate": '',
      //   "parameterid": last[j].parameterid, "parametername": last[j].parametername, "stepno": last[j].stepno, "sortno": last[j].sortno, "parameterversionid": last[j].parameterversionid
      //   , "sectionname": last[j].sectionname, "tblname": last[j].tblname
      // })

    }
  }
  else
  {
    this.last = this.tableData.rows[this.tableData.rows.length - 1];
    for (let j = 0; j < this.tableData.rows[this.tableData.rows.length - 1]; j++) {
      this.dataTopush.push({
        "rowno": this.last[j].rowno+1 , "rid": this.last[j].rid, "header_name": this.last[j].header_name, "batchdataid": null, "parametervalue": '', "typename": this.last[j].typename, "formattype": this.last[j].formattype,
        "regex_code": this.last[j].regex_code, "enteredby":this. last[j].enteredby, "enteredon": this.last[j].enteredon, "lastupdatedby": 1, "lastupdatedate": '',
        "parameterid": this.last[j].parameterid, "parametername":this.last[j].parametername, "stepno": this.last[j].stepno, "sortno": this.last[j].sortno, "parameterversionid": this.last[j].parameterversionid
        , "sectionname": this.last[j].sectionname, "tblname": this.last[j].tblname, "recipesectionid": this.last[j].recipesectionid, "dataformatid": this.last[j].dataformatid
      })
    } 
  }
    this.tableData.rows.push(this.dataTopush)
    console.log(this.tableData)

    // for (let i = 0; i < this.tableData.rows.length; i++) {
    // console.log(this.tableData.rows)

    // this.tableData.rows.push({
    //   "rowno": last.rowno + 1, "rid": last.rid, "header_name": last.header_name, "batchdataid": 0, "parametervalue": '', "typename": last.typename, "formattype": last.formattype, "listname": last.listname,
    //   "limittolist": last.limittolist, "dataentryinstructions": last.dataentryinstructions, "regex_code": last.regex_code, "enteredby": last.enteredby, "enteredon": last.enteredon, "lastupdatedby": 1, "lastupdatedate": ''
    // })
    // this.tableData[i].rows.push({
    //   "rowno": last.rowno + 1, "rid": last.rid, "header_name": last.header_name, "batchdataid": 0, "parametervalue": '', "typename": last.typename, "formattype": last.formattype, "listname": last.listname,
    //   "limittolist": last.limittolist, "dataentryinstructions": last.dataentryinstructions, "regex_code": last.regex_code, "enteredby": last.enteredby, "enteredon": last.enteredon, "lastupdatedby": 1, "lastupdatedate": ''
    // })
    // }
  }

  displayicon: boolean = false;


  onKeyPress(type: any, event) {
    this.displayicon = true;
    if (type == 'Float') {
      let charCode = (event.which) ? event.which : event.keyCode;
      if (charCode != 46 && charCode > 31
        && (charCode < 48 || charCode > 57))
        return false;
      return true;
    }
    if (type == 'Number') {

      const charCode = (event.which) ? event.which : event.keyCode;
      if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
      }
      return true;
    }
  }


  //Set selected parameter index
  setSelectedParamIndex(data: any) {
    this.dataEntryService.setSelectedParamIndex(data)

  }

  setSelectedCommIndex(data: any) {
    this.dataEntryService.setSelectedCommIndex(data)
  }

  clickMe() {
    console.log(this.tableData)
  }


  newParam(param: any, table: any,parameterid:any) {
    this.data.changeParam({ message: param, table: table,parameterplotid: parameterid})
  }

  //Toggle Comment

  toggleComment(toggle: boolean) {
    console.log(this.data)
    this.data.toggleComment(toggle)
  }


  getDateFormate() {
    this.dateFormat = this.preference.getDateFormate()

  }

  getDateTimeFormate() {
    this.dateTimeFormat = this.preference.getDateTimeFormate()

  }



  checkDateFormate($event, index, secondIndex = null, type) {
    if (type == "normal") {
      this.errorIndexDate = (this.p - 1) * 5 + index;
      // console.log($event.model.angularValue)
      if ($event.model.angularValue) {
        this.dateFormate = false
      }
      else {
        this.dateFormate = true

      }
    } else {
      this.errorIndexDateTable = index;
      this.errorIndexDateTableSecond = secondIndex;
      // console.log($event.model.angularValue)
      if ($event.model.angularValue) {
        this.dateFormateTable = false
      }
      else {
        this.dateFormateTable = true

      }
    }

  }

  checkDateTimeFormate($event, index, secondindex = null, type) {
    if (type == "normal") {
      this.errorIndexDateTime = (this.p - 1) * 5 + index;
      // console.log($event.model.angularValue)
      if ($event.model.angularValue) {
        this.dateTimeFormate = false
      }
      else {
        this.dateTimeFormate = true

      }
    } else {
      this.errorIndexDateTimeTable = index;
      this.errorIndexDateTimeTableSecond = secondindex;
      // console.log($event.model.angularValue)
      if ($event.model.angularValue) {
        this.dateTimeFormateTable = false
      }
      else {
        this.dateTimeFormateTable = true

      }
    }

  }




  checkTimeFormate($event, index, secondindex = null, type) {
    if (type == "normal") {
      this.errorIndexTime = (this.p - 1) * 5 + index;
      // console.log($event.model.angularValue)
      if ($event.model.angularValue) {
        this.timeFormate = false
      }
      else {
        this.timeFormate = true

      }
    } else {
      this.errorIndexTimeTable = index;
      this.errorIndexTimeTableSecond = secondindex;
      // console.log($event.model.angularValue)
      if ($event.model.angularValue) {
        this.timeFormateTable = false
      }
      else {
        this.timeFormateTable = true

      }
    }

  }


  testdata() {
    // this.rowData = []
    // for (let i = 0; i < this.tableData.rows.length; i++) {
    //   //  console.log(this.tableData.rows[i][i+1])
    //   //  for(let j=0;j<this.tableData.rows[i][i+1].length;j++)
    //   // {
    //   // //  console.log(this.tableData.rows[i][i+1][j])

    //   // } 
    //   this.rowData.push(this.tableData.rows[i][i + 1])
    // }
    console.log(this.tableData)
  }



  //Ng -Zorro
  mapOfExpandData: { [key: string]: boolean } = {};
  isAllDisplayDataChecked = false;
  isIndeterminate = false;
  listOfDisplayData: any[] = [];
  mapOfCheckedId: { [key: string]: boolean } = {};
  editCache: { [key: string]: any } = {};
  listOfData: any[] = [];

  startEdit(id: string): void {
    this.listOfData.forEach(item => {
      this.editCache[item.id] = {
        edit: false,
        data: { ...item }
      };
    });
    this.editCache[id].edit = true;
  }

  cancelEdit(id: string): void {
    const index = this.listOfData.findIndex(item => item.id === id);
    this.editCache[id] = {
      data: { ...this.listOfData[index] },
      edit: false
    };
  }

  saveEdit(id: string): void {
    // console.log(id)
    const index = this.tableData.findIndex(item => item.batchdataid === id);
    Object.assign(this.tableData[index], this.editCache[id].data);
    // this.editCache[id].edit = false;
  }

  updateEditCache(): void {
    this.listOfData.forEach(item => {
      this.editCache[item.id] = {
        edit: false,
        data: { ...item }
      };
    });
  }

  addRowTable() {
    let last: any = this.listOfData.length - 1;
    this.listOfData = [
      ...this.listOfData,

      {
        id: `${last + 1}`,

      }
    ];

    this.updateEditCache();

    this.startEdit(last + 1);
  }



  // dataConvertion(type, id) {
  //   if (id !== null) {

  //     if (type == "recipe") {
  //       return this.recipes.find(x => x.savedvalue == id).displayvalue
  //     }
  //     if (type == "template") {
  //       return this.templates.find(x => x.savedvalue == id).displayvalue
  //     }
  //     if (type == "batchtype") {
  //       return this.batchType.find(x => x.savedvalue == id).displayvalue
  //     }
  //     if (type == "user") {
  //       return this.users.find(x => x.savedvalue == id).displayvalue
  //     }
  //   }
  // }
  dateConvertion(data: any) {
    if (data) {

      return this.preference.setDate(data)
    } else {
      return null
    }


  }

  deleteRow(id: string): void {
    this.listOfData = this.listOfData.filter(d => d.id !== id);
  }


  batchNewData(batchdataid, type, index) {
    // console.log(index)
    // console.log(batchdataid)
    // console.log(this.allParam)

    this.setPercentCalc(batchdataid)

    if (type == 'normal') {
      const indexVal = this.allParam.batchdata_parameter.findIndex((e) => e.batchdataid === batchdataid);
      // console.log(this.allParam.batchdata_parameter[indexVal].parametervalue)

      if (this.allParam.batchdata_parameter[indexVal].parametervalue == this.parentData.batchdata_parameter[indexVal].parametervalue) {
        // console.log("same")
        // this.updatedParameter = []
        this.dataEntryService.setUpdateBatchesData(this.updatedParameter);

      } else {
        this.updatedParameter.push(this.allParam.batchdata_parameter[indexVal])

        this.dataEntryService.setUpdateBatchesData(this.updatedParameter);
      }
      // console.log(this.updatedParameter)
    }
    else {
      this.dataEntryService.setUpdateBatchesData(this.updatedParameter);

      // console.log(this.tableData)
      // console.log("table")
      // console.log(this.tableData)
    }

  }


  pushToArray(obj) {
    const index = this.parameters.findIndex((e) => e.batchdataid === obj);

    if (index === -1) {
      this.parameters.push(obj);
    } else {
      this.parameters[index] = obj;
    }
  }

  test() {
    console.log(this.tableData)

  }

  getCommentTagCount() {
    this.getGeneric.getTagCommentCount(this.queryParams.batchid).
      subscribe(data => {

        this.tagComment = data
        // console.log(this.tagComment)
      },
        error => {
          console.log(error)
        })
  }


  serachTag(batchdataid?) {
    // console.log(this.tagComment.batchdata_tagcomment.length)
    if (this.tagComment && this.tagComment.batchdata_tagcomment) {
      return this.tagComment.batchdata_tagcomment.find(data => (data.batchdataid == batchdataid) && (data.hastags))
    }

  }



  serachComment(batchdataid?) {
    if (this.tagComment && this.tagComment.batchdata_tagcomment) {
      // console.log(batchdataid)

      return this.tagComment.batchdata_tagcomment.find(data => (data.batchdataid == batchdataid) && (data.hascomment == true))
      // if (this.tagComment.batchdata_tagcomment.find(data => data.batchdataid == batchdataid)) {
      //   console.log(true)
      // }
      // else {
      //   console.log(false)
      // }

      // return this.tagComment.batchdata_tagcomment.filter(data => data.recipesectionid == batchdataid)
      // return this.tagComment.batchdata_tagcomment.some(data => (data.recipesectionid==recipesectionid && data.hascomment) || (data.parentsectionid==parentsectionid))
    }
  }


  commentFlag() {

    this.data.commentFlag.subscribe(data => {
      this.getCommentTagCount()
    },
      error => {

        // console.log(error)
      })
  }

  setPercentCalc(batchdataid) {
    this.data.fnPercentCalc(batchdataid)
  }






  setFocus() {
    this._el.nativeElement.focus();
  }

  getRecipeSectionId() {
    this.data.recepiSetionId.subscribe(data => {
      this.recipeSectionId = data
      // console.log(data)
    })
  }




 

  /////////////line Chart
  
  
 

  config(arg0: {}, config: any, arg2: { class: string; }): any {
    throw new Error("Method not implemented.");
  }


  test1() {
    console.log(this.graph)
  }




  //////////////////////////////Syncfusion chart////////////////////////////
  lineData:any;
  xvalues:any;
  temp=[];
  maxx:number;
  tempy=[];
  maxy:number;
  checkGraph(parameterid) {
    this.lineData=[]
    if(this.graph)
    {
   console
      let pid = 'pid_' + parameterid
      // console.log(this.graph)

      if((this.graph))
      {
        if(this.graph[pid])
        {
         
          for(let i=0;i<this.graph[pid].labels.length;i++){
        this.temp.push(this.graph[pid].labels[i].substring(0, 7))
        }
        this.maxx = this.temp.reduce((a, b)=>Math.max(a, b)); 
        // console.log("max value"+this.maxx);
        
        // console.log(this.graph[pid])
        
        // for(let j=0;j<this.graph[pid].values.length;j++){
        //   this.tempy.push(this.graph[pid].values[j]);
          
        //   }
        this.tempy=this.graph[pid].values;
        // console.log(this.tempy)
          this.maxy = this.tempy.reduce((a, b)=>Math.max(a, b)); 
          // console.log("maxy value"+this.maxy);
    let count=0;
for(let i=0;i< this.graph[pid].labels.length;i++)
{

if(this.graph[pid].labels[i].substring(0,6) ==  this.queryParams.batch)
{
this.index=count;
}
else
{
  count++;
}
   this.lineData.push(  {x:this.graph[pid].labels[i].substring(0,7),yval:this.graph[pid].values[i]})
   
      }

   
    return true
        }
       
      }
    }  
 }
/////////////////////////////////////////////////////END////////////////////////////////


///////////////////synfusion Model line chart/////////////////////////////////////

index:number=0;
 plotmodel(parameterid, template: TemplateRef<any>)
 {
   
  //  this.modalRef = this.modalService.show(template, Object.assign({}, this.config, { class: 'modal-sm custom-modal' }));
      this.lineData=[]
      if(this.graph)
      {
     let pid = 'pid_' + parameterid
        if((this.graph))
        {
          if(this.graph[pid])
          {
            this.modalRef = this.modalService.show(template);  
 
            this.showAnalysis=true; 
let count=0;     

for(let i=0;i<this.graph[pid].labels.length;i++){
  this.temp.push(this.graph[pid].labels[i].substring(0, 7))
  }
  this.maxx = this.temp.reduce((a, b)=>Math.max(a, b)); 
  // console.log("max value"+this.maxx);
  
  // console.log(this.graph[pid])
  
  // for(let j=0;j<this.graph[pid].values.length;j++){
  //   this.tempy.push(this.graph[pid].values[j]);
    
  //   }
  this.tempy=this.graph[pid].values;
  // console.log(this.tempy)
    this.maxy = this.tempy.reduce((a, b)=>Math.max(a, b)); 
    // console.log("maxy value"+this.maxy);

  for(let i=0;i< this.graph[pid].labels.length;i++)
  {
    if(this.graph[pid].labels[i].substring(0,6) ==  this.queryParams.batch)
    {
this.index=count;
    }
    else
    {
      count++;
    }

     this.lineData.push(  {x:this.graph[pid].labels[i].substring(0,7),yval:this.graph[pid].values[i]})
     
        }
        // console.log(this.index)
      return true
          }
        }
      }
      // console.log(this.index)
 }


 ////////////////////////////// END syncfusion line chart//////////////////////////////


  // lineBoxPlot1 = {
  //   data: [
  //     {
  //        x:[100,102,103.,99,107],y:[5,6,7,9],
  //       // x: this.graph[pid].labels, y: this.graph[pid].values,
  //       // y:[this.pvalues[0],this.pvalues[1],this.pvalues[3]],
  //       marker: { color: 'blue' }, type: 'scatter', name: '', selectedpoints: [100], boxpoints: 'all',
  //       jitter: 0.3,
  //       pointpos: -1.8,
  //     },
  //     {
  //       displayModeBar: false,
  //     }

  //   ],
  //   layout: {
  //     autosize: true, height: 50, width: 100, margin: {
  //       l: 0,
  //       r: 0,
  //       b: 0,
  //       t: 5,
  //       pad: 2
  //     }
  //   },

  //   config: {
  //     displayModeBar: false
  //   }
  // }

//   public tooltipSettings: object = {
//     enable:true,
//     visible: true,
//     format: '${x} : ${yval}',
//     trackLineSettings: {
//         visible: true
//     }
// };
// public markerSettings: object = {
//     visible: ['All'],
//     size: 2.5,
//     fill: 'blue',
// };
// public border: object =  { color: '#3C78EF', width: 1};
// public axisSettings: {
//     lineSettings: {
//         visible: true
//     }
// };

public border: object =  { color: '#3C78EF', width: 1};
public tooltipSettings: object = {
 enable: true,
 trackLineSettings: {
          visible: true
       }
};
public axisSettings: {
      lineSettings: {
          visible: true
      }
  };

public markerSettings: object = {
  visible: true,
  
  dataLabel:{
  visible: false
  }
}

public primaryYAxis: object={
   maximum:this.maxy,
};

public pointRender(args: IPointRenderEventArgs): void {
  if(args.point.index === this.index) {
    args.width=12;
     args.height=12;
          args.fill = 'red';
  }
};

disablegraph:boolean=false;
displaygraphinner()
{
  if(this.disablegraph==true)
  {
this.disablegraph=false;
  }
  else
  {
this.disablegraph=true;
  }
// this.disablegraph=false;



}
// displaygraphswitch()
// {
// this.disablegraph=true;
// }



/////////////////////////////////Plotly chart///////////////////////////////
public debug = true;
public useResizeHandler = true;
public labels: string[];
 labelsrequired=[];
public pvalues = [];
horizontalBoxPlot: any;
enablegraph: boolean = false;
plotdata: string;
lineBoxPlot:any;
histogram:any;
Boxplot:any;
// checkGraph1(parameterid) {
//   if(this.graph)
//   {
 
//     let pid = 'pid_' + parameterid
  
//       if(this.graph[pid])
//       {
//         console.log(pid)
// console.log(this.graph[pid])
//         // console.log(this.graph[pid].labels)
//         this.labels = this.graph[pid].labels;
//          this.pvalues = this.graph[pid].values;
//       //  console.log(this.labels)
//         this.lineBoxPlot = {
//                   data: [
//                     {
//                       x:this.labels,y:this.pvalues,
//                       // y:[this.pvalues[0],this.pvalues[1],this.pvalues[3]],
//                       marker: { color: 'blue' }, type: 'scatter', name: '', boxpoints: 'all',
//                       jitter: 0.3,
//                       pointpos: -1.8,
//                     },
//                     {
//                       displayModeBar: false,
//                     }
        
//                   ],

//                   layout: {
//                               autosize: true, height: 50, width: 100, margin: {
//                                 l: 0,
//                                 r: 0,
//                                 b: 0,
//                                 t: 5,
//                                 pad: 2
//                               }
//                             },
//                             config: {
//                               displayModeBar: false
//                             }

//         }

       
//       }
     
    
//   }  
  
  // this.getGeneric.getAnalysisAll(this.recipeSectionId, this.recipeId).subscribe(plotdata => {
  //   if (this.parameters.parameterid == plotdata["pid_" + this.parameters.parameterid]) {
  //     this.plotdata = "pid_" + this.parameters.parameterid;
  //     this.enablegraph = true;
  //     this.labels = plotdata["pid_" + parameterid].labels;
  //     this.pvalues = plotdata["pid_" + parameterid].values;
  //     if (this.labels != null) {
  //       this.showAnalysis = true;
  //       console.log(plotdata)

  //       this.horizontalBoxPlot = {
  //         data: [
  //           {
  //             x: this.labels, y: this.pvalues,
  //             // y:[this.pvalues[0],this.pvalues[1],this.pvalues[3]],
  //             marker: { color: 'blue' }, type: 'scatter', name: '', selectedpoints: [100], boxpoints: 'all',
  //             jitter: 0.3,
  //             pointpos: -1.8,
  //           },
  //           {
  //             displayModeBar: false,
  //           }

  //         ],
  //         layout: {
  //           autosize: true, height: 50, width: 100, margin: {
  //             l: 0,
  //             r: 0,
  //             b: 0,
  //             t: 5,
  //             pad: 2
  //           }
  //         },
  //         config: {
  //           displayModeBar: false
  //         }
  //       };
  //     }
  //   }
  // },
  //   error => {
  //   })
// }


////////////////////////////END/////////////////////////////////////////////

/////////////////////////////plotly model ////////////////////////
ControlChart:any
charttypes=[];
 plotmodel1(parameterid, template: TemplateRef<any>)
 {

  if(this.graph)
  {
 
    let pid = 'pid_' + parameterid
  
      if(this.graph[pid])
      {
        // this.charttypes=this.Chartdata.getspecificchart(this.graph[pid]);

        this.Analytics.getspcSingleAnalyticplot(parameterid).subscribe(data=>    
          {
            console.log(data)
            for (let obj of data) {
              console.log("object:", obj);
              for (let key in obj) {
                  console.log("      key:", key, "value:", obj[key]);
                 
                
              console.log(obj[key].data)
     this.Boxplotfn2(obj[key].data, obj[key].layout);
           
            
              }
          }
           
          })


        this.modalRef = this.modalService.show(template, Object.assign({},  { class: 'modal-lg' }));
        // this.modalRef = this.modalService.show(template);  
        this.showAnalysis=true; 
        
    }
    
  }  
 }


//  spchart:any;

// Boxplotfn2(parameterdata1:any,layout:any)
// {
 

// this.spchart={
// data:parameterdata1,
// layout:layout
// }

// }

/////////////////////////////END Plotly Model/////////////////////

spchart:any;

Boxplotfn2(parameterdata1:any,layout:any)
{
this.spchart={
data:parameterdata1,
layout:layout
}

}










}

