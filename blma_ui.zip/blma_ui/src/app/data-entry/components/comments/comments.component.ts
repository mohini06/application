// import { DataService } from './../../../_core/services/data.service';
// import { ApiService } from './../../../_core/services/api.service';
// import { Component, OnInit, OnChanges, TemplateRef } from '@angular/core';
// import { Store } from '@ngrx/store';
// import { DataEntryState, dataEntryStateActions } from '../../../_core/store/data-entry.actions';
// import { SideBarState, sideBarStateActions } from '../../../_core/store/side-bar.actions';
// import { DataEntryService } from '../../../_core/services/data-entry.service'
// import { Location } from '@angular/common';
// import { BehaviorSubject, Observable } from 'rxjs/Rx';
// import { ActivatedRoute } from '@angular/router';

// import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

// @Component({
//   selector: 'app-comments',
//   templateUrl: './comments.component.html',
//   styleUrls: ['./comments.component.scss']
// })
// export class CommentsComponent implements OnInit {
//   translateY$;
//   dataEntryState$;
//   sideBarState$;
//   user$;
//   user
//   parameterIdSelected$;
//   parameterIdSelected;
//   text;
//   queryParams: any;
//   paramSelect$;
//   paramSelect: string = 'Data-log';
//   batch$;
//   batch;
//   batchDataSelect$
//   batchDataSelect: number;
//   username: string;

//   loading: boolean = false;
//   currentStatus: string = 'open'
//   currentStatus$


//   selectedIndex$;
//   selectedIndex;

//   parameters$;
//   parameters;
//   tableData$;
//   tableData;
//   allParam$;
//   allParam: any;

//   allComment$;
//   allcomment;

//   comments: any;
//   commentsSpec: any;
//   eidtcommentval: any;

//   enablebutton: any = -1;

//   newComment: any;

//   sucessMsg: any;

//   //Model
//   modalRef: BsModalRef;
//   config = {
//     backdrop: true,
//     ignoreBackdropClick: true
//   };

//   configLoading = {
//     backdropBackgroundColour: 'rgba(255,255,255,0.2)', backdropBorderRadius: '10px',
//     primaryColour: '#f96332', secondaryColour: '#f27b25', tertiaryColour: '#f49123', fullScreenBackdrop: true
//   };

//   constructor(
//     private store: Store<DataEntryState | SideBarState>,
//     private dataEntryService: DataEntryService,
//     private route: ActivatedRoute,
//     private location: Location,
//     private modalService: BsModalService,
//     private api: ApiService,
//     private data: DataService,
//   ) {
//     this.dataEntryState$ = this.store.select('dataEntry');

//     this.sideBarState$ = this.store.select('sideBar');

//     this.translateY$ = this.dataEntryState$
//       .map(state => state.topFormInfo);

//     this.user$ = this.sideBarState$
//       .map(state => state.user);

//     this.parameterIdSelected$ = this.dataEntryState$
//       .map(state => state.parameteridSelected);

//     this.paramSelect$ = this.dataEntryState$
//       .map(state => state.paramsSelect)

//     this.batch$ = this.dataEntryState$
//       .map(state => state.batch);

//     this.batchDataSelect$ = this.dataEntryState$
//       .map(state => state.batchData);

//     this.currentStatus$ = this.dataEntryState$
//       .map(state => state.currentStatus);




//     this.parameters$ = this.dataEntryState$
//       .map(state => state.filterParam);

//     this.tableData$ = this.dataEntryState$
//       .map(state => state.tableData);

//     this.allParam$ = this.dataEntryState$
//       .map(state => state.AllParam);

//     this.selectedIndex$ = this.dataEntryState$
//       .map(state => state.selectedCommIndex);



//     this.allComment$ = this.dataEntryState$
//       .map(state => state.allComment);
//   }

//   checkBatchComments = () => {
//     if (this.batch[this.paramSelect].title === "") return false
//     else return this.batch[this.paramSelect].parameters[this.batchDataSelect].comments.length > 0
//   }

//   ngOnInit() {
//     this.sucessMsg = "";

//     this.selectedIndex$.subscribe(selectedIndex => this.selectedIndex = selectedIndex)
//     this.parameters$.subscribe(parameter => this.parameters = parameter);
//     this.tableData$.subscribe(tabledata => this.tableData = tabledata);
//     this.allParam$.subscribe(allparam => this.allParam = allparam);
//     this.allComment$.subscribe(allcomment => this.allcomment = allcomment);


//     // console.log(this.commentsSpec['spec'])

//     this.user$.subscribe(user => this.user = user);
//     this.parameterIdSelected$.subscribe((id) => {
//       this.parameterIdSelected = id;
//       this.text = '';
//     });
//     this.route.queryParams.subscribe(params => this.queryParams = params);
//     this.paramSelect$.subscribe(param => this.paramSelect = param)
//     this.batch$.subscribe(batch => this.batch = batch);
//     this.batchDataSelect$.subscribe(batchData => this.batchDataSelect = batchData);
//     this.username = this.dataEntryService.getUserName();
//     this.currentStatus$.subscribe(currentStatus => this.currentStatus = currentStatus);

//   }
//   backClicked() {
//     this.location.back();
//   }
//   saveComment() {
//     // this.loading = true;
//     const resp = this.dataEntryService.postComment({ text: this.text, username: this.username, parameterid: this.parameterIdSelected, batchid: this.queryParams.batchid });
//     resp.subscribe(resp => {
//       if (resp.status) {
//         this.loading = false;
//         window.alert('new comment')
//         this.pushCommentRow({ updated_at: 'Now', user: { username: this.username }, text: this.text })
//       } else {
//         this.loading = false;
//         window.alert('error')
//       }
//     })
//   }

//   pushCommentRow = (params: { updated_at: string, user: { username: string }, text: string }) => this.batch[this.paramSelect].parameters[this.batchDataSelect].comments.push(params);

//   //New code for comment condition.

//   checkMultiple() {
//     if (this.selectedIndex && this.allcomment.spec['allow_multiple']) {
//       return this.allcomment.spec['allow_multiple'];
//     }
//   }

//   checkEdit() {
//     if (this.selectedIndex && this.comments.spec['allow_edits']) {
//       return this.comments.spec['allow_edits'];
//     }
//   }

//   checkDataforComment() {
//     if (this.selectedIndex && this.allcomment !== null) {
//       return true;

//     }
//   }

//   countOfComment() {

//     if (this.selectedIndex && this.allcomment.comments) {
//       if (this.allcomment.comments['COM_' + this.parameters[this.selectedIndex.firstIndex].batchdataid]) {
//         return this.allcomment.comments['COM_' + this.parameters[this.selectedIndex.firstIndex].batchdataid].length
//       }
//       else {
//         return false;
//       }
//     }
//   }

//   allowSingleComment() {
//     if (this.selectedIndex) {
//       if (this.checkEdit && this.countOfComment()) {
//         // console.log("not allowed")
//         return false;

//       }
//       else {
//         // console.log('allow single comment')
//         return true;
//       }
//     }
//   }

//   editPopUp() {
//     alert(this.allParam.batchdata_doccomments['COM_' + this.parameters[this.selectedIndex.firstIndex].batchdataid][0].comment)
//   }


//   openModal(template: TemplateRef<any>, commentId) {
//     //  console.log(commentId);
//     this.newParam(commentId, 'comment');
//     this.modalRef = this.modalService.show(template, Object.assign({}, this.config, { class: 'gray modal-lg' }));
//   }


//   // editComment()
//   // {
//   //   this.allParam.batchdata_doccomments['COM_' + this.parameters[this.selectedIndex.firstIndex].batchdataid][0].commentid

//   //   this.modalRef.hide()
//   // }


//   editComment(cmtId: any, comment: any) {
//     let batchid = this.parameters[this.selectedIndex.firstIndex].batchid;
//     let commentid = cmtId;

//     let batchdataid = this.parameters[this.selectedIndex.firstIndex].batchdataid;
//     this.api.editCommentBatchData(batchid, batchdataid, commentid, comment).
//       subscribe(data => {

//         this.newComment = '';
//         alert("Data Successfully updated")
//         console.log(data['batchdata_doccomments'])
//         this.dataEntryService.setAllComment(data['batchdata_doccomments'])
//         this.enablebutton = -1


//       },
//         error => {
//           alert("Something went wrong")
//         })
//   }


//   enableBtn(i) {
//     this.enablebutton = i

//   }

//   newParam(param: any, table: any) {
//     this.data.changeParam({ message: param, table: table })
//   }

//   test() {
//     console.log(this.allcomment)
//   }

// }
