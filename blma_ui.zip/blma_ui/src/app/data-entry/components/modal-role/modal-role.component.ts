import { Component, OnInit, AfterViewChecked, ChangeDetectorRef } from '@angular/core';

import { DataEntryState, dataEntryStateActions } from '../../../_core/store/data-entry.actions';

import { DataEntryService } from '../../../_core/services/data-entry.service';

import { AuthService } from '../../../_core/services/auth.service';

import { Store } from '@ngrx/store';

import { BsModalService } from 'ngx-bootstrap/modal';

import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';

@Component({
  selector: 'app-modal-role',
  templateUrl: './modal-role.component.html',
  styleUrls: ['./modal-role.component.scss']
})
export class ModalRoleComponent implements OnInit, AfterViewChecked {
  
  dataEntryState$;
  item;
  currentItem;
  username: string;
  password: string;
  error: {text: string, active: boolean} = {text: '', active: false};
  
  currentBatchid;
  batchid;
  
  alloweRole$
  alloweRole: boolean;
  roles$;
  role;
  
  batch$;
  batch;

  constructor(
    private store: Store< DataEntryState >,
    private dataEntryService: DataEntryService,
    private authService: AuthService,
    public bsModalRef: BsModalRef,
    private ref: ChangeDetectorRef
  ) {
    this.dataEntryState$ = this.store.select('dataEntry');

    this.batch$ = this.dataEntryState$
                      .map(state => state.batch );

    this.alloweRole$ = this.dataEntryState$
                        .map(state => state.allowedRole);
    
    this.roles$ = this.dataEntryState$
                    .map(state => state.currentRole);

   }

  ngOnInit() {
    this.batch$.subscribe(batch => this.batch = batch);
    this.alloweRole$.subscribe(allowedRole => this.alloweRole = allowedRole);
    this.roles$.subscribe(roles => this.role = roles);
    Object.assign(this.error, {text: '', active: false})
  }

  ngAfterViewChecked() {
    this.currentItem = this.item;
    this.currentBatchid = this.batchid;
    this.ref.detectChanges();
  }

  validate = () => this.dataEntryService.allowedRole({validateuser: this.username, password: this.password}).subscribe(resp => {
    this.authService.setAllowedRole(resp.allowed);
    this.authService.setUserSig(this.username);
    if (!resp.response) Object.assign(this.error, {text: 'User invalid', active: true})
    else {
      const esig = this.dataEntryService.setEsig(this.username, this.role);
      const [updateBatch, batchdataid] = this.dataEntryService.changeEsig(this.batch, this.currentItem.parameter.uniquename, esig);
      this.dataEntryService.postEsig({batchid: this.currentBatchid, esig: esig, batchdataid: batchdataid}).subscribe(resp => {
        const notice = resp.status ? 'update' : 'We have some problems'; 
        window.alert(notice)
      })
      this.dataEntryService.setBatch(updateBatch);
      this.bsModalRef.hide();
    }
  })

}
