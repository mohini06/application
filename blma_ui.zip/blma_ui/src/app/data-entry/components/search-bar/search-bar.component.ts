import { Component, OnInit } from '@angular/core';

import { DataEntryState, dataEntryStateActions } from '../../../_core/store/data-entry.actions';

import { DataEntryService } from '../../../_core/services/data-entry.service';

import { Store } from '@ngrx/store';

import { Observable } from 'rxjs';

@Component({
  selector: 'search-bar',
  templateUrl: './search-bar.component.html',
  styleUrls: ['./search-bar.component.scss']
})
export class SearchBarComponent implements OnInit {
  filters$;
  filters: any;
  dataEntryState$;
  removeFilterTrigger: boolean;
  textFilter: string;
  constructor(
    private store: Store<DataEntryState>,
    private dataEntryService: DataEntryService
  ) {
    this.dataEntryState$ = this.store.select('dataEntry');
    this.filters$ = this.dataEntryState$
                  .map(state => state.filters );
    this.removeFilterTrigger = false;
    this.textFilter = '';
   }

  ngOnInit() {
    this.filters$.subscribe(filters => this.filters = filters); 
  }

  filter = () => {
    if (this.textFilter === '') this.removeFilter()
    else{
      this.removeFilterTrigger = true;
      const index = this.filters.findIndex(filter => filter !== 'lock' && filter !== 'comment' && filter !== 'flag');
      index !== -1 ? this.filters[index] = this.textFilter : this.filters.push(this.textFilter);
      this.dataEntryService.setFilters(this.filters);
    }
  }

  removeFilter = () => {
    this.removeFilterTrigger = false;
    this.textFilter = '';
    this.filters = this.filters.filter(f => f === 'lock' || f === 'comment' || f === 'flag');
    this.dataEntryService.setFilters(this.filters);
  }

}
