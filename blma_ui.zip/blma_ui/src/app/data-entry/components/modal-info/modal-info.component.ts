import { Component, OnInit, AfterViewChecked, ChangeDetectorRef } from '@angular/core';

import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';


@Component({
  selector: 'modal-info',
  templateUrl: './modal-info.component.html',
  styleUrls: ['./modal-info.component.scss'],
})
export class ModalInfoComponent implements OnInit, AfterViewChecked {
  
  title: string;
  list: any[] = [];
  title2 = '';
  list2 = [];
  constructor(
    public bsModalRef: BsModalRef,
    private ref: ChangeDetectorRef
    ) { }

  ngOnInit() {
    
  }
  
  ngAfterViewChecked() {
    this.title2 = this.title;
    this.list2 = this.list;
    this.ref.detectChanges();
  }

}
