import { ExcelexportService } from './../../../../_core/services/excelexport.service';
import { FilterPipe } from './../../../../pipes/filter.pipe';
import { DataEntryService } from './../../../../_core/services/data-entry.service';
import { DataService } from './../../../../_core/services/data.service';
import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { GridComponent, ToolbarItems } from '@syncfusion/ej2-angular-grids';
import { ClickEventArgs } from '@syncfusion/ej2-navigations'
import { DataManager, WebApiAdaptor, ODataAdaptor } from '@syncfusion/ej2-data';
import { PageSettingsModel } from '@syncfusion/ej2-angular-grids';
import * as cloneDeep from 'lodash/cloneDeep';


@Component({
  selector: 'form-info-audit',
  templateUrl: './audit.component.html',
  styleUrls: ['./audit.component.scss']
})
export class AuditComponent implements OnInit {
  audit: any = [];
  auditHeader: any = [];
  searchText: any
  public dTdata: any;
  public searchedData: any
  public filterSettings: Object;
  public toolbarOptions: ToolbarItems[];
  public initialPage: PageSettingsModel;
  public formatOptions: any;
  ExportData = []

  @ViewChild('grid', { static: false }) public grid: GridComponent;

  constructor(private excelExp: ExcelexportService, private data: DataService, private dataEntryService: DataEntryService, ) {
  }

  toolbarClick(args: ClickEventArgs): void {
    if (args.item.id === 'Grid_excelexport') { // 'Grid_excelexport' -> Grid component id + _ + toolbar item name
      this.grid.excelExport();
    }
  }

  ngOnInit() {
    // this.data.currentParam.subscribe(message => this.param = message)
    // console.log(this.param)

    this.getSelectedParam()

    this.initialPage = { pageSize: 5 };
    this.filterSettings = { type: 'Menu' };
    this.toolbarOptions = ['ExcelExport', 'Search'];
    this.formatOptions = { type: 'date', format: "MM/dd/yyyy hh:mm a" };


  }



  ngAfterContentInit() {
    // console.log("ngAfterContentInit");
  }
  ngAfterContentChecked() {
    // console.log("ngAfterContentChecked");
  }
  ngAfterViewInit() {
    // console.log("ngAfterViewInit");
  }
  ngAfterViewChecked() {
    // console.log("ngAfterViewChecked");
  }
  ngOnDestroy() {

  }

  getAuditView = (pageno = 0, param, table) => {
    // console.log(param)
    if (!param) {
      return;
    }
    this.dataEntryService.getAuditView(pageno, param, table).
      subscribe(data => {

        if (data.audit_history[0]) {
          this.audit = data.audit_history[0];
          this.dTdata = this.audit.cl;
          this.searchedData = this.audit.cl
          // console.log(this.searchedData);
          this.auditHeader = data.audit_header[0]
        }


        //  this.audit=JSON.stringify(this.audit.beforechange)

      },
        error => {

          // console.log(error)
        })

  }


  getSelectedParam = (pageno = 0) => {

    this.data.currentParam.subscribe(data => {
      this.getAuditView(0, data.message, data.table)

    },
      error => {

        // console.log(error)
      })

  }

  getSecondPart(str) {

    let colon = str.split(':')[1];
    var result = colon.substring(1, colon.length - 1);

    return result.replace(/['"]+/g, '')
  }

  test() {
    console.log(this.dTdata)
  }

  search(data) {

    let filters = { Changes: [data], User: [data] },
      result = this.dTdata.filter(({ Changes, User }) => filters.Changes.some(n => Changes.includes(n)) || filters.User.includes(User));
    this.searchedData = result
    // console.log(result);
    //     let filters = { name: ["Krishna", "Naveen"], city : ["qwedss"]},
    //     results = [{    "name": "Krishna#Surname",    "city": "London",    "age": 23},{    "name": "Naveen",    "city": "London",    "age": 23},{    "name": "Krishna",    "city": "NewYork",    "age": 23},{    "name": "Praveen",    "city": "Washington",    "age": 23}],
    //     result = results.filter(({name, city}) => filters.name.some(n => name.includes(n)) || filters.city.includes(city));

    // console.log(result);

  }

  expoertToExcel() {
    this.ExportData = []
    // console.log(this.dTdata)
    this.ExportData = this.dTdata
    this.ExportData = cloneDeep(this.dTdata);
    for (let i = 0; i < this.ExportData.length; i++) {
      this.ExportData[i].Changes = this.dTdata[i].Changes.replace(/<[^>]*>/g, '');
    }
    this.excelExp.exportAsExcelFile(this.ExportData, 'Audit');
  }


}
