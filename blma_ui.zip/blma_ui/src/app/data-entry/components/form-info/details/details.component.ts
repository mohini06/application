import { Subject, Observable } from 'rxjs';
import { Component, OnInit, Input, SimpleChanges, EventEmitter } from '@angular/core';

import { Details } from '../../../../_core/interfaces/data-entry.interface'

import { Store } from '@ngrx/store';

import { DataEntryState, dataEntryStateActions } from '../../../../_core/store/data-entry.actions';

import { DataEntryService } from '../../../../_core/services/data-entry.service';

@Component({
  selector: 'form-info-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})
export class DetailsComponent implements OnInit {
  @Input() details: any
  public eventsSubject: Subject<void> = new Subject<void>();
  public eventsSubscription: any

  parent = 'batchdata'
  dataEntryState$;
  batch$;
  batch;
  paramSelect$;
  paramSelect;
  newBatchesData;
  newBatchesData$;
  batchDataSelect$
  batchDataSelect;
  updateBatchesData$;
  updateBatchesData;



  constructor(
    private store: Store<DataEntryState>,
    private dataEntryService: DataEntryService
  ) {
    this.dataEntryState$ = this.store.select('dataEntry');
    this.batch$ = this.dataEntryState$
      .map(state => state.batch);
    this.paramSelect$ = this.dataEntryState$
      .map(state => state.paramsSelect)
    this.newBatchesData$ = this.dataEntryState$
      .map(state => state.newBatchesData);
    this.batchDataSelect$ = this.dataEntryState$
      .map(state => state.batchData);
    this.updateBatchesData$ = this.dataEntryState$
      .map(state => state.updateBatchesData);


  }



  ngOnInit() {
    this.batch$.subscribe(batch => this.batch = batch);
    this.paramSelect$.subscribe(paramSelect => this.paramSelect = paramSelect);
    this.batchDataSelect$.subscribe(batchDataSelected => this.batchDataSelect = batchDataSelected);
    this.newBatchesData$.subscribe(newBatchesData => this.newBatchesData = newBatchesData);
    this.updateBatchesData$.subscribe(updateBatchesData => this.updateBatchesData = updateBatchesData)

  }

  usercomment(event: any) {
    const parameterSelected = this.batch[this.paramSelect].parameters[this.batchDataSelect];
    const uniquename = parameterSelected.parameter.uniquename;
    const value = event.target.value;
    if (this.newBatchesData[uniquename] !== undefined) {
      // New Batch Data
      this.newBatchesData[uniquename].usercomment = value;
      this.dataEntryService.setNewBatchesData(this.newBatchesData);

    } else if (this.updateBatchesData[parameterSelected.batch_data.slice(-1).pop().batchdataid] === undefined) {

      const batchdataid = parameterSelected.batch_data.slice(-1).pop().batchdataid;
      this.updateBatchesData[batchdataid] = parameterSelected.batch_data.slice(-1).pop();
      this.updateBatchesData[batchdataid].usercomment = value;
      this.dataEntryService.setUpdateBatchesData(this.updateBatchesData);

    } else if (this.updateBatchesData[parameterSelected.batch_data.slice(-1).pop().batchdataid] !== undefined) {

      const batchdataid = parameterSelected.batch_data.slice(-1).pop().batchdataid;
      this.updateBatchesData[batchdataid].usercomment = value;
      this.dataEntryService.setUpdateBatchesData(this.updateBatchesData);

    }

  }

  emitEventToChild() {

    this.eventsSubject.next(this.details['batchDataId'])
  }

  ngOnChanges(changes: SimpleChanges) {
    // only run when property "data" changed

  }

  private _state: boolean;
  stateChanged: EventEmitter<boolean> = new EventEmitter();

  set state(val: boolean) {
    this._state = val;
    this.stateChanged.emit(this._state);
  }

  get state(): boolean {
    return this._state;
  }

  stateChangedEmitter() {
    return this.stateChanged;
  }


}
