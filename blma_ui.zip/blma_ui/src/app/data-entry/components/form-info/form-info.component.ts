import { DataService } from './../../../_core/services/data.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Store } from '@ngrx/store';
import { DataEntryState, dataEntryStateActions } from '../../../_core/store/data-entry.actions';
import { DataEntryService } from "../../../_core/services/data-entry.service"
import { Batch, Details, Params } from "../../../_core/interfaces/data-entry.interface"

import { paramsData } from "../../data.service"
import { BehaviorSubject, Observable } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { TypeaheadOptions, TabsetComponent } from 'ngx-bootstrap';



@Component({
  selector: 'form-info',
  templateUrl: './form-info.component.html',
  styleUrls: ['./form-info.component.scss']
})
export class FormInfoComponent implements OnInit {


  parent = "batchdata"
  childData = ''

  translateY$;
  paramSelect$;
  subParamIndex$;
  paramSelectAux: string = 'Data-log';
  paramSelect
  subParamIndex: number = 0;
  params: Batch
  batch$
  batch
  batchDataSelect$
  batchDataSelect: number;
  dataEntryState$;
  analysis: { data: number[], labels: string[] }


  parameters$;
  parameters;
  tableData$;
  tableData;

  selectedIndex$;
  selectedIndex;

  loading: boolean = false;
  configLoading = {
    backdropBackgroundColour: 'rgba(255,255,255,0.2)', backdropBorderRadius: '10px',
    primaryColour: '#f96332', secondaryColour: '#f27b25', tertiaryColour: '#f49123', fullScreenBackdrop: true
  };

  queryParams: { batchid: number, recipeid: number }
  constructor(
    private store: Store<DataEntryState>,
    private dataEntryService: DataEntryService,
    private router: Router,
    private route: ActivatedRoute,
    private data: DataService
  ) {
    this.dataEntryState$ = this.store.select('dataEntry')

    this.parameters$ = this.dataEntryState$
      .map(state => state.filterParam);


    this.translateY$ = this.dataEntryState$
      .map(state => state.topFormInfo)

    this.batch$ = this.dataEntryState$
      .map(state => state.batch)

    this.paramSelect$ = this.dataEntryState$
      .map(state => state.paramsSelect)

    this.batchDataSelect$ = this.dataEntryState$
      .map(state => state.batchData)

    this.selectedIndex$ = this.dataEntryState$
      .map(state => state.selectedParamIndex);

    this.tableData$ = this.dataEntryState$
      .map(state => state.tableData);

    this.queryParams = { batchid: null, recipeid: null };

    this.route.queryParams.subscribe((params) => {
      Object.assign(this.queryParams, { batchid: Number(params['batchid']), recipeid: Number(params['recipeid']) })
    })

    this.analysis = {
      data: [],
      labels: []
    }

  }

  ngOnInit() {
    this.parameters$.subscribe(parameter => this.parameters = parameter);
    this.tableData$.subscribe(tabledata => this.tableData = tabledata);


    this.paramSelect$.subscribe(param => this.paramSelect = param);
    this.batch$.subscribe(batch => {
    
      this.batch = batch
    });
    this.batchDataSelect$.subscribe(batchData => this.batchDataSelect = batchData);
    this.params = paramsData;

    this.selectedIndex$.subscribe(selectedIndex => this.selectedIndex = selectedIndex)
    this.getToggleComment();
     this.selectTab(2);
    this.staticTabs.tabs[1].active = true;
    // const parameterid = this.batch[this.paramSelect].parameters[this.batchDataSelect].parameter.parameterid;
    // console.log(parameterid)
   this.getAnalysis()
  }

  getAnalysis() {
    const parameters = this.batch[this.paramSelect].parameters[this.batchDataSelect]
  //  console.log(parameters)
    return {
      data: parameters.analysis.data,
      labels: parameters.analysis.labels
    }
  }

  getAudit = () => {
    const parameters = this.batch[this.paramSelect].parameters[this.batchDataSelect]
    return parameters.audit
  };

  getAnalysisView = () => {
    // if (this.batch[this.paramSelect].parameters[this.batchDataSelect].analysis.data.length > 0) return 
    // this.loading = true;
    const sectionname = this.batch[this.paramSelect].title;
    const parameterid = this.batch[this.paramSelect].parameters[this.batchDataSelect].parameter.parameterid;
    this.dataEntryService.getAnalysisView({ batchid: this.queryParams.batchid, sectionname: sectionname, recipeid: this.queryParams.recipeid, parameterid: parameterid }).subscribe(resp => {
      if (resp === false) {
        window.alert('error');
        this.loading = false;
        return
      }
      Object.assign(this.batch[this.paramSelect].parameters[this.batchDataSelect].analysis, { labels: resp.labels, data: resp.data })
      this.dataEntryService.setBatch(this.batch);
      this.loading = false;
    })
  }




  getDetails() {
    let parameters: any;

    if (this.selectedIndex.type == 'table') {
      // console.log(this.tableData)
      // console.log(this.tableData.rows[this.selectedIndex.firstIndex][this.selectedIndex.secondIndex])
      parameters = this.tableData.rows[this.selectedIndex.firstIndex][this.selectedIndex.secondIndex]
      console.log("parameters_data"+parameters)
      this.childData = parameters.batchdataid
      console.log(this.childData)

      return {

        description: '',
        // stepDescription: '',
        note: '',
        name: parameters.header_name ? parameters.header_name : '',
        specMin: parameters.specmin ? parameters.specmin : '',
        specMax: parameters.specmax ? parameters.specmax : '',
        batchDataId: parameters.batchdataid ? parameters.batchdataid : '',
        stepLabel: parameters.stepnolabel ? parameters.stepnolabel : '',
        specialInstruction: parameters.dataentryinstructions ? parameters.dataentryinstructions : '',
        // description:  parameters.parameter ? parameters.parameter.description : '',
        stepDescription: parameters.stepdescription ? parameters.stepdescription : '',
        // note: parameters.batch_data ? parameters.batch_data.slice(-1).pop().usercomment: ''
      }


    } else if (this.selectedIndex.type == 'normal') {

      // console.log(this.parameters[this.selectedIndex.firstIndex])
      parameters = this.parameters[this.selectedIndex.firstIndex];
      this.childData = parameters.batchdataid

      return {

        description: '',
        // stepDescription: '',
        note: '',
        name: parameters.parametername ? parameters.parametername : '',
        specMin: parameters.specmin ? parameters.specmin : '',
        specMax: parameters.specmax ? parameters.specmax : '',
        batchDataId: parameters.batchdataid ? parameters.batchdataid : 0,
        stepLabel: parameters.stepnolabel ? parameters.stepnolabel : '',
        specialInstruction: parameters.dataentryinstructions ? parameters.dataentryinstructions : '',
        // description:  parameters.parameter ? parameters.parameter.description : '',
        stepDescription: parameters.stepdescription ? parameters.stepdescription : '',
        // note: parameters.batch_data ? parameters.batch_data.slice(-1).pop().usercomment: ''
      }

    } else {
      return {

        description: '',
        // stepDescription: '',
        note: '',
        name: '',
        specMin: '',
        specMax: '',
        batchDataId: '',
        stepLabel: '',
        specialInstruction: '',
        // description:  parameters.parameter ? parameters.parameter.description : '',
        stepDescription: '',
        // note: parameters.batch_data ? parameters.batch_data.slice(-1).pop().usercomment: ''
      }

    }




  }



  getBatchdataId() {
    return this.childData;
  }


  test() {
    console.log(this.selectedIndex.type)
  }

  @ViewChild('staticTabs', { static: false }) staticTabs: TabsetComponent;

  selectTab(tabId: number) {
    console.log("forminfo")
  console.log(this.dataEntryService.selecttab);
    this.staticTabs.tabs[1].active = true;
  }

  getToggleComment = () => {
    this.data.comment.subscribe(data => {
},
      error => {
        // console.log(error)
      })
  }


}
