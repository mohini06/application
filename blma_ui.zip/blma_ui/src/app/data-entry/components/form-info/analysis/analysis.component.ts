import { ChartdataService } from './../../../../_core/services/chartdata.service';
import { Component, OnInit, ViewChild, ElementRef, Input, OnChanges, SimpleChanges } from '@angular/core';
import { DataEntryService } from './../../../../_core/services/data-entry.service';
import { DataService } from './../../../../_core/services/data.service';
import { Subject } from 'rxjs';
// import * as d3 from 'd3';

@Component({
  selector: 'form-info-analysis',
  templateUrl: './analysis.component.html',
  styleUrls: ['./analysis.component.scss']
})
export class AnalysisComponent implements OnInit {
  analysis: any;
  graph: any;
  graphdata: any;
  parameterid:any;
  // @Input() details: any
  // public eventsSubject: Subject<void> = new Subject<void>();
  // public eventsSubscription: any
  constructor(private data: DataService, private dataEntryService: DataEntryService,private Chartdata:ChartdataService) {

  }
chartvalues=[];
  ngOnInit() {
    // this.data.currentParam.subscribe(message => this.param = message)
    // console.log(this.param)
    this.getGraph()
    this.getSelectedParam()
    
  
  //  this.chartvalues=this.Chartdata.getspecificchart(this.graph['pid_'+this.parameterid]); 
   
  
  }

  // emitEventToChild() {

  //   this.eventsSubject.next(this.details['batchDataId'])
  // }
  // ngOnChanges(changes: SimpleChanges) {
  //   // only run when property "data" changed

  // }
  getAnalysisView = (param) => {

  console.log(param)
    if (!param.message) {
      return;
    }else
    {
        
            this.chartvalues=this.Chartdata.getspecificchart(this.graph['pid_'+this.parameterid]); 
            if(this.chartvalues==null || this.chartvalues.length==0)
            {
this.chartvalues=[];
            }

  
    }
    

  }


  getSelectedParam = (pageno = 0) => {

    this.data.currentParam.subscribe(data => {

       
this.parameterid=data.parameterid;

       this.getAnalysisView(data)
      
    },
      error => {

        // console.log(error)
      })

  }

  // public layoutdata = {

  //   layout: { width: 450, height: 400, title: '', displaylogo: false }
  // };


 
   getGraph = () => {

    this.data.graphData.subscribe(data => {
      this.graph=data;
      
   
    },
      error => {

        
      })
      

  }








  
  
  
  
  
  // }
  // if(this.charttype=='histogram')
  // {

  
  



}
