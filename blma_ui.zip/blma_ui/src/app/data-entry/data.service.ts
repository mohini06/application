export const data = {
  'Data-log': [{
      title: 'ETOH %',
      input: 'number',
      combox: [],
      messageIcon: 'fa fa-commenting',
      lockIcon: 'fa fa-unlock',
      active: true,
      name: 't1',
      details: {
          name: 'ETOH %',
          specMin: 1,
          specMax: 10,
          batchDataId: 57820,
          stepLabel: 0,
          description: 'description .....',
          stepDescription: ' step description .....',
          specialInstruction: 'This is dataentryinstructions for parameter',
          note:'lkjhgfcx',
          tags:['tag 1', 'tag 2', 'tag 3'],
          tagList: ['tag 3']
      },
      analysis: {
          labels: ['label 1', 'label 2', 'label 3', 'label 4', 'label 5'],
          data: [3, 5, 8, 2, 10]
      },
      audit:{}
    },
    {
      title: 'Comments',
      input: 'text',
      combox: [],
      messageIcon: 'fa fa-commenting',
      lockIcon: 'fa fa-unlock',
      active: false,
      name: 't2',
      details: {
          name: 'Comments',
          specMin: 1,
          specMax: 10,
          batchDataId: 57820,
          stepLabel: 0,
          description: 'description .....',
          stepDescription: ' step description .....',
          specialInstruction: 'This is dataentryinstructions for parameter',
          note:'',
          tags:['tag 1', 'tag 2', 'tag 3'],
          tagList: ['tag 3']
      },
      analysis: {
          labels: ['label 1', 'label 2', 'label 3', 'label 4', 'label 5'],
          data: [3, 5, 8, 2, 10]
      },
      audit:{
          
      }
    },
    {
      title: 'Agitation (RPM)',
      input: 'number',
      combox: ['option 1', 'option 2'],
      messageIcon: 'fa fa-commenting',
      lockIcon: 'fa fa-unlock',
      active: false,
      name: 't3',
      details: {
          name: 'Agitation (RPM)',
          specMin: 1,
          specMax: 10,
          batchDataId: 57820,
          stepLabel: 0,
          description: 'description .....',
          stepDescription: ' step description .....',
          specialInstruction: 'This is dataentryinstructions for parameter',
          note:'',
          tags:['tag 1', 'tag 2', 'tag 3'],
          tagList: ['tag 3']
      },
      analysis: {
          labels: ['label 1', 'label 2', 'label 3', 'label 4', 'label 5'],
          data: [3, 5, 8, 2, 10]
      },
      audit:{
          
      }
    },
    {
      title: 'Temperature',
      input: 'number',
      combox: ['option 1', 'option 2'],
      messageIcon: 'fa fa-commenting',
      lockIcon: 'fa fa-unlock',
      active: false,
      name: 't4',
      details: {
          name: 'Temperature',
          specMin: 1,
          specMax: 10,
          batchDataId: 57820,
          stepLabel: 0,
          description: 'description .....',
          stepDescription: ' step description .....',
          specialInstruction: 'This is dataentryinstructions for parameter',
          note:'',
          tags:['tag 1', 'tag 2', 'tag 3'],
          tagList: ['tag 3']
      },
      analysis: {
          labels: ['label 1', 'label 2', 'label 3', 'label 4', 'label 5'],
          data: [3, 5, 8, 2, 10]
      },
      audit:{
          
      }
    },
    {
      title: 'Date/Time',
      input: 'date',
      combox: [],
      messageIcon: 'fa fa-commenting',
      lockIcon: 'fa fa-unlock',
      active: false,
      name: 't5',
      details: {
          name: 'Date/Time',
          specMin: 1,
          specMax: 10,
          batchDataId: 57820,
          stepLabel: 0,
          description: 'description .....',
          stepDescription: ' step description .....',
          specialInstruction: 'This is dataentryinstructions for parameter',
          note:'',
          tags:['tag 1', 'tag 2', 'tag 3'],
          tagList: ['tag 3']
      },
      analysis: {
          labels: ['label 1', 'label 2', 'label 3', 'label 4', 'label 5'],
          data: [3, 5, 8, 2, 10]
      },
      audit:{
          
      }
    },
    {
      title: 'PCV %',
      input: 'number',
      combox: [],
      messageIcon: 'fa fa-commenting',
      lockIcon: 'fa fa-unlock',
      active: false,
      name: 't6',
      details: {
          name: 'PCV %',
          specMin: 1,
          specMax: 10,
          batchDataId: 57820,
          stepLabel: 0,
          description: 'description .....',
          stepDescription: ' step description .....',
          specialInstruction: 'This is dataentryinstructions for parameter',
          note:'',
          tags:['tag 1', 'tag 2', 'tag 3'],
          tagList: ['tag 3']
      },
      analysis: {
          labels: ['label 1', 'label 2', 'label 3', 'label 4', 'label 5'],
          data: [3, 5, 8, 2, 10]
      },
      audit:{
          
      }
    },
    {
      title: 'Glucose %',
      input: 'number',
      combox: ['option 1', 'option 2'],
      messageIcon: 'fa fa-commenting',
      lockIcon: 'fa fa-unlock',
      active: false,
      name: 't7',
      details: {
          name: 'Glucose %',
          specMin: 1,
          specMax: 10,
          batchDataId: 57820,
          stepLabel: 0,
          description: 'description .....',
          stepDescription: ' step description .....',
          specialInstruction: 'This is dataentryinstructions for parameter',
          note:'',
          tags:['tag 1', 'tag 2', 'tag 3'],
          tagList: ['tag 3']
      },
      analysis: {
          labels: ['label 1', 'label 2', 'label 3', 'label 4', 'label 5'],
          data: [3, 5, 8, 2, 10]
      },
      audit:{
          
      }
    },
    {
      title: 'Pressure (PSIG)',
      input: 'number',
      combox: ['option 1', 'option 2'],
      messageIcon: 'fa fa-commenting',
      lockIcon: 'fa fa-unlock',
      active: false,
      name: 't8',
      details: {
          name: 'Pressure (PSIG)',
          specMin: 1,
          specMax: 10,
          batchDataId: 57820,
          stepLabel: 0,
          description: 'description .....',
          stepDescription: ' step description .....',
          specialInstruction: 'This is dataentryinstructions for parameter',
          note:'',
          tags:['tag 1', 'tag 2', 'tag 3'],
          tagList: ['tag 3']
      },
      analysis: {
          labels: ['label 1', 'label 2', 'label 3', 'label 4', 'label 5'],
          data: [3, 5, 8, 2, 10]
      },
      audit:{
          
      }
    },
    {
      title: 'Run Time',
      input: 'number',
      combox: ['option 1', 'option 2'],
      messageIcon: 'fa fa-commenting',
      lockIcon: 'fa fa-unlock',
      active: false,
      name: 't9',
      details: {
          name: 'Run Time',
          specMin: 1,
          specMax: 10,
          batchDataId: 57820,
          stepLabel: 0,
          description: 'description .....',
          stepDescription: ' step description .....',
          specialInstruction: 'This is dataentryinstructions for parameter',
          note:'',
          tags:['tag 1', 'tag 2', 'tag 3'],
          tagList: ['tag 3']
      },
      analysis: {
          labels: ['label 1', 'label 2', 'label 3', 'label 4', 'label 5'],
          data: [3, 5, 8, 2, 10]
      },
      audit:{
          
      }
    },
    {
      title: 'Air Flow (SLPM)',
      input: 'number',
      combox: ['option 1', 'option 2'],
      messageIcon: 'fa fa-commenting',
      lockIcon: 'fa fa-unlock',
      active: false,
      name: 't10',
      details: {
          name: 'Air Flow (SLPM)',
          specMin: 1,
          specMax: 10,
          batchDataId: 57820,
          stepLabel: 0,
          description: 'description .....',
          stepDescription: ' step description .....',
          specialInstruction: 'This is dataentryinstructions for parameter',
          note:'',
          tags:['tag 1', 'tag 2', 'tag 3'],
          tagList: ['tag 3']
      },
      analysis: {
          labels: ['label 1', 'label 2', 'label 3', 'label 4', 'label 5'],
          data: [3, 5, 8, 2, 10]
      },
      audit:{
          
      }
    },
    {
      title: 'Phase',
      input: 'number',
      combox: [],
      messageIcon: 'fa fa-commenting',
      lockIcon: 'fa fa-unlock',
      active: false,
      name: 't11',
      details: {
          name: 'Phase',
          specMin: 1,
          specMax: 10,
          batchDataId: 57820,
          stepLabel: 0,
          description: 'description .....',
          stepDescription: ' step description .....',
          specialInstruction: 'This is dataentryinstructions for parameter',
          note:'',
          tags:['tag 1', 'tag 2', 'tag 3'],
          tagList: ['tag 3']
      },
      analysis: {
          labels: ['label 1', 'label 2', 'label 3', 'label 4', 'label 5'],
          data: [3, 5, 8, 2, 10]
      },
      audit:{
          
      }
    },
    {
      title: 'Sample No',
      input: 'number',
      combox: [],
      messageIcon: 'fa fa-commenting',
      lockIcon: 'fa fa-unlock',
      active: false,
      name: 't12',
      details: {
          name: 'Sample No',
          specMin: 1,
          specMax: 10,
          batchDataId: 57820,
          stepLabel: 0,
          description: 'description .....',
          stepDescription: ' step description .....',
          specialInstruction: 'This is dataentryinstructions for parameter',
          note:'',
          tags:['tag 1', 'tag 2', 'tag 3'],
          tagList: ['tag 3']
      },
      analysis: {
          labels: ['label 1', 'label 2', 'label 3', 'label 4', 'label 5'],
          data: [3, 5, 8, 2, 10]
      },
      audit:{
          
      }
    }
  ],
  'General': [{
      title: 'Mnfg Start Date',
      input: 'date',
      combox: [],
      messageIcon: 'fa fa-commenting',
      lockIcon: 'fa fa-unlock',
      active: true,
      name: 't1',
      details: {
          name: 'Mnfg Start Date',
          specMin: 1,
          specMax: 10,
          batchDataId: 57820,
          stepLabel: 0,
          description: 'description .....',
          stepDescription: ' step description .....',
          specialInstruction: 'This is dataentryinstructions for parameter',
          note:'',
          tags:['tag 1', 'tag 2', 'tag 3'],
          tagList: ['tag 3']
      },
      analysis: {
          labels: ['label 1', 'label 2', 'label 3', 'label 4', 'label 5'],
          data: [3, 5, 8, 2, 10]
      },
      audit:{
          
      }
    },
    {
      title: 'Final Yield',
      input: 'number',
      combox: ['option 1', 'option 2'],
      messageIcon: 'fa fa-commenting',
      lockIcon: 'fa fa-unlock',
      active: false,
      name: 't2',
      details: {
          name: 'Final Yield',
          specMin: 1,
          specMax: 10,
          batchDataId: 57820,
          stepLabel: 0,
          description: 'description .....',
          stepDescription: ' step description .....',
          specialInstruction: 'This is dataentryinstructions for parameter',
          note:'',
          tags:['tag 1', 'tag 2', 'tag 3'],
          tagList: ['tag 3']
      },
      analysis: {
          labels: ['label 1', 'label 2', 'label 3', 'label 4', 'label 5'],
          data: [3, 5, 8, 2, 10]
      },
      audit:{
        
      }
    },
    {
      title: 'BPD Version No',
      input: 'number',
      combox: [],
      messageIcon: 'fa fa-commenting',
      lockIcon: 'fa fa-unlock',
      active: false,
      name: 't3',
      details: {
          name: 'BPD Version No',
          specMin: 1,
          specMax: 10,
          batchDataId: 57820,
          description: 'description .....',
          stepDescription: ' step description .....',
          stepLabel: 0,
          specialInstruction: 'This is dataentryinstructions for parameter',
          note:'',
          tags:['tag 1', 'tag 2', 'tag 3'],
          tagList: ['tag 3']
      },
      analysis: {
          labels: ['label 1', 'label 2', 'label 3', 'label 4', 'label 5'],
          data: [3, 5, 8, 2, 10]
      },
      audit:{
          
      }
    },
    {
      title: 'Comments',
      input: 'number',
      combox: [],
      messageIcon: 'fa fa-commenting',
      lockIcon: 'fa fa-unlock',
      active: false,
      name: 't4',
      details: {
          name: 'Comments',
          specMin: 1,
          specMax: 10,
          batchDataId: 57820,
          description: 'description .....',
          stepDescription: ' step description .....',
          stepLabel: 0,
          specialInstruction: 'This is dataentryinstructions for parameter',
          note:'',
          tags:['tag 1', 'tag 2', 'tag 3'],
          tagList: ['tag 3']
      },
      analysis: {
          labels: ['label 1', 'label 2', 'label 3', 'label 4', 'label 5'],
          data: [3, 5, 8, 2, 10]
      },
      audit:{
          
      }
    },
    {
      title: 'DR No',
      input: 'number',
      combox: [],
      messageIcon: 'fa fa-commenting',
      lockIcon: 'fa fa-unlock',
      active: false,
      name: 't5',
      details: {
          name: 'DR No',
          specMin: 1,
          specMax: 10,
          batchDataId: 57820,
          stepLabel: 0,
          description: 'description .....',
          stepDescription: ' step description .....',
          specialInstruction: 'This is dataentryinstructions for parameter',
          note:'',
          tags:['tag 1', 'tag 2', 'tag 3'],
          tagList: ['tag 3']
      },
      analysis: {
          labels: ['label 1', 'label 2', 'label 3', 'label 4', 'label 5'],
          data: [3, 5, 8, 2, 10]
      },
      audit:{
          
      }
    },
  ],
  'Process': [
      {
      title: 'DR No',
      input: 'number',
      combox: [],
      messageIcon: 'fa fa-commenting',
      lockIcon: 'fa fa-unlock',
      active: true,
      name: 't5',
      details: {
          name: 'DR No',
          specMin: 1,
          specMax: 10,
          batchDataId: 57820,
          stepLabel: 0,
          description: 'description .....',
          stepDescription: ' step description .....',
          specialInstruction: 'This is dataentryinstructions for parameter',
          note:'',
          tags:['tag 1', 'tag 2', 'tag 3'],
          tagList: ['tag 3']
      },
      analysis: {
          labels: ['label 1', 'label 2', 'label 3', 'label 4', 'label 5'],
          data: [3, 5, 8, 2, 10]
      },
      audit:{
          
      }
    }
  ]
}
export const paramsData = data;