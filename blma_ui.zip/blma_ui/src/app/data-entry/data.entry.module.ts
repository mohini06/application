import { TooltipModule } from '@syncfusion/ej2-angular-popups';
import { DataService } from './../_core/services/data.service';
import { NgSelectModule } from '@ng-select/ng-select';

import * as PlotlyJS from 'plotly.js/dist/plotly.js';
import { PlotlyModule } from 'angular-plotly.js';
//Modules
import { NgModule  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { BsDropdownModule, TabsModule, ModalModule, ProgressbarModule, BsDatepickerModule,ButtonsModule, TimepickerModule } from 'ngx-bootstrap';
import { DatetimePopupModule } from 'ngx-bootstrap-datetime-popup';
import { FormsModule } from '@angular/forms';
import { ScrollToModule } from 'ng2-scroll-to-el';
import { NgxPaginationModule } from 'ngx-pagination';

//Components
import { DataEntryComponent } from './data-entry.component'
import { HeaderComponent } from './components/header/header.component';
import { ModalInfoComponent } from './components/modal-info/modal-info.component';
import { FormInfoComponent } from './components/form-info/form-info.component';
import { FormComponent } from './components/form/form.component';
// import { CommentsComponent } from './components/comments/comments.component';
import { FlagsComponent } from './components/flags/flags.component';
import { SearchBarComponent } from './components/search-bar/search-bar.component';
import { DetailsComponent } from './components/form-info/details/details.component';
import { AnalysisComponent } from './components/form-info/analysis/analysis.component';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { ModalRoleComponent } from './components/modal-role/modal-role.component'

//Routes
import { routes } from '../app.routes';

//Services
import { BsModalService } from 'ngx-bootstrap/modal';
import { ComponentLoaderFactory, PositioningService } from "ngx-bootstrap"
import { DataEntryService } from "../_core/services/data-entry.service";
import {AutosizeModule} from 'ngx-autosize';
import {MatProgressBarModule} from '@angular/material/progress-bar';
PlotlyModule.plotlyjs = PlotlyJS;


import { SharedModule } from '../_shared/share.module';



import { CheckBoxModule } from "@syncfusion/ej2-angular-buttons";

import { DropDownListAllModule } from '@syncfusion/ej2-angular-dropdowns';

 

 import { GridAllModule } from '@syncfusion/ej2-angular-grids';


 import {MatTooltipModule} from '@angular/material/tooltip';
 import { SparklineAllModule,ChartModule,LineSeriesService,CategoryService,DataLabelService,TooltipService} from '@syncfusion/ej2-angular-charts';
import { RolePermissionsDirective } from './role-permissions.directive';



@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild([]),
    ModalModule.forRoot(),
    FormsModule,
    // bootstrap
    BsDropdownModule.forRoot(),
    BsDatepickerModule.forRoot(),
    TabsModule.forRoot(),
    DatetimePopupModule.forRoot(),
    ProgressbarModule.forRoot(),
    ScrollToModule.forRoot(),
    ButtonsModule.forRoot(),
    LoadingModule,
    NgxPaginationModule,
    NgSelectModule, 
    AutosizeModule,  
    PlotlyModule,
    GridAllModule,
    SharedModule,
    TooltipModule,
    SparklineAllModule,
    MatTooltipModule,
    DropDownListAllModule,
    CheckBoxModule,
    MatProgressBarModule,
    ChartModule
  ],
  exports: [
    CommonModule,
    RouterModule,
  ],
  declarations: [
    DataEntryComponent,
    HeaderComponent,
    ModalInfoComponent,
    SearchBarComponent,
    FormInfoComponent,
    FormComponent,
    DetailsComponent,
    AnalysisComponent,
   
    // CommentsComponent,
    FlagsComponent,
    ModalRoleComponent,
    RolePermissionsDirective,
 
  
  ],
 providers: [ BsModalService, ComponentLoaderFactory, PositioningService, DataEntryService,DataService,LineSeriesService,CategoryService,DataLabelService,TooltipService
  ],
  entryComponents: [ModalInfoComponent, ModalRoleComponent]
})
export class DataEntryModule {}