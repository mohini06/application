import { DataEntryService } from './../_core/services/data-entry.service';

import { GetGenericService } from './../_core/services/get-generic.service';
import { DataService } from './../_core/services/data.service';
import { Component, OnInit, Inject, HostListener, Directive, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Store } from '@ngrx/store';
import { DataEntryState, dataEntryStateActions } from '../_core/store/data-entry.actions';

import { Observable } from 'rxjs/Observable';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ModalInfoComponent } from './components/modal-info/modal-info.component'


import { ItemSideBar } from '../_core/interfaces/data-entry.interface'
import { Router, ActivatedRoute } from '@angular/router';

import { dataEntryAnimation } from '../_core/animations/page.animations'
import { trigger, state, style, animate, transition, query } from '@angular/animations';
import * as cloneDeep from 'lodash/cloneDeep';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';



@Component({
  selector: 'data-entry',
  templateUrl: './data-entry.component.html',
  styleUrls: ['./data-entry.component.scss'],
  animations: [dataEntryAnimation]
})
export class DataEntryComponent implements OnInit {

  // @HostListener('click', ['$event'])
  // onClick(event: Event){ console.log('inside click host listener'); event.stopImmediatePropagation(); }

graph:any

  bsModalRef: BsModalRef;
  items: ItemSideBar[];
  titleForm: string;
  dataEntryState$;
  batch$;
  parameters: any[];
  paramData: any[];
  parameters$;
  allParam;
  allParam$;
  table;
  newTable = [];
  newTableSelected = [];
  batch;
  batchDataActive: number;
  batchDataActive$
  paramsSelect$;
  paramsSelect: number;
  titleBatch;
  title$;
  itemCode$;
  itemCode;
  BatchDescription;
  description$;
  hide = true;
  filters$;
  filters;
  batchFiltered;
  translateY$;
  transY;
  batchNumber: string;
  batchId;
  recipeId;
  parameterLoaded: { sectionname: string, loaded: boolean }[];

  loading: boolean = false;
  step = -1;
  childStep = -1;

  perComp: any = 100
  perRem: any = 0
  totalPercentage: any = 0
  percentagMsg=""
  

  configLoading = {
    backdropBackgroundColour: 'rgba(255,255,255,0.2)', backdropBorderRadius: '10px',
    primaryColour: '#f96332', secondaryColour: '#f27b25', tertiaryColour: '#f49123', fullScreenBackdrop: true
  };

  size: any = 0;
  parameter: any;

  tableData: Array<any>;

  firstLevel = "";
  secondLevel: "";
  allParamChild: any;
  _changeDetectorRef: any;

  tagComment: any = []
  showComment: boolean = false
  showTags: boolean = false

  constructor(
    private store: Store<DataEntryState>,
    private router: Router,
    private route: ActivatedRoute,
    // private modalService: BsModalService,
    private dataEntryService: DataEntryService,
    private data: DataService,
    private getGeneric: GetGenericService
  ) {

    // event.stopPropagation();
    // Get Batches

    const queryParams: { batchid: number, recipeid: number } = { batchid: null, recipeid: null };
    this.route.queryParams.subscribe((params) => {
      Object.assign(queryParams, { batchid: Number(params['batchid']) });
      Object.assign(queryParams, { recipeid: Number(params['recipeid']) });
      this.batchNumber = params['batch'];
      this.batchId = queryParams.batchid;
      this.recipeId = queryParams.recipeid;
      this.getBatch(queryParams);
    })

    this.dataEntryState$ = this.store.select('dataEntry')

    this.translateY$ = this.dataEntryState$
      .map(state => state.topFormInfo)

    this.batch$ = this.dataEntryState$
      .map(state => state.batch);
    this.parameterLoaded = [];

    this.title$ = this.dataEntryState$
      .map(state => state.recipeName);

    this.itemCode$ = this.dataEntryState$
      .map(state => state.itemCode);

    this.description$ = this.dataEntryState$
      .map(state => state.recipeDescription);

    this.filters$ = this.dataEntryState$
      .map(state => state.filters);

    this.parameters$ = this.dataEntryState$
      .map(state => state.parameters);

    this.allParam$ = this.dataEntryState$
      .map(state => state.AllParam);

    this.getCommentTagCount()
  }


  clickNavLink(label: any, recipesectionid: any, index: any, is_table: any, rid: any, e: Event) {


    this.data.fnRecipeSectionId(recipesectionid)
    // console.log(e)
    this.newParam('');
    // console.log(is_table, rid)
    this.firstLevel = label;
    this.secondLevel = ""
    this.getGeneric.getAnalysisAll(recipesectionid, this.recipeId).subscribe(plotdata => {
console.log(this.graph)
      this.graph=plotdata;
      //  this.dataEntryService.setGraph(this.graph);
      console.log(plotdata)
       this.data.fnSetGraph(plotdata)
       
    })
    console.log(this.graph)
    this.dataEntryService.setSelectedParamIndex('')
    this.dataEntryService.setSelectedCommIndex('')

    this.step = index;
    this.childStep = -1;
    if (is_table == true) {
      this.paramData = [];
      this.dataEntryService.setFilterParams(this.paramData);
      this.table = this.allParam.batchdata_tables[rid];
      this.dataEntryService.setTableData(this.table)

      this.newTableSelected = this.allParam.batchdata_tables[rid];
      // console.log(this.newTableSelected)

      this.newTable.push(this.newTableSelected);

      // console.log(this.newTable)
      // console.log(this.newTable.reduce(((r, c) => Object.assign(r, c)), {}));


      this.dataEntryService.setNewTableData(this.newTable);
      // console.log(this.table)
      // console.log(this.allParam.batchdata_tables[rid])

      e.stopPropagation()
      e.preventDefault()
      e.stopImmediatePropagation()
      e.cancelBubble


    }
    else {
      this.table = [];
      this.dataEntryService.setTableData(this.table)
      this.paramData = this.parameters.filter(param => param.recipesectionid === recipesectionid);
      this.dataEntryService.setFilterParams(this.paramData);
      // console.log(this.paramData)
      e.stopPropagation()
      e.preventDefault()
      e.stopImmediatePropagation()
      e.cancelBubble

    }
    this.loading = false;

    // this.loadRecipeSection(item.title)
    // if (item.parameters.length > 0) {
    //   if (Object.keys(item.parameters[0]).length > 1)
    //     this.toggleNavLink(item.title)
    //   else if (Object.keys(item.parameters[0]).length === 1 && !this.parameterLoaded.find(p => p.sectionname === item.title).loaded)
    //     this.loadRecipeSection(item.title)
    // } else {
    //   this.loadRecipeSection(item.title)
    // }
    // e.stopPropagation()
    // e.preventDefault()
    // e.stopImmediatePropagation()
    // e.cancelBubble
  }


 
  clickNavLinkChild(parent: any, child: any, recipesectionid: any, step: any, is_table: any, rid: any, e: Event) {
        this.data.fnRecipeSectionId(recipesectionid)
   
    this.newParam('');
    this.firstLevel = parent 
    this.secondLevel = child;
    this.getGeneric.getAnalysisAll(recipesectionid, this.recipeId).subscribe(plotdata => {

      this.graph=plotdata;
      //  this.dataEntryService.setGraph(this.graph);
      // console.log(plotdata)
       this.data.fnSetGraph(plotdata)
      })

      //  function selectchildtab(callback){ 
       
      //   callback(); 
      //   // callback
      // }
      
      // function selecttab(){
      
        this.childStep = step;
        this.step = -1;
        if (is_table == true) {
  
          this.paramData = [];
          this.dataEntryService.setFilterParams(this.paramData);
        
          this.table = this.allParam.batchdata_tables[rid];
          this.dataEntryService.setTableData(this.table);
    
          this.newTableSelected = this.allParam.batchdata_tables[rid];
    
          this.newTable.push(this.newTableSelected);
    
          this.dataEntryService.setNewTableData(this.newTable);
          console.log(this.graph)
          console.log(this.paramData)
          
         
        }
        else {
          this.table = [];
    
           this.paramData = this.parameters.filter(param => param.recipesectionid === recipesectionid);
         this.dataEntryService.setTableData(this.table)
          this.dataEntryService.setFilterParams(this.paramData);
          
        }
       
      // }
      
      // selectchildtab(selecttab);


      // this.childStep = step;
      // this.step = -1;
    //   selectchildtable(selecttable);


    //  function selectchildtable(callback){ 
    //     callback(); 
    //     // callback
    //   }


    //   function selecttable(){
      
    //   }

  }


//   clickNavLinkChild(parent: any, child: any, recipesectionid: any, step: any, is_table: any, rid: any, e: Event) {
//     this.data.fnRecipeSectionId(recipesectionid)

// this.newParam('');
// this.firstLevel = parent 
// this.secondLevel = child;
// this.getGeneric.getAnalysisAll(recipesectionid, this.recipeId).subscribe(plotdata => {

//   this.graph=plotdata;
//   //  this.dataEntryService.setGraph(this.graph);
//   // console.log(plotdata)
//    this.data.fnSetGraph(plotdata)
//   })

//   // this.dataEntryService.setSelectedParamIndex('')
//   // this.dataEntryService.setSelectedCommIndex('')
//   // function selectchildtab(callback){ 
//   //       callback(); 
//   //          }

//   //          function selecttab(){
//   //          }

//   //          selectchildtab(selecttab);
      
//     this.childStep = step;
//     this.step = -1;
//     if (is_table == true) {

//       this.paramData = [];
//       this.dataEntryService.setFilterParams(this.paramData);
    
//       this.table = this.allParam.batchdata_tables[rid];
//       this.dataEntryService.setTableData(this.table);

//       this.newTableSelected = this.allParam.batchdata_tables[rid];

//      this.newTable.push(this.newTableSelected);

//        this.dataEntryService.setNewTableData(this.newTable);
      
      
     
//     }
//     else {

//       this.table = [];

//        this.paramData = this.parameters.filter(param => param.recipesectionid === recipesectionid);

//            this.dataEntryService.setTableData(this.table)
//           this.dataEntryService.setFilterParams(this.paramData);
      
//     }
//    return false;
// }




  checkRecipeSection = (item: any) => {
    if (this.parameterLoaded.length === 0) return false
    const parameter = this.parameterLoaded.find(d => d.sectionname === item.title)
    return (item.parameters.length === 0)
  }

  getBatch = (queryParams: { batchid: number, recipeid: number }) => this.dataEntryService.getBatch(queryParams)
    .subscribe((resp: any) => {
      //  console.log(resp)
      if (resp.batchdata_sections == null) {
        alert("No Data found for selected batch - " + this.batchId);
        this.router.navigate(['/batches']);
        return;
      }
      // this.openModalWithComponent();


      this.allParamChild = cloneDeep(resp);
      this.dataEntryService.setCurrentStatus(resp.batchdata_header[0].currentstatus);
      this.dataEntryService.setCurrentStatusDrop(resp.batchdata_batchstatus)
      // this.dataEntryService.setItemCode(resp.itemcode);
      this.dataEntryService.setRecipeName(resp.batchdata_header[0].recipename); //as title in title$
      // this.dataEntryService.setRecipeDescription(resp.batchcomment);
      this.dataEntryService.setBatch(resp.batchdata_sections);
      this.dataEntryService.setParameterDetails(resp.batchdata_parameter);
      this.dataEntryService.setAllParams(resp);
      this.dataEntryService.setAllComment(resp.batchdata_doccomments);


      // for (let i = 0; i < resp.batch.length; i++) {
      //   if (resp.batch[i].parameters[0] == null) {
      //     //  console.log("No data")
      //     this.parameterLoaded.push({ sectionname: resp.batch[i].title, loaded: false })
      //   }
      //   else {
      //     // console.log("with data")

      //     this.parameterLoaded.push({ sectionname: resp.batch[i].title, loaded: true })
      //   }
      // }
      // resp.batch.map(d => Object.keys(d.parameters[0]).length > 1 ? this.parameterLoaded.push({ sectionname: d.title, loaded: true }) : this.parameterLoaded.push({ sectionname: d.title, loaded: false }))
      // console.log(this.parameterLoaded)

      this.loading = false;


    })

  // openModalWithComponent() {
  //   this.loading = true;
  //   const list = [
  //     'Batch: ' + this.batchNumber,
  //     'Description: ' + (this.BatchDescription === null ? 'No descrption' : this.BatchDescription)
  //   ];
  //   this.bsModalRef = this.modalService.show(ModalInfoComponent);
  //   this.bsModalRef.content.title = this.titleBatch;
  //   this.bsModalRef.content.list = list;

  // }

  ngOnInit() {

    this.hide = true;
    this.dataEntryService.setFilterParams("");
    this.dataEntryService.setTableData("");
    this.batch$.subscribe(batch => this.batch = batch);
    this.parameters$.subscribe(parameters => this.parameters = parameters);
    this.allParam$.subscribe(alldata => this.allParam = alldata);
    this.title$.subscribe(title => this.titleBatch = title);
    this.itemCode$.subscribe(itemCode => this.itemCode = itemCode);
    this.description$.subscribe(description => this.BatchDescription = description);
    this.filters$.subscribe(filters => {
      (this.batch[0].title !== '' && filters.length > 0) ?
        this.batchFiltered = this.dataEntryService.setFilterBatch(filters, this.batch) :
        this.batchFiltered = this.batch.map(d => Object.assign({}, d));


    });
    this.translateY$.subscribe(y => {
      this.hide ? this.transY = 'translateY(' + 0 + 'px)' : this.transY = 'translateY(' + (y + 15).toString() + 'px)';
    });

    // this.toggleNavLink(this.batch[0].title)

    this.getToggleComment();
    this.hide = true;

    this.commentFlag()

    setTimeout(() => {
      this.percentaCalc()
    }, 500);


    this.getPercentCalc()
  }

  Chartdata:boolean=false;
  showchart()
  {
this. Chartdata=true;
  }


  toggleNavLink = (name: string) => {
    this.batch.forEach((d: any) => d.title === name ? d.active = true : d.active = false);

    const paramsSelect = this.batch.findIndex((d: any) => d.title === name)
    // console.log(this.batch[paramsSelect].parameters)
    // this.batch[paramsSelect].parameters.forEach((d, i) => i === 0 ? d.active = true : d.active = false)
    this.dataEntryService.setParamsSelect(name, this.batch)

    if (this.batch[paramsSelect].parameters.length > 0) this.dataEntryService.setBatchData(this.batch[paramsSelect].parameters[0].parameter.uniquename, this.batch[paramsSelect].parameters)
    this.dataEntryService.setTopFormInfo(0)
    this.dataEntryService.setBatch(this.batch)
  }

  getRouteAnimation(outlet) {
    return outlet.activatedRouteData.animation
  }

  hideTrigger = () => this.hide = !this.hide;


  newParam(param: any) {
    this.data.changeParam(param)
  }



  commentFlag() {

    this.data.commentFlag.subscribe(data => {
      this.getCommentTagCount()
    },
      error => {

        // console.log(error)
      })
  }

  ///Communicating two component
  getToggleComment = () => {


    this.data.comment.subscribe(data => {

      this.hide = data
    },
      error => {

        // console.log(error)
      })

  }


  serachTag(recipesectionid?) {
    // console.log(this.tagComment.batchdata_tagcomment.length)
    if (this.tagComment && this.tagComment.batchdata_tagcomment) {
      return this.tagComment.batchdata_tagcomment.some(data => (data.recipesectionid == recipesectionid && data.hastags) || (data.parentrecipesectionid == recipesectionid && data.hastags))
    }

  }



  serachComment(recipesectionid?) {
    // console.log(this.tagComment.batchdata_tagcomment.length)
    if (this.tagComment && this.tagComment.batchdata_tagcomment) {
      return this.tagComment.batchdata_tagcomment.some(data => (data.recipesectionid == recipesectionid && data.hascomment) || (data.parentrecipesectionid == recipesectionid && data.hascomment))
      // return this.tagComment.batchdata_tagcomment.some(data => (data.recipesectionid==recipesectionid && data.hascomment) || (data.parentsectionid==parentsectionid))
    }
  }




  getCommentTagCount() {
    this.getGeneric.getTagCommentCount(this.batchId).
      subscribe(data => {

        this.tagComment = data
        // console.log(this.tagComment)
      },
        error => {
          console.log(error)
        })
  }

  percentaCalc() {
    // console.log(this.tagComment.batchdata_tagcomment.filter(data => data.recipesectionid==recipesectionid
    //    && data.hascomment==true));

    //  console.log(this.tagComment.batchdata_tagcomment.some(data => data.recipesectionid==recipesectionid)); // true
    // console.log(this.batchFiltered)
    // console.log(this.allParam.batchdata_parameter)
    if (this.allParam.batchdata_parameter) {
      this.perRem = this.allParam.batchdata_parameter.filter(data => data.parametervalue == '' || data.parametervalue == null).length
      this.perComp = this.allParam.batchdata_parameter.filter(data => data.parametervalue).length

      // console.log(notFillcount)
      // console.log(fillcount)
      let total = this.perRem + this.perComp
      let perc = ((this.perComp / total) * 100).toFixed(0)
      console.log(perc)
      this.totalPercentage = perc

      this.percentagMsg=this.perRem + " of " + (this.perComp + this.perRem)
    }
  }

  test2(recipesectionid) {
    // console.log(this.tagComment.batchdata_tagcomment.filter(data => data.recipesectionid==recipesectionid
    //    && data.hascomment==true));

    //  console.log(this.tagComment.batchdata_tagcomment.some(data => data.recipesectionid==recipesectionid)); // true


  }


  navMenuState: string;



  linkToggler($event) {
    this.hideTrigger();
  }



getPercentCalc()
{
this.data.percentCalc.subscribe(data => {
 this.percentaCalc()
},
  error => {

    // console.log(error)
  })
}

}
