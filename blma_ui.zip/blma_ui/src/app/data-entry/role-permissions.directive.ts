
import { Directive, ElementRef, HostListener, Input } from '@angular/core';
import { LoginService } from '../_core/services/login.service';
import { ItemmasterService } from '../_core/services/itemmaster.service';

@Directive({
  selector: '[appRolePermissions]'
})
export class RolePermissionsDirective {

  @Input() name: string;
  @Input() action: string;
  @Input() type: string;
  constructor(private el: ElementRef, private login: LoginService, private roleservice:ItemmasterService) { 
    this.login.roles().subscribe(data => {

      this.Roledata = data.body;

      if (this.Roledata[this.name]) {
     
        if (this.Roledata[this.name][this.action]) {
        
          this.show()
        }
   else if(this.Roledata[this.name][this.type])
    {
      this.show()
     }

        else {
          this.hide()
        }
      }

    })
  }


  Roledata: any;
  ngOnInit() {

  }


  show() {
    this.el.nativeElement.style.display = 'block'
  }


  hide() {
    this.el.nativeElement.disabled = true;

    // this.el.nativeElement.style.visibility = "hidden";
  }

}
