import { environment } from './../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';


import { DataStateChangeEventArgs, Sorts, DataResult } from '@syncfusion/ej2-angular-grids'
import { Observable } from 'rxjs';
import { Subject } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})
export class OrdersserviceService extends Subject<DataStateChangeEventArgs> {
   
apiUrl=environment.apiUrl
    constructor(private http: HttpClient) {
        super();
    }

    public execute(state: any, url: any): void {
        this.getData(state, url).subscribe(x => super.next(x));
    }

    protected getData(state, url: any): Observable<DataStateChangeEventArgs> {
        console.log(state)
       let pageQuery
    
        if(state.skip==0)
        {
        pageQuery = `page=${1}&per=${state.take}`;
      
        }else
        {
        pageQuery = `page=${((state.skip)/(state.take)+1)}&per=${state.take}`;
 
        }
     
        // let sortQuery: string =  `&orderby=itemcode`;
        let sortQuery: string =  `&orderby=itemcode`;
        let searchQuery=[];
        let whereQuery=[];

        if ((state.sorted || []).length) {
            sortQuery =`&orderby=`+ state.sorted.map((obj: Sorts) => {
                return obj.direction === 'descending' ? `${obj.name} desc` : obj.name;
            }).reverse().join(',');
        }
        if ((state.where || []).length) {
            // where clause
            // console.log(state.where[0]['predicates'])
        }
        if ((state.search || []).length) {
            // console.log(state.search[0])
            // searchQuery.push(state.search[0])
        }
        return this.http
            .post(`${this.apiUrl + url}${pageQuery}${sortQuery}${sortQuery}&filter=`,{})
            .map((response: any) => response)
            .pipe(map((response: any) => (<DataResult>{
                result: response['item_list'],
                count: (parseInt(response['item_count'][0].pagecount, 10)*state.take)
            })))
            .pipe((data: any) => data);
    }
}
