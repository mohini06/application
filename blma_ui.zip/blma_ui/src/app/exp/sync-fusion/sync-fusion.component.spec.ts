import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SyncFusionComponent } from './sync-fusion.component';

describe('SyncFusionComponent', () => {
  let component: SyncFusionComponent;
  let fixture: ComponentFixture<SyncFusionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SyncFusionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SyncFusionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
