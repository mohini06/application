import { TestBed } from '@angular/core/testing';

import { OrdersserviceService } from './ordersservice.service';

describe('OrdersserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: OrdersserviceService = TestBed.get(OrdersserviceService);
    expect(service).toBeTruthy();
  });
});
