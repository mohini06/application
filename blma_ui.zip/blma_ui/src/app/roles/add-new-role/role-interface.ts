export interface EditRolelist {
  roleid?:string;
  rolename?:string;
  effectivedate?: string;
  inactivedate?: string;
  }
export interface AttributesEntity {
  attributeid: number;
  attributevalue: string;
}
export interface AttributetableEntity {
  attributedataid: number;
  attributeid: number;
  attributevalue: string;
  rowno: number;
}
