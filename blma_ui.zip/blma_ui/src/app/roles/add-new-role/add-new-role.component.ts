import { GetGenericService } from './../../_core/services/get-generic.service';
import { PreferenceService } from './../../_core/services/preference.service';
import { Subject, of } from 'rxjs';
import { AlertService } from './../../_core/services/alert.service';
import { DataService } from './../../_core/services/data.service';


import { ItemmasterService } from '../../_core/services/itemmaster.service';
import { Component, OnInit, TemplateRef, Input, ViewChild, Output, EventEmitter, AfterViewInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BatchesService } from './../../_core/services/batches.service';
import { ChartdataService } from './../../_core/services/chartdata.service';
import { EditRolelist } from './role-interface';


@Component({
  selector: 'app-add-new-role',
  templateUrl: './add-new-role.component.html',
  styleUrls: ['./add-new-role.component.scss']
})
export class AddNewRoleComponent implements OnInit, AfterViewInit {
  private eventsSubject: Subject<void> = new Subject<void>();
  @Input() type: any;
  @Input() rowData: any;
  @Output() getGroupList = new EventEmitter<string>();
  @Output() createNew = new EventEmitter<string>();


  Charttype = ["lineBoxPlot", "Boxplot", "Control chart", "histogram"];
  parametertypeData: any;
  parameterstatusData: any;
  parameteruomData: any;
  parameterDatatype: any
  createRoleForm: FormGroup;
  sucess: string;
  error: string;
  parent = "parameter";
  detailsFlag: Boolean = false;
  editRoleData: EditRolelist = {};
  username: string;
  childData = "";
  formData = [];
  attributeData: any;
  formatedAttributeData = [];
  formatedAttributeTable = []
  tagData = [];
  formatedTagId = [];
  tableData = [];
  modalRef: BsModalRef;
  isSubmitted: boolean = false;
  dateFormate = ''
  public defaultDate = new Date()
  public dateTime = new Date()

  //Plotly Graph
  analysis: any;
  graphdata: any;


  constructor(private formBuilder: FormBuilder, private modalService: BsModalService,
    private parametermaster: ItemmasterService, private data: DataService,
    private batchesService: BatchesService, private alert: AlertService,
    private preference: PreferenceService, private getgeneric: GetGenericService, private Chartdata: ChartdataService) { }

  ngOnInit() {
    this.createRoleForm = this.formBuilder.group({
      rolename: ['', [Validators.required, Validators.pattern(".*\\S.*[a-zA-z0-9 ]")]],

      startdate: [this.defaultDate],
      enddate: [null],
      // parameterDatatype: [''],
      roleid: ['0'],

    });
    // this.enableVersion.value == true

    this.username = this.batchesService.getUserName();
    if (this.type == "edit") {
      this.setFormValue()
      this.childData = this.rowData.roleid
      this.formData = this.createRoleForm.value
      this.detailsFlag = true;
      // console.log(this.rowData)
      this.getAnalyticsData(this.rowData.roleid)
    }


    this.dateFormate = this.preference.getDateFormate()

  }

  get rolename() { return this.createRoleForm.get('rolename'); }

  get startdate() { return this.createRoleForm.get('startdate'); }

  get enddate() { return this.createRoleForm.get('enddate'); }
  get roleid() { return this.createRoleForm.get('roleid'); }



  emitEventToChild() {
    this.eventsSubject.next(this.createRoleForm.value)
  }

  setFormValue() {
    this.rolename.setValue(this.rowData.rolename)

    this.startdate.setValue(this.rowData.effectivedate)
    this.enddate.setValue(this.rowData.inactivedate)


    this.roleid.setValue(this.rowData.roleid)


  }



  effectivestartdate: any;
  onChangeeffective(args) {

    this.effectivestartdate = args.value;
  }

  effectiveenddate: any;
  onChangeeffectiveend(args) {

    this.effectiveenddate = args.value;
  }
  operationEditSave() {
    if (this.childData) {
      // console.log("edit")
      if (this.attributeData) {
        for (let i = 0; i < this.attributeData.attribute_data.length; i++) {
          this.formatedAttributeData.push({ 'attributeid': this.attributeData.attribute_data[i].attributeid, 'attributevalue': this.attributeData.attribute_data[i].attributevalue })

        }

        for (let i = 0; i < this.attributeData['attribute_grpsections'].length; i++) {

          if (this.attributeData['attribute_grpsections'][i].is_table) {
            // console.log(this.attributeData['attribute_datatables']['ag_'+this.attributeData['attribute_grpsections'][i].attributegroupid])
            for (let j = 0; j < this.attributeData['attribute_datatables']['ag_' + this.attributeData['attribute_grpsections'][i].attributegroupid].rows.length; j++) {
              // console.log( this.attributeData['attribute_datatables']['ag_'+this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j])

              for (let k = 0; k < this.attributeData['attribute_datatables']['ag_' + this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j].length; k++) {
                // console.log(this.attributeData['attribute_datatables']['ag_'+this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j][k])
                this.formatedAttributeTable.push(this.attributeData['attribute_datatables']['ag_' + this.attributeData['attribute_grpsections'][i].attributegroupid].rows[j][k])
              }
            }
          }
        }

      }
      else {
        this.formatedAttributeData = [];
      }
      //  all data
      this.editRoleData.roleid = this.childData
      this.editRoleData.rolename = this.rolename.value

      // this.editParameterSaveData.username = this.username;

      this.editRoleData.effectivedate = this.preference.setDateFormate(this.effectivestartdate)
      this.editRoleData.inactivedate = this.preference.setDateFormate(this.enddate.value)
      //   // this.editParameterSaveData.inactivedate = this.effectiveenddate

      // this.editParameterSaveData.attributes = this.formatedAttributeData;
      // this.editParameterSaveData.attributetable = this.formatedAttributeTable


      if (this.tagData) {
        for (let i = 0; i < this.tagData.length; i++) {
          this.formatedTagId.push({ 'id': this.tagData[i].tagid })
        }
      } else {
        this.formatedTagId = []
      }

      // this.editParameterSaveData.tags = this.formatedTagId;
      // console.log(this.formatedAttributeData)
      this.editRoleDetails(this.editRoleData)

    }
    else {
      // console.log("save")
      this.saveNewRole()
    }
  }



  saveNewRole() {
    this.alert.removeAlert();
    // if (this.enableVersion.value == "") {
    //   this.enableVersion.setValue(false)
    // }
    if (this.createRoleForm.invalid) {
      return
    }
    else {
      this.parametermaster.saveRole(this.createRoleForm.value).
        subscribe(data => {
          // console.log(data)
          if (data.role.STATUS == "SUCCESS") {

            this.detailsFlag = true;
            this.childData = data['role'].rows[0]['Inserted Row ID'];
            console.log(this.childData)
            // this.formData = this.parameterMasterNewForm.value
            this.getGroupList.emit(null)
            console.log(data)
            this.alert.success('Role Added Successfully')
          }
          else {
            this.alert.error(data.role.rows[0].MESSAGE)
          }

          // this.getAnalyticsData(data['item'].rows[0]['Inserted Row ID'])

          setTimeout(() => {
            this.alert.removeAlert();
            this.emitEventToChild()
          }, 1500);


        },
          error => {
            if (error.status == 409) {
              this.alert.error("Parameter name already exist")
            }
            this.alert.error(error.error.message)
          })

    }



  }

  editRoleDetails(data: any) {
    console.log(this.createRoleForm.value)
    console.log(data)

    // return;
    this.parametermaster.saveRole(data).
      subscribe(data => {

        this.emitEventToChild()
        this.alert.success("Successfully Saved")
        this.getGroupList.emit(null)
        setTimeout(() => {
          this.alert.removeAlert();
        }, 1500);
      },
        error => {
          this.alert.error("Parameter Name Already Exists")


        })
  }




  getAttributeDataParameter(data): void {
    // console.log(data)
    this.attributeData = data
  }

  getTagDataParameter(tagdata): void {
    this.tagData = tagdata
    // console.log(tagdata)
  }


  ngAfterViewInit() {
    this.emitEventToChild()
  }

  createNewTab() {
    this.createNew.emit(null)
    // console.log("new clicked")

  }
  config = {
    backdrop: true,
    ignoreBackdropClick: true
  };
  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);

  }
  openModalAudit(audithistory: TemplateRef<any>) {
    this.newParam(this.rowData.roleid, 'role')
    this.modalRef = this.modalService.show(audithistory, Object.assign({}, this.config, { class: 'gray modal-lg' }));

  }

  newParam(param: any, table: any) {
    this.data.changeParam({ message: param, table: table })
  }

  removeAlert() {
    this.alert.removeAlert();

  }

  labelsrequired = [];
  chartvalues = [];
  getAnalyticsData(roleid) {
    this.getgeneric.getParameterAnalysis(roleid).
      subscribe(data => {
        //  console.log(data)

        this.analysis = data.parameter_analysis;
        // alert(this.analysis[0].json_object_agg.analysis.labels)
        //     for(let i=0;i<this.analysis[0].json_object_agg.analysis.labels.length;i++)
        //       {
        // this.labelsrequired.push(this.analysis[0].json_object_agg.analysis.labels[i].substring(0,7));
        //       }

        this.chartvalues = this.Chartdata.getspecificchart(this.analysis[0].json_object_agg.analysis);
        // this.graphdata = [

        //   { x: this.analysis[0].json_object_agg.analysis.labels, y: this.analysis[0].json_object_agg.analysis.values, type: 'scatter', mode: 'lines+points', marker: { color: 'red' } },
        //   { x: this.analysis[0].json_object_agg.analysis.labels, y: this.analysis[0].json_object_agg.analysis.values, type: 'bar' },
        // ]
      },

        error => {
          console.log(error.error)

        })




  }

  getcharttype(value: any) {
    for (let i = 0; i < this.chartvalues.length; i++) {
      if (this.chartvalues[i].layout.title == value) {
        alert("found same")
      }
    }

  }




}



