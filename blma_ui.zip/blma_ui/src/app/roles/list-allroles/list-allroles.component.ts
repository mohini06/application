
import { TabDirective } from 'ngx-bootstrap/tabs';
import { PreferenceService } from '../../_core/services/preference.service';
import { Component, OnInit, ViewChild } from "@angular/core";
import { ClickEventArgs } from "@syncfusion/ej2-navigations";
import { DataManager, ODataAdaptor, WebApiAdaptor } from "@syncfusion/ej2-data";

import { DataStateChangeEventArgs } from '@syncfusion/ej2-grids';
import { Observable } from 'rxjs';
import {
  GridComponent,
  ToolbarItems,
  EditService,
  PageService,
  CommandColumnService,
  CommandModel,
  PageSettingsModel,
  ColumnMenuService,
  RowSelectEventArgs, FilterSettingsModel,IFilter
} from "@syncfusion/ej2-angular-grids";
import { ItemmasterService } from "./../../_core/services/itemmaster.service";
import { DataService } from './../../_core/services/data.service';



@Component({
  selector: 'app-list-allroles',
  templateUrl: './list-allroles.component.html',
  styleUrls: ['./list-allroles.component.scss'],
  providers: [EditService, PageService, CommandColumnService, ColumnMenuService]
})
export class ListAllrolesComponent implements OnInit {
  public data: Observable<DataStateChangeEventArgs>;
  public pageOptions: Object;
  public state: DataStateChangeEventArgs;
  public filterSettings: FilterSettingsModel;
  public editSettings: Object;
  public toolbarOptions: ToolbarItems[];
  public dTdata: any;
  public editparams: Object;
  public commands: CommandModel[];
  public initialPage: PageSettingsModel;
  public formatOptions: any;
  dateFormate:any;
  @ViewChild("grid", { static: false })
  public grid: GridComponent;
  public viewData;
  url: any
  public pageSizes: number[] = [10, 20, 100, 500, 1000];
  public pageSettings: Object;

  filter:IFilter;

  constructor(private itemList: ItemmasterService, private dataservice: DataService, private preference: PreferenceService) {

    this.data = itemList
  }
  Nodedata = [];
  toolbarClick(args: ClickEventArgs): void {
    if (args.item.id === "Grid_excelexport") {
      // 'Grid_excelexport' -> Grid component id + _ + toolbar item name
      this.grid.excelExport();
    }
  }
  ngOnInit() {
    this.url = "/generic/list"
    this.pageSettings = { pageCount: 10, pageSize: this.pageSizes[0], pageSizes: this.pageSizes };
    let state = { skip: 0, take: 10 };
    this.itemList.execute(state, this.url, 'role');

    this.filter={
      type:'Date'
    }

    this.filterSettings = { type: "Menu" };
    this.toolbarOptions = ["ExcelExport", "Search"];
    this.dateFormate = this.preference.getDateFormate();

    this.formatOptions = { type: 'date', format: this.dateFormate };

  }


  public dataStateChange(state: DataStateChangeEventArgs): void {
    // console.log(state)
    this.itemList.execute(state, this.url, "role");

  }

  refreshList() {
    let state = { skip: 0, take: 10 };
    this.itemList.execute(state, this.url, 'role');
  }


  getRowData(args: any): void {
    let data = this.grid.getRowInfo(args.target);
    this.viewData = data.rowData;
    this.addNewTab(data["rowData"], "edit");
  }

  // tabs
  tabs: any[] = [];

  addNewTab(rowdata: any, type: any): void {
    if (type == "new") {
      this.tabs.push({
        title: `Add New Role`,
        content: type,
        disabled: false,
        removable: true,
        active: true
      });
    } else if (type == "edit") {
      if (this.tabs.some(title => title.title === rowdata.rolename)) {
        for (let i = 0; i < this.tabs.length; i++) {
          if (this.tabs[i].title == rowdata.rolename) {
            this.tabs[i].active = true;
          }
        }
      } else {
        this.tabs.push({
          title: rowdata.rolename,
          content: type,
          disabled: false,
          removable: true,
          active: true
        });
      }
    }
  }
  removeTabHandler(tab: any): void {
    this.tabs.splice(this.tabs.indexOf(tab), 1);
    // console.log('Remove Tab handler');
  }


  onSelect(data: TabDirective): void {
    console.log(data.heading);
    console.log("calling")
  }






}
