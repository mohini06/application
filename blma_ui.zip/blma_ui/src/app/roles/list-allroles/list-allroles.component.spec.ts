import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListAllrolesComponent } from './list-allroles.component';

describe('ListAllrolesComponent', () => {
  let component: ListAllrolesComponent;
  let fixture: ComponentFixture<ListAllrolesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListAllrolesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListAllrolesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
