import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewRoleDetailComponent } from './view-role-detail.component';

describe('ViewRoleDetailComponent', () => {
  let component: ViewRoleDetailComponent;
  let fixture: ComponentFixture<ViewRoleDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewRoleDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewRoleDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
