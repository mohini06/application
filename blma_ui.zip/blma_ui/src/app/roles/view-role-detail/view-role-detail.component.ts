import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-role-detail',
  templateUrl: './view-role-detail.component.html',
  styleUrls: ['./view-role-detail.component.scss']
})
export class ViewRoleDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
