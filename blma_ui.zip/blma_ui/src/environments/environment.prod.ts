export const environment = {
  production: true,
  //QA Internal
  //  apiUrl: 'http://192.168.137.5:8990'
    // apiUrl: 'http://192.168.137.5:8990'

  //UAT External
  //  apiUrl: 'http://113.193.29.67:8988'
  //Dev External
 // apiUrl: 'http://113.193.29.67:8992'
  // apiUrl: 'http://113.193.29.67:8992'

//apiUrl:'http://localhost:8190'

};
