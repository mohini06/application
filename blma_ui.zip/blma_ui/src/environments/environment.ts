// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.


export const environment = {
  production: false,
  //Localhost
//   apUirl: 'http://localhost:8190'

  //QA
    apiUrl: 'http://192.168.137.5:8990'
  //  apiUrl: 'http://localhost:8190'

 
  //Prod External
  // apiUrl: 'http://113.193.29.67:8988'
  //Prod Internal
  // apiUrl: 'http://192.168.137.5:8988'

  //Dev
  // apiUrl: 'http://192.168.137.5:8992'

  // Dev External
    // apiUrl: 'http://113.193.29.67:8992'
  //python

  // apiUrl: 'http://192.168.137.5:8994'
};
