export const User = {
  username: 'user1',
  password: 'testing123',
  name: 'Alfonso'
};

export const Picture = {
  name: 'picture1',
  file: new File([''], 'picture1')
};
