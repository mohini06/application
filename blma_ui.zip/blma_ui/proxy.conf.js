const serverUrl = 'http://localhost:3000'

const PROXY_CONF = {
  "/api":{
    "target": serverUrl,
    "secure": false,
  }
}

module.exports = PROXY_CONF;